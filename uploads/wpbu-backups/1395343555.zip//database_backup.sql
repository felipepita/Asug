--
-- Table structure for table `wp_blc_filters`
--
DROP TABLE IF EXISTS `wp_blc_filters`;
CREATE TABLE `wp_blc_filters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_blc_filters`
--
LOCK TABLES `wp_blc_filters` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_blc_instances`
--
DROP TABLE IF EXISTS `wp_blc_instances`;
CREATE TABLE `wp_blc_instances` (
  `instance_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link_id` int(10) unsigned NOT NULL,
  `container_id` int(10) unsigned NOT NULL,
  `container_type` varchar(40) NOT NULL DEFAULT 'post',
  `link_text` varchar(250) NOT NULL DEFAULT '',
  `parser_type` varchar(40) NOT NULL DEFAULT 'link',
  `container_field` varchar(250) NOT NULL DEFAULT '',
  `link_context` varchar(250) NOT NULL DEFAULT '',
  `raw_url` text NOT NULL,
  PRIMARY KEY (`instance_id`),
  KEY `link_id` (`link_id`),
  KEY `source_id` (`container_type`,`container_id`),
  KEY `parser_type` (`parser_type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_blc_instances`
--
LOCK TABLES `wp_blc_instances` WRITE;
INSERT INTO `wp_blc_instances` VALUES ('1', '1', '1', 'comment', 'Sr. WordPress', 'url_field', 'comment_author_url', '', 'http://wordpress.org/'); 
INSERT INTO `wp_blc_instances` VALUES ('4', '2', '2', 'page', 'seu painel', 'link', 'post_content', '', 'http://127.0.0.1/asug/wp-admin/'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_blc_links`
--
DROP TABLE IF EXISTS `wp_blc_links`;
CREATE TABLE `wp_blc_links` (
  `link_id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` text CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `first_failure` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_check` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_success` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_check_attempt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `check_count` int(4) unsigned NOT NULL DEFAULT '0',
  `final_url` text CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `redirect_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `log` text NOT NULL,
  `http_code` smallint(6) NOT NULL DEFAULT '0',
  `status_code` varchar(100) DEFAULT '',
  `status_text` varchar(250) DEFAULT '',
  `request_duration` float NOT NULL DEFAULT '0',
  `timeout` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `broken` tinyint(1) NOT NULL DEFAULT '0',
  `may_recheck` tinyint(1) NOT NULL DEFAULT '1',
  `being_checked` tinyint(1) NOT NULL DEFAULT '0',
  `result_hash` varchar(200) NOT NULL DEFAULT '',
  `false_positive` tinyint(1) NOT NULL DEFAULT '0',
  `dismissed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`),
  KEY `url` (`url`(150)),
  KEY `final_url` (`final_url`(150)),
  KEY `http_code` (`http_code`),
  KEY `broken` (`broken`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_blc_links`
--
LOCK TABLES `wp_blc_links` WRITE;
INSERT INTO `wp_blc_links` VALUES ('1', 'http://wordpress.org/', '0000-00-00 00:00:00', '2014-03-18 22:37:19', '2014-03-18 22:37:19', '2014-03-18 22:37:19', '0', 'http://wordpress.org/', '0', '=== Código HTTP : 200 ===

HTTP/1.1 200 OK
Server: nginx
Date: Tue, 18 Mar 2014 22:37:19 GMT
Content-Type: text/html; charset=utf-8
Connection: keep-alive
Vary: Accept-Encoding
X-nc: HIT lax 250


O link é válido.', '200', '', '', '0.406', '0', '0', '1', '0', '200|0|0|8e73c6b5bc5ba66d98238874d1d08cfb', '0', '0'); 
INSERT INTO `wp_blc_links` VALUES ('2', 'http://127.0.0.1/asug/wp-admin/', '0000-00-00 00:00:00', '2014-03-18 22:37:20', '2014-03-18 22:37:20', '2014-03-18 22:37:20', '0', 'http://127.0.0.1/asug/wp-login.php?redirect_to=http%3A%2F%2F127.0.0.1%2Fasug%2Fwp-admin%2F&reauth=1', '1', '=== Código HTTP : 200 ===

HTTP/1.1 302 Found
Date: Tue, 18 Mar 2014 22:37:20 GMT
Server: Apache/2.4.7 (Win32) OpenSSL/0.9.8y PHP/5.4.22
X-Powered-By: PHP/5.4.22
Set-Cookie: PHPSESSID=7lpj9vp4q7i2j0fivape8v7he2; path=/
Expires: Wed, 11 Jan 1984 05:00:00 GMT
Cache-Control: no-cache, must-revalidate, max-age=0
Pragma: no-cache
X-CF-Powered-By: WP 1.3.13
Location: http://127.0.0.1/asug/wp-login.php?redirect_to=http%3A%2F%2F127.0.0.1%2Fasug%2Fwp-admin%2F&reauth=1
Content-Type: text/html

HTTP/1.1 200 OK
Date: Tue, 18 Mar 2014 22:37:27 GMT
Server: Apache/2.4.7 (Win32) OpenSSL/0.9.8y PHP/5.4.22
X-Powered-By: PHP/5.4.22
Set-Cookie: PHPSESSID=nhuh98hr4biq19a9jureo6blk3; path=/
Expires: Wed, 11 Jan 1984 05:00:00 GMT
Cache-Control: no-cache, must-revalidate, max-age=0
Pragma: no-cache
X-CF-Powered-By: WP 1.3.13
Set-Cookie: wordpress_test_cookie=WP+Cookie+check; path=/asug/
X-Frame-Options: SAMEORIGIN
Set-Cookie: wordpress_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/wp-admin
Set-Cookie: wordpress_sec_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/wp-admin
Set-Cookie: wordpress_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/wp-content/plugins
Set-Cookie: wordpress_sec_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/wp-content/plugins
Set-Cookie: wordpress_logged_in_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Set-Cookie: wordpress_logged_in_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Set-Cookie: wordpress_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Set-Cookie: wordpress_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Set-Cookie: wordpress_sec_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Set-Cookie: wordpress_sec_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Set-Cookie: wordpressuser_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Set-Cookie: wordpresspass_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Set-Cookie: wordpressuser_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Set-Cookie: wordpresspass_ecebd0e940afe458a00b5b9314c4c219=+; expires=Mon, 18-Mar-2013 22:37:29 GMT; path=/asug/
Content-Type: text/html; charset=UTF-8


O link é válido.', '200', '', '', '9.578', '0', '0', '1', '0', '200|0|0|8c33a872e990979eeb8f57054b843f07', '0', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_blc_synch`
--
DROP TABLE IF EXISTS `wp_blc_synch`;
CREATE TABLE `wp_blc_synch` (
  `container_id` int(20) unsigned NOT NULL,
  `container_type` varchar(40) NOT NULL,
  `synched` tinyint(2) unsigned NOT NULL,
  `last_synch` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`container_type`,`container_id`),
  KEY `synched` (`synched`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_blc_synch`
--
LOCK TABLES `wp_blc_synch` WRITE;
INSERT INTO `wp_blc_synch` VALUES ('1', 'comment', '1', '2014-03-15 13:08:59'); 
INSERT INTO `wp_blc_synch` VALUES ('2', 'page', '1', '2014-03-16 01:44:36'); 
INSERT INTO `wp_blc_synch` VALUES ('6', 'page', '1', '2014-03-15 13:34:47'); 
INSERT INTO `wp_blc_synch` VALUES ('8', 'page', '1', '2014-03-15 13:35:07'); 
INSERT INTO `wp_blc_synch` VALUES ('10', 'page', '1', '2014-03-15 13:35:36'); 
INSERT INTO `wp_blc_synch` VALUES ('12', 'page', '1', '2014-03-15 13:35:50'); 
INSERT INTO `wp_blc_synch` VALUES ('14', 'page', '1', '2014-03-15 13:36:04'); 
INSERT INTO `wp_blc_synch` VALUES ('16', 'page', '1', '2014-03-15 13:36:43'); 
INSERT INTO `wp_blc_synch` VALUES ('18', 'page', '1', '2014-03-15 13:37:08'); 
INSERT INTO `wp_blc_synch` VALUES ('20', 'page', '1', '2014-03-15 13:37:31'); 
INSERT INTO `wp_blc_synch` VALUES ('22', 'page', '1', '2014-03-15 13:37:46'); 
INSERT INTO `wp_blc_synch` VALUES ('35', 'page', '1', '2014-03-15 13:39:08'); 
INSERT INTO `wp_blc_synch` VALUES ('37', 'page', '1', '2014-03-20 12:40:35'); 
INSERT INTO `wp_blc_synch` VALUES ('39', 'page', '1', '2014-03-20 13:11:49'); 
INSERT INTO `wp_blc_synch` VALUES ('41', 'page', '1', '2014-03-20 12:40:35'); 
INSERT INTO `wp_blc_synch` VALUES ('43', 'page', '1', '2014-03-20 12:40:58'); 
INSERT INTO `wp_blc_synch` VALUES ('96', 'page', '1', '2014-03-18 22:29:36'); 
INSERT INTO `wp_blc_synch` VALUES ('97', 'page', '1', '2014-03-18 22:29:36'); 
INSERT INTO `wp_blc_synch` VALUES ('98', 'page', '1', '2014-03-18 22:29:36'); 
INSERT INTO `wp_blc_synch` VALUES ('99', 'page', '1', '2014-03-18 22:29:36'); 
INSERT INTO `wp_blc_synch` VALUES ('1', 'post', '1', '2014-03-16 20:45:43'); 
INSERT INTO `wp_blc_synch` VALUES ('90', 'post', '1', '2014-03-16 20:46:16'); 
INSERT INTO `wp_blc_synch` VALUES ('92', 'post', '1', '2014-03-16 20:46:43'); 
INSERT INTO `wp_blc_synch` VALUES ('94', 'post', '1', '2014-03-16 20:47:15'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_files`
--
DROP TABLE IF EXISTS `wp_bup_files`;
CREATE TABLE `wp_bup_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL,
  `date` datetime DEFAULT NULL,
  `download_limit` int(11) NOT NULL DEFAULT '0',
  `period_limit` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `type_id` smallint(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_files`
--
LOCK TABLES `wp_bup_files` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_bup_htmltype`
--
DROP TABLE IF EXISTS `wp_bup_htmltype`;
CREATE TABLE `wp_bup_htmltype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_htmltype`
--
LOCK TABLES `wp_bup_htmltype` WRITE;
INSERT INTO `wp_bup_htmltype` VALUES ('1', 'text', 'Text'); 
INSERT INTO `wp_bup_htmltype` VALUES ('2', 'password', 'Password'); 
INSERT INTO `wp_bup_htmltype` VALUES ('3', 'hidden', 'Hidden'); 
INSERT INTO `wp_bup_htmltype` VALUES ('4', 'checkbox', 'Checkbox'); 
INSERT INTO `wp_bup_htmltype` VALUES ('5', 'checkboxlist', 'Checkboxes'); 
INSERT INTO `wp_bup_htmltype` VALUES ('6', 'datepicker', 'Date Picker'); 
INSERT INTO `wp_bup_htmltype` VALUES ('7', 'submit', 'Button'); 
INSERT INTO `wp_bup_htmltype` VALUES ('8', 'img', 'Image'); 
INSERT INTO `wp_bup_htmltype` VALUES ('9', 'selectbox', 'Drop Down'); 
INSERT INTO `wp_bup_htmltype` VALUES ('10', 'radiobuttons', 'Radio Buttons'); 
INSERT INTO `wp_bup_htmltype` VALUES ('11', 'countryList', 'Countries List'); 
INSERT INTO `wp_bup_htmltype` VALUES ('12', 'selectlist', 'List'); 
INSERT INTO `wp_bup_htmltype` VALUES ('13', 'countryListMultiple', 'Country List with posibility to select multiple countries'); 
INSERT INTO `wp_bup_htmltype` VALUES ('14', 'block', 'Will show only value as text'); 
INSERT INTO `wp_bup_htmltype` VALUES ('15', 'statesList', 'States List'); 
INSERT INTO `wp_bup_htmltype` VALUES ('16', 'textFieldsDynamicTable', 'Dynamic table - multiple text options set'); 
INSERT INTO `wp_bup_htmltype` VALUES ('17', 'textarea', 'Textarea'); 
INSERT INTO `wp_bup_htmltype` VALUES ('18', 'checkboxHiddenVal', 'Checkbox with Hidden field'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_log`
--
DROP TABLE IF EXISTS `wp_bup_log`;
CREATE TABLE `wp_bup_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL,
  `data` text,
  `date_created` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_log`
--
LOCK TABLES `wp_bup_log` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_bup_modules`
--
DROP TABLE IF EXISTS `wp_bup_modules`;
CREATE TABLE `wp_bup_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `type_id` smallint(3) NOT NULL DEFAULT '0',
  `params` text,
  `has_tab` tinyint(1) NOT NULL DEFAULT '0',
  `label` varchar(128) DEFAULT NULL,
  `description` text,
  `ex_plug_dir` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_modules`
--
LOCK TABLES `wp_bup_modules` WRITE;
INSERT INTO `wp_bup_modules` VALUES ('1', 'adminmenu', '1', '1', '', '0', 'Admin Menu', '', ''); 
INSERT INTO `wp_bup_modules` VALUES ('2', 'options', '1', '1', '', '1', 'Options', '', ''); 
INSERT INTO `wp_bup_modules` VALUES ('3', 'log', '1', '1', '', '1', 'Log', 'Internal system module to log some actions on server', ''); 
INSERT INTO `wp_bup_modules` VALUES ('4', 'templates', '1', '1', '', '0', 'Templates for Plugin', '', ''); 
INSERT INTO `wp_bup_modules` VALUES ('5', 'backup', '1', '1', '', '1', 'Backup ready!', 'Backup ready!', ''); 
INSERT INTO `wp_bup_modules` VALUES ('6', 'schedule', '1', '1', '', '1', 'Schedule', 'Schedule', ''); 
INSERT INTO `wp_bup_modules` VALUES ('7', 'storage', '1', '1', '', '1', 'Storage', 'Storage', ''); 
INSERT INTO `wp_bup_modules` VALUES ('8', 'promo_ready', '1', '1', '', '0', 'Promo ready', '', ''); 
INSERT INTO `wp_bup_modules` VALUES ('9', 'logger', '1', '1', '', '0', 'System logger', '', ''); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_modules_type`
--
DROP TABLE IF EXISTS `wp_bup_modules_type`;
CREATE TABLE `wp_bup_modules_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_modules_type`
--
LOCK TABLES `wp_bup_modules_type` WRITE;
INSERT INTO `wp_bup_modules_type` VALUES ('1', 'system'); 
INSERT INTO `wp_bup_modules_type` VALUES ('2', 'addons'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_options`
--
DROP TABLE IF EXISTS `wp_bup_options`;
CREATE TABLE `wp_bup_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(64) CHARACTER SET latin1 NOT NULL,
  `value` longtext,
  `label` varchar(128) CHARACTER SET latin1 DEFAULT NULL,
  `description` text CHARACTER SET latin1,
  `htmltype_id` smallint(2) NOT NULL DEFAULT '1',
  `params` text,
  `cat_id` mediumint(3) DEFAULT '0',
  `sort_order` mediumint(3) DEFAULT '0',
  `value_type` varchar(16) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_options`
--
LOCK TABLES `wp_bup_options` WRITE;
INSERT INTO `wp_bup_options` VALUES ('1', 'full', '1', 'Full backup', 'on/off full backup', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('2', 'plugins', '0', 'Plugins', 'on/off backup plugins', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('3', 'themes', '0', 'Themes', 'on/off backup themes', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('4', 'uploads', '0', 'Uploads', 'on/off backup uploads', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('5', 'database', '0', 'Database', 'on/off backup database', '1', '', '0', '0', 'db_backup'); 
INSERT INTO `wp_bup_options` VALUES ('6', 'any_directories', '0', 'Any', 'Any other directories found inside wp-content', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('7', 'warehouse', '/wp-content/upready/', 'Warehouse', 'path to storage', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('8', 'warehouse_ignore', 'upready', 'Warehouse_ignore', 'Name ignore directory storage', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('9', 'safe_array', '', 'Safe array', 'Safe file array', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('10', 'count_folder', '', 'Count folder', 'Count folder', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('11', 'exclude', 'upgrade,cache', 'Exclude', 'Exclude directories', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('12', 'sch_enable', '0', 'Enable shedule', 'Enable shedule', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('13', 'sch_every_hour', '0', 'Schedule every hour', 'Schedule every hour', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('14', 'sch_every_day', '0', 'Schedule every day', 'Schedule every day', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('15', 'sch_every_day_twice', '0', 'Schedule every day twice', 'Schedule every day twice', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('16', 'sch_every_week', '0', 'Schedule every week', 'Schedule every week', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('17', 'sch_every_month', '0', 'Schedule every month', 'Schedule every month', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('18', 'sch_time', 'a:1:{i:1;i:0;}', 'Schedule time backup', 'Schedule time backup', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('19', 'sch_dest', '1', 'Destination backup', 'Destination backup', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('20', 'email', '', 'Email', 'Email', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('21', 'glb_dest', 'ftp', 'Manual destination', 'Manual destination', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('22', 'force_update', '0', 'Force Update', 'Force Update', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('23', 'safe_update', '1', 'Safe Update', 'Safe Update', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('24', 'replace_newer', '1', 'Replace Newer', 'Replace newer files or not', '1', '', '0', '0', ''); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_options_categories`
--
DROP TABLE IF EXISTS `wp_bup_options_categories`;
CREATE TABLE `wp_bup_options_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_options_categories`
--
LOCK TABLES `wp_bup_options_categories` WRITE;
INSERT INTO `wp_bup_options_categories` VALUES ('1', 'General'); 
INSERT INTO `wp_bup_options_categories` VALUES ('2', 'Template'); 
INSERT INTO `wp_bup_options_categories` VALUES ('3', 'Subscribe'); 
INSERT INTO `wp_bup_options_categories` VALUES ('4', 'Social'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bwps_lockouts`
--
DROP TABLE IF EXISTS `wp_bwps_lockouts`;
CREATE TABLE `wp_bwps_lockouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL,
  `active` int(1) NOT NULL,
  `starttime` int(10) NOT NULL,
  `exptime` int(10) NOT NULL,
  `host` varchar(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_bwps_lockouts`
--
LOCK TABLES `wp_bwps_lockouts` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_bwps_log`
--
DROP TABLE IF EXISTS `wp_bwps_log`;
CREATE TABLE `wp_bwps_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) NOT NULL,
  `timestamp` int(10) NOT NULL,
  `host` varchar(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `mem_used` varchar(255) DEFAULT NULL,
  `referrer` varchar(255) DEFAULT NULL,
  `data` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_bwps_log`
--
LOCK TABLES `wp_bwps_log` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_commentmeta`
--
DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_commentmeta`
--
LOCK TABLES `wp_commentmeta` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_comments`
--
DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_comments`
--
LOCK TABLES `wp_comments` WRITE;
INSERT INTO `wp_comments` VALUES ('1', '1', 'Sr. WordPress', '', 'http://wordpress.org/', '', '2014-03-15 15:51:25', '2014-03-15 15:51:25', 'Olá, Isto é um comentário.
Para excluir um comentário, faça o login e veja os comentários de posts. Lá você terá a opção de editá-los ou excluí-los.', '0', '1', '', '', '0', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_em_bookings`
--
DROP TABLE IF EXISTS `wp_em_bookings`;
CREATE TABLE `wp_em_bookings` (
  `booking_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `person_id` bigint(20) unsigned NOT NULL,
  `booking_spaces` int(5) NOT NULL,
  `booking_comment` text,
  `booking_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `booking_status` tinyint(1) NOT NULL DEFAULT '1',
  `booking_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `booking_tax_rate` decimal(5,2) DEFAULT NULL,
  `booking_taxes` decimal(10,2) DEFAULT NULL,
  `booking_meta` longtext,
  PRIMARY KEY (`booking_id`),
  KEY `event_id` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_em_bookings`
--
LOCK TABLES `wp_em_bookings` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_em_events`
--
DROP TABLE IF EXISTS `wp_em_events`;
CREATE TABLE `wp_em_events` (
  `event_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `event_slug` varchar(200) DEFAULT NULL,
  `event_owner` bigint(20) unsigned DEFAULT NULL,
  `event_status` int(1) DEFAULT NULL,
  `event_name` text,
  `event_start_time` time DEFAULT NULL,
  `event_end_time` time DEFAULT NULL,
  `event_all_day` int(1) DEFAULT NULL,
  `event_start_date` date DEFAULT NULL,
  `event_end_date` date DEFAULT NULL,
  `post_content` longtext,
  `event_rsvp` tinyint(1) NOT NULL DEFAULT '0',
  `event_rsvp_date` date DEFAULT NULL,
  `event_rsvp_time` time DEFAULT NULL,
  `event_rsvp_spaces` int(5) DEFAULT NULL,
  `event_spaces` int(5) DEFAULT '0',
  `event_private` tinyint(1) NOT NULL DEFAULT '0',
  `location_id` bigint(20) unsigned DEFAULT NULL,
  `recurrence_id` bigint(20) unsigned DEFAULT NULL,
  `event_category_id` bigint(20) unsigned DEFAULT NULL,
  `event_attributes` text,
  `event_date_created` datetime DEFAULT NULL,
  `event_date_modified` datetime DEFAULT NULL,
  `recurrence` tinyint(1) NOT NULL DEFAULT '0',
  `recurrence_interval` int(4) DEFAULT NULL,
  `recurrence_freq` tinytext,
  `recurrence_byday` tinytext,
  `recurrence_byweekno` int(4) DEFAULT NULL,
  `recurrence_days` int(4) DEFAULT NULL,
  `blog_id` bigint(20) unsigned DEFAULT NULL,
  `group_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `event_status` (`event_status`),
  KEY `post_id` (`post_id`),
  KEY `blog_id` (`blog_id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_em_events`
--
LOCK TABLES `wp_em_events` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_em_locations`
--
DROP TABLE IF EXISTS `wp_em_locations`;
CREATE TABLE `wp_em_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `blog_id` bigint(20) unsigned DEFAULT NULL,
  `location_slug` varchar(200) DEFAULT NULL,
  `location_name` text,
  `location_owner` bigint(20) unsigned NOT NULL DEFAULT '0',
  `location_address` varchar(200) DEFAULT NULL,
  `location_town` varchar(200) DEFAULT NULL,
  `location_state` varchar(200) DEFAULT NULL,
  `location_postcode` varchar(10) DEFAULT NULL,
  `location_region` varchar(200) DEFAULT NULL,
  `location_country` char(2) DEFAULT NULL,
  `location_latitude` float(10,6) DEFAULT NULL,
  `location_longitude` float(10,6) DEFAULT NULL,
  `post_content` longtext,
  `location_status` int(1) DEFAULT NULL,
  `location_private` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`location_id`),
  KEY `location_state` (`location_state`),
  KEY `location_region` (`location_region`),
  KEY `location_country` (`location_country`),
  KEY `post_id` (`post_id`),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_em_locations`
--
LOCK TABLES `wp_em_locations` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_em_meta`
--
DROP TABLE IF EXISTS `wp_em_meta`;
CREATE TABLE `wp_em_meta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  `meta_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`meta_id`),
  KEY `object_id` (`object_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_em_meta`
--
LOCK TABLES `wp_em_meta` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_em_tickets`
--
DROP TABLE IF EXISTS `wp_em_tickets`;
CREATE TABLE `wp_em_tickets` (
  `ticket_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `ticket_name` tinytext NOT NULL,
  `ticket_description` text,
  `ticket_price` decimal(10,2) DEFAULT NULL,
  `ticket_start` datetime DEFAULT NULL,
  `ticket_end` datetime DEFAULT NULL,
  `ticket_min` int(10) DEFAULT NULL,
  `ticket_max` int(10) DEFAULT NULL,
  `ticket_spaces` int(11) DEFAULT NULL,
  `ticket_members` int(1) DEFAULT NULL,
  `ticket_members_roles` longtext,
  `ticket_guests` int(1) DEFAULT NULL,
  `ticket_required` int(1) DEFAULT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `event_id` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_em_tickets`
--
LOCK TABLES `wp_em_tickets` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_em_tickets_bookings`
--
DROP TABLE IF EXISTS `wp_em_tickets_bookings`;
CREATE TABLE `wp_em_tickets_bookings` (
  `ticket_booking_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) unsigned NOT NULL,
  `ticket_id` bigint(20) unsigned NOT NULL,
  `ticket_booking_spaces` int(6) NOT NULL,
  `ticket_booking_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ticket_booking_id`),
  KEY `booking_id` (`booking_id`),
  KEY `ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_em_tickets_bookings`
--
LOCK TABLES `wp_em_tickets_bookings` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_ewwwio_images`
--
DROP TABLE IF EXISTS `wp_ewwwio_images`;
CREATE TABLE `wp_ewwwio_images` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  `image_md5` varchar(55) DEFAULT NULL,
  `results` varchar(55) NOT NULL,
  `gallery` varchar(30) DEFAULT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_ewwwio_images`
--
LOCK TABLES `wp_ewwwio_images` WRITE;
INSERT INTO `wp_ewwwio_images` VALUES ('1', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/asug-brasil-150x76.jpg', '', 'No savings', '', '5539', '5539'); 
INSERT INTO `wp_ewwwio_images` VALUES ('2', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/asug-brasil.jpg', '', 'No savings', '', '7992', '7992'); 
INSERT INTO `wp_ewwwio_images` VALUES ('3', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/slider-150x150.jpg', '', 'No savings', '', '8444', '8444'); 
INSERT INTO `wp_ewwwio_images` VALUES ('4', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/slider-300x138.jpg', '', 'No savings', '', '14952', '14952'); 
INSERT INTO `wp_ewwwio_images` VALUES ('5', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/slider.jpg', '', 'No savings', '', '43712', '43712'); 
INSERT INTO `wp_ewwwio_images` VALUES ('6', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/banner03-150x121.jpg', '', 'No savings', '', '6771', '6771'); 
INSERT INTO `wp_ewwwio_images` VALUES ('7', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/banner03.jpg', '', 'No savings', '', '28264', '28264'); 
INSERT INTO `wp_ewwwio_images` VALUES ('8', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/banner04-150x121.jpg', '', 'No savings', '', '9955', '9955'); 
INSERT INTO `wp_ewwwio_images` VALUES ('9', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/banner04.jpg', '', 'No savings', '', '37298', '37298'); 
INSERT INTO `wp_ewwwio_images` VALUES ('10', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/banner01-150x122.jpg', '', 'No savings', '', '8160', '8160'); 
INSERT INTO `wp_ewwwio_images` VALUES ('11', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/banner01.jpg', '', 'No savings', '', '30840', '30840'); 
INSERT INTO `wp_ewwwio_images` VALUES ('12', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/banner02-150x122.jpg', '', 'No savings', '', '9855', '9855'); 
INSERT INTO `wp_ewwwio_images` VALUES ('13', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/banner02.jpg', '', 'No savings', '', '37694', '37694'); 
INSERT INTO `wp_ewwwio_images` VALUES ('14', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/eventos01.jpg', '', 'No savings', '', '7911', '7911'); 
INSERT INTO `wp_ewwwio_images` VALUES ('15', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/eventos02.jpg', '', 'No savings', '', '8019', '8019'); 
INSERT INTO `wp_ewwwio_images` VALUES ('16', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/eventos011.jpg', '', 'No savings', '', '7911', '7911'); 
INSERT INTO `wp_ewwwio_images` VALUES ('17', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/eventos021.jpg', '', 'No savings', '', '8019', '8019'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_links`
--
DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_links`
--
LOCK TABLES `wp_links` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_communications`
--
DROP TABLE IF EXISTS `wp_m_communications`;
CREATE TABLE `wp_m_communications` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) DEFAULT NULL,
  `message` text,
  `periodunit` int(11) DEFAULT NULL,
  `periodtype` varchar(5) DEFAULT NULL,
  `periodprepost` varchar(5) DEFAULT NULL,
  `lastupdated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `active` int(11) DEFAULT '0',
  `periodstamp` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_communications`
--
LOCK TABLES `wp_m_communications` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_coupons`
--
DROP TABLE IF EXISTS `wp_m_coupons`;
CREATE TABLE `wp_m_coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) DEFAULT '0',
  `couponcode` varchar(250) DEFAULT NULL,
  `discount` decimal(11,2) DEFAULT '0.00',
  `discount_type` varchar(5) DEFAULT NULL,
  `discount_currency` varchar(5) DEFAULT NULL,
  `coupon_startdate` datetime DEFAULT NULL,
  `coupon_enddate` datetime DEFAULT NULL,
  `coupon_sub_id` bigint(20) DEFAULT '0',
  `coupon_uses` int(11) DEFAULT '0',
  `coupon_used` int(11) DEFAULT '0',
  `coupon_apply_to` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `couponcode` (`couponcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_coupons`
--
LOCK TABLES `wp_m_coupons` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_levelmeta`
--
DROP TABLE IF EXISTS `wp_m_levelmeta`;
CREATE TABLE `wp_m_levelmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_id` bigint(20) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_value` text,
  `meta_stamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `level_id` (`level_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_levelmeta`
--
LOCK TABLES `wp_m_levelmeta` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_member_payments`
--
DROP TABLE IF EXISTS `wp_m_member_payments`;
CREATE TABLE `wp_m_member_payments` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `member_id` bigint(20) DEFAULT NULL,
  `sub_id` bigint(20) DEFAULT NULL,
  `level_id` bigint(20) DEFAULT NULL,
  `level_order` int(11) DEFAULT NULL,
  `paymentmade` datetime DEFAULT NULL,
  `paymentexpires` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_member_payments`
--
LOCK TABLES `wp_m_member_payments` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_membership_levels`
--
DROP TABLE IF EXISTS `wp_m_membership_levels`;
CREATE TABLE `wp_m_membership_levels` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_title` varchar(250) DEFAULT NULL,
  `level_slug` varchar(250) DEFAULT NULL,
  `level_active` int(11) DEFAULT '0',
  `level_count` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_membership_levels`
--
LOCK TABLES `wp_m_membership_levels` WRITE;
INSERT INTO `wp_m_membership_levels` VALUES ('1', 'assinantes', 'assinantes', '1', '0'); 
INSERT INTO `wp_m_membership_levels` VALUES ('2', 'Visitors', 'visitors', '1', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_membership_news`
--
DROP TABLE IF EXISTS `wp_m_membership_news`;
CREATE TABLE `wp_m_membership_news` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `newsitem` text,
  `newsdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_membership_news`
--
LOCK TABLES `wp_m_membership_news` WRITE;
INSERT INTO `wp_m_membership_news` VALUES ('1', '<strong>pita</strong> has joined level <strong>assinantes</strong> on subscription <strong>assinantes</strong>', '2014-03-20 02:31:41'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_membership_relationships`
--
DROP TABLE IF EXISTS `wp_m_membership_relationships`;
CREATE TABLE `wp_m_membership_relationships` (
  `rel_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT '0',
  `sub_id` bigint(20) DEFAULT '0',
  `level_id` bigint(20) DEFAULT '0',
  `startdate` datetime DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `order_instance` bigint(20) DEFAULT '0',
  `usinggateway` varchar(50) DEFAULT 'admin',
  PRIMARY KEY (`rel_id`),
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  KEY `usinggateway` (`usinggateway`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_membership_relationships`
--
LOCK TABLES `wp_m_membership_relationships` WRITE;
INSERT INTO `wp_m_membership_relationships` VALUES ('1', '2', '1', '1', '2014-03-20 02:31:41', '2014-03-20 02:31:41', '2015-03-20 02:31:41', '1', 'admin'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_membership_rules`
--
DROP TABLE IF EXISTS `wp_m_membership_rules`;
CREATE TABLE `wp_m_membership_rules` (
  `level_id` bigint(20) NOT NULL DEFAULT '0',
  `rule_ive` varchar(20) NOT NULL DEFAULT '',
  `rule_area` varchar(20) NOT NULL DEFAULT '',
  `rule_value` text,
  `rule_order` int(11) DEFAULT '0',
  PRIMARY KEY (`level_id`,`rule_ive`,`rule_area`),
  KEY `rule_area` (`rule_area`),
  KEY `rule_ive` (`rule_ive`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_membership_rules`
--
LOCK TABLES `wp_m_membership_rules` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_ping_history`
--
DROP TABLE IF EXISTS `wp_m_ping_history`;
CREATE TABLE `wp_m_ping_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ping_id` bigint(20) DEFAULT NULL,
  `ping_sent` timestamp NULL DEFAULT NULL,
  `ping_info` text,
  `ping_return` text,
  PRIMARY KEY (`id`),
  KEY `ping_id` (`ping_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_ping_history`
--
LOCK TABLES `wp_m_ping_history` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_pings`
--
DROP TABLE IF EXISTS `wp_m_pings`;
CREATE TABLE `wp_m_pings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pingname` varchar(250) DEFAULT NULL,
  `pingurl` varchar(250) DEFAULT NULL,
  `pinginfo` text,
  `pingtype` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_pings`
--
LOCK TABLES `wp_m_pings` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_subscription_transaction`
--
DROP TABLE IF EXISTS `wp_m_subscription_transaction`;
CREATE TABLE `wp_m_subscription_transaction` (
  `transaction_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_subscription_ID` bigint(20) NOT NULL DEFAULT '0',
  `transaction_user_ID` bigint(20) NOT NULL DEFAULT '0',
  `transaction_sub_ID` bigint(20) DEFAULT '0',
  `transaction_paypal_ID` varchar(30) DEFAULT NULL,
  `transaction_payment_type` varchar(20) DEFAULT NULL,
  `transaction_stamp` bigint(35) NOT NULL DEFAULT '0',
  `transaction_total_amount` bigint(20) DEFAULT NULL,
  `transaction_currency` varchar(35) DEFAULT NULL,
  `transaction_status` varchar(35) DEFAULT NULL,
  `transaction_duedate` date DEFAULT NULL,
  `transaction_gateway` varchar(50) DEFAULT NULL,
  `transaction_note` text,
  `transaction_expires` datetime DEFAULT NULL,
  PRIMARY KEY (`transaction_ID`),
  KEY `transaction_gateway` (`transaction_gateway`),
  KEY `transaction_subscription_ID` (`transaction_subscription_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_subscription_transaction`
--
LOCK TABLES `wp_m_subscription_transaction` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_subscriptionmeta`
--
DROP TABLE IF EXISTS `wp_m_subscriptionmeta`;
CREATE TABLE `wp_m_subscriptionmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub_id` bigint(20) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_value` text,
  `meta_stamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_id` (`sub_id`,`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_subscriptionmeta`
--
LOCK TABLES `wp_m_subscriptionmeta` WRITE;
INSERT INTO `wp_m_subscriptionmeta` VALUES ('1', '1', 'joining_ping', '', ''); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('2', '1', 'leaving_ping', '', ''); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_subscriptions`
--
DROP TABLE IF EXISTS `wp_m_subscriptions`;
CREATE TABLE `wp_m_subscriptions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(200) DEFAULT NULL,
  `sub_active` int(11) DEFAULT '0',
  `sub_public` int(11) DEFAULT '0',
  `sub_count` bigint(20) DEFAULT '0',
  `sub_description` text,
  `sub_pricetext` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_subscriptions`
--
LOCK TABLES `wp_m_subscriptions` WRITE;
INSERT INTO `wp_m_subscriptions` VALUES ('1', 'assinantes', '1', '1', '0', '', ''); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_subscriptions_levels`
--
DROP TABLE IF EXISTS `wp_m_subscriptions_levels`;
CREATE TABLE `wp_m_subscriptions_levels` (
  `sub_id` bigint(20) DEFAULT NULL,
  `level_id` bigint(20) DEFAULT NULL,
  `level_period` int(11) DEFAULT NULL,
  `sub_type` varchar(20) DEFAULT NULL,
  `level_price` decimal(11,2) DEFAULT '0.00',
  `level_currency` varchar(5) DEFAULT NULL,
  `level_order` bigint(20) DEFAULT '0',
  `level_period_unit` varchar(1) DEFAULT 'd',
  KEY `sub_id` (`sub_id`),
  KEY `level_id` (`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_subscriptions_levels`
--
LOCK TABLES `wp_m_subscriptions_levels` WRITE;
INSERT INTO `wp_m_subscriptions_levels` VALUES ('1', '1', '1', 'finite', '1800.00', '', '1', 'y'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_urlgroups`
--
DROP TABLE IF EXISTS `wp_m_urlgroups`;
CREATE TABLE `wp_m_urlgroups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(250) DEFAULT NULL,
  `groupurls` text,
  `isregexp` int(11) DEFAULT '0',
  `stripquerystring` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_urlgroups`
--
LOCK TABLES `wp_m_urlgroups` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_nextend_smartslider_layouts`
--
DROP TABLE IF EXISTS `wp_nextend_smartslider_layouts`;
CREATE TABLE `wp_nextend_smartslider_layouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `slide` longtext,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_nextend_smartslider_layouts`
--
LOCK TABLES `wp_nextend_smartslider_layouts` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_nextend_smartslider_sliders`
--
DROP TABLE IF EXISTS `wp_nextend_smartslider_sliders`;
CREATE TABLE `wp_nextend_smartslider_sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `params` text NOT NULL,
  `generator` text NOT NULL,
  `slide` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_nextend_smartslider_sliders`
--
LOCK TABLES `wp_nextend_smartslider_sliders` WRITE;
INSERT INTO `wp_nextend_smartslider_sliders` VALUES ('2', 'Slide Home', 'simple', '{"size":"542|*|250|*|1","responsive":"1|*|0","globalfontsize":"12|*|16|*|20","margin":"0|*|0|*|0|*|0|*|px","simplebackgroundimage":"","simplebackgroundimagesize":"auto","simplepadding":"0|*|0|*|0|*|0","simpleborder":"0|*|3E3E3Eff","simpleborderradius":"0|*|0|*|0|*|0","simpleresponsivemaxwidth":"3000","improvedtouch":"horizontal","simpleskins":"","simpleslidercss":"","simpleanimation":"horizontal","simpleanimationproperties":"800|*|0|*|easeInOutQuad|*|1","simplebackgroundanimation":"0|*|bars||blocks","fadeonload":"1|*|0","playfirstlayer":"0","mainafterout":"0","inaftermain":"1","controls":"0|*|horizontal|*|0","blockrightclick":"0","randomize":"0","autoplay":"1|*|8000","autoplayfinish":"0|*|loop|*|current","stopautoplay":"1|*|1|*|1","resumeautoplay":"0|*|1|*|0","widgetarrow":"transition","widgetarrowdisplay":"1|*|always|*|0|*|0","previousposition":"left|*|0|*|%|*|top|*|height\/2-previousheight\/2|*|%","previous":"plugins\/nextendsliderwidgetarrow\/transition\/transition\/previous\/my-test.png","nextposition":"right|*|0|*|%|*|top|*|height\/2-nextheight\/2|*|%","next":"plugins\/nextendsliderwidgetarrow\/transition\/transition\/next\/my-test.png","arrowbackground":"00000080","arrowbackgroundhover":"7670c7ff","widgetbullet":"numbers","widgetbulletdisplay":"1|*|always|*|0|*|0","bulletposition":"left|*|0|*|%|*|bottom|*|5|*|%","bulletwidth":"100%","bulletorientation":"horizontal","bulletalign":"center","bullet":"plugins\/nextendsliderwidgetbullet\/numbers\/numbers\/bullets\/square.png","bulletbackground":"00000060","bulletbackgroundhover":"7670C7ff","fontclassnumber":"sliderfont7","bulletbar":"none","bulletshadow":"none","bulletbarcolor":"00000060","bullethumbnail":"0|*|top","thumbnailsizebullet":"100|*|60","bulletthumbnail":"00000060","widgetautoplay":"image","widgetautoplaydisplay":"0|*|always|*|0|*|0","autoplayimageposition":"left|*|0|*|%|*|top|*|50|*|%","autoplayimage":"plugins\/nextendsliderwidgetautoplay\/image\/image\/play\/cream-button-minii.png","widgetindicator":"pie","widgetindicatordisplay":"0|*|always|*|0|*|0","indicatorposition":"right|*|5|*|%|*|top|*|5|*|%","indicatorskin":"plugins\/nextendsliderwidgetindicator\/pie\/pie\/pie\/default.png","indicatorcolor":"ffffffff|*|00000080","indicatorsize":"25","indicatorthickness":"0.5","indicatorlinecap":"butt","widgetbar":"colored","widgetbardisplay":"0|*|always|*|0|*|0","barcoloredposition":"left|*|0|*|%|*|top|*|0|*|%","barcolored":"plugins\/nextendsliderwidgetbar\/colored\/colored\/colored\/colored.png","barcoloredwidth":"200","barcoloredpadding":"1","barcoloredborderradius":"0|*|0|*|0|*|0","barcoloredtitlefont":"sliderfont5","barcoloreddescriptionfont":"sliderfont7","barbackground":"00000080","widgetthumbnail":"gallery","widgetthumbnaildisplay":"0|*|always|*|0|*|0","thumbnailgalleryposition":"left|*|0|*|%|*|bottom|*|0|*|px","thumbnailgalleryoutersize":"100%|*|auto","thumbnailgallerypadding":"5|*|5|*|5|*|5","thumbnailgalleryborderradius":"0|*|0|*|0|*|0","thumbnailgallerybackground":"EEEEEEFF","thumbnailgallerysize":"100|*|60","thumbnailgallerymargin":"0|*|1|*|1|*|0","thumbnail":"plugins\/nextendsliderwidgetthumbnail\/gallery\/gallery\/thumbnails\/aligncenter.png","widgetshadow":"shadow","widgetshadowdisplay":"0|*|always|*|0|*|0","shadowposition":"left|*|0|*|%|*|top|*|height|*|%","shadowwidth":"width","shadowcss":"","widgethtml":"html","widgethtmldisplay":"0|*|always|*|0|*|0","htmlposition":"left|*|0|*|px|*|top|*|0|*|px","widgethtmlcontent":"","widgets":"arrow","backgroundresize":"cover"}', '{"enabled":"1","cachetime":"1","generateslides":"1000|*|1|*|1","generatorgroup":"1","images":"{\"0\":{\"image\":\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\",\"title\":\"slider\",\"url\":\"\",\"description\":\"\"},\"1\":{\"image\":\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\",\"title\":\"slider\",\"url\":\"\",\"description\":\"\"},\"2\":{\"image\":\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\",\"title\":\"slider\",\"url\":\"\",\"description\":\"\"}}","source":"imagefromfolder_quickimage"}', '{"title":"{|title-1|}","description":"{|description-1|}","published":"1","publishdates":"|*|","thumbnail":"{|thumbnail-1|}","background":"00000000|*|{|image-1|}","link":"{|url-1|}|*|_self","slide":"","adminmode":"all"}'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_nextend_smartslider_slides`
--
DROP TABLE IF EXISTS `wp_nextend_smartslider_slides`;
CREATE TABLE `wp_nextend_smartslider_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `slider` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  `first` int(11) NOT NULL,
  `slide` longtext,
  `description` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `background` varchar(300) NOT NULL,
  `params` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `generator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_nextend_smartslider_slides`
--
LOCK TABLES `wp_nextend_smartslider_slides` WRITE;
INSERT INTO `wp_nextend_smartslider_slides` VALUES ('2', 'slider', '2', '2014-03-15 04:49:58', '2024-03-16 04:49:58', '1', '0', '', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '00000000|*|http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '{"slider":2,"publish_up":"0000-00-00 00:00:00","publish_down":"0000-00-00 00:00:00","params":"{\"link\":\"#|*|_self\",\"adminmode\":\"all\"}","ordering":0,"link":"#|*|_self","adminmode":"all"}', '1', '0'); 
INSERT INTO `wp_nextend_smartslider_slides` VALUES ('3', 'slider', '2', '2014-03-15 04:49:58', '2024-03-16 04:49:58', '1', '0', '', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '00000000|*|http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '{"slider":2,"publish_up":"0000-00-00 00:00:00","publish_down":"0000-00-00 00:00:00","params":"{\"link\":\"#|*|_self\",\"adminmode\":\"all\"}","ordering":1,"link":"#|*|_self","adminmode":"all"}', '2', '0'); 
INSERT INTO `wp_nextend_smartslider_slides` VALUES ('4', 'slider', '2', '2014-03-15 04:49:58', '2024-03-16 04:49:58', '1', '0', '', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '00000000|*|http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '{"slider":2,"publish_up":"0000-00-00 00:00:00","publish_down":"0000-00-00 00:00:00","params":"{\"link\":\"#|*|_self\",\"adminmode\":\"all\"}","ordering":2,"link":"#|*|_self","adminmode":"all"}', '3', '0'); 
INSERT INTO `wp_nextend_smartslider_slides` VALUES ('5', 'slider', '2', '2014-03-15 04:50:28', '2024-03-16 04:50:28', '1', '0', '', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '00000000|*|http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '{"slider":2,"publish_up":"0000-00-00 00:00:00","publish_down":"0000-00-00 00:00:00","params":"{\"link\":\"#|*|_self\",\"adminmode\":\"desktop\"}","ordering":0,"link":"#|*|_self","adminmode":"desktop"}', '4', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_nextend_smartslider_storage`
--
DROP TABLE IF EXISTS `wp_nextend_smartslider_storage`;
CREATE TABLE `wp_nextend_smartslider_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(200) NOT NULL,
  `value` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_nextend_smartslider_storage`
--
LOCK TABLES `wp_nextend_smartslider_storage` WRITE;
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('1', 'layout', '{"size":"1024|*|768"}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('2', 'settings', '{"debugmessages":"1","slideeditoralert":"1","translateurl":"|*|","externalcssfile":"","jquery":"1","translate3d":"1","placeholder":"http:\/\/www.nextendweb.com\/static\/placeholder.png","resizeremote":"0","responsivebasedon":"combined","responsivescreenwidth":"480|*|480","slideeditorratios":"1.0|*|1.0|*|0.7|*|0.5","generatordesignermode":"1","tidy-input-encoding":"utf8","tidy-output-encoding":"utf8"}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('3', 'font', '{"sliderfont1customlabel":"Heading light","sliderfont1":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"ffffffff\",\"size\":\"320||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.3\",\"bold\":1,\"italic\":0,\"underline\":0,\"align\":\"left\",\"paddingleft\":0},\"Link\":{\"paddingleft\":0,\"size\":\"100||%\"},\"Link:Hover\":{\"paddingleft\":0,\"size\":\"100||%\"}}","sliderfont2customlabel":"Heading dark","sliderfont2":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"000000db\",\"size\":\"320||%\",\"tshadow\":\"0|*|1|*|0|*|ffffff33\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.3\",\"bold\":1,\"italic\":0,\"underline\":0,\"align\":\"left\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont3customlabel":"Subheading light","sliderfont3":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"ffffffff\",\"size\":\"170||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.2\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"left\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont4customlabel":"Subheading dark","sliderfont4":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"000000db\",\"size\":\"170||%\",\"tshadow\":\"0|*|1|*|0|*|ffffff33\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.2\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"left\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont5customlabel":"Paragraph light","sliderfont5":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"ffffffff\",\"size\":\"114||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.4\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"justify\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont6customlabel":"Paragraph dark","sliderfont6":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"000000db\",\"size\":\"114||%\",\"tshadow\":\"0|*|1|*|0|*|ffffff33\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.4\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"justify\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont7customlabel":"Small text light","sliderfont7":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"ffffffff\",\"size\":\"90||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.2\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"left\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont8customlabel":"Small text dark","sliderfont8":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"000000db\",\"size\":\"90||%\",\"tshadow\":\"0|*|1|*|0|*|ffffff33\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.1\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"left\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont9customlabel":"Handwritten light","sliderfont9":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"ffffffff\",\"size\":\"140||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Pacifico);),Arial\",\"lineheight\":\"1.3\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"left\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont10customlabel":"Handwritten dark","sliderfont10":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"000000db\",\"size\":\"140||%\",\"tshadow\":\"0|*|1|*|0|*|ffffff33\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Pacifico);),Arial\",\"lineheight\":\"1.3\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"left\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont11customlabel":"Button light","sliderfont11":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"ffffffff\",\"size\":\"100||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.3\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"center\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfont12customlabel":"Button dark","sliderfont12":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"000000db\",\"size\":\"100||%\",\"tshadow\":\"0|*|1|*|0|*|ffffff33\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.3\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"center\",\"paddingleft\":0},\"Link\":{\"paddingleft\":0,\"size\":\"100||%\"},\"Link:Hover\":{\"paddingleft\":0,\"size\":\"100||%\"}}","sliderfontcustom1customlabel":"My first custom font","sliderfontcustom1":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"1abc9cff\",\"size\":\"360||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Pacifico);),Arial\",\"lineheight\":\"1.3\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"left\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfontcustom2customlabel":"My second custom font","sliderfontcustom2":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"ffffffff\",\"size\":\"140||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.2\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"center\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfontcustom3customlabel":"My third custom font","sliderfontcustom3":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"1abc9cff\",\"size\":\"120||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.2\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"center\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}","sliderfontcustom4customlabel":"My fourthcustom font ","sliderfontcustom4":"{\"firsttab\":\"Text\",\"Text\":{\"color\":\"1abc9cff\",\"size\":\"120||%\",\"tshadow\":\"0|*|1|*|1|*|000000c7\",\"afont\":\"google(@import url(http:\/\/fonts.googleapis.com\/css?family=Open Sans);),Arial\",\"lineheight\":\"1.2\",\"bold\":0,\"italic\":0,\"underline\":0,\"align\":\"right\",\"paddingleft\":0},\"Link\":{\"size\":\"100||%\",\"paddingleft\":0},\"Link:Hover\":{\"size\":\"100||%\",\"paddingleft\":0}}"}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('4', 'sliderchanged1', '1'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('5', 'sliderchanged2', '0'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('6', 'font2', '{"sliderfont1customlabel":"Heading light","sliderfont1":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InBhZGRpbmdsZWZ0IjowLCJzaXplIjoiMTAwfHwlIn0sIkxpbms6SG92ZXIiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifX0=","sliderfont2customlabel":"Heading dark","sliderfont2":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont3customlabel":"Subheading light","sliderfont3":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont4customlabel":"Subheading dark","sliderfont4":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont5customlabel":"Paragraph light","sliderfont5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont6customlabel":"Paragraph dark","sliderfont6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont7customlabel":"Small text light","sliderfont7":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwxfCp8MDAwMDAwYzciLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont8customlabel":"Small text dark","sliderfont8":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwwfCp8ZmZmZmZmMzMiLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMSIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont9customlabel":"Handwritten light","sliderfont9":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont10customlabel":"Handwritten dark","sliderfont10":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont11customlabel":"Button light","sliderfont11":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont12customlabel":"Button dark","sliderfont12":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifSwiTGluazpIb3ZlciI6eyJwYWRkaW5nbGVmdCI6MCwic2l6ZSI6IjEwMHx8JSJ9fQ==","sliderfontcustom5customlabel":"Post generator title v1","sliderfontcustom5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNmI2YjZiZmYiLCJzaXplIjoiMjIwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6Ijg3ZDJjZWZmIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI4MmM3YzNmZiIsInNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom6customlabel":"Post generator categoryv1","sliderfontcustom6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiODc4Nzg3ZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9QXZlcmFnZSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJjb2xvciI6IjY5YmRiOWZmIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom7customlabel":"Post generator paragraph v1","sliderfontcustom7":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYTdhN2E3ZmYiLCJzaXplIjoiMTMwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9QXZlcmFnZSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjYiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6IjY5YmRiOWIzIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI2OWJkYjlmZiIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfontcustom8customlabel":"Post generator button v1","sliderfontcustom8":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNmNjOGMzZmYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNSIsImJvbGQiOjEsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImNlbnRlciIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiZmZmZmZmZWIiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom9customlabel":"Post generator title v2","sliderfontcustom9":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNmI2YjZiZmYiLCJzaXplIjoiMjIwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiI4N2QyY2VmZiJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiODJjN2MzZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom10customlabel":"Post generator categoryv2","sliderfontcustom10":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYWFhYWFhZmYiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMyIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJjb2xvciI6IjY5YmRiOWZmIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom11customlabel":"Post generator paragraph v2","sliderfontcustom11":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYTdhN2E3ZmYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6Imp1c3RpZnkiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6IjY5YmRiOWIzIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI2OWJkYjlmZiIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfontcustom12customlabel":"Post generator button v2","sliderfontcustom12":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNSIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImNlbnRlciIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiZmZmZmZmZWIiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom13customlabel":"Post generator title v3","sliderfontcustom13":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMjIwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiJmZmZmZmZlZCJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiODJjN2MzZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom14customlabel":"Post generator paragraph v3","sliderfontcustom14":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmYzQiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6Imp1c3RpZnkiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6IjY5YmRiOWIzIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI2OWJkYjlmZiIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfontcustom15customlabel":"Post generator title v4","sliderfontcustom15":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMjcwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6ImZmZmZmZmZmIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI4MmM3YzNmZiIsInNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom16customlabel":"Post generator paragraph v4","sliderfontcustom16":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmYzQiLCJzaXplIjoiMTIwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImNlbnRlciIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjAsImNvbG9yIjoiNjliZGI5YjMifSwiTGluazpIb3ZlciI6eyJjb2xvciI6IjY5YmRiOWZmIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom17customlabel":"Webshop generator title v1 ","sliderfontcustom17":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNDM1NjY0ZmYiLCJzaXplIjoiMjQwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiI0MzU2NjRmZiJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiOGU0NGFkZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom18customlabel":"Webshop generator subtitle v1 ","sliderfontcustom18":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNjA3MjgwZmYiLCJzaXplIjoiMTMwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiI0MzU2NjRmZiJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiOGU0NGFkZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom19customlabel":"Webshop generator paragraph v1","sliderfontcustom19":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOGY5NTlkZTYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNCIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6Imp1c3RpZnkiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6IjQzNTY2NGZmIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI4ZTQ0YWRmZiIsInNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom20customlabel":"Webshop generator price v1 ","sliderfontcustom20":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOGU0NGFkZmYiLCJzaXplIjoiMjQwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJyaWdodCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjAsImNvbG9yIjoiNDM1NjY0ZmYifSwiTGluazpIb3ZlciI6eyJjb2xvciI6IjdmM2M5Y2ZmIiwic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfontcustom21customlabel":"Webshop generator title v2","sliderfontcustom21":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYjQ3MGEyZmYiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UmFsZXdheSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsImNvbG9yIjoiZjU4NzAwZmYiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom22customlabel":"Webshop generator price v2","sliderfontcustom22":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOGU0NGFkZmYiLCJzaXplIjoiMTYwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiI0MzU2NjRmZiJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiN2YzYzljZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom23customlabel":"Webshop generator paragraph v2","sliderfontcustom23":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOTk5OTk5ZmYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UmFsZXdheSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjYiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsImNvbG9yIjoiZjU4NzAwZmYiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom24customlabel":"Webshop generator price v3","sliderfontcustom24":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYjQ3MGEyZmYiLCJzaXplIjoiMjYwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9QmViYXMpOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS41IiwiYm9sZCI6MSwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom25customlabel":"Webshop generator subtitle","sliderfontcustom25":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOGE4YThhZmYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UmFsZXdheSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsImNvbG9yIjoiZjU4NzAwZmYiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom26customlabel":"Webshop generator title v3","sliderfontcustom26":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMjYwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UmFsZXdheSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsImNvbG9yIjoiZmZmZmZmZDkiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom27customlabel":"Webshop generator price v4","sliderfontcustom27":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzgwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9QmViYXMpOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4yIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoicmlnaHQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ=="}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('7', 'generator2', '{"time":1394945378,"hash":"1a024e4efcbe0642b2e94a249bc37351","data":[{"image":"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg","title":"slider","url":"#","description":"","thumbnail":"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg","url_label":"View","author_name":"","author_url":"#"},{"image":"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg","title":"slider","url":"#","description":"","thumbnail":"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg","url_label":"View","author_name":"","author_url":"#"},{"image":"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg","title":"slider","url":"#","description":"","thumbnail":"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg","url_label":"View","author_name":"","author_url":"#"}]}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('8', 'slidercache2', '{"time":1394945378,"data":{"css":"http:\/\/127.0.0.1\/asug\/wp-content\/cache\/css\/static\/8b692a708f47fdaf2c22f57333159da4.css","js":{"core":{"C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\assets\\js\\class.js":"C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\assets\\js\\class.js"}},"fonts":{"Montserrat":{"0":400,"1":"latin","400,latin":1},"Pacifico":{"0":400,"1":"latin","400,latin":1},"Average":{"0":400,"1":"latin","400,latin":1},"Open Sans":{"0":400,"1":"latin","400,latin":1},"Raleway":{"0":400,"1":"latin","400,latin":1},"Bebas":{"0":400,"1":"latin","400,latin":1}},"html":"<script type=\"text\/javascript\">\r\n    window[\'nextend-smart-slider-2-onresize\'] = [];\r\n<\/script>\r\n\r\n<div id=\"nextend-smart-slider-2\" class=\"nextend-slider-fadeload nextend-desktop \" style=\"font-size: 12px;\" data-allfontsize=\"12\" data-desktopfontsize=\"12\" data-tabletfontsize=\"16\" data-phonefontsize=\"20\">\r\n    <div class=\"smart-slider-border1\" style=\"\">\r\n        <div class=\"smart-slider-border2\">\r\n            \r\n                            <div class=\"smart-slider-canvas smart-slider-slide-active smart-slider-bg-colored\" style=\"\">\r\n                                            <img src=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\" class=\"nextend-slide-bg\"\/>\r\n                                                            <div class=\"smart-slider-canvas-inner\">\r\n                                            <\/div>\r\n                                    <\/div>\r\n                            <div class=\"smart-slider-canvas smart-slider-bg-colored\" style=\"\">\r\n                                            <img src=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\" class=\"nextend-slide-bg\"\/>\r\n                                                            <div class=\"smart-slider-canvas-inner\">\r\n                                            <\/div>\r\n                                    <\/div>\r\n                            <div class=\"smart-slider-canvas smart-slider-bg-colored\" style=\"\">\r\n                                            <img src=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\" class=\"nextend-slide-bg\"\/>\r\n                                                            <div class=\"smart-slider-canvas-inner\">\r\n                                            <\/div>\r\n                                    <\/div>\r\n                            <div class=\"smart-slider-canvas smart-slider-bg-colored\" style=\"\">\r\n                                            <img src=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\" class=\"nextend-slide-bg\"\/>\r\n                                                            <div class=\"smart-slider-canvas-inner\">\r\n                                            <\/div>\r\n                                    <\/div>\r\n                    <\/div>\r\n    <\/div>\r\n    <div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'previous\');\" class=\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-arrow-previous nextend-transition nextend-transition-previous nextend-transition-previous-my-test\" style=\"position: absolute;left:0%;\" data-sstop=\"height\/2-previousheight\/2\" ><div class=\"smartslider-outer\"><\/div><div class=\"smartslider-inner\"><\/div><\/div><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'next\');\" class=\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-arrow-next nextend-transition nextend-transition-next nextend-transition-next-my-test\" style=\"position: absolute;right:0%;\" data-sstop=\"height\/2-nextheight\/2\" ><div class=\"smartslider-outer\"><\/div><div class=\"smartslider-inner\"><\/div><\/div><div style=\"position: absolute;left:0%;bottom:5%;visibility: hidden;z-index:10; line-height: 0;width:100%;text-align:center;\" class=\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-widget-bullet \" ><div class=\"nextend-bullet-container nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',0,false);\" data-thumbnail=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><span class=\"sliderfont7\">\r\n                1\r\n                <\/span><\/div><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',1,false);\" data-thumbnail=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><span class=\"sliderfont7\">\r\n                2\r\n                <\/span><\/div><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',2,false);\" data-thumbnail=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><span class=\"sliderfont7\">\r\n                3\r\n                <\/span><\/div><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',3,false);\" data-thumbnail=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><span class=\"sliderfont7\">\r\n                4\r\n                <\/span><\/div><\/div><\/div><\/div>\r\n\r\n<script type=\"text\/javascript\">\r\n    njQuery(document).ready(function () {\r\n        njQuery(\'#nextend-smart-slider-2\').smartslider({\"translate3d\":1,\"playfirstlayer\":0,\"mainafterout\":0,\"inaftermain\":1,\"fadeonscroll\":0,\"autoplay\":1,\"autoplayConfig\":{\"duration\":8000,\"counter\":0,\"autoplayToSlide\":0,\"stopautoplay\":{\"click\":1,\"mouseenter\":1,\"slideplaying\":1},\"resumeautoplay\":{\"mouseleave\":0,\"slideplayed\":1,\"slidechanged\":0}},\"responsive\":{\"downscale\":1,\"upscale\":0,\"maxwidth\":3000,\"basedon\":\"combined\",\"screenwidth\":{\"tablet\":480,\"phone\":480},\"ratios\":[1,1,0.7,0.5]},\"controls\":{\"scroll\":0,\"touch\":\"horizontal\",\"keyboard\":0},\"blockrightclick\":0,\"type\":\"ssSimpleSlider\",\"animation\":[\"horizontal\"],\"animationSettings\":{\"duration\":800,\"delay\":0,\"easing\":\"easeInOutQuad\",\"parallax\":1},\"flux\":[0,[\"bars\",\"blocks\"]],\"touchanimation\":\"horizontal\"});\r\n    });\r\n<\/script>\r\n<div style=\"clear: both;\"><\/div>\r\n<div id=\"nextend-smart-slider-2-placeholder\" ><img alt=\"\" style=\"width:100%; max-width: 3000px;\" src=\"data:image\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAh4AAAD6CAYAAADuiU73AAAEQklEQVR4nO3WMQEAIAzAMMC\/5+GiHCQKenbPAgBonNcBAMA\/jAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZC6jWgLztugg\/QAAAABJRU5ErkJggg==\" \/><\/div>","libraries":{"modernizr":{"jsfiles":["C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/modernizr\/modernizr.js"],"js":""},"jquery":{"jsfiles":["C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/njQuery.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jQuery.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/uacss.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jquery.unique-element-id.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jquery.waitforimages.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jquery.touchSwipe.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/easing.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jquery.transit.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\animationbase.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\smartsliderbase.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\mainslider.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\layers.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\no.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\fade.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\fadestatic.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\slide.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\slidestatic.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\transit.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\plugins\\nextendslidertype\\simple\\simple\\slider.js"],"js":""}}},"expire":"1"}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('9', 'sliderchanged3', '1'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_options`
--
DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1289 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_options`
--
LOCK TABLES `wp_options` WRITE;
INSERT INTO `wp_options` VALUES ('1', 'siteurl', 'http://127.0.0.1/asug', 'yes'); 
INSERT INTO `wp_options` VALUES ('2', 'blogname', 'Asug | SAP NetWeaver Portal', 'yes'); 
INSERT INTO `wp_options` VALUES ('3', 'blogdescription', 'Só mais um site WordPress', 'yes'); 
INSERT INTO `wp_options` VALUES ('4', 'users_can_register', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('5', 'admin_email', 'contato@montarsite.com.br', 'yes'); 
INSERT INTO `wp_options` VALUES ('6', 'start_of_week', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('7', 'use_balanceTags', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('8', 'use_smilies', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('9', 'require_name_email', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('10', 'comments_notify', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('11', 'posts_per_rss', '10', 'yes'); 
INSERT INTO `wp_options` VALUES ('12', 'rss_use_excerpt', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('13', 'mailserver_url', 'mail.example.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('14', 'mailserver_login', 'login@example.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('15', 'mailserver_pass', 'password', 'yes'); 
INSERT INTO `wp_options` VALUES ('16', 'mailserver_port', '110', 'yes'); 
INSERT INTO `wp_options` VALUES ('17', 'default_category', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('18', 'default_comment_status', 'closed', 'yes'); 
INSERT INTO `wp_options` VALUES ('19', 'default_ping_status', 'open', 'yes'); 
INSERT INTO `wp_options` VALUES ('20', 'default_pingback_flag', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('21', 'posts_per_page', '10', 'yes'); 
INSERT INTO `wp_options` VALUES ('22', 'date_format', 'j \d\e F \d\e Y', 'yes'); 
INSERT INTO `wp_options` VALUES ('23', 'time_format', 'H:i', 'yes'); 
INSERT INTO `wp_options` VALUES ('24', 'links_updated_date_format', 'j \d\e F \d\e Y, H:i', 'yes'); 
INSERT INTO `wp_options` VALUES ('25', 'links_recently_updated_prepend', '<em>', 'yes'); 
INSERT INTO `wp_options` VALUES ('26', 'links_recently_updated_append', '</em>', 'yes'); 
INSERT INTO `wp_options` VALUES ('27', 'links_recently_updated_time', '120', 'yes'); 
INSERT INTO `wp_options` VALUES ('28', 'comment_moderation', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('29', 'moderation_notify', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('30', 'permalink_structure', '/%postname%/', 'yes'); 
INSERT INTO `wp_options` VALUES ('31', 'gzipcompression', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('32', 'hack_file', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('33', 'blog_charset', 'UTF-8', 'yes'); 
INSERT INTO `wp_options` VALUES ('34', 'moderation_keys', '', 'no'); 
INSERT INTO `wp_options` VALUES ('35', 'active_plugins', 'a:20:{i:0;s:29:"ads-by-datafeedrcom/dfads.php";i:1;s:51:"auto-excerpt-everywhere/auto-excerpt-everywhere.php";i:2;s:41:"better-wp-security/better-wp-security.php";i:3;s:43:"broken-link-checker/broken-link-checker.php";i:4;s:25:"cloudflare/cloudflare.php";i:5;s:36:"contact-form-7/wp-contact-form-7.php";i:6;s:33:"events-manager/events-manager.php";i:7;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:8;s:43:"google-analytics-dashboard-for-wp/gadwp.php";i:9;s:50:"google-analytics-for-wordpress/googleanalytics.php";i:10;s:36:"google-sitemap-generator/sitemap.php";i:11;s:29:"ready-backup/backup-ready.php";i:12;s:33:"seo-image/seo-friendly-images.php";i:13;s:33:"smart-slider-2/smart-slider-2.php";i:14;s:37:"user-role-editor/user-role-editor.php";i:15;s:29:"user-status-manager/start.php";i:16;s:37:"widgets-on-pages/widgets_on_pages.php";i:17;s:27:"woocommerce/woocommerce.php";i:18;s:31:"wp-backupware/wp-backupware.php";i:19;s:27:"wp-optimize/wp-optimize.php";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('36', 'home', 'http://127.0.0.1/asug', 'yes'); 
INSERT INTO `wp_options` VALUES ('37', 'category_base', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('38', 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'); 
INSERT INTO `wp_options` VALUES ('39', 'advanced_edit', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('40', 'comment_max_links', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('41', 'gmt_offset', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('42', 'default_email_category', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('43', 'recently_edited', 'a:2:{i:0;s:87:"C:\xampp\htdocs\asug/wp-content/plugins/twenty-eleven-theme-extensions/moztheme2011.php";i:1;s:0:"";}', 'no'); 
INSERT INTO `wp_options` VALUES ('44', 'template', 'twentytwelve', 'yes'); 
INSERT INTO `wp_options` VALUES ('45', 'stylesheet', 'twentytwelve', 'yes'); 
INSERT INTO `wp_options` VALUES ('46', 'comment_whitelist', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('47', 'blacklist_keys', '', 'no'); 
INSERT INTO `wp_options` VALUES ('48', 'comment_registration', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('49', 'html_type', 'text/html', 'yes'); 
INSERT INTO `wp_options` VALUES ('50', 'use_trackback', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('51', 'default_role', 'subscriber', 'yes'); 
INSERT INTO `wp_options` VALUES ('52', 'db_version', '26691', 'yes'); 
INSERT INTO `wp_options` VALUES ('53', 'uploads_use_yearmonth_folders', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('54', 'upload_path', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('55', 'blog_public', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('56', 'default_link_category', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('57', 'show_on_front', 'page', 'yes'); 
INSERT INTO `wp_options` VALUES ('58', 'tag_base', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('59', 'show_avatars', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('60', 'avatar_rating', 'G', 'yes'); 
INSERT INTO `wp_options` VALUES ('61', 'upload_url_path', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('62', 'thumbnail_size_w', '150', 'yes'); 
INSERT INTO `wp_options` VALUES ('63', 'thumbnail_size_h', '150', 'yes'); 
INSERT INTO `wp_options` VALUES ('64', 'thumbnail_crop', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('65', 'medium_size_w', '300', 'yes'); 
INSERT INTO `wp_options` VALUES ('66', 'medium_size_h', '300', 'yes'); 
INSERT INTO `wp_options` VALUES ('67', 'avatar_default', 'mystery', 'yes'); 
INSERT INTO `wp_options` VALUES ('68', 'large_size_w', '1024', 'yes'); 
INSERT INTO `wp_options` VALUES ('69', 'large_size_h', '1024', 'yes'); 
INSERT INTO `wp_options` VALUES ('70', 'image_default_link_type', 'file', 'yes'); 
INSERT INTO `wp_options` VALUES ('71', 'image_default_size', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('72', 'image_default_align', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('73', 'close_comments_for_old_posts', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('74', 'close_comments_days_old', '14', 'yes'); 
INSERT INTO `wp_options` VALUES ('75', 'thread_comments', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('76', 'thread_comments_depth', '5', 'yes'); 
INSERT INTO `wp_options` VALUES ('77', 'page_comments', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('78', 'comments_per_page', '50', 'yes'); 
INSERT INTO `wp_options` VALUES ('79', 'default_comments_page', 'newest', 'yes'); 
INSERT INTO `wp_options` VALUES ('80', 'comment_order', 'asc', 'yes'); 
INSERT INTO `wp_options` VALUES ('81', 'sticky_posts', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('82', 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('83', 'widget_text', 'a:3:{i:2;a:3:{s:5:"title";s:0:"";s:4:"text";s:2595:"<aside>
					<div id="post_recentes">
						<div class="table-responsive forum_home">
							<table class="table table-hover">
								<thead>
									<tr class="titulos">
										<th class="post_recentes" colspan="2">Fórum | Posts mais recentes</th>
										<th class="post_recentes_f">Ir para o fórum</th>
									</tr>
								</thead>
								<tbody class="textos">
									<tr class="topo">
										<td>Título</td>
										<td>Autor</td>
										<td>Data</td>
									</tr>
									<tr class="posts_recentes">
										<td class="posts">
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
									<tr class="posts_recentes">
										<td>
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
									<tr class="posts_recentes">
										<td>
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
									<tr class="posts_recentes">
										<td>
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
									<tr class="posts_recentes">
										<td>
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</aside>";s:6:"filter";b:0;}i:3;a:3:{s:5:"title";s:5:"Teste";s:4:"text";s:7:"Direito";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('84', 'widget_rss', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('85', 'uninstall_plugins', 'a:4:{s:41:"better-wp-security/better-wp-security.php";a:2:{i:0;s:10:"bwps_setup";i:1;s:12:"on_uninstall";}s:43:"google-analytics-dashboard-for-wp/gadwp.php";a:2:{i:0;s:16:"GADASH_Uninstall";i:1;s:9:"uninstall";}s:41:"simple-ads-manager/simple-ads-manager.php";a:2:{i:0;s:21:"SimpleAdsManagerAdmin";i:1;s:11:"onUninstall";}s:21:"adrotate/adrotate.php";s:18:"adrotate_uninstall";}', 'no'); 
INSERT INTO `wp_options` VALUES ('86', 'timezone_string', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('87', 'page_for_posts', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('88', 'page_on_front', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('89', 'default_post_format', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('90', 'link_manager_enabled', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('91', 'initial_db_version', '26691', 'yes'); 
INSERT INTO `wp_options` VALUES ('92', 'wp_user_roles', 'a:8:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:138:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:57:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:20:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:15:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:12:{s:4:"read";b:1;s:7:"level_0";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:3:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"delete_posts";b:0;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:93:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:13:"representante";a:2:{s:4:"name";s:13:"Representante";s:12:"capabilities";a:2:{s:4:"read";i:1;s:7:"level_0";i:1;}}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('93', 'widget_search', 'a:3:{i:2;a:1:{s:5:"title";s:0:"";}i:3;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('94', 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('95', 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('96', 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('97', 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('98', 'sidebars_widgets', 'a:9:{s:15:"sidebar_direito";a:0:{}s:16:"sidebar_esquerdo";a:0:{}s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:1:{i:0;s:6:"text-2";}s:9:"sidebar-3";a:0:{}s:5:"wop-1";a:2:{i:0;s:7:"pages-2";i:1;s:6:"text-3";}s:5:"wop-2";a:1:{i:0;s:8:"search-3";}s:13:"array_version";i:3;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('99', 'cron', 'a:13:{i:1395343620;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1395346135;a:1:{s:20:"blc_cron_check_links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1395346819;a:1:{s:40:"membership_perform_cron_processes_hourly";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1395360000;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1395365302;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1395373897;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1395373898;a:2:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1395417114;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1395418135;a:2:{s:28:"blc_cron_email_notifications";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:19:"blc_cron_check_news";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1395419658;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1395429952;a:1:{s:17:"wpbu_backup_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1395835735;a:1:{s:29:"blc_cron_database_maintenance";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:9:"bimonthly";s:4:"args";a:0:{}s:8:"interval";i:936000;}}}s:7:"version";i:2;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('101', '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:2:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:49:"http://br.wordpress.org/wordpress-3.8.1-pt_BR.zip";s:6:"locale";s:5:"pt_BR";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:49:"http://br.wordpress.org/wordpress-3.8.1-pt_BR.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.8.1";s:7:"version";s:5:"3.8.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:41:"https://wordpress.org/wordpress-3.8.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:41:"https://wordpress.org/wordpress-3.8.1.zip";s:10:"no_content";s:52:"https://wordpress.org/wordpress-3.8.1-no-content.zip";s:11:"new_bundled";s:53:"https://wordpress.org/wordpress-3.8.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.8.1";s:7:"version";s:5:"3.8.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1395337617;s:15:"version_checked";s:5:"3.8.1";s:12:"translations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('105', '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1395337619;s:7:"checked";a:1:{s:12:"twentytwelve";s:3:"1.3";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('106', '_site_transient_timeout_browser_e1afaea9da6625c3c07a7062325fa07d', '1395503515', 'yes'); 
INSERT INTO `wp_options` VALUES ('107', '_site_transient_browser_e1afaea9da6625c3c07a7062325fa07d', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"33.0.1750.152";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('114', 'can_compress_scripts', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('131', 'wpcf7', 'a:1:{s:7:"version";s:5:"3.7.2";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('132', 'recently_activated', 'a:7:{s:47:"twenty-eleven-theme-extensions/moztheme2011.php";i:1395337395;s:37:"new-user-approve/new-user-approve.php";i:1395284181;s:25:"membership/membership.php";i:1395282783;s:85:"carousel-horizontal-posts-content-slider/carousel-horizontal-posts-content-slider.php";i:1395190989;s:21:"adrotate/adrotate.php";i:1394949891;s:41:"simple-ads-manager/simple-ads-manager.php";i:1394949159;s:45:"wp-bootstrap-navmenu/wp-bootstrap-navmenu.php";i:1394905161;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('133', 'Yoast_Google_Analytics', 'a:51:{s:16:"advancedsettings";b:0;s:11:"allowanchor";b:0;s:9:"allowhash";b:0;s:11:"allowlinker";b:0;s:11:"anonymizeip";b:0;s:10:"customcode";s:0:"";s:11:"cv_loggedin";b:0;s:13:"cv_authorname";b:0;s:11:"cv_category";b:0;s:17:"cv_all_categories";b:0;s:7:"cv_tags";b:0;s:7:"cv_year";b:0;s:12:"cv_post_type";b:0;s:5:"debug";b:0;s:12:"dlextensions";s:30:"doc,exe,js,pdf,ppt,tgz,zip,xls";s:6:"domain";s:0:"";s:11:"domainorurl";s:6:"domain";s:7:"extrase";b:0;s:10:"extraseurl";s:0:"";s:11:"firebuglite";b:0;s:8:"ga_token";s:0:"";s:16:"ga_api_responses";a:0:{}s:16:"gajslocalhosting";b:0;s:7:"gajsurl";s:0:"";s:16:"ignore_userlevel";s:2:"11";s:12:"internallink";s:0:"";s:17:"internallinklabel";s:0:"";s:16:"outboundpageview";b:0;s:17:"downloadspageview";b:0;s:17:"othercrossdomains";s:0:"";s:8:"position";s:6:"header";s:18:"primarycrossdomain";s:0:"";s:13:"theme_updated";b:0;s:16:"trackcommentform";b:1;s:16:"trackcrossdomain";b:0;s:12:"trackadsense";b:0;s:13:"trackoutbound";b:1;s:17:"trackregistration";b:0;s:14:"rsslinktagging";b:1;s:8:"uastring";s:13:"UA-45871625-6";s:7:"version";s:5:"4.3.5";s:3:"msg";s:0:"";s:14:"tracking_popup";s:4:"done";s:14:"yoast_tracking";b:0;s:15:"gfsubmiteventpv";s:0:"";s:11:"trackprefix";s:0:"";s:13:"admintracking";b:0;s:15:"manual_uastring";b:1;s:11:"taggfsubmit";b:0;s:13:"wpec_tracking";b:0;s:14:"shopp_tracking";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('136', 'bit51_bwps_data', 'a:3:{s:7:"version";s:4:"3064";s:13:"activatestamp";i:1394899192;s:14:"no-nag-upgrade";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('137', 'bit51_bwps', 'a:74:{s:10:"bu_banlist";s:1:"
";s:12:"id_whitelist";s:0:"";s:13:"st_writefiles";i:1;s:17:"initial_filewrite";i:1;s:14:"ssl_forcelogin";s:1:"0";s:14:"ssl_forceadmin";s:1:"0";s:12:"ssl_frontend";i:1;s:14:"initial_backup";i:1;s:10:"am_enabled";s:1:"0";s:7:"am_type";s:1:"0";s:12:"am_startdate";s:1:"1";s:10:"am_enddate";s:1:"1";s:12:"am_starttime";s:1:"1";s:10:"am_endtime";s:1:"1";s:12:"backup_email";s:1:"1";s:19:"backup_emailaddress";s:0:"";s:11:"backup_time";s:1:"1";s:15:"backup_interval";s:1:"1";s:14:"backup_enabled";s:1:"0";s:11:"backup_last";i:1394900100;s:11:"backup_next";s:0:"";s:17:"backups_to_retain";s:2:"10";s:10:"bu_enabled";s:1:"0";s:11:"bu_banagent";s:0:"";s:12:"bu_blacklist";s:1:"0";s:10:"hb_enabled";i:1;s:8:"hb_login";s:8:"adm_asug";s:11:"hb_register";s:8:"register";s:8:"hb_admin";s:5:"admin";s:6:"hb_key";s:21:"htclssk0u6gecffqf6gpu";s:10:"ll_enabled";s:1:"0";s:18:"ll_maxattemptshost";s:1:"5";s:18:"ll_maxattemptsuser";s:2:"10";s:16:"ll_checkinterval";s:1:"5";s:12:"ll_banperiod";s:2:"15";s:14:"ll_blacklistip";s:1:"1";s:23:"ll_blacklistipthreshold";s:1:"3";s:14:"ll_emailnotify";s:1:"1";s:15:"ll_emailaddress";s:0:"";s:10:"id_enabled";s:1:"0";s:14:"id_emailnotify";s:1:"1";s:16:"id_checkinterval";s:1:"5";s:12:"id_threshold";s:2:"20";s:12:"id_banperiod";s:2:"15";s:14:"id_blacklistip";s:1:"0";s:23:"id_blacklistipthreshold";s:1:"3";s:15:"id_emailaddress";s:0:"";s:14:"id_fileenabled";s:1:"0";s:18:"id_fileemailnotify";s:1:"1";s:19:"id_filedisplayerror";s:1:"1";s:19:"id_fileemailaddress";s:0:"";s:14:"id_specialfile";s:0:"";s:12:"id_fileincex";s:1:"1";s:16:"id_filechecktime";s:0:"";s:11:"st_ht_files";s:1:"0";s:14:"st_ht_browsing";s:1:"0";s:13:"st_ht_request";s:1:"0";s:11:"st_ht_query";s:1:"0";s:13:"st_ht_foreign";s:1:"0";s:12:"st_generator";s:1:"0";s:11:"st_manifest";s:1:"0";s:10:"st_edituri";s:1:"0";s:11:"st_themenot";s:1:"0";s:12:"st_pluginnot";s:1:"0";s:10:"st_corenot";s:1:"0";s:17:"st_enablepassword";s:1:"0";s:11:"st_passrole";s:13:"administrator";s:13:"st_loginerror";s:1:"0";s:11:"st_fileperm";s:1:"0";s:10:"st_comment";s:1:"0";s:16:"st_randomversion";s:1:"0";s:10:"st_longurl";s:1:"0";s:11:"st_fileedit";s:1:"0";s:14:"oneclickchosen";s:1:"0";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('141', 'acf_version', '4.3.4', 'yes'); 
INSERT INTO `wp_options` VALUES ('143', 'ewww_image_optimizer_bulk_attachments', '', 'no'); 
INSERT INTO `wp_options` VALUES ('144', 'ewww_image_optimizer_flag_attachments', '', 'no'); 
INSERT INTO `wp_options` VALUES ('145', 'ewww_image_optimizer_ngg_attachments', '', 'no'); 
INSERT INTO `wp_options` VALUES ('146', 'ewww_image_optimizer_aux_attachments', '', 'no'); 
INSERT INTO `wp_options` VALUES ('147', 'ewww_image_optimizer_disable_pngout', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('148', 'ewww_image_optimizer_optipng_level', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('149', 'ewww_image_optimizer_pngout_level', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('150', 'ewww_image_optimizer_version', '184', 'yes'); 
INSERT INTO `wp_options` VALUES ('151', 'ewww_image_optimizer_cloud_jpg', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('152', 'ewww_image_optimizer_cloud_png', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('153', 'ewww_image_optimizer_cloud_gif', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('154', 'wp-optimize-schedule', 'false', 'no'); 
INSERT INTO `wp_options` VALUES ('155', 'wp-optimize-last-optimized', 'Never', 'no'); 
INSERT INTO `wp_options` VALUES ('156', 'wp-optimize-schedule-type', 'wpo_weekly', 'no'); 
INSERT INTO `wp_options` VALUES ('157', 'wp-optimize-retention-enabled', 'false', 'no'); 
INSERT INTO `wp_options` VALUES ('158', 'wp-optimize-retention-period', '2', 'no'); 
INSERT INTO `wp_options` VALUES ('159', 'wp-optimize-enable-admin-menu', 'false', 'no'); 
INSERT INTO `wp_options` VALUES ('160', 'wp-optimize-total-cleaned', '0', 'no'); 
INSERT INTO `wp_options` VALUES ('161', 'wp-optimize-auto', 'a:8:{s:9:"revisions";s:4:"true";s:6:"drafts";s:4:"true";s:5:"spams";s:4:"true";s:10:"unapproved";s:5:"false";s:9:"transient";s:5:"false";s:8:"postmeta";s:5:"false";s:4:"tags";s:5:"false";s:8:"optimize";s:4:"true";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('162', 'wsblc_options', '{"max_execution_time":300,"check_threshold":72,"recheck_count":3,"recheck_threshold":1800,"run_in_dashboard":true,"run_via_cron":true,"mark_broken_links":true,"broken_link_css":".broken_link, a.broken_link {\n\ttext-decoration: line-through;\n}","nofollow_broken_links":false,"mark_removed_links":false,"removed_link_css":".removed_link, a.removed_link {\n\ttext-decoration: line-through;\n}","exclusion_list":[],"send_email_notifications":true,"send_authors_email_notifications":false,"notification_email_address":"","notification_schedule":"daily","last_notification_sent":0,"suggestions_enabled":true,"server_load_limit":4,"enable_load_limit":false,"custom_fields":[],"enabled_post_statuses":["publish"],"autoexpand_widget":true,"dashboard_widget_capability":"edit_others_posts","show_link_count_bubble":true,"table_layout":"flexible","table_compact":true,"table_visible_columns":["new-url","status","used-in","new-link-text"],"table_links_per_page":30,"table_color_code_status":true,"need_resynch":false,"current_db_version":6,"timeout":30,"highlight_permanent_failures":false,"failure_duration_threshold":3,"installation_complete":true,"installation_flag_cleared_on":"2014-03-15T16:08:45+00:00 (1394899725.4907)","installation_flag_set_on":"2014-03-15T16:08:53+00:00 (1394899733.6746)","user_has_donated":false,"donation_flag_fixed":false,"first_installation_timestamp":1394899725,"active_modules":{"http":{"ModuleID":"http","ModuleCategory":"checker","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcHttpChecker","ModulePriority":-1,"ModuleCheckerUrlPattern":"","ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"Name":"Basic HTTP","PluginURI":"","Version":"1.0","Description":"Check all links that have the HTTP\/HTTPS protocol.","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"Basic HTTP","AuthorName":"Janis Elsts","file":"checkers\/http.php"},"link":{"ModuleID":"link","ModuleCategory":"parser","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcHTMLLink","ModulePriority":1000,"ModuleCheckerUrlPattern":"","ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"Name":"HTML links","PluginURI":"","Version":"1.0","Description":"Example : <code>&lt;a href=\"http:\/\/example.com\/\"&gt;link text&lt;\/a&gt;<\/code>","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"HTML links","AuthorName":"Janis Elsts","file":"parsers\/html_link.php"},"image":{"ModuleID":"image","ModuleCategory":"parser","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcHTMLImage","ModulePriority":900,"ModuleCheckerUrlPattern":"","ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"Name":"HTML images","PluginURI":"","Version":"1.0","Description":"e.g. <code>&lt;img src=\"http:\/\/example.com\/fluffy.jpg\"&gt;<\/code>","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"HTML images","AuthorName":"Janis Elsts","file":"parsers\/image.php"},"metadata":{"ModuleID":"metadata","ModuleCategory":"parser","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcMetadataParser","ModulePriority":0,"ModuleCheckerUrlPattern":"","ModuleHidden":true,"ModuleAlwaysActive":true,"ModuleRequiresPro":false,"Name":"Metadata","PluginURI":"","Version":"1.0","Description":"Parses metadata (AKA custom fields)","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"Metadata","AuthorName":"Janis Elsts","file":"parsers\/metadata.php"},"url_field":{"ModuleID":"url_field","ModuleCategory":"parser","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcUrlField","ModulePriority":0,"ModuleCheckerUrlPattern":"","ModuleHidden":true,"ModuleAlwaysActive":true,"ModuleRequiresPro":false,"Name":"URL fields","PluginURI":"","Version":"1.0","Description":"Parses data fields that contain a single, plaintext URL.","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"URL fields","AuthorName":"Janis Elsts","file":"parsers\/url_field.php"},"comment":{"ModuleID":"comment","ModuleCategory":"container","ModuleContext":"all","ModuleLazyInit":false,"ModuleClassName":"blcCommentManager","ModulePriority":0,"ModuleCheckerUrlPattern":"","ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"Name":"Comments","PluginURI":"","Version":"1.0","Description":"","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"Comments","AuthorName":"Janis Elsts","file":"containers\/comment.php"},"post":{"Name":"Posts","ModuleCategory":"container","ModuleContext":"all","ModuleClassName":"blcAnyPostContainerManager","ModuleID":"post","file":"","ModuleLazyInit":false,"ModulePriority":0,"ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"TextDomain":"broken-link-checker","virtual":true},"page":{"Name":"P\u00e1ginas","ModuleCategory":"container","ModuleContext":"all","ModuleClassName":"blcAnyPostContainerManager","ModuleID":"page","file":"","ModuleLazyInit":false,"ModulePriority":0,"ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"TextDomain":"broken-link-checker","virtual":true},"dummy":{"ModuleID":"dummy","ModuleCategory":"container","ModuleContext":"all","ModuleLazyInit":false,"ModuleClassName":"blcDummyManager","ModulePriority":0,"ModuleCheckerUrlPattern":"","ModuleHidden":true,"ModuleAlwaysActive":true,"ModuleRequiresPro":false,"Name":"Dummy","PluginURI":"","Version":"1.0","Description":"","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"Dummy","AuthorName":"Janis Elsts","file":"containers\/dummy.php"}},"module_deactivated_when":{"custom_field":1394899726},"plugin_news":["Admin Menu Editor","http:\/\/wordpress.org\/extend\/plugins\/admin-menu-editor\/"]}', 'yes'); 
INSERT INTO `wp_options` VALUES ('163', 'blc_installation_log', 'a:54:{i:0;a:3:{i:0;i:1;i:1;s:40:"Plugin activated at 2014-03-15 16:08:45.";i:2;N;}i:1;a:3:{i:0;i:1;i:1;s:27:"Installation/update begins.";i:2;N;}i:2;a:3:{i:0;i:1;i:1;s:25:"Upgrading the database...";i:2;N;}i:3;a:3:{i:0;i:1;i:1;s:222:" [OK] 	
	CREATE TABLE IF NOT EXISTS `wp_blc_filters` (
		`id` int(10) unsigned NOT NULL AUTO_INCREMENT,
		`name` varchar(100) NOT NULL,
		`params` text NOT NULL,
		
		PRIMARY KEY (`id`)
	) DEFAULT CHARACTER SET utf8";i:2;N;}i:4;a:3:{i:0;i:1;i:1;s:689:" [OK] 
	
	CREATE TABLE IF NOT EXISTS `wp_blc_instances` (
		`instance_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
		`link_id` int(10) unsigned NOT NULL,
		`container_id` int(10) unsigned NOT NULL,
		`container_type` varchar(40) NOT NULL DEFAULT \'post\',
		`link_text` varchar(250) NOT NULL DEFAULT \'\',
		`parser_type` varchar(40) NOT NULL DEFAULT \'link\',
		`container_field` varchar(250) NOT NULL DEFAULT \'\',
		`link_context` varchar(250) NOT NULL DEFAULT \'\',
		`raw_url` text NOT NULL,
		  
		PRIMARY KEY (`instance_id`),
		KEY `link_id` (`link_id`),
		KEY `source_id` (`container_type`, `container_id`),
		KEY `parser_type` (`parser_type`)
	) DEFAULT CHARACTER SET utf8";i:2;N;}i:5;a:3:{i:0;i:1;i:1;s:1402:" [OK] 
	
	CREATE TABLE IF NOT EXISTS `wp_blc_links` (
		`link_id` int(20) unsigned NOT NULL AUTO_INCREMENT,
		`url` text CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
		`first_failure` datetime NOT NULL DEFAULT \'0000-00-00 00:00:00\',
		`last_check` datetime NOT NULL DEFAULT \'0000-00-00 00:00:00\',
		`last_success` datetime NOT NULL DEFAULT \'0000-00-00 00:00:00\',
		`last_check_attempt` datetime NOT NULL DEFAULT \'0000-00-00 00:00:00\',
		`check_count` int(4) unsigned NOT NULL DEFAULT \'0\',
		`final_url` text CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
		`redirect_count` smallint(5) unsigned NOT NULL DEFAULT \'0\',
		`log` text NOT NULL,
		`http_code` smallint(6) NOT NULL DEFAULT \'0\',
		`status_code` varchar(100) DEFAULT \'\',
		`status_text` varchar(250) DEFAULT \'\',
		`request_duration` float NOT NULL DEFAULT \'0\',
		`timeout` tinyint(1) unsigned NOT NULL DEFAULT \'0\',
		`broken` tinyint(1) NOT NULL DEFAULT \'0\',
		`may_recheck` tinyint(1) NOT NULL DEFAULT \'1\',
		`being_checked` tinyint(1) NOT NULL DEFAULT \'0\',

		`result_hash` varchar(200) NOT NULL DEFAULT \'\',
		`false_positive` tinyint(1) NOT NULL DEFAULT \'0\',
		`dismissed` tinyint(1) NOT NULL DEFAULT \'0\',
		
		PRIMARY KEY (`link_id`),
		KEY `url` (`url`(150)),
		KEY `final_url` (`final_url`(150)),
		KEY `http_code` (`http_code`),
		KEY `broken` (`broken`)
	) DEFAULT CHARACTER SET utf8";i:2;N;}i:6;a:3:{i:0;i:1;i:1;s:364:" [OK] 
	
	CREATE TABLE IF NOT EXISTS `wp_blc_synch` (
		`container_id` int(20) unsigned NOT NULL,
		`container_type` varchar(40) NOT NULL,
		`synched` tinyint(2) unsigned NOT NULL,
		`last_synch` datetime NOT NULL DEFAULT \'0000-00-00 00:00:00\',
		
		PRIMARY KEY (`container_type`,`container_id`),
		KEY `synched` (`synched`)
	) DEFAULT CHARACTER SET utf8";i:2;N;}i:7;a:3:{i:0;i:1;i:1;s:24:"Database schema updated.";i:2;N;}i:8;a:3:{i:0;i:1;i:1;s:31:"Database successfully upgraded.";i:2;N;}i:9;a:3:{i:0;i:1;i:1;s:27:"Cleaning up the database...";i:2;N;}i:10;a:3:{i:0;i:1;i:1;s:38:"... Deleting invalid container records";i:2;N;}i:11;a:3:{i:0;i:0;i:1;s:27:"... 0 synch records deleted";i:2;N;}i:12;a:3:{i:0;i:1;i:1;s:35:"... Deleting invalid link instances";i:2;N;}i:13;a:3:{i:0;i:0;i:1;s:23:"... 0 instances deleted";i:2;N;}i:14;a:3:{i:0;i:0;i:1;s:28:"... 0 more instances deleted";i:2;N;}i:15;a:3:{i:0;i:1;i:1;s:27:"... Deleting orphaned links";i:2;N;}i:16;a:3:{i:0;i:0;i:1;s:19:"... 0 links deleted";i:2;N;}i:17;a:3:{i:0;i:1;i:1;s:20:"Notifying modules...";i:2;N;}i:18;a:3:{i:0;i:0;i:1;s:25:"... Updating module cache";i:2;N;}i:19;a:3:{i:0;i:0;i:1;s:27:"... Notifying module "http"";i:2;N;}i:20;a:3:{i:0;i:0;i:1;s:27:"... Notifying module "link"";i:2;N;}i:21;a:3:{i:0;i:0;i:1;s:59:"...... Parser "link" is marking relevant items as unsynched";i:2;N;}i:22;a:3:{i:0;i:0;i:1;s:272:"...... Executing query: UPDATE wp_blc_synch SET synched = 0 WHERE (container_type = \'page\' AND last_synch >= \'1970-01-01 00:00:00\') OR (container_type = \'post\' AND last_synch >= \'1970-01-01 00:00:00\') OR (container_type = \'comment\' AND last_synch >= \'1970-01-01 00:00:00\')";i:2;N;}i:23;a:3:{i:0;i:0;i:1;s:37:"...... 0 rows affected, 0.000 seconds";i:2;N;}i:24;a:3:{i:0;i:0;i:1;s:28:"... Notifying module "image"";i:2;N;}i:25;a:3:{i:0;i:0;i:1;s:60:"...... Parser "image" is marking relevant items as unsynched";i:2;N;}i:26;a:3:{i:0;i:0;i:1;s:272:"...... Executing query: UPDATE wp_blc_synch SET synched = 0 WHERE (container_type = \'page\' AND last_synch >= \'1970-01-01 00:00:00\') OR (container_type = \'post\' AND last_synch >= \'1970-01-01 00:00:00\') OR (container_type = \'comment\' AND last_synch >= \'1970-01-01 00:00:00\')";i:2;N;}i:27;a:3:{i:0;i:0;i:1;s:37:"...... 0 rows affected, 0.000 seconds";i:2;N;}i:28;a:3:{i:0;i:0;i:1;s:31:"... Notifying module "metadata"";i:2;N;}i:29;a:3:{i:0;i:0;i:1;s:63:"...... Parser "metadata" is marking relevant items as unsynched";i:2;N;}i:30;a:3:{i:0;i:0;i:1;s:32:"... Notifying module "url_field"";i:2;N;}i:31;a:3:{i:0;i:0;i:1;s:64:"...... Parser "url_field" is marking relevant items as unsynched";i:2;N;}i:32;a:3:{i:0;i:0;i:1;s:134:"...... Executing query: UPDATE wp_blc_synch SET synched = 0 WHERE (container_type = \'comment\' AND last_synch >= \'1970-01-01 00:00:00\')";i:2;N;}i:33;a:3:{i:0;i:0;i:1;s:37:"...... 0 rows affected, 0.000 seconds";i:2;N;}i:34;a:3:{i:0;i:0;i:1;s:30:"... Notifying module "comment"";i:2;N;}i:35;a:3:{i:0;i:0;i:1;s:51:"...... Deleting synch. records for removed comments";i:2;N;}i:36;a:3:{i:0;i:0;i:1;s:22:"...... 0 rows affected";i:2;N;}i:37;a:3:{i:0;i:0;i:1;s:47:"...... Creating synch. records for new comments";i:2;N;}i:38;a:3:{i:0;i:0;i:1;s:22:"...... 1 rows affected";i:2;N;}i:39;a:3:{i:0;i:0;i:1;s:27:"... Notifying module "post"";i:2;N;}i:40;a:3:{i:0;i:0;i:1;s:47:"...... Deleting synch records for removed posts";i:2;N;}i:41;a:3:{i:0;i:0;i:1;s:21:"...... 0 rows deleted";i:2;N;}i:42;a:3:{i:0;i:0;i:1;s:41:"...... Marking changed posts as unsynched";i:2;N;}i:43;a:3:{i:0;i:0;i:1;s:21:"...... 0 rows updated";i:2;N;}i:44;a:3:{i:0;i:0;i:1;s:43:"...... Creating synch records for new posts";i:2;N;}i:45;a:3:{i:0;i:0;i:1;s:22:"...... 2 rows inserted";i:2;N;}i:46;a:3:{i:0;i:0;i:1;s:27:"... Notifying module "page"";i:2;N;}i:47;a:3:{i:0;i:0;i:1;s:74:"...... Skipping "page" resyncyh since all post types were already synched.";i:2;N;}i:48;a:3:{i:0;i:0;i:1;s:28:"... Notifying module "dummy"";i:2;N;}i:49;a:3:{i:0;i:1;i:1;s:38:"Updating server load limit settings...";i:2;N;}i:50;a:3:{i:0;i:1;i:1;s:26:"Optimizing the database...";i:2;N;}i:51;a:3:{i:0;i:1;i:1;s:26:"Completing installation...";i:2;N;}i:52;a:3:{i:0;i:1;i:1;s:20:"Configuration saved.";i:2;N;}i:53;a:3:{i:0;i:1;i:1;s:78:"Installation/update completed at 2014-03-15 16:08:53 with 26 queries executed.";i:2;N;}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('165', 'bup_db_version', '0.4.1', 'yes'); 
INSERT INTO `wp_options` VALUES ('166', 'bup_db_installed', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('168', '_transient_twentyfourteen_category_count', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('169', 'excerpt_everywhere_length', '500', 'yes'); 
INSERT INTO `wp_options` VALUES ('170', 'excerpt_everywhere_align', 'alignleft', 'yes'); 
INSERT INTO `wp_options` VALUES ('171', 'excerpt_everywhere_moretext', 'Detalhes [...]', 'yes'); 
INSERT INTO `wp_options` VALUES ('172', 'excerpt_everywhere_moreimg', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('173', 'excerpt_everywhere_rss', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES ('174', 'excerpt_everywhere_homepage', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('175', 'excerpt_everywhere_sticky', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('176', 'excerpt_everywhere_thumb', 'none', 'yes'); 
INSERT INTO `wp_options` VALUES ('185', 'gadash_options', '{"ga_dash_apikey":"","ga_dash_clientid":"","ga_dash_clientsecret":"","ga_dash_access_front":"manage_options","ga_dash_access_back":"manage_options","ga_dash_tableid_jail":"","ga_dash_pgd":0,"ga_dash_rd":0,"ga_dash_sd":0,"ga_dash_map":0,"ga_dash_traffic":0,"ga_dash_style":"#3366CC","ga_dash_jailadmins":1,"ga_dash_cachetime":3600,"ga_dash_tracking":1,"ga_dash_tracking_type":"classic","ga_dash_default_ua":"","ga_dash_anonim":0,"ga_dash_userapi":0,"ga_event_tracking":0,"ga_event_downloads":"zip|mp3|mpeg|pdf|doc*|ppt*|xls*|jpeg|png|gif|tiff","ga_track_exclude":"manage_options","ga_target_geomap":"","ga_target_number":10,"ga_realtime_pages":10,"ga_dash_token":"","ga_dash_refresh_token":"","ga_dash_profile_list":"","ga_dash_tableid":"","ga_dash_frontend_keywords":0,"ga_tracking_code":"","ga_enhanced_links":0,"ga_dash_default_metric":"visits","ga_dash_default_dimension":"30daysAgo","ga_dash_frontend_stats":0}', 'yes'); 
INSERT INTO `wp_options` VALUES ('186', 'seo_friendly_images_alt', '%name %title', 'yes'); 
INSERT INTO `wp_options` VALUES ('187', 'seo_friendly_images_title', '%title', 'yes'); 
INSERT INTO `wp_options` VALUES ('188', 'seo_friendly_images_override', 'on', 'yes'); 
INSERT INTO `wp_options` VALUES ('189', 'seo_friendly_images_override_title', 'off', 'yes'); 
INSERT INTO `wp_options` VALUES ('190', 'excerpt_everywhere_class', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('191', 'bup_re_used', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('192', '_transient_random_seed', '85e0e1ce2543b87c743542d7b2db649a', 'yes'); 
INSERT INTO `wp_options` VALUES ('198', 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1394900750;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('199', 'current_theme', 'Twenty Twelve', 'yes'); 
INSERT INTO `wp_options` VALUES ('200', 'theme_mods_twentytwelve', 'a:5:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:12:"header_image";s:64:"http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg";s:17:"header_image_data";a:5:{s:13:"attachment_id";i:61;s:3:"url";s:64:"http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg";s:13:"thumbnail_url";s:64:"http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg";s:5:"width";i:229;s:6:"height";i:76;}s:16:"header_textcolor";s:5:"blank";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('201', 'theme_switched', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('202', 'sm_options', 'a:56:{s:18:"sm_b_prio_provider";s:41:"GoogleSitemapGeneratorPrioByCountProvider";s:13:"sm_b_filename";s:11:"sitemap.xml";s:10:"sm_b_debug";b:1;s:8:"sm_b_xml";b:1;s:9:"sm_b_gzip";b:1;s:9:"sm_b_ping";b:1;s:12:"sm_b_pingmsn";b:1;s:19:"sm_b_manual_enabled";b:0;s:17:"sm_b_auto_enabled";b:1;s:15:"sm_b_auto_delay";b:1;s:15:"sm_b_manual_key";s:32:"0b0518f847adc712682d32a70b511966";s:11:"sm_b_memory";s:0:"";s:9:"sm_b_time";i:-1;s:14:"sm_b_max_posts";i:-1;s:13:"sm_b_safemode";b:0;s:18:"sm_b_style_default";b:1;s:10:"sm_b_style";s:0:"";s:11:"sm_b_robots";b:1;s:12:"sm_b_exclude";a:0:{}s:17:"sm_b_exclude_cats";a:0:{}s:18:"sm_b_location_mode";s:4:"auto";s:20:"sm_b_filename_manual";s:0:"";s:19:"sm_b_fileurl_manual";s:0:"";s:10:"sm_in_home";b:1;s:11:"sm_in_posts";b:1;s:15:"sm_in_posts_sub";b:0;s:11:"sm_in_pages";b:1;s:10:"sm_in_cats";b:0;s:10:"sm_in_arch";b:0;s:10:"sm_in_auth";b:0;s:10:"sm_in_tags";b:0;s:9:"sm_in_tax";a:0:{}s:17:"sm_in_customtypes";a:0:{}s:13:"sm_in_lastmod";b:1;s:10:"sm_cf_home";s:5:"daily";s:11:"sm_cf_posts";s:7:"monthly";s:11:"sm_cf_pages";s:6:"weekly";s:10:"sm_cf_cats";s:6:"weekly";s:10:"sm_cf_auth";s:6:"weekly";s:15:"sm_cf_arch_curr";s:5:"daily";s:14:"sm_cf_arch_old";s:6:"yearly";s:10:"sm_cf_tags";s:6:"weekly";s:10:"sm_pr_home";d:1;s:11:"sm_pr_posts";d:0.59999999999999997779553950749686919152736663818359375;s:15:"sm_pr_posts_min";d:0.200000000000000011102230246251565404236316680908203125;s:11:"sm_pr_pages";d:0.59999999999999997779553950749686919152736663818359375;s:10:"sm_pr_cats";d:0.299999999999999988897769753748434595763683319091796875;s:10:"sm_pr_arch";d:0.299999999999999988897769753748434595763683319091796875;s:10:"sm_pr_auth";d:0.299999999999999988897769753748434595763683319091796875;s:10:"sm_pr_tags";d:0.299999999999999988897769753748434595763683319091796875;s:12:"sm_i_donated";b:0;s:17:"sm_i_hide_donated";b:0;s:17:"sm_i_install_date";i:1394901253;s:14:"sm_i_hide_note";b:0;s:15:"sm_i_hide_works";b:0;s:16:"sm_i_hide_donors";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('205', 'sm_status', 'O:28:"GoogleSitemapGeneratorStatus":24:{s:10:"_startTime";d:1395331925.0501019954681396484375;s:8:"_endTime";d:1395331927.213993072509765625;s:11:"_hasChanged";b:1;s:12:"_memoryUsage";i:28573696;s:9:"_lastPost";i:31;s:9:"_lastTime";d:1395331926.185309886932373046875;s:8:"_usedXml";b:1;s:11:"_xmlSuccess";b:1;s:8:"_xmlPath";s:32:"C:/xampp/htdocs/asug/sitemap.xml";s:7:"_xmlUrl";s:33:"http://127.0.0.1/asug/sitemap.xml";s:8:"_usedZip";b:1;s:11:"_zipSuccess";b:1;s:8:"_zipPath";s:35:"C:/xampp/htdocs/asug/sitemap.xml.gz";s:7:"_zipUrl";s:36:"http://127.0.0.1/asug/sitemap.xml.gz";s:11:"_usedGoogle";b:1;s:10:"_googleUrl";s:101:"http://www.google.com/webmasters/sitemaps/ping?sitemap=http%3A%2F%2F127.0.0.1%2Fasug%2Fsitemap.xml.gz";s:15:"_gooogleSuccess";b:1;s:16:"_googleStartTime";d:1395331926.3359699249267578125;s:14:"_googleEndTime";d:1395331926.7244739532470703125;s:8:"_usedMsn";b:1;s:7:"_msnUrl";s:94:"http://www.bing.com/webmaster/ping.aspx?siteMap=http%3A%2F%2F127.0.0.1%2Fasug%2Fsitemap.xml.gz";s:11:"_msnSuccess";b:1;s:13:"_msnStartTime";d:1395331926.7544500827789306640625;s:11:"_msnEndTime";d:1395331927.1142990589141845703125;}', 'no'); 
INSERT INTO `wp_options` VALUES ('222', 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('263', 'sam_pointers', 'a:4:{s:6:"places";b:0;s:3:"ads";b:0;s:5:"zones";b:0;s:6:"blocks";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('265', '_transient_timeout_sam_maintenance_date', '1396317602', 'no'); 
INSERT INTO `wp_options` VALUES ('266', '_transient_sam_maintenance_date', '1 de April de 2014 02:00', 'no'); 
INSERT INTO `wp_options` VALUES ('276', 'adrotate_db_timer', '1394949155', 'yes'); 
INSERT INTO `wp_options` VALUES ('281', '_transient_timeout_feed_b0c4de94b1cd78ed7eb394a67d5f052b', '1394992385', 'no'); 
INSERT INTO `wp_options` VALUES ('282', '_transient_feed_b0c4de94b1cd78ed7eb394a67d5f052b', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"AdRotate for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:29:"http://www.adrotateplugin.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:26:"Be better in ad management";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 16 Mar 2014 02:55:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.8.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"New licenses and a sale!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/BHaSswWStPQ/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:71:"http://www.adrotateplugin.com/2014/03/new-licenses-and-a-sale/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 09 Mar 2014 20:27:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:3:"pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"sale";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"upgrade";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11752";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:600:"<p>Starting March 10th 2014 a sale for the rest of the month to introduce the new Network License and the renewed Developer License. Network License The Network License is essentially a Single License but with the big advantage of being able to &#8220;Network Activate&#8221; the plugin. Making AdRotate Pro available throughout your entire network of [&#8230;]</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/new-licenses-and-a-sale/">New licenses and a sale!</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1878:"<p>Starting March 10th 2014 a sale for the rest of the month to introduce the new <a href="http://www.adrotateplugin.com/shop/adrotate-plugin/adrotate-pro-network/" title="AdRotate Pro (Network)">Network License</a> and the renewed <a href="http://www.adrotateplugin.com/shop/adrotate-plugin/adrotate-pro-developer/" title="AdRotate Pro (Developer)">Developer License</a>.</p>
<h3>Network License</h3>
<p>The Network License is essentially a Single License but with the big advantage of being able to &#8220;Network Activate&#8221; the plugin. Making AdRotate Pro available throughout your entire network of blogs instantly. There is no limit on the amount of blogs.<br />
Available for € 199 (€ 149 from March 10th through March 31st 2014).<br />
<a href="http://www.adrotateplugin.com/shop/adrotate-plugin/adrotate-pro-network/" title="AdRotate Pro (Network)">Buy now &raquo;</a></p>
<h3>Developer License</h3>
<p>The developer license works as before but now also supports unlimited network activations. If you manage multiple networks in WordPress this is the one to get.<br />
Available for € 299 (€ 249 from March 10th through March 31st 2014).<br />
<a href="http://www.adrotateplugin.com/shop/adrotate-plugin/adrotate-pro-developer/" title="AdRotate Pro (Developer)">Buy now &raquo;</a></p>
<h3>The other licenses</h3>
<p>All other licenses support Multisite on a blog (instance, or multiple if you use the Duo or Multi license) but can not be network activated.</p>
<p>(All prices are including VAT where applicable)</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/new-licenses-and-a-sale/">New licenses and a sale!</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/BHaSswWStPQ" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.adrotateplugin.com/2014/03/new-licenses-and-a-sale/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.adrotateplugin.com/2014/03/new-licenses-and-a-sale/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"AdRotate Pro 3.9.8 and AdRotate Free 3.9.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/0VzrjbdqJHQ/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.adrotateplugin.com/2014/03/adrotate-pro-3-9-8-and-adrotate-free-3-9-7/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 09 Mar 2014 20:19:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:7:"Updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"bugfix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"free";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:3:"pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:6:"update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11750";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:636:"<p>A number of bugfixes and tweaks for both versions. Optimized Javascript and of course &#8211; Multisite support for everyone. Network admins If you use a Multisite network with WordPress benefit this month from the special introduction price for the Network license. Valid from March 10th through March 31st 2014. Compare all licenses side by side [&#8230;]</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/adrotate-pro-3-9-8-and-adrotate-free-3-9-7/">AdRotate Pro 3.9.8 and AdRotate Free 3.9.7</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2381:"<p>A number of bugfixes and tweaks for both versions. Optimized Javascript and of course &#8211; Multisite support for everyone.</p>
<h3>Network admins</h3>
<p>If you use a Multisite network with WordPress benefit this month from the special introduction price for the <a href="http://www.adrotateplugin.com/shop/adrotate-plugin/adrotate-pro-network/" title="AdRotate Pro (Network)">Network license</a>. Valid from March 10th through March 31st 2014.<br />
Compare all licenses side by side <a href="http://www.adrotateplugin.com/adrotate-pro/" title="AdRotate Pro">here</a>.</p>
<h3>AdRotate Pro</h3>
<div class="shortcode-unorderedlist arrow"></p>
<ul>
<li>AdRotate 3.7.x no longer supported for upgrades</li>
<li>[new] Full multisite compatibility</li>
<li>[fix] Better responsive sizing for Dynamic and Block groups</li>
<li>[fix] Advertiser banners now get proper image paths</li>
<li>[fix] Clear displaying of advertiser error states</li>
<li>[fix] Improved click detection for Dynamic groups</li>
<li>[fix] Default access roles now set correct</li>
<li>[fix] Improved database engine detection for new installations</li>
</ul>
<p></div>

<h3>AdRotate Free</h3>
<div class="shortcode-unorderedlist arrow"></p>
<ul>
<li>AdRotate 3.7.x no longer supported for upgrades</li>
<li>[change] Prettied up the settings page</li>
<li>[change] Optimized and updated jQuery.jshowoff library</li>
<li>[change] Rebranded jQuery.jshowoff to jQuery.jshowoff.adrotate for compatibility</li>
<li>[new] Same dynamic group can now be used more than once on a page</li>
<li>[new] Full multisite compatibility</li>
<li>[fix] Better responsive sizing for Dynamic and Block groups</li>
<li>[fix] Various missing stripslashes() for displaying names</li>
<li>[fix] Some &#8220;cancel&#8221; buttons going the wrong way</li>
<li>[fix] Improved click detection for Dynamic groups</li>
<li>[fix] Default access roles now set correct</li>
<li>[fix] Improved database engine detection for new installations</li>
</ul>
<p></div>

<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/adrotate-pro-3-9-8-and-adrotate-free-3-9-7/">AdRotate Pro 3.9.8 and AdRotate Free 3.9.7</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/0VzrjbdqJHQ" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:86:"http://www.adrotateplugin.com/2014/03/adrotate-pro-3-9-8-and-adrotate-free-3-9-7/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.adrotateplugin.com/2014/03/adrotate-pro-3-9-8-and-adrotate-free-3-9-7/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"Upcoming: Full multisite support and fixes for clicktracking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/PSZPnbaIMZw/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:107:"http://www.adrotateplugin.com/2014/03/upcoming-full-multisite-support-and-fixes-for-clicktracking/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 08 Mar 2014 21:11:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"free";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"license";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"multisite";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:3:"pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:7:"updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11731";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:672:"<p>With the ongoing flurry of questions about WordPress multisite I&#8217;ve spent the last week or so figuring out how multisite actually works and am now testing AdRotate and AdRotate Pro with Multisite. The support for Multisite will be full featured with each instance having it&#8217;s own separate data-set and settings &#8211; Just as it should [&#8230;]</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/upcoming-full-multisite-support-and-fixes-for-clicktracking/">Upcoming: Full multisite support and fixes for clicktracking</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3528:"<p>With the ongoing flurry of questions about WordPress multisite I&#8217;ve spent the last week or so figuring out how multisite actually works and am now testing AdRotate and AdRotate Pro with Multisite.<br />
The support for Multisite will be full featured with each instance having it&#8217;s own separate data-set and settings &#8211; Just as it should be. Due to good coding practise AdRotate was mostly compatible already, with the exception of Network Activated setups. This will be added in the next version.</p>
<p>On top of that, a nasty flaw with clicktracking was discovered by a few users. This has been fixed with all new code for Dynamic groups to make Dynamic groups more efficient but also compatible with clicktracking &#8211; Clicks weren&#8217;t always recorded for dynamic groups. These patches have been tested over the past 2 weeks with great success on various users sites who were kind enough to give me access their servers to try and figure this out.</p>
<h3>Multisite for AdRotate Pro</h3>
<p>With the coming addition for Multisite a few things have to change for the AdRotate Pro licenses, too.<br />
For Single, Duo and Multi licenses not much will change other than that it&#8217;s now officially supported on Multisite instances.</p>
<p>The developer License will also support network activation and can be activated on unlimited networks and blogs within that network. With this expanded functionality and the included freedoms in the license the price will be raised to €299 (up from €199).<br />
All existing Developer licenses will have the benefits of the renewed Developer options at no extra cost.</p>
<p>To make things accessible for network administrators, a new mid-tier license will be introduced specifically for Multisite setups. This license can be used on 1 network and unlimited blogs within that network. Every user will have the full set of features of AdRotate Pro at his/her disposal. However, you yourself are responsible for supporting the individual blogs. The ticket support option will be hidden from your users. The price for this license will be €199.<br />
This option is also interesting for network admins who have all their sites in one network and plan to use AdRotate Pro on 6 or more blogs in that network.</p>
<p>The new licenses are laid out on the <a href="http://www.adrotateplugin.com/adrotate-pro/" title="AdRotate Pro">AdRotate Pro page</a>.<br />
The network license will be available soon.</p>
<h3>Sale! sale! sale!</h3>
<p>Both the Developer and Network license will be on sale from March 10th throughout 31st of March 2014 for a special introduction price. Check out the <a href="http://www.adrotateplugin.com/shop/category/adrotate-plugin/">AdRotate Pro store</a>.</p>
<h3>Follow development</h3>
<p>Curious to see if the upcoming versions do and what will change? Check out the <a href="http://www.adrotateplugin.com/development/" title="Development">development page</a>.<br />
Also for all up-to-date news and information simply subscribe to the blogs RSS feeds.</p>
<p>(All mentioned prices including VAT where applicable)</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/upcoming-full-multisite-support-and-fixes-for-clicktracking/">Upcoming: Full multisite support and fixes for clicktracking</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/PSZPnbaIMZw" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:103:"http://www.adrotateplugin.com/2014/03/upcoming-full-multisite-support-and-fixes-for-clicktracking/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:98:"http://www.adrotateplugin.com/2014/03/upcoming-full-multisite-support-and-fixes-for-clicktracking/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"GeoLocation for AdRotate Pro extended";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/HCTjaxaGBh8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:85:"http://www.adrotateplugin.com/2014/03/geolocation-for-adrotate-pro-extended/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 05 Mar 2014 22:44:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:3:"geo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"geolocation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:3:"pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11677";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:619:"<p>Based on mixed feedback from several users about FreegeoIP and it&#8217;s lack of accuracy for certain areas. Ireland and some South American countries for example. Someone suggested adding GeoSelect as an option. Luckily they offer a nice API for it. GeoSelect which is governed and developed by GeoBytes is a premium service where you buy [&#8230;]</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/geolocation-for-adrotate-pro-extended/">GeoLocation for AdRotate Pro extended</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1671:"<p>Based on mixed feedback from several users about FreegeoIP and it&#8217;s lack of accuracy for certain areas. Ireland and some South American countries for example. Someone suggested adding GeoSelect as an option. Luckily they offer a nice API for it. </p>
<p><a href="http://www.adrotateplugin.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-05-at-23.38.25.png" rel="lightbox-0"><img src="http://www.adrotateplugin.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-05-at-23.38.25.png" alt="Screen Shot 2014-03-05 at 23.38.25" width="802" height="223" class="alignnone size-full wp-image-11678" /></a></p>
<p>GeoSelect which is governed and developed by <a href="http://www.geobytes.com" title="GeoBytes" target="_blank">GeoBytes</a> is a premium service where you buy MapBytes (their form of credits) Each credit is worth a number of requests. This means you can keep it as cheap or make it as expensive as you need. No silly multi-hundred-dollar contracts etc. Just pay as you go.<br />
Reportedly their database is super accurate so that&#8217;s a good thing. And they do not use MaxMind which FreegeoIP already uses. So if FreegeoIP (Which is free) doesn&#8217;t work for you, GeoSelect is a proper alternative.</p>
<p>GeoSelect will be available in a near future version of AdRotate Pro.</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/geolocation-for-adrotate-pro-extended/">GeoLocation for AdRotate Pro extended</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/HCTjaxaGBh8" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.adrotateplugin.com/2014/03/geolocation-for-adrotate-pro-extended/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:76:"http://www.adrotateplugin.com/2014/03/geolocation-for-adrotate-pro-extended/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Multisite now a possibility?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/16sY3QGa_pI/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://www.adrotateplugin.com/2014/03/multisite-now-a-possibility/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 05 Mar 2014 22:36:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"adrotate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"multisite";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:3:"pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11674";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:581:"<p>While continuing to iron out some kinks with Clicktracking I&#8217;ve not been sitting still with other stuff&#8230; Behold the multisite! - #AdRotate Results! pic.twitter.com/lpbMVkh1ZR &#8212; AJdG Solutions (@AJdGSolutions) March 5, 2014 This is very early in testing on AdRotate Pro. But it seems the database stuff is working.</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/multisite-now-a-possibility/">Multisite now a possibility?</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1041:"<p>While continuing to iron out some kinks with Clicktracking I&#8217;ve not been sitting still with other stuff&#8230;<br />
Behold the multisite! -</p>
<blockquote class="twitter-tweet" width="500"><p><a href="https://twitter.com/search?q=%23AdRotate&amp;src=hash">#AdRotate</a> Results! <a href="http://t.co/lpbMVkh1ZR">pic.twitter.com/lpbMVkh1ZR</a></p>
<p>&mdash; AJdG Solutions (@AJdGSolutions) <a href="https://twitter.com/AJdGSolutions/statuses/441340385747812352">March 5, 2014</a></p></blockquote>
<p><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script></p>
<p>This is very early in testing on AdRotate Pro. But it seems the database stuff is working.</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/03/multisite-now-a-possibility/">Multisite now a possibility?</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/16sY3QGa_pI" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://www.adrotateplugin.com/2014/03/multisite-now-a-possibility/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:66:"http://www.adrotateplugin.com/2014/03/multisite-now-a-possibility/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"Your adverts are wrong! Fix it before your advertisers find out!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/I1PkB6J9Nr4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:110:"http://www.adrotateplugin.com/2014/02/your-adverts-are-wrong-fix-it-before-your-advertisers-find-out/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 26 Feb 2014 23:01:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:4:"News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"adverts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"fix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:5:"setup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:5:"wrong";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11569";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:629:"<p>Over the past few weeks there has been a huge influx of traffic to my business site www.ajdg.net, originating from a number of sites that have nothing to do with me. Turns out they&#8217;re all AdRotate (Pro) users. Looking into that further, it turns out that a whole bunch of their ads are set up [&#8230;]</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/your-adverts-are-wrong-fix-it-before-your-advertisers-find-out/">Your adverts are wrong! Fix it before your advertisers find out!</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2856:"<p>Over the past few weeks there has been a huge influx of traffic to my business site <a href="http://www.ajdg.net" title="AJdG Solutions" target="_blank">www.ajdg.net</a>, originating from a number of sites that have nothing to do with me. Turns out they&#8217;re all AdRotate (Pro) users.<br />
Looking into that further, it turns out that a whole bunch of their ads are set up wrong and people blindly use the provided code examples without swapping out my URL with their own.</p>
<p>I don&#8217;t mind the traffic, but I bet your advertisers won&#8217;t be too happy once they find out they paid for ads that link to the wrong site&#8230; So fix it <img src="http://www.adrotateplugin.com/wp-includes/images/smilies/icon_wink.gif" alt=";)" class="wp-smiley" /> </p>
<h3>How to fix?</h3>
<p>It&#8217;s simple. Check any recently created ads. Look in the adcode specifically. You&#8217;ll probably see something like:</p>

<div class="wp_syntax"><table><tr><td class="code"><pre class="text" style="font-family:monospace;">&lt;a href=&quot;http://www.ajdg.net/&quot;&gt;&lt;img src=&quot;%image&quot; /&gt;&lt;/a&gt;</pre></td></tr></table></div>

<p>Obviously you have to swap out the www.ajdg.net bit with where-ever the ad has to link to.<br />
More information on how you create adverts can be found here: <a href="http://www.adrotateplugin.com/support/knowledgebase/creating-adverts/" title="Creating Adverts">Creating adverts/</a>.</p>
<h3>But I use %link%</h3>
<p>Then you&#8217;re not affected at all.<br />
However, if you&#8217;re still using %link% in your ads that&#8217;s fine. For the time being that still works. But you are encouraged to do away with that deprecated tag. In a future version it will be removed and then your ad won&#8217;t work at all.<br />
I would let current ads that use it run out &#8211; Unless they run for another year or two. But when you create new ads put the target url in the adcode.</p>
<h3>New clicktracker</h3>
<p>To Re-iterate the recent changes;<br />
<a href="http://www.adrotateplugin.com/2014/01/the-new-click-tracking-explained/" title="The new click tracking explained">www.adrotateplugin.com/2014/01/the-new-click-tracking-explained/</a><br />
<a href="http://www.adrotateplugin.com/2014/01/adrotate-pro-3-9-2-and-adrotate-free-3-9-1/" title="AdRotate Pro 3.9.2 and AdRotate Free 3.9.1">http://www.adrotateplugin.com/2014/01/adrotate-pro-3-9-2-and-adrotate-free-3-9-1/</a></p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/your-adverts-are-wrong-fix-it-before-your-advertisers-find-out/">Your adverts are wrong! Fix it before your advertisers find out!</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/I1PkB6J9Nr4" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:106:"http://www.adrotateplugin.com/2014/02/your-adverts-are-wrong-fix-it-before-your-advertisers-find-out/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:101:"http://www.adrotateplugin.com/2014/02/your-adverts-are-wrong-fix-it-before-your-advertisers-find-out/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Bitesize Bio uses AdRotate Pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/lN7FDvhRibU/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.adrotateplugin.com/2014/02/bitesize-bio-uses-adrotate-pro/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 22 Feb 2014 11:14:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:8:"Showcase";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"demo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"featured";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:3:"pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"showcase";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11502";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:580:"<p>Take a look at Bitesize Bio. The premier online magazine for the Biotech Industry providing tips, tricks and loads of useful information. Check out the showcase page for their and other great sites that use AdRotate in all kinds of ways. What’s this? The Showcase page is meant to show you how people use AdRotate [&#8230;]</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/bitesize-bio-uses-adrotate-pro/">Bitesize Bio uses AdRotate Pro</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1304:"<p><a href="http://www.adrotateplugin.com/wp-content/uploads/2013/04/showcase-bitesizebio.png" rel="lightbox-0"><img src="http://www.adrotateplugin.com/wp-content/uploads/2013/04/showcase-bitesizebio.png" alt="showcase-bitesizebio" width="250" height="126" class="alignleft size-full wp-image-11500" /></a>Take a look at Bitesize Bio. The premier online magazine for the Biotech Industry providing tips, tricks and loads of useful information.</p>
<p>Check out the <a href="http://www.adrotateplugin.com/showcase/" title="Showcase">showcase page</a> for their and other great sites that use AdRotate in all kinds of ways.</p>
<h4>What’s this?</h4>
<p>The Showcase page is meant to show you how people use AdRotate and what AdRotate can do for you. The page will feature both users using AdRotate Pro and AdRotate Free.<br />
Think you should be on there as well? <a href="http://www.adrotateplugin.com/contact/" title="Contact">Let me know</a>!</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/bitesize-bio-uses-adrotate-pro/">Bitesize Bio uses AdRotate Pro</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/lN7FDvhRibU" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"http://www.adrotateplugin.com/2014/02/bitesize-bio-uses-adrotate-pro/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:69:"http://www.adrotateplugin.com/2014/02/bitesize-bio-uses-adrotate-pro/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Knowledge base refreshed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/jMOgOTMJt9k/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:72:"http://www.adrotateplugin.com/2014/02/knowledge-base-refreshed/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 16 Feb 2014 01:29:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"Website";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:2:"kb";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:13:"knowledgebase";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"manual";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11368";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:585:"<p>Today I&#8217;ve re-done the knowledge base. Most pages needed some tweaks and updates. All pages are now up-to-date again. A number of pages have been created to better explain the newer features or got split up from another page to better illustrate what&#8217;s what. Also for simplicity most pages have had their name updated so [&#8230;]</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/knowledge-base-refreshed/">Knowledge base refreshed</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:975:"<p>Today I&#8217;ve re-done the knowledge base.<br />
Most pages needed some tweaks and updates. All pages are now up-to-date again.<br />
A number of pages have been created to better explain the newer features or got split up from another page to better illustrate what&#8217;s what.</p>
<p>Also for simplicity most pages have had their name updated so it&#8217;s more clear what the page is about. And the pages are re-organized in better categories for easier navigation.</p>
<p>Check out the renewed pages here: <a href="http://www.adrotateplugin.com/support/knowledgebase/">www.adrotateplugin.com/support/knowledgebase/</a></p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/knowledge-base-refreshed/">Knowledge base refreshed</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/jMOgOTMJt9k" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.adrotateplugin.com/2014/02/knowledge-base-refreshed/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:63:"http://www.adrotateplugin.com/2014/02/knowledge-base-refreshed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"AdRotate Pro 3.9.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/IxW6_ik--DE/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:66:"http://www.adrotateplugin.com/2014/02/adrotate-pro-3-9-7/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Feb 2014 15:07:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:7:"Updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"bugfixes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:13:"clicktracking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"jquery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:3:"pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:6:"update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11206";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:577:"<p>Largely a maintenance update fixing a number of issues and improving existing items. I have largely re-done the jquery.showoff library to work more in tune with what AdRotate needs from it. This resulted in a smaller package and some improvements on speed and such. The jQuery.showoff Library has for that reason be rebranded (or forked [&#8230;]</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/adrotate-pro-3-9-7/">AdRotate Pro 3.9.7</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2229:"<p>Largely a maintenance update fixing a number of issues and improving existing items.<br />
I have largely re-done the jquery.showoff library to work more in tune with what AdRotate needs from it. This resulted in a smaller package and some improvements on speed and such.</p>
<p>The jQuery.showoff Library has for that reason be rebranded (or forked if you will) in jQuery.showoff.adrotate.js to maintain compatibility with other plugins requiring the original showoff plugin which is now 4 years old without updates.</p>
<p>The clicktracking code has again been optimised to enhance compatibility. A number of people have tested this over the past few days with good results.</p>
<p>This update is available now via the automated update system put in place in AdRotate Pro 3.9.5 and newer.<br />
You can also download the update via your account and update manually.</p>
<h3>Changelog</h3>
<div class="shortcode-unorderedlist arrow"></p>
<ul>
<li>[change] Improved clicktracker code</li>
<li>[change] Optimized and updated jQuery.jshowoff library</li>
<li>[change] Rebranded jQuery.jshowoff to jQuery.jshowoff.adrotate for compatibility</li>
<li>[change] Prettied up the settings page</li>
<li>[new] Same dynamic group can now be used more than once on a page</li>
<li>[new] Highlighted schedules to better indicate their status</li>
<li>[new] Hide schedules not in use for the advert you&#8217;re editing</li>
<li>[fix] Advertisers not being able to save adcode</li>
<li>[fix] Image verification for advertisers</li>
<li>[fix] Improved schedule creation process, no more stray schedules</li>
<li>[fix] Various missing stripslashes() for displaying names</li>
<li>[fix] Clicktracked links no longer open in a tab</li>
<li>[fix] Stray apostrophes in Schedule names</li>
<li>[fix] Some &#8220;cancel&#8221; buttons going the wrong way</li>
<li>[i18n] Now available in Swedish</li>
</ul>
<p></div>

<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/adrotate-pro-3-9-7/">AdRotate Pro 3.9.7</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/IxW6_ik--DE" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.adrotateplugin.com/2014/02/adrotate-pro-3-9-7/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:57:"http://www.adrotateplugin.com/2014/02/adrotate-pro-3-9-7/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:6:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"AdRotate Free 3.8.6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://feedproxy.google.com/~r/AdrotatePluginForWordpress/~3/LgUUZOzfDI4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.adrotateplugin.com/2014/02/adrotate-free-3-8-6/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 06 Feb 2014 19:53:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:7:"Updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"bugfix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"fixes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"free";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:11:"translation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:38:"http://www.adrotateplugin.com/?p=11057";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:404:"<p>An update to clicktracking &#8211; No more popup windows. The click counter is more reliable now. Also the settings page has been fixed and now looks as it should. Changes</p>
<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/adrotate-free-3-8-6/">AdRotate Free 3.8.6</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Arnan de Gans";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:818:"<p>An update to clicktracking &#8211; No more popup windows. The click counter is more reliable now.<br />
Also the settings page has been fixed and now looks as it should.</p>
<h3>Changes</h3>
<div class="shortcode-unorderedlist arrow"></p>
<ul>
<li>[change] Improved clicktracker code</li>
<li>[fix] Settings page Maintenance section not showing up correctly</li>
<li>[fix] Clicktracked links no longer open in a tab</li>
<li>[i18n] Swedish translation available</li>
</ul>
<p></div>

<p>The post <a rel="nofollow" href="http://www.adrotateplugin.com/2014/02/adrotate-free-3-8-6/">AdRotate Free 3.8.6</a> appeared first on <a rel="nofollow" href="http://www.adrotateplugin.com">AdRotate for WordPress</a>.</p>
<img src="http://feeds.feedburner.com/~r/AdrotatePluginForWordpress/~4/LgUUZOzfDI4" height="1" width="1"/>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://www.adrotateplugin.com/2014/02/adrotate-free-3-8-6/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:58:"http://www.adrotateplugin.com/2014/02/adrotate-free-3-8-6/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:54:"http://feeds.feedburner.com/AdrotatePluginForWordpress";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:26:"adrotatepluginforwordpress";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"LYricm+fcC+IZoWlplgP+Prf5wk";s:13:"last-modified";s:29:"Sun, 16 Mar 2014 04:32:03 GMT";s:4:"date";s:29:"Sun, 16 Mar 2014 05:53:07 GMT";s:7:"expires";s:29:"Sun, 16 Mar 2014 05:53:07 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('283', '_transient_timeout_feed_mod_b0c4de94b1cd78ed7eb394a67d5f052b', '1394992385', 'no'); 
INSERT INTO `wp_options` VALUES ('284', '_transient_feed_mod_b0c4de94b1cd78ed7eb394a67d5f052b', '1394949185', 'no'); 
INSERT INTO `wp_options` VALUES ('285', '_transient_timeout_feed_9d9591190fb768987f389ffa4b4942d4', '1394992387', 'no'); 
INSERT INTO `wp_options` VALUES ('286', '_transient_feed_9d9591190fb768987f389ffa4b4942d4', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Me and my Mac";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:21:"http://meandmymac.net";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:36:"One man to inspire the multitudes...";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 21:44:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.8.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Stop ruining the market!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/aZZBTT4uqFg/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"http://meandmymac.net/2068/stop-ruining-the-market/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 00:41:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"random";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"rant";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"rubbish";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"software";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:4:"work";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=2068";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:521:"<p>Earlier this week I apparently received an email from some guy &#8211; I had to search far and deep in my spam box. I did find it though, and I had decided it was spam based on 2 words; &#8220;India&#8221; and &#8220;developer&#8221;. Today they had the audacity to call me on the phone &#8211; Keep [&#8230;]</p><p>The post <a rel="nofollow" href="http://meandmymac.net/2068/stop-ruining-the-market/">Stop ruining the market!</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"http://meandmymac.net/2068/stop-ruining-the-market/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:51:"http://meandmymac.net/2068/stop-ruining-the-market/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Such accusations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/2GcS1JR0qtc/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:53:"http://meandmymac.net/2066/such-accusations/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 22:37:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"adrotate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"angry";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"chat";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:4:"crap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:4:"fail";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:6:"random";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=2066";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:483:"<p>Yea one of those days again I guess. This is a special kind of idiot &#8211; Worth a mockery or 2. I&#8217;m not sure what kind of grudge this guy has but for the sake of decency I won&#8217;t name him. Actually I don&#8217;t have to anonymize much, as this guy is too lame to [&#8230;]</p><p>The post <a rel="nofollow" href="http://meandmymac.net/2066/such-accusations/">Such accusations</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:49:"http://meandmymac.net/2066/such-accusations/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:44:"http://meandmymac.net/2066/such-accusations/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"iOS Touch ID not exactly working for you? Here’s a trick that worked for me.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/i10rF2oMtVs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:110:"http://meandmymac.net/2040/ios-touch-id-not-exactly-working-for-you-heres-a-trick-that-worked-for-me/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 04 Jan 2014 18:42:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:3:"fix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:6:"iphone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:5:"touch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=2040";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:616:"<p>I bought the iPhone 5S as soon as it was available and *only* because I wanted Touch ID. Otherwise I was perfectly fine with my iPhone 4. So imagine my huge disappointment when Touch ID sucked so bad I couldn&#8217;t use it. I felt like I had wasted 700 euros right there. Of course the [&#8230;]</p><p>The post <a rel="nofollow" href="http://meandmymac.net/2040/ios-touch-id-not-exactly-working-for-you-heres-a-trick-that-worked-for-me/">iOS Touch ID not exactly working for you? Here&#8217;s a trick that worked for me.</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:106:"http://meandmymac.net/2040/ios-touch-id-not-exactly-working-for-you-heres-a-trick-that-worked-for-me/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:101:"http://meandmymac.net/2040/ios-touch-id-not-exactly-working-for-you-heres-a-trick-that-worked-for-me/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Customers are awesome!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/eOpxLoEnN4E/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:54:"http://meandmymac.net/2034/customers-awesome/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Dec 2013 19:19:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"adrotate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:3:"end";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"omnicard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:4:"work";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=2034";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:530:"<p>Recently I had a realisation &#8211; And I think it&#8217;s suiting to close the year writing about it. Making popular products creates a lot of changes in ones life. Once the user base passes 100000 users the awesome power I have over the internet starts to dawn&#8230; One update and I can delete/ruin/change up to [&#8230;]</p><p>The post <a rel="nofollow" href="http://meandmymac.net/2034/customers-awesome/">Customers are awesome!</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:50:"http://meandmymac.net/2034/customers-awesome/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:45:"http://meandmymac.net/2034/customers-awesome/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"pfSense OpenVPN Site-to-Site with DNS resolving";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/HSjpZshacQ0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"http://meandmymac.net/2020/pfsense-openvpn-site-site-dns-resolving/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Dec 2013 20:38:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"firewall";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"howto";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"network";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:10:"networking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"tutorials";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:3:"vpn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=2020";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:608:"<p>Apparently it&#8217;s quite hard to set up a Site-to-Site VPN Connection *and* resolve DNS names over that tunnel. Lots of googling and silly advise later it turns out it&#8217;s not half as complicated as many make it seem. It&#8217;s actually stupidly simple if you use pfSense (www.pfsense.com). Wait what? VPN (Virtual Private Networking) is a [&#8230;]</p><p>The post <a rel="nofollow" href="http://meandmymac.net/2020/pfsense-openvpn-site-site-dns-resolving/">pfSense OpenVPN Site-to-Site with DNS resolving</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"http://meandmymac.net/2020/pfsense-openvpn-site-site-dns-resolving/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:67:"http://meandmymac.net/2020/pfsense-openvpn-site-site-dns-resolving/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"But it worked earlier…";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/ouaXyeDJ_Sw/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:58:"http://meandmymac.net/1989/but-it-worked-earlier/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 19:46:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:5:"apple";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"fail";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"mavericks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=1989";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:544:"<p>What does this even mean &#8220;This type of Mac&#8221;. It worked fine *before* I upgraded to Mavericks&#8230; So basically Apple blocked this version. Since there is no technical reason why it couldn&#8217;t work. What if I would have an older Airport that won&#8217;t work with the new Airport Utility&#8230; Oh wait I do. Hmm.</p><p>The post <a rel="nofollow" href="http://meandmymac.net/1989/but-it-worked-earlier/">But it worked earlier&#8230;</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:54:"http://meandmymac.net/1989/but-it-worked-earlier/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:49:"http://meandmymac.net/1989/but-it-worked-earlier/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Let’s hope it doesn’t come to this…";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/0s2h40Xau1M/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:69:"http://meandmymac.net/1985/lets-hope-it-doesnt-come-to-this/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Oct 2013 18:34:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"fail";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"hosting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=1985";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:558:"<p>Almost a year ago I was on the hunt for a new hosting provider. My then webhost failed to resolve numerous issues with the server I was using. After a month or so of misunderstandings I had enough, cancelled my service and moved on. Some people recommended GoDaddy for some reason. But they were so [&#8230;]</p><p>The post <a rel="nofollow" href="http://meandmymac.net/1985/lets-hope-it-doesnt-come-to-this/">Let&#8217;s hope it doesn&#8217;t come to this&#8230;</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://meandmymac.net/1985/lets-hope-it-doesnt-come-to-this/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:60:"http://meandmymac.net/1985/lets-hope-it-doesnt-come-to-this/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"I’ve got a nice rack!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/-CjFNGD01kc/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:56:"http://meandmymac.net/1981/ive-got-a-nice-rack/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Oct 2013 21:23:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:7:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"apache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"hosting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:2:"pc";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:4:"rack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:6:"server";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:6:"ubuntu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=1981";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:471:"<p>For work at the moment it makes a bit of sense to set up a server for various things. And I&#8217;m a bit torn to just get some Mini ITX PC for a few bucks and put it in my fancy rack space. Or if I should get a proper rackmount computer from Dell or [&#8230;]</p><p>The post <a rel="nofollow" href="http://meandmymac.net/1981/ive-got-a-nice-rack/">I&#8217;ve got a nice rack!</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:52:"http://meandmymac.net/1981/ive-got-a-nice-rack/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:47:"http://meandmymac.net/1981/ive-got-a-nice-rack/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"Can the iPhone 5S Touch ID be circumvented? Maybe – Possibly… Obviously";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/sGn_RcH6aKA/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:104:"http://meandmymac.net/1979/can-the-iphone-5s-touch-id-be-circumvented-maybe-possibly-obviously/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 06 Oct 2013 12:54:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:5:"apple";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"crap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:4:"ipad";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:6:"iphone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:8:"security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=1979";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:681:"<p>Notice how the title says &#8216;circumvented&#8217;, not hacked. I&#8217;m no hacker&#8230; So I wouldn&#8217;t know about that. But people (yes, smart people, too) trying to hack Apple&#8217;s Touch ID are just being stupid. Seriously&#8230; This article is only meant to point out the ridiculousness of hackers trying to defeat the Touch ID for the sake [&#8230;]</p><p>The post <a rel="nofollow" href="http://meandmymac.net/1979/can-the-iphone-5s-touch-id-be-circumvented-maybe-possibly-obviously/">Can the iPhone 5S Touch ID be circumvented? Maybe &#8211; Possibly&#8230; Obviously</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:100:"http://meandmymac.net/1979/can-the-iphone-5s-touch-id-be-circumvented-maybe-possibly-obviously/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:95:"http://meandmymac.net/1979/can-the-iphone-5s-touch-id-be-circumvented-maybe-possibly-obviously/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		
		
		

		
		
		
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Fraud or just flat out ridiculous?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://feedproxy.google.com/~r/meandmymacnet/~3/uWo3-JojfL8/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:70:"http://meandmymac.net/1975/fraud-or-just-flat-out-ridiculous/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 03 Oct 2013 19:04:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"failboat";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"money";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"paypal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:7:"screwed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:29:"http://meandmymac.net/?p=1975";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:560:"<p>Yesterday someone bought a Multi License of me for AdRotate Pro. The payment went well. Client was granted access to the download and a license key was sent out. Can&#8217;t be simpler. All was good&#8230; Then Paypal peeked around the corner and deemed the client a fraud and of course they took my money&#8230; Great [&#8230;]</p><p>The post <a rel="nofollow" href="http://meandmymac.net/1975/fraud-or-just-flat-out-ridiculous/">Fraud or just flat out ridiculous?</a> appeared first on <a rel="nofollow" href="http://meandmymac.net">Me and my Mac</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:66:"http://meandmymac.net/1975/fraud-or-just-flat-out-ridiculous/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:8:"origLink";a:1:{i:0;a:5:{s:4:"data";s:61:"http://meandmymac.net/1975/fraud-or-just-flat-out-ridiculous/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:41:"http://feeds.feedburner.com/meandmymacnet";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:1:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:13:"meandmymacnet";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:13:"last-modified";s:29:"Sun, 16 Mar 2014 05:53:10 GMT";s:4:"etag";s:27:"s6dVWWcyO4dHlnE/qc2yZX40TP8";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"date";s:29:"Sun, 16 Mar 2014 05:53:10 GMT";s:7:"expires";s:29:"Sun, 16 Mar 2014 05:53:10 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('287', '_transient_timeout_feed_mod_9d9591190fb768987f389ffa4b4942d4', '1394992387', 'no'); 
INSERT INTO `wp_options` VALUES ('288', '_transient_feed_mod_9d9591190fb768987f389ffa4b4942d4', '1394949187', 'no'); 
INSERT INTO `wp_options` VALUES ('289', '_transient_timeout_feed_b1a3b2fa3faa0a7bfe41edc84c9e4076', '1394992390', 'no'); 
INSERT INTO `wp_options` VALUES ('290', '_transient_feed_b1a3b2fa3faa0a7bfe41edc84c9e4076', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"AJdG Solutions » News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:19:"http://www.ajdg.net";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:24:"Development that matters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 22:16:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.8.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Facebook Ads, is it worth it?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://www.ajdg.net/2014/03/13/facebook-ads-is-it-worth-it/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.ajdg.net/2014/03/13/facebook-ads-is-it-worth-it/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 11:03:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"adrotate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"adverts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"facebook";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"omnicard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=648";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:638:"<p>Since a few days I&#8217;m running a bunch of ad campaigns on Facebook for AdRotate and OmniCard. Lot&#8217;s of likes, the targeting of people seems good. But there is little to no engagement so far. Nobody sees my posts or<span class="ellipsis">&#8230;</span>
<div class="read-more"><a href="http://www.ajdg.net/2014/03/13/facebook-ads-is-it-worth-it/">Read more &#8250;</a></div>
<p><!-- end of .read-more --></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/03/13/facebook-ads-is-it-worth-it/">Facebook Ads, is it worth it?</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1277:"<p><a href="http://www.ajdg.net/wp-content/uploads/2014/03/Screen-Shot-2014-03-13-at-11.56.22-.png" rel="lightbox-0"><img src="http://www.ajdg.net/wp-content/uploads/2014/03/Screen-Shot-2014-03-13-at-11.56.22-.png" alt="Screen Shot 2014-03-13 at 11.56.22" width="190" height="70" class="alignleft size-full wp-image-649" /></a>Since a few days I&#8217;m running a bunch of ad campaigns on Facebook for <a href="http://www.adrotateplugin.com" title="AdRotate for WordPress" target="_blank">AdRotate</a> and <a href="http://www.ajdg.net/products/omnicard/" title="OmniCard" target="_blank">OmniCard</a>.</p>
<p>Lot&#8217;s of likes, the targeting of people seems good. But there is little to no engagement so far. Nobody sees my posts or something &#8211; Perhaps I&#8217;m impatient. Facebook doesn&#8217;t offer much insights in when to expect results. Just &#8220;you&#8217;ll get much likes per day&#8221;. But that&#8217;s useless if nobody sees your posts. So how useful are Facebook Ads for you?</p>
<p>Do you use it? Does it work for you? Thoughts?</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/03/13/facebook-ads-is-it-worth-it/">Facebook Ads, is it worth it?</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:64:"http://www.ajdg.net/2014/03/13/facebook-ads-is-it-worth-it/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"Tired of different pricing depending on tax calculations when using WooCommerce?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:111:"http://www.ajdg.net/2014/03/06/tired-of-different-pricing-depending-on-tax-calculations-when-using-woocommerce/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:120:"http://www.ajdg.net/2014/03/06/tired-of-different-pricing-depending-on-tax-calculations-when-using-woocommerce/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 06 Mar 2014 22:34:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"online payment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"payment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:11:"woocommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=643";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:797:"<p>If you&#8217;re tired of uneven prices for products or tired of people complaining why their asking price was suddenly a lot higher because of taxes in their local region you should get this mod. If your shop uses prices without<span class="ellipsis">&#8230;</span>
<div class="read-more"><a href="http://www.ajdg.net/2014/03/06/tired-of-different-pricing-depending-on-tax-calculations-when-using-woocommerce/">Read more &#8250;</a></div>
<p><!-- end of .read-more --></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/03/06/tired-of-different-pricing-depending-on-tax-calculations-when-using-woocommerce/">Tired of different pricing depending on tax calculations when using WooCommerce?</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2027:"<p><a href="http://www.ajdg.net/wp-content/uploads/2014/02/ajdg-plugin.png" rel="lightbox-0"><img src="http://www.ajdg.net/wp-content/uploads/2014/02/ajdg-plugin-100x100.png" alt="ajdg-plugin" width="100" height="100" class="alignleft size-thumbnail wp-image-632" /></a>If you&#8217;re tired of uneven prices for products or tired of people complaining why their asking price was suddenly a lot higher because of taxes in their local region you should get this mod.<br />
If your shop uses prices without tax included, customers from the EU are overcharged.<br />
If your shop has prices including tax your customers not from the EU are undercharged.<br />
It&#8217;s almost like WooCommerce wants you to be unfair to your customers and surprise your customers unpleasantly!</p>
<h3>Meet WooCommerce Price Equality</h3>
<p>Using correct tax/Vat rules in your store and the <a href="http://www.ajdg.net/product/woocommerce-price-equality/" title="WooCommerce Price Equality">WooCommerce Price Equality plugin</a> I&#8217;ve created you can even up all prices and depending on your customers locale they get charged tax without surprises. Or perhaps no tax at all.</p>
<p>If your site lists a product of €100 euros and someone from within the EU buys that product they pay €100 (including tax). So your net income on that is €100 minus tax.<br />
If you sell that same product to someone from outside the EU they still pay €100 but with €0 tax this time. Your net income is €100.<br />
This means the listed asking price is always right. No matter where your customer is.</p>
<p>Get the plugin <a href="http://www.ajdg.net/products/woocommerce-plugins/" title="WooCommerce Plugins">here</a>.</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/03/06/tired-of-different-pricing-depending-on-tax-calculations-when-using-woocommerce/">Tired of different pricing depending on tax calculations when using WooCommerce?</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:116:"http://www.ajdg.net/2014/03/06/tired-of-different-pricing-depending-on-tax-calculations-when-using-woocommerce/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Heb jij al OmniCard versie 1.2?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.ajdg.net/2014/03/06/heb-jij-al-omnicard-versie-1-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:71:"http://www.ajdg.net/2014/03/06/heb-jij-al-omnicard-versie-1-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 06 Mar 2014 22:17:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:8:"OmniCard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"bugfix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"gateway";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"omnicard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:6:"update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:11:"woocommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=640";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:699:"<p>Is jouw OmniCard versie al up-to-date? Als je inmiddels WooCommerce 2.1 of nieuwer hebt geinstalleerd word je dringend geadviseerd om OmniCard naar versie 1.2 te updaten. Alle voorgaande versies gebruiken een incompatibele manier van bedragen noteren wat resulteert in verkeerd<span class="ellipsis">&#8230;</span>
<div class="read-more"><a href="http://www.ajdg.net/2014/03/06/heb-jij-al-omnicard-versie-1-2/">Read more &#8250;</a></div>
<p><!-- end of .read-more --></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/03/06/heb-jij-al-omnicard-versie-1-2/">Heb jij al OmniCard versie 1.2?</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1098:"<p><a href="http://www.ajdg.net/wp-content/uploads/2013/02/omnicard-logo.jpg" rel="lightbox-0"><img src="http://www.ajdg.net/wp-content/uploads/2013/02/omnicard-logo-100x100.jpg" alt="omnicard-logo" width="100" height="100" class="alignleft size-thumbnail wp-image-249" /></a>Is jouw <a href="http://www.ajdg.net/products/omnicard/" title="OmniCard">OmniCard</a> versie al up-to-date? Als je inmiddels WooCommerce 2.1 of nieuwer hebt geinstalleerd word je dringend geadviseerd om OmniCard naar versie 1.2 te updaten. Alle voorgaande versies gebruiken een incompatibele manier van bedragen noteren wat resulteert in verkeerd afgerekende bedragen. €23 word €0.23 etc.<br />
Dit probleem is opgelost in OmniCard 1.2.</p>
<p>Versie 1.2 is GRATIS te downloaden vanaf deze site via de <a href="http://www.ajdg.net/billing/" title="Billing">Billing</a> pagina in de footer.</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/03/06/heb-jij-al-omnicard-versie-1-2/">Heb jij al OmniCard versie 1.2?</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.ajdg.net/2014/03/06/heb-jij-al-omnicard-versie-1-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Introducing – WooCommerce Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://www.ajdg.net/2014/02/22/introducing-woocommerce-plugins/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:72:"http://www.ajdg.net/2014/02/22/introducing-woocommerce-plugins/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 22 Feb 2014 02:20:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:11:"woocommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=625";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:695:"<p>Attention WooCommerce users. Earlier tonight I came to the conclusion that lots of people can use this stuff &#8211; Following a few questions about how adrotateplugin.com works. And some encouragement from people around me. So I&#8217;ve decided to release these<span class="ellipsis">&#8230;</span>
<div class="read-more"><a href="http://www.ajdg.net/2014/02/22/introducing-woocommerce-plugins/">Read more &#8250;</a></div>
<p><!-- end of .read-more --></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/02/22/introducing-woocommerce-plugins/">Introducing &#8211; WooCommerce Plugins</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1229:"<p>Attention WooCommerce users.</p>
<p>Earlier tonight I came to the conclusion that lots of people can use this stuff &#8211; Following a few questions about how <a href="http://adrotateplugin.com" title="AdRotate for WordPress" target="_blank">adrotateplugin.com</a> works. And some encouragement from people around me.<br />
So I&#8217;ve decided to release these plugins for everyone to buy.</p>
<p>Originally I never planned on ever releasing them but I patched up the code a bit. Made it so that it&#8217;s useful for others too and voila. A set of useful, small, WooCommerce Plugins.<br />
Most notable a way to work around the clumsy tax handling in WooCommerce for European merchants trading worldwide.<br />
For now there are 3 plugins; WooCommerce Price Equality, WooCommerce License manager and WooCommerce Generate Key.</p>
<p>Check out the <a href="http://www.ajdg.net/products/woocommerce-plugins/" title="WooCommerce Plugins">WooCommerce Plugins page</a> for more information.</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/02/22/introducing-woocommerce-plugins/">Introducing &#8211; WooCommerce Plugins</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:68:"http://www.ajdg.net/2014/02/22/introducing-woocommerce-plugins/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:63:"
		
		
		
		
		
				
		
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"OmniCard nu écht compatibel met WooCommerce 2.1!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://www.ajdg.net/2014/02/17/omnicard-nu-echt-compatibel-met-woocommerce-2-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:88:"http://www.ajdg.net/2014/02/17/omnicard-nu-echt-compatibel-met-woocommerce-2-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Feb 2014 13:14:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:8:{i:0;a:5:{s:4:"data";s:8:"OmniCard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"bugfix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"ideal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:10:"mastercard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"rabobank";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:6:"update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:4:"visa";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:11:"woocommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=577";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:752:"<p>Belangrijke update voor OmniCard. Door verschillende wijzigingen (bugs?) in WooCommerce worden sommige bedragen van producten als centen gezien. €38.00 wordt dan door de Rabobank als €0.38 afgerekend. Dit is natuurlijk niet de bedoeling. Versie 1.2 lost dit probleem op. Ook<span class="ellipsis">&#8230;</span>
<div class="read-more"><a href="http://www.ajdg.net/2014/02/17/omnicard-nu-echt-compatibel-met-woocommerce-2-1/">Read more &#8250;</a></div>
<p><!-- end of .read-more --></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/02/17/omnicard-nu-echt-compatibel-met-woocommerce-2-1/">OmniCard nu écht compatibel met WooCommerce 2.1!</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1604:"<p>Belangrijke update voor OmniCard.</p>
<p>Door verschillende wijzigingen (bugs?) in WooCommerce worden sommige bedragen van producten als centen gezien.<br />
€38.00 wordt dan door de Rabobank als €0.38 afgerekend. Dit is natuurlijk niet de bedoeling.<br />
Versie 1.2 lost dit probleem op. Ook zijn verschillende andere mechanieken bijgewerkt en weer helemaal up-to-date met WooCommerce 2.1.</p>
<p><strong>Let op:</strong> Door deze wijzigingen werkt OmniCard 1.2 en nieuwer niet meer met WooCommerce 1.6.x. De minimum vereiste is WooCommerce 2.0!</p>
<h5>Wijzigingen</h5>
<ul>
<li>[fix] Correct order amounts send to bank</li>
<li>[fix] Small code tune-ups increasing performance</li>
<li>[change] Redirect End-points for pending and on-hold orders</li>
<li>[change] Redirect End-points for completed orders</li>
<li>[change] Old calls updated for payment processing</li>
<li>[i18n] Language files updated</li>
</ul>
<h5>Downloaden</h5>
<p>De update is gratis te downloaden uit je originele bestelling via het bestel systeem: <a href="http://www.ajdg.net/billing/" title="Billing">Order Tracker</a></p>
<h5>Installatie</h5>
<p>Upgraden is heel eenvoudig en neemt slechts een paar minuten in beslag.<br />
De instructie om te upgraden zie je <a href="http://www.ajdg.net/products/omnicard/#tabs-4" title="OmniCard Upgraden">hier</a>.</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/02/17/omnicard-nu-echt-compatibel-met-woocommerce-2-1/">OmniCard nu écht compatibel met WooCommerce 2.1!</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:84:"http://www.ajdg.net/2014/02/17/omnicard-nu-echt-compatibel-met-woocommerce-2-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"OmniCard Compatibel met WooCommerce 2.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://www.ajdg.net/2014/02/10/omnicard-compatibel-met-woocommerce-2-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:80:"http://www.ajdg.net/2014/02/10/omnicard-compatibel-met-woocommerce-2-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 10 Feb 2014 18:33:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:8:"OmniCard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:10:"compatible";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"gateway";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"omnicard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:11:"woocommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=565";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:463:"<p>De huidige versies van OmniCard en OmniCard iDeal zijn volledig compatibel met WooCommerce 2.1. Er lijkt vooralsnog geen update nodig te zijn. Je hebt OmniCard 1.2 nodig voor WooCommerce 2.1 en nieuwer &#8211; Link.</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/02/10/omnicard-compatibel-met-woocommerce-2-1/">OmniCard Compatibel met WooCommerce 2.1</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:618:"<p>De huidige versies van OmniCard en OmniCard iDeal zijn volledig compatibel met WooCommerce 2.1.<br />
<del datetime="2014-02-22T00:23:57+00:00">Er lijkt vooralsnog geen update nodig te zijn.</del></p>
<p>Je hebt OmniCard 1.2 nodig voor WooCommerce 2.1 en nieuwer &#8211; <a href="http://www.ajdg.net/2014/02/17/omnicard-nu-echt-compatibel-met-woocommerce-2-1/">Link</a>.</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2014/02/10/omnicard-compatibel-met-woocommerce-2-1/">OmniCard Compatibel met WooCommerce 2.1</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:76:"http://www.ajdg.net/2014/02/10/omnicard-compatibel-met-woocommerce-2-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"Clickandbuy now accepted as a payment method for AdRotate Purchases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.ajdg.net/2013/12/15/clickandbuy-now-accepted-payment-method-adrotate-purchases/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:99:"http://www.ajdg.net/2013/12/15/clickandbuy-now-accepted-payment-method-adrotate-purchases/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 15 Dec 2013 12:23:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:8:"AdRotate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"adrotate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"credit card";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"gateway";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=546";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:757:"<p>With my ongoing struggle to find a decent Creditcard processor I came across Click&#038;Buy. They accept creditcards too. Yay! All you need is an account with Clickandbuy and link up your preferred payment methods, which can be a bank account,<span class="ellipsis">&#8230;</span>
<div class="read-more"><a href="http://www.ajdg.net/2013/12/15/clickandbuy-now-accepted-payment-method-adrotate-purchases/">Read more &#8250;</a></div>
<p><!-- end of .read-more --></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2013/12/15/clickandbuy-now-accepted-payment-method-adrotate-purchases/">Clickandbuy now accepted as a payment method for AdRotate Purchases</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1658:"<p><img src="http://www.ajdg.net/wp-content/uploads/2013/12/clickandbuy.jpg" alt="clickandbuy" width="213" height="171" class="alignleft size-full wp-image-547" />With my ongoing struggle to find a decent Creditcard processor I came across Click&#038;Buy. They accept creditcards too. Yay!<br />
All you need is an account with Clickandbuy and link up your preferred payment methods, which can be a bank account, debit card or Creditcard!</p>
<p>I have cancelled my application with Worldpay. Luckily I didn&#8217;t pay the setup fee yet. They have the most horrid customer service ever. I&#8217;ve been emailing them at least twice a week for the last 4-5 weeks asking about my application status and when I can expect to accept creditcards. All I ever got in return was out-of-office replies and apologetic emails of some idiot claiming he spoke to sales about it. Terrible. And obviously my patience ran out.</p>
<p>I&#8217;m still working on some other options. But it seems none of the processing companies want new customers or something&#8230; :(</p>
<p>But for now, Clickandbuy. I&#8217;ve used them in the past for my iTunes account (When I had no Creditcard myself) and it works really well I think.<br />
Don&#8217;t have an account yet? Make one today on <a href="http://www.clickandbuy.com" title="Click and Buy" target="_blank">www.clickandbuy.com</a>.</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2013/12/15/clickandbuy-now-accepted-payment-method-adrotate-purchases/">Clickandbuy now accepted as a payment method for AdRotate Purchases</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:95:"http://www.ajdg.net/2013/12/15/clickandbuy-now-accepted-payment-method-adrotate-purchases/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:43:"Computer netwerk beveiliging binnen het MKB";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://www.ajdg.net/2013/12/07/computer-netwerk-beveiliging-binnen-het-mkb/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:84:"http://www.ajdg.net/2013/12/07/computer-netwerk-beveiliging-binnen-het-mkb/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Dec 2013 13:53:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"beveiliging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"diensten";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"firewall";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:7:"netwerk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:8:"services";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=537";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:687:"<p>Op het internet en gaan!! En zo hoort het ook. Echter veel bedrijven besteden weinig tot geen aandacht aan de beveiliging van hun computer netwerk. Ook als je thuis werkt als ZZP&#8217;er is het belangrijk dat je veilig te werk<span class="ellipsis">&#8230;</span>
<div class="read-more"><a href="http://www.ajdg.net/2013/12/07/computer-netwerk-beveiliging-binnen-het-mkb/">Read more &#8250;</a></div>
<p><!-- end of .read-more --></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2013/12/07/computer-netwerk-beveiliging-binnen-het-mkb/">Computer netwerk beveiliging binnen het MKB</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3946:"<h3>Op het internet en gaan!!</h3>
<p><img src="http://www.ajdg.net/wp-content/uploads/2013/12/freebsd-firewall-100x100.png" alt="freebsd-firewall" width="100" height="100" class="alignleft size-thumbnail wp-image-539" />En zo hoort het ook. Echter veel bedrijven besteden weinig tot geen aandacht aan de beveiliging van hun computer netwerk.<br />
Ook als je thuis werkt als ZZP&#8217;er is het belangrijk dat je veilig te werk gaat. Een simpel modem van je internet provider bied wel wat bescherming en voor velen zal dit prima werken. Maar als veel met klantgegevens werkt, of servers op kantoor of zelfs thuis hebt draaien dan is een goede firewall on-ontbeerlijk!</p>
<h3>Maar dat is heel duur</h3>
<p>Niet als je je goed informeert. Onlangs heeft AJdG Solutions netwerken geïnstalleerd op verschillende locaties welke heel kosteneffectief te onderhouden zijn en de investering is minimaal. Denk dan aan minder dan €1000 euro inclusief installatie.<br />
Wat netwerk beveiliging vaak duur maakt is de onwetendheid van de gebruiker. Ook zien gebruikers op tegen het installeren en de technische poespas die erbij komt kijken. ICT Dienstverleners maken daar graag gebruik van.<br />
Maar wat als het nou makkelijker (leuker?) en goedkoper kan&#8230; En beter nog, je kunt een groot deel zelf onderhouden!</p>
<h3>Hoe werkt dat dan?</h3>
<p>Werk samen met andere kleine ondernemers die zich specialiseren in ICT oplossingen. Zoek verder dan de standaard oplossing van een plug-and-play firewall en maak een afweging van wat je daadwerkelijk nodig hebt aan beveiliging en gemak. Een goed opgezet netwerk bespaard tijd en zorgt ervoor dat je makkelijker meer kan doen.</p>
<p><strong>Bijvoorbeeld:</strong><br />
Bij WifiTea in Alkmaar (<a href="http://www.wifitea.nl" title="WifiTea - Het betere flexwerken" target="_blank">www.wifitea.nl</a>) heeft AJdG Solutions een compleet netwerk beveiligd met gratis te verkrijgen software en speciale hardware welke niet duur in de aanschaf is. Bovendien is de gebruikte hardware voordelig in stroomgebruik. Wat dus op de lange termijn ook nog eens voordelig is.</p>
<h3>Firewalls zijn moeilijk</h3>
<p>Alleen de eerste installatie kan wat complex zijn. En natuurlijk vereist dit de nodige technische kennis. Maar ook &#8211; Hoe stel je de Firewall in. En wat wil je dat deze computer nog meer gaat doen? Ga je inloggen vanaf andere locaties? Wil je locaties koppelen aan elkaar over een beveiligde verbinding&#8230; Noem maar op.</p>
<p>Als het geheel eenmaal werkt heb je er geen omkijken meer naar. Wat voor nut heeft een duur service contract dan nog? Veel bedrijven maken hier gebruik van. Elke maand 100-200 Euro. Onzin.</p>
<h3>Hoe dan wel?</h3>
<p>State-of-the-art firewalls zijn gratis beschikbaar. Hoogwaardige specialistische hardware is niet perse duur. Wat moet je met een geluidskaart of HDMI poort in je router? Juist, overbodig. Tegelijkertijd heb je in de meeste computers maar 1 netwerk poort, terwijl je er misschien wel 3 nodig hebt. En de &#8216;gewone&#8217; netwerk kaart is meestal kwalitatief niet toereikend.</p>
<p>AJdG Solutions kan je hier mee adviseren en helpen. Kennis van zaken is super belangrijk. Advies over wat wel en niet nuttig is. Verder kijken dan de standaard oplossingen en servicecontracten. En natuurlijk de uitvoering van de oplossing of een gedeelte daarvan.</p>
<h3>Een systeem op maat voor jouw locatie</h3>
<p>Neem de controle over de beveiliging en de kosten daarvan in eigen handen en start direct met een beter, veiliger netwerk wat ook nog eens voordeliger is.</p>
<p>Meer weten? <a href="http://www.ajdg.net/contact/" title="Contact me" target="_blank">Neem contact op</a> met AJdG Solutions.</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2013/12/07/computer-netwerk-beveiliging-binnen-het-mkb/">Computer netwerk beveiliging binnen het MKB</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:80:"http://www.ajdg.net/2013/12/07/computer-netwerk-beveiliging-binnen-het-mkb/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"OmniKassa nogsteeds niet een oplossing voor Credit Cards";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://www.ajdg.net/2013/11/26/omnikassa-nogsteeds-niet-een-oplossing-voor-credit-cards/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:97:"http://www.ajdg.net/2013/11/26/omnikassa-nogsteeds-niet-een-oplossing-voor-credit-cards/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Nov 2013 19:50:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:8:"OmniCard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"credit card";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:7:"gateway";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:8:"omnicard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:6:"update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=529";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:744:"<p>In een discussie die al maanden loopt met de Rabobank zit geen schot. Duidelijke, en tijdige, antwoorden blijven uit. En creditcard transacties werken nogsteeds niet naar behoren. Zoals hier, hier en hier al eens beschreven gaat het nog wel eens<span class="ellipsis">&#8230;</span>
<div class="read-more"><a href="http://www.ajdg.net/2013/11/26/omnikassa-nogsteeds-niet-een-oplossing-voor-credit-cards/">Read more &#8250;</a></div>
<p><!-- end of .read-more --></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2013/11/26/omnikassa-nogsteeds-niet-een-oplossing-voor-credit-cards/">OmniKassa nogsteeds niet een oplossing voor Credit Cards</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3890:"<p>In een discussie die al maanden loopt met de Rabobank zit geen schot. Duidelijke, en tijdige, antwoorden blijven uit. En creditcard transacties werken nogsteeds niet naar behoren.</p>
<p>Zoals <a href="http://meandmymac.net/1850/are-they-really-serious-how-to-dissatisfy-a-client-101/" target="_blank">hier</a>, <a href="http://meandmymac.net/1893/failing-creditcards-resolved/" target="_blank">hier</a> en <a target="_blank" href="http://www.ajdg.net/2013/07/31/rabobank-omnikassa-trouble-with-omnicard/">hier</a> al eens beschreven gaat het nog wel eens mis met de OmniKassa. Helaas echter kost dit de Merchant klauwen met geld zonder een nette oplossing of zelfs maar een excuses. Vragen over enige vergoeding word genegeerd en een oplossing word niet gezocht.<br />
Alleen deze maand al loop ik ruim 1000 Euro mis doordat de OmniKassa simpelweg niet werkt met Credit cards. Ookal zeggen ze van wel.</p>
<blockquote><p>Meer dan 60% van alle transacties mislukt</p></blockquote>
<h3>Een trieste zaak</h3>
<p>Wat vind de Rabobank ervan. Rabobank vind het een ernstige zaak, zeggen ze. Los het dan verdorie ook op.<br />
Wat vinden ze er op de afdeling van OmniKassa van? Ook erg jammer. Maar wederom geen oplossing of zelfs maar een duidelijke uitleg.</p>
<p>Smoesjes verzinnen en mijn tijd verspillen, dat kunnen ze als de beste.</p>
<blockquote><p>iDeal werkt wel meneer.</p></blockquote>
<p>En goed ook! Maar daar heb je niks aan als 98% van je klanten met Credit card betalen.</p>
<h3>Wat gaat er mis?</h3>
<p>Geen idee, ATOS (de achterliggende acquirer) weigert duidelijke informatie te geven over de mislukte transacties. Hun automatische systeem gooit vrijwel alles op een status code 05. Wat zoveel betekend als een overschreden limiet of simpelweg &#8220;geweigerd&#8221;. Dit werkt verwarrend vooral omdat het merendeel van de kaarten gewoon werkt. Deze status is dus niet accuraat.</p>
<p>De Rabobank gooit het op falende 3D secure kaarten (Kaarten die dat dus niet hebben). Maar als dat waar is, waarom geeft ATOS dan niet status code 14 (foutief creditcard nummer, CVV Code of ongeldige kaart) of 63 (Probleem met beveiliging). Deze lijken me toch beter dan code 05. In ieder geval minder verwarrend.</p>
<p>Wat ook héél vaak gebeurt is dat er een code 97 gegeven word. Welke betekend dat de &#8220;tijd&#8221; overschreden is. Welke tijd is niet helemaal duidelijk. Maar volgens de Rabobank heeft dit te maken met communicatie tussen hun systemen onderling. Of&#8230; de communicatie die niet plaatsvind. Dus óók een probleem bij de bank, en niet bij de merchant.</p>
<p>Kortom &#8211; Als je creditcards wilt gebruiken. OmniKassa is niet de oplossing.</p>
<h3>Werkt OmniKassa dan wel?</h3>
<p>Jazeker, voor binnenlands (Europees?) betalingsverkeer zoals iDeal werkt het zelfs heel goed. Dus voor Nederlandse webshop eigenaren welke voornamelijk klanten uit Nederland bedienen is het een goed en mooi product. Lage transactiekosten, relatief korte lijnen. En lekker alles onder 1 dak bij je eigen bank. Geen gedoe met externen zoals bij veel concurrenten.<br />
Dit betekend dat <a href="http://www.ajdg.net/products/omnicard/" title="OmniCard">OmniCard</a> nog steeds een geldig product is welke gewoon inzetbaar is. Echter, als jeje, zoals ik, op de internationale markt richt waar je veel met Credit cards te maken hebt zou ik even verder kijken.</p>
<p><strong>Noot:</strong> Alle bovengenoemde kritiek en problemen slaan volledig op Credit card betalingen en de achterliggende ATOS bank en de communicatie tussen hun en Rabobank. iDeal gaat niet via ATOS en werkt direct via Rabobank.</p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2013/11/26/omnikassa-nogsteeds-niet-een-oplossing-voor-credit-cards/">OmniKassa nogsteeds niet een oplossing voor Credit Cards</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:93:"http://www.ajdg.net/2013/11/26/omnikassa-nogsteeds-niet-een-oplossing-voor-credit-cards/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:54:"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Donderdag inloop middag – Netwerken op zijn best";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.ajdg.net/2013/10/20/donderdag-inloop-middag-netwerken-op-zijn-best/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.ajdg.net/2013/10/20/donderdag-inloop-middag-netwerken-op-zijn-best/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 20 Oct 2013 12:07:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:5:{i:0;a:5:{s:4:"data";s:7:"WifiTea";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"adrotate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"omnicard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:9:"spreekuur";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:26:"http://www.ajdg.net/?p=499";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:709:"<p>Onlangs heb ik samen met een vennoot een bedrijf geopend in Alkmaar. Een leuke combinatie van een Theehuis en flexibele werkplekken. Onder de naam WifiTea ontvangen wij gasten en klanten. Het idee is dat we met de combinatie van een<span class="ellipsis">&#8230;</span>
<div class="read-more"><a href="http://www.ajdg.net/2013/10/20/donderdag-inloop-middag-netwerken-op-zijn-best/">Read more &#8250;</a></div>
<p><!-- end of .read-more --></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2013/10/20/donderdag-inloop-middag-netwerken-op-zijn-best/">Donderdag inloop middag &#8211; Netwerken op zijn best</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3836:"<p><img src="http://www.ajdg.net/wp-content/uploads/2013/10/logo-150x145.jpg" alt="logo-150x145" width="150" height="145" class="alignleft size-full wp-image-500" />Onlangs heb ik samen met een vennoot een bedrijf geopend in Alkmaar. Een leuke combinatie van een Theehuis en flexibele werkplekken. Onder de naam <a href="http://www.wifitea.nl" title="WifiTea - Het betere Flexwerken" target="_blank">WifiTea</a> ontvangen wij gasten en klanten. Het idee is dat we met de combinatie van een Theehuis en Flexwerkplekken een gezellige ruimte creëren waar zelfstandigen, kleine bedrijven of mensen die een flexibele werkplek nodig hebben (bijvoorbeeld omdat het bedrijf waar ze werken op die manier werkt) kunnen komen werken.<br />
Dit is bijzonder aantrekkelijk voor bedrijven die willen besparen op kantoor ruimte maar ook voor zelfstandigen die geen &#8220;echt&#8221; kantoor kunnen betalen.</p>
<h3>Inloop (mid)dag</h3>
<p>Een soms gehoorde wens van klanten is dat ze willen weten met wie ze zaken doen. Waar gaat hun geld heen. Kunnen we ontmoeten?<br />
Dat was voorheen simpel; AJdG Solutions is een internet bedrijf en heeft geen kantoor om klanten te ontvangen.</p>
<p>Nu met mijn nieuwe bedrijf <a href="http://www.wifitea.nl" title="WifiTea - Het betere Flexwerken" target="_blank">WifiTea</a> kan ik aan deze wens invulling geven!<br />
Elke donderdagmiddag ben ik beschikbaar bij WifiTea om je vragen te beantwoorden over bijvoorbeeld <a href="http://www.adrotateplugin.com" title="AdRotate for WordPress" target="_blank">AdRotate</a>, <a href="http://www.ajdg.net/products/omnicard/" title="OmniCard" target="_blank">OmniCard</a> of Apple apparatuur en software.<br />
Ben je bezig met een website en kom je er niet uit met AdRotate of OmniCard? Maak een afspraak of kom gewoon langs en dan gaan we samen kijken wat de juiste oplossing is.<br />
Snap jeje iPhone of iPad niet? Bepaalde apps die niet goed lijken te werken op je laptop? Kom langs en vind het antwoord!<br />
Kun je niet op donderdag? Maak even een afspraak voor een andere dag.<br />
Korte vragen of probleempjes zijn meestal vrijblijvend. Mocht het een ingewikkeld probleem betreffen of iets wat veel tijd gaat kosten dan is er een uurtarief van &euro;45 van toepassing. Dit word per geval bekeken.</p>
<h3>Locatie</h3>
<p>In tegenstelling tot veel andere bedrijven die allemaal verstopt zitten op lelijke industrieterreinen of andere afgelegen plekken zitten wij op het randje van het centrum van Alkmaar, in Noord Holland. Onze locatie is daardoor makkelijk bereikbaar voor iedereen hier in de omgeving met voldoende parkeergelegenheid op loopafstand mocht je met de auto komen.</p>
<h3>Waar vind je ons</h3>
<p>WifiTea is gevestigd op de Geesterweg 1N, 1815CR in Alkmaar.</p>
<p><iframe width="575" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=wifitea+alkmaar&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=59.639182,118.037109&amp;ie=UTF8&amp;hq=wifitea&amp;hnear=Alkmaar,+Noord-Holland,+The+Netherlands&amp;t=m&amp;ll=52.634431,4.74139&amp;spn=0.006295,0.026368&amp;output=embed"></iframe><br /><small><a href="https://maps.google.com/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=wifitea+alkmaar&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=59.639182,118.037109&amp;ie=UTF8&amp;hq=wifitea&amp;hnear=Alkmaar,+Noord-Holland,+The+Netherlands&amp;t=m&amp;ll=52.634431,4.74139&amp;spn=0.006295,0.026368" style="color:#0000FF;text-align:left">View Larger Map</a></small></p>
<p>The post <a rel="nofollow" href="http://www.ajdg.net/2013/10/20/donderdag-inloop-middag-netwerken-op-zijn-best/">Donderdag inloop middag &#8211; Netwerken op zijn best</a> appeared first on <a rel="nofollow" href="http://www.ajdg.net">AJdG Solutions</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://www.ajdg.net/2013/10/20/donderdag-inloop-middag-netwerken-op-zijn-best/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:30:"http://www.ajdg.net/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:13:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 16 Mar 2014 05:53:12 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:14:"content-length";s:4:"9605";s:10:"connection";s:5:"close";s:10:"x-pingback";s:30:"http://www.ajdg.net/xmlrpc.php";s:4:"etag";s:34:""8540bb5d91334e6ea3c7ec3f723e8dd2"";s:12:"x-robots-tag";s:14:"noindex,follow";s:13:"last-modified";s:29:"Thu, 13 Mar 2014 22:05:57 GMT";s:4:"vary";s:15:"Accept-Encoding";s:16:"content-encoding";s:4:"gzip";s:12:"x-powered-by";s:8:"PleskLin";s:13:"ms-author-via";s:3:"DAV";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('291', '_transient_timeout_feed_mod_b1a3b2fa3faa0a7bfe41edc84c9e4076', '1394992390', 'no'); 
INSERT INTO `wp_options` VALUES ('292', '_transient_feed_mod_b1a3b2fa3faa0a7bfe41edc84c9e4076', '1394949190', 'no'); 
INSERT INTO `wp_options` VALUES ('293', '_transient_timeout_feed_b03206e9e529778fddda28b3780376bd', '1394992391', 'no'); 
INSERT INTO `wp_options` VALUES ('294', '_transient_feed_b03206e9e529778fddda28b3780376bd', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:2:"

";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:52:"
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"AdRotate News feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.adrotateplugin.com/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:61:"Find updates, promocodes and related important messages here.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Sun, 9 Mar 2014 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-us";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:20:{i:0;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"New licenses and a sale!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://www.adrotateplugin.com/2014/03/new-licenses-and-a-sale/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Sun, 9 Mar 2014 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"Important: Your opinion about AdRotate stats and the future of it";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:103:"http://www.adrotateplugin.com/2014/01/important-your-opinion-about-adrotate-stats-and-the-future-of-it/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"Important: AdRotate Update - Fixes Clicktracking - Update now!!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://www.adrotateplugin.com/2014/01/adrotate-pro-3-9-4-adrotate-free-3-9-3-fixes-clicktracking/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 17 Jan 2014 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"AdRotate Pro 3.9.2 now available!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.adrotateplugin.com/2014/01/adrotate-pro-3-9-2-and-adrotate-free-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 14 Jan 2014 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"AdRotate Pro 3.9.1 now available!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://www.adrotateplugin.com/2014/01/adrotate-pro-3-9-1-fixes-for-things/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Tue, 7 Jan 2014 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"AdRotate Pro 3.9 now available!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://www.adrotateplugin.com/2014/01/adrotate-pro-3-9-available-now/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Mon, 6 Jan 2014 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Black Friday and Cyber Monday 2013";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://www.adrotateplugin.com/2013/11/black-friday-cyber-monday-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 28 Nov 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"AdRotate Pro 3.8.15 - Fixes group margins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://www.adrotateplugin.com/2013/11/adrotate-pro-3-8-15-adrotate-free-3-8-11-fixing-blocks/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Nov 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"AdRotate Pro 3.8.13 - Important bugfix for GeoLocation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://www.adrotateplugin.com/2013/10/adrotate-pro-fixing-geo-location/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Oct 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"AdRotate Pro 3.8.11";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://www.adrotateplugin.com/2013/10/adrotate-pro-3-8-11/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Wed, 2 Oct 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"AdRotate Pro 3.8.9 and AdRotate Free 3.8.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.adrotateplugin.com/2013/08/adrotate-pro-3-8-9-and-adrotate-free-3-8-7/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 17 Aug 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"AdRotate Development - Upcoming Changes? Your input matters!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://www.adrotateplugin.com/2013/08/adrotate-development-upcoming-changes/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 10 Aug 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"Hot sale, 30 percent off on AdRotate Pro - This weekend only!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://www.adrotateplugin.com/2013/08/hot-sale-30-off-on-adrotate-this-weekend-only/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Fri, 2 Aug 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"AdRotate Pro 3.8.8 - Javascript ads!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://www.adrotateplugin.com/2013/07/adrotate-pro-3-8-8-and-adrotate-free-3-8-6-auto-refresh-ads/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Jul 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"AdRotate Pro 3.8.7.1 - Fixing Geolocation and Timezones!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://www.adrotateplugin.com/2013/07/adrotate-pro-3-8-7-1-fixing-geolocation-and-timezones/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 14 Jul 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"AdRotate Pro 3.8.7 - Improved statistics!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.adrotateplugin.com/2013/06/adrotate-pro-3-8-7-and-adrotate-free-3-8-5/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 26 Jun 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"AdRotate Pro 3.8.6 - GeoLocation support!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://www.adrotateplugin.com/2013/06/adrotate-pro-3-8-6-available-now/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Mon, 3 Jun 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"AJdG Solutions turns one! - Discounts to be had!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://www.adrotateplugin.com/2013/04/ajdg-solutions-turns-one/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Wed, 3 Apr 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"Blocks have no future - Your opinion?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://www.adrotateplugin.com/2013/03/blocks-have-no-future/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Mar 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:11:"
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"AdRotate Pro 3.8.5 - Upgrade today!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://www.adrotateplugin.com/2013/03/adrotate-pro-3-8-5/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 29 Mar 2013 00:00:00 GMT+1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 16 Mar 2014 05:53:13 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:4:"4815";s:13:"last-modified";s:29:"Sun, 09 Mar 2014 20:29:14 GMT";s:10:"connection";s:5:"close";s:13:"cache-control";s:22:"max-age=604800, public";s:7:"expires";s:29:"Sun, 23 Mar 2014 05:53:13 GMT";s:4:"etag";s:15:""531ccf1a-12cf"";s:12:"x-powered-by";s:8:"PleskLin";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('295', '_transient_timeout_feed_mod_b03206e9e529778fddda28b3780376bd', '1394992391', 'no'); 
INSERT INTO `wp_options` VALUES ('296', '_transient_feed_mod_b03206e9e529778fddda28b3780376bd', '1394949191', 'no'); 
INSERT INTO `wp_options` VALUES ('301', 'dfads_transient_data_deleted_time', '1395343557', 'yes'); 
INSERT INTO `wp_options` VALUES ('302', 'nextend_error', 'a:1:{s:13:"missingfooter";a:1:{i:0;s:6:"/asug/";}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('303', 'dfads-settings', 'a:1:{s:28:"dfads_enable_count_for_admin";s:1:"1";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('309', 'dfads_group_children', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('404', 'dbem_events_page', '79', 'yes'); 
INSERT INTO `wp_options` VALUES ('405', 'dbem_locations_page', '80', 'yes'); 
INSERT INTO `wp_options` VALUES ('406', 'dbem_categories_page', '81', 'yes'); 
INSERT INTO `wp_options` VALUES ('407', 'dbem_tags_page', '82', 'yes'); 
INSERT INTO `wp_options` VALUES ('408', 'dbem_my_bookings_page', '83', 'yes'); 
INSERT INTO `wp_options` VALUES ('409', 'dbem_hello_to_user', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('410', 'dbem_time_format', 'H:i', 'yes'); 
INSERT INTO `wp_options` VALUES ('411', 'dbem_date_format', 'd/m/Y', 'yes'); 
INSERT INTO `wp_options` VALUES ('412', 'dbem_date_format_js', 'dd/mm/yy', 'yes'); 
INSERT INTO `wp_options` VALUES ('413', 'dbem_dates_separator', ' - ', 'yes'); 
INSERT INTO `wp_options` VALUES ('414', 'dbem_times_separator', ' - ', 'yes'); 
INSERT INTO `wp_options` VALUES ('415', 'dbem_default_category', '-1', 'yes'); 
INSERT INTO `wp_options` VALUES ('416', 'dbem_default_location', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('417', 'dbem_events_default_orderby', 'event_start_date,event_start_time,event_name', 'yes'); 
INSERT INTO `wp_options` VALUES ('418', 'dbem_events_default_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('420', 'dbem_events_default_limit', '10', 'yes'); 
INSERT INTO `wp_options` VALUES ('421', 'dbem_search_form_submit', 'Buscar', 'yes'); 
INSERT INTO `wp_options` VALUES ('422', 'dbem_search_form_advanced', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('423', 'dbem_search_form_advanced_hidden', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('424', 'dbem_search_form_advanced_show', 'Show Advanced Search', 'yes'); 
INSERT INTO `wp_options` VALUES ('425', 'dbem_search_form_advanced_hide', 'Hide Advanced Search', 'yes'); 
INSERT INTO `wp_options` VALUES ('426', 'dbem_search_form_text', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('427', 'dbem_search_form_text_label', 'Buscar', 'yes'); 
INSERT INTO `wp_options` VALUES ('428', 'dbem_search_form_geo', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('429', 'dbem_search_form_geo_label', 'Near...', 'yes'); 
INSERT INTO `wp_options` VALUES ('430', 'dbem_search_form_geo_units', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('431', 'dbem_search_form_geo_units_label', 'Within', 'yes'); 
INSERT INTO `wp_options` VALUES ('432', 'dbem_search_form_geo_unit_default', 'mi', 'yes'); 
INSERT INTO `wp_options` VALUES ('433', 'dbem_search_form_geo_distance_default', '25', 'yes'); 
INSERT INTO `wp_options` VALUES ('434', 'dbem_search_form_dates', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('435', 'dbem_search_form_dates_label', 'Dates', 'yes'); 
INSERT INTO `wp_options` VALUES ('436', 'dbem_search_form_dates_separator', 'e', 'yes'); 
INSERT INTO `wp_options` VALUES ('437', 'dbem_search_form_categories', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('438', 'dbem_search_form_categories_label', 'Todas as Categorias', 'yes'); 
INSERT INTO `wp_options` VALUES ('439', 'dbem_search_form_category_label', 'Categoria', 'yes'); 
INSERT INTO `wp_options` VALUES ('440', 'dbem_search_form_countries', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('441', 'dbem_search_form_default_country', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('442', 'dbem_search_form_countries_label', 'Todos os Países', 'yes'); 
INSERT INTO `wp_options` VALUES ('443', 'dbem_search_form_country_label', 'País', 'yes'); 
INSERT INTO `wp_options` VALUES ('444', 'dbem_search_form_regions', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('445', 'dbem_search_form_regions_label', 'Todas as Regiões', 'yes'); 
INSERT INTO `wp_options` VALUES ('446', 'dbem_search_form_region_label', 'Region', 'yes'); 
INSERT INTO `wp_options` VALUES ('447', 'dbem_search_form_states', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('448', 'dbem_search_form_states_label', 'Todos os Estados', 'yes'); 
INSERT INTO `wp_options` VALUES ('449', 'dbem_search_form_state_label', 'State/County', 'yes'); 
INSERT INTO `wp_options` VALUES ('450', 'dbem_search_form_towns', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('451', 'dbem_search_form_towns_label', 'All Cities/Towns', 'yes'); 
INSERT INTO `wp_options` VALUES ('452', 'dbem_search_form_town_label', 'City/Town', 'yes'); 
INSERT INTO `wp_options` VALUES ('453', 'dbem_events_form_editor', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('454', 'dbem_events_form_reshow', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('459', 'dbem_events_form_result_success', 'You have successfully submitted your event, which will be published pending approval.', 'yes'); 
INSERT INTO `wp_options` VALUES ('460', 'dbem_events_form_result_success_updated', 'You have successfully updated your event, which will be republished pending approval.', 'yes'); 
INSERT INTO `wp_options` VALUES ('461', 'dbem_events_anonymous_submissions', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('462', 'dbem_events_anonymous_user', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('463', 'dbem_events_anonymous_result_success', 'You have successfully submitted your event, which will be published pending approval.', 'yes'); 
INSERT INTO `wp_options` VALUES ('464', 'dbem_event_submitted_email_admin', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('465', 'dbem_event_submitted_email_subject', 'Submitted Event Awaiting Approval', 'yes'); 
INSERT INTO `wp_options` VALUES ('466', 'dbem_event_submitted_email_body', 'A new event has been submitted by #_CONTACTNAME.

Name : #_EVENTNAME 

Date : #_EVENTDATES 

Time : #_EVENTTIMES 

Please visit http://127.0.0.1/asug/wp-admin/post.php?action=edit&post=#_EVENTPOSTID to review this event for approval.


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('467', 'dbem_event_resubmitted_email_subject', 'Re-Submitted Event Awaiting Approval', 'yes'); 
INSERT INTO `wp_options` VALUES ('468', 'dbem_event_resubmitted_email_body', 'A previously published event has been modified by #_CONTACTNAME, and this event is now unpublished and pending your approval.

Name : #_EVENTNAME 

Date : #_EVENTDATES 

Time : #_EVENTTIMES 

Please visit http://127.0.0.1/asug/wp-admin/post.php?action=edit&post=#_EVENTPOSTID to review this event for approval.


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('469', 'dbem_event_published_email_subject', 'Published Event - #_EVENTNAME', 'yes'); 
INSERT INTO `wp_options` VALUES ('470', 'dbem_event_published_email_body', 'A new event has been published by #_CONTACTNAME.

Name : #_EVENTNAME 

Date : #_EVENTDATES 

Time : #_EVENTTIMES 

Edit this event - http://127.0.0.1/asug/wp-admin/post.php?action=edit&post=#_EVENTPOSTID 

 View this event - #_EVENTURL


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('471', 'dbem_event_approved_email_subject', 'Event Approved - #_EVENTNAME', 'yes'); 
INSERT INTO `wp_options` VALUES ('472', 'dbem_event_approved_email_body', 'Dear #_CONTACTNAME, 

Your event #_EVENTNAME on #_EVENTDATES has been approved.

You can view your event here: #_EVENTURL


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('473', 'dbem_event_reapproved_email_subject', 'Event Approved - #_EVENTNAME', 'yes'); 
INSERT INTO `wp_options` VALUES ('474', 'dbem_event_reapproved_email_body', 'Dear #_CONTACTNAME, 

Your event #_EVENTNAME on #_EVENTDATES has been approved.

You can view your event here: #_EVENTURL


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('475', 'dbem_events_page_title', 'Eventos', 'yes'); 
INSERT INTO `wp_options` VALUES ('476', 'dbem_events_page_scope', 'future', 'yes'); 
INSERT INTO `wp_options` VALUES ('477', 'dbem_events_page_search_form', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('478', 'dbem_event_list_item_format_header', '<table cellpadding="0" cellspacing="0" class="events-table" >
    <thead>
        <tr>
			<th class="event-time" width="150">Data / Hora</th>
			<th class="event-description" width="*">Evento</th>
		</tr>
   	</thead>
    <tbody>', 'yes'); 
INSERT INTO `wp_options` VALUES ('479', 'dbem_event_list_item_format', '<tr>
			<td>
                #_EVENTDATES<br/>
                #_EVENTTIMES
            </td>
            <td>
                #_EVENTLINK
                {has_location}<br/><i>#_LOCATIONNAME, #_LOCATIONTOWN #_LOCATIONSTATE</i>{/has_location}
            </td>
        </tr>', 'yes'); 
INSERT INTO `wp_options` VALUES ('480', 'dbem_event_list_item_format_footer', '</tbody></table>', 'yes'); 
INSERT INTO `wp_options` VALUES ('481', 'dbem_display_calendar_in_events_page', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('482', 'dbem_single_event_format', '<div style="float:right; margin:0px 0px 15px 15px;">#_LOCATIONMAP</div>
<p>
	<strong>Data / Hora</strong><br/>
	Date(s) - #_EVENTDATES<br /><i>#_EVENTTIMES</i>
</p>
{has_location}
<p>
	<strong>Localização</strong><br/>
	#_LOCATIONLINK
</p>
{/has_location}
<p>
	<strong>Categorias</strong>
	#_CATEGORIES
</p>
<br style="clear:both" />
#_EVENTNOTES
{has_bookings}
<h3>Bookings</h3>
#_BOOKINGFORM
{/has_bookings}', 'yes'); 
INSERT INTO `wp_options` VALUES ('483', 'dbem_event_page_title_format', '#_EVENTNAME', 'yes'); 
INSERT INTO `wp_options` VALUES ('484', 'dbem_event_all_day_message', 'All Day', 'yes'); 
INSERT INTO `wp_options` VALUES ('485', 'dbem_no_events_message', 'Não Eventos', 'yes'); 
INSERT INTO `wp_options` VALUES ('486', 'dbem_locations_default_orderby', 'location_name', 'yes'); 
INSERT INTO `wp_options` VALUES ('487', 'dbem_locations_default_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('488', 'dbem_locations_default_limit', '10', 'yes'); 
INSERT INTO `wp_options` VALUES ('489', 'dbem_locations_page_title', 'Evento Locais', 'yes'); 
INSERT INTO `wp_options` VALUES ('490', 'dbem_locations_page_search_form', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('491', 'dbem_no_locations_message', 'Não Locais', 'yes'); 
INSERT INTO `wp_options` VALUES ('492', 'dbem_location_default_country', 'BR', 'yes'); 
INSERT INTO `wp_options` VALUES ('493', 'dbem_location_list_item_format_header', '<ul class="em-locations-list">', 'yes'); 
INSERT INTO `wp_options` VALUES ('494', 'dbem_location_list_item_format', '<li>#_LOCATIONLINK<ul><li>#_LOCATIONFULLLINE</li></ul></li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('495', 'dbem_location_list_item_format_footer', '</ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('496', 'dbem_location_page_title_format', '#_LOCATIONNAME', 'yes'); 
INSERT INTO `wp_options` VALUES ('497', 'dbem_single_location_format', '<div style="float:right; margin:0px 0px 15px 15px;">#_LOCATIONMAP</div>
<p>
	<strong>Endereço</strong><br/>
	#_LOCATIONADDRESS<br/>
	#_LOCATIONTOWN<br/>
	#_LOCATIONSTATE<br/>
	#_LOCATIONREGION<br/>
	#_LOCATIONPOSTCODE<br/>
	#_LOCATIONCOUNTRY
</p>
<br style="clear:both" />
#_LOCATIONNOTES

<h3>Upcoming Events</h3>
<p>#_LOCATIONNEXTEVENTS</p>', 'yes'); 
INSERT INTO `wp_options` VALUES ('498', 'dbem_location_no_events_message', '<li>No events in this location</li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('499', 'dbem_location_event_list_item_header_format', '<ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('500', 'dbem_location_event_list_item_format', '<li>#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES</li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('501', 'dbem_location_event_list_item_footer_format', '</ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('502', 'dbem_location_event_list_limit', '20', 'yes'); 
INSERT INTO `wp_options` VALUES ('503', 'dbem_location_event_single_format', '#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES', 'yes'); 
INSERT INTO `wp_options` VALUES ('504', 'dbem_location_no_event_message', 'No events in this location', 'yes'); 
INSERT INTO `wp_options` VALUES ('505', 'dbem_categories_default_limit', '10', 'yes'); 
INSERT INTO `wp_options` VALUES ('506', 'dbem_categories_default_orderby', 'name', 'yes'); 
INSERT INTO `wp_options` VALUES ('507', 'dbem_categories_default_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('508', 'dbem_categories_list_item_format_header', '<ul class="em-categories-list">', 'yes'); 
INSERT INTO `wp_options` VALUES ('509', 'dbem_categories_list_item_format', '<li>#_CATEGORYLINK</li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('510', 'dbem_categories_list_item_format_footer', '</ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('511', 'dbem_no_categories_message', 'Não Categorias', 'yes'); 
INSERT INTO `wp_options` VALUES ('512', 'dbem_category_page_title_format', '#_CATEGORYNAME', 'yes'); 
INSERT INTO `wp_options` VALUES ('513', 'dbem_category_page_format', '#_CATEGORYNOTES<h3>Upcoming Events</h3>#_CATEGORYNEXTEVENTS', 'yes'); 
INSERT INTO `wp_options` VALUES ('514', 'dbem_category_no_events_message', '<li>No events in this category</li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('515', 'dbem_category_event_list_item_header_format', '<ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('516', 'dbem_category_event_list_item_format', '<li>#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES</li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('517', 'dbem_category_event_list_item_footer_format', '</ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('518', 'dbem_category_event_list_limit', '20', 'yes'); 
INSERT INTO `wp_options` VALUES ('519', 'dbem_category_event_single_format', '#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES', 'yes'); 
INSERT INTO `wp_options` VALUES ('520', 'dbem_category_no_event_message', 'No events in this category', 'yes'); 
INSERT INTO `wp_options` VALUES ('521', 'dbem_tags_default_limit', '10', 'yes'); 
INSERT INTO `wp_options` VALUES ('522', 'dbem_tags_default_orderby', 'name', 'yes'); 
INSERT INTO `wp_options` VALUES ('523', 'dbem_tags_default_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('524', 'dbem_tags_list_item_format_header', '<ul class="em-tags-list">', 'yes'); 
INSERT INTO `wp_options` VALUES ('525', 'dbem_tags_list_item_format', '<li>#_TAGLINK</li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('526', 'dbem_tags_list_item_format_footer', '</ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('527', 'dbem_no_tags_message', 'Não Tags', 'yes'); 
INSERT INTO `wp_options` VALUES ('528', 'dbem_tag_page_title_format', '#_TAGNAME', 'yes'); 
INSERT INTO `wp_options` VALUES ('529', 'dbem_tag_page_format', '<h3>Upcoming Events</h3>#_TAGNEXTEVENTS', 'yes'); 
INSERT INTO `wp_options` VALUES ('530', 'dbem_tag_no_events_message', '<li>No events with this tag</li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('531', 'dbem_tag_event_list_item_header_format', '<ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('532', 'dbem_tag_event_list_item_format', '<li>#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES</li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('533', 'dbem_tag_event_list_item_footer_format', '</ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('534', 'dbem_tag_event_single_format', '#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES', 'yes'); 
INSERT INTO `wp_options` VALUES ('535', 'dbem_tag_no_event_message', 'No events with this tag', 'yes'); 
INSERT INTO `wp_options` VALUES ('536', 'dbem_tag_event_list_limit', '20', 'yes'); 
INSERT INTO `wp_options` VALUES ('537', 'dbem_rss_limit', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('538', 'dbem_rss_scope', 'future', 'yes'); 
INSERT INTO `wp_options` VALUES ('539', 'dbem_rss_main_title', 'Asug | SAP NetWeaver Portal - Eventos', 'yes'); 
INSERT INTO `wp_options` VALUES ('540', 'dbem_rss_main_description', 'Só mais um site WordPress - Eventos', 'yes'); 
INSERT INTO `wp_options` VALUES ('541', 'dbem_rss_description_format', '#_EVENTDATES - #_EVENTTIMES <br/>#_LOCATIONNAME <br/>#_LOCATIONADDRESS <br/>#_LOCATIONTOWN', 'yes'); 
INSERT INTO `wp_options` VALUES ('542', 'dbem_rss_title_format', '#_EVENTNAME', 'yes'); 
INSERT INTO `wp_options` VALUES ('543', 'em_rss_pubdate', 'Sun, 16 Mar 2014 22:39:36 +0000', 'yes'); 
INSERT INTO `wp_options` VALUES ('544', 'dbem_ical_limit', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('545', 'dbem_ical_scope', 'future', 'yes'); 
INSERT INTO `wp_options` VALUES ('546', 'dbem_ical_description_format', '#_EVENTNAME - #_LOCATIONNAME - #_EVENTDATES - #_EVENTTIMES', 'yes'); 
INSERT INTO `wp_options` VALUES ('547', 'dbem_ical_real_description_format', '#_EVENTEXCERPT', 'yes'); 
INSERT INTO `wp_options` VALUES ('548', 'dbem_ical_location_format', '#_LOCATION', 'yes'); 
INSERT INTO `wp_options` VALUES ('549', 'dbem_gmap_is_active', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('550', 'dbem_map_default_width', '400px', 'yes'); 
INSERT INTO `wp_options` VALUES ('551', 'dbem_map_default_height', '300px', 'yes'); 
INSERT INTO `wp_options` VALUES ('552', 'dbem_location_baloon_format', '<strong>#_LOCATIONNAME</strong><br/>#_LOCATIONADDRESS - #_LOCATIONTOWN<br/><a href="#_LOCATIONPAGEURL">Eventos</a>', 'yes'); 
INSERT INTO `wp_options` VALUES ('553', 'dbem_map_text_format', '<strong>#_LOCATIONNAME</strong><p>#_LOCATIONADDRESS</p><p>#_LOCATIONTOWN</p>', 'yes'); 
INSERT INTO `wp_options` VALUES ('554', 'dbem_email_disable_registration', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('555', 'dbem_rsvp_mail_port', '465', 'yes'); 
INSERT INTO `wp_options` VALUES ('556', 'dbem_smtp_host', 'localhost', 'yes'); 
INSERT INTO `wp_options` VALUES ('557', 'dbem_mail_sender_name', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('558', 'dbem_rsvp_mail_send_method', 'mail', 'yes'); 
INSERT INTO `wp_options` VALUES ('559', 'dbem_rsvp_mail_SMTPAuth', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('560', 'dbem_smtp_html', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('561', 'dbem_smtp_html_br', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('562', 'dbem_image_max_width', '700', 'yes'); 
INSERT INTO `wp_options` VALUES ('563', 'dbem_image_max_height', '700', 'yes'); 
INSERT INTO `wp_options` VALUES ('564', 'dbem_image_min_width', '50', 'yes'); 
INSERT INTO `wp_options` VALUES ('565', 'dbem_image_min_height', '50', 'yes'); 
INSERT INTO `wp_options` VALUES ('566', 'dbem_image_max_size', '204800', 'yes'); 
INSERT INTO `wp_options` VALUES ('567', 'dbem_list_date_title', 'Eventos - #j #M #y', 'yes'); 
INSERT INTO `wp_options` VALUES ('568', 'dbem_full_calendar_month_format', 'M Y', 'yes'); 
INSERT INTO `wp_options` VALUES ('569', 'dbem_full_calendar_event_format', '<li>#_EVENTLINK</li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('570', 'dbem_full_calendar_long_events', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('571', 'dbem_full_calendar_initials_length', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('572', 'dbem_full_calendar_abbreviated_weekdays', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('573', 'dbem_display_calendar_day_single_yes', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('574', 'dbem_small_calendar_month_format', 'M Y', 'yes'); 
INSERT INTO `wp_options` VALUES ('575', 'dbem_small_calendar_event_title_format', '#_EVENTNAME', 'yes'); 
INSERT INTO `wp_options` VALUES ('576', 'dbem_small_calendar_event_title_separator', ', ', 'yes'); 
INSERT INTO `wp_options` VALUES ('577', 'dbem_small_calendar_initials_length', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('578', 'dbem_small_calendar_abbreviated_weekdays', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('579', 'dbem_display_calendar_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('580', 'dbem_display_calendar_orderby', 'event_name,event_start_time', 'yes'); 
INSERT INTO `wp_options` VALUES ('581', 'dbem_display_calendar_events_limit', '3', 'yes'); 
INSERT INTO `wp_options` VALUES ('582', 'dbem_display_calendar_events_limit_msg', 'more...', 'yes'); 
INSERT INTO `wp_options` VALUES ('583', 'dbem_calendar_direct_links', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('584', 'dbem_require_location', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('585', 'dbem_locations_enabled', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('586', 'dbem_use_select_for_locations', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('587', 'dbem_attributes_enabled', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('588', 'dbem_recurrence_enabled', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('589', 'dbem_rsvp_enabled', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('590', 'dbem_categories_enabled', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('591', 'dbem_tags_enabled', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('592', 'dbem_placeholders_custom', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('593', 'dbem_location_attributes_enabled', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('594', 'dbem_location_placeholders_custom', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('595', 'dbem_bookings_registration_disable', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('596', 'dbem_bookings_registration_disable_user_emails', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('597', 'dbem_bookings_registration_user', '4', 'yes'); 
INSERT INTO `wp_options` VALUES ('598', 'dbem_bookings_approval', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('599', 'dbem_bookings_approval_reserved', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('600', 'dbem_bookings_approval_overbooking', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('601', 'dbem_bookings_double', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('602', 'dbem_bookings_user_cancellation', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('603', 'dbem_bookings_currency', 'BRL', 'yes'); 
INSERT INTO `wp_options` VALUES ('604', 'dbem_bookings_currency_decimal_point', ',', 'yes'); 
INSERT INTO `wp_options` VALUES ('605', 'dbem_bookings_currency_thousands_sep', '.', 'yes'); 
INSERT INTO `wp_options` VALUES ('606', 'dbem_bookings_currency_format', '@#', 'yes'); 
INSERT INTO `wp_options` VALUES ('607', 'dbem_bookings_tax', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('608', 'dbem_bookings_tax_auto_add', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('609', 'dbem_bookings_submit_button', 'Enviar a sua reserva', 'yes'); 
INSERT INTO `wp_options` VALUES ('610', 'dbem_bookings_login_form', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('611', 'dbem_bookings_anonymous', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('612', 'dbem_bookings_form_max', '20', 'yes'); 
INSERT INTO `wp_options` VALUES ('613', 'dbem_bookings_form_msg_disabled', 'Reservas on-line não estão disponíveis para este evento.', 'yes'); 
INSERT INTO `wp_options` VALUES ('614', 'dbem_bookings_form_msg_closed', 'As reservas estão fechados para este evento.', 'yes'); 
INSERT INTO `wp_options` VALUES ('615', 'dbem_bookings_form_msg_full', 'This event is fully booked.', 'yes'); 
INSERT INTO `wp_options` VALUES ('616', 'dbem_bookings_form_msg_attending', 'You are currently attending this event.', 'yes'); 
INSERT INTO `wp_options` VALUES ('617', 'dbem_bookings_form_msg_bookings_link', 'Manage my bookings', 'yes'); 
INSERT INTO `wp_options` VALUES ('618', 'dbem_booking_warning_cancel', 'Tem certeza de que deseja cancelar a sua reserva?', 'yes'); 
INSERT INTO `wp_options` VALUES ('619', 'dbem_booking_feedback_cancelled', 'Reserva Cancelado', 'yes'); 
INSERT INTO `wp_options` VALUES ('620', 'dbem_booking_feedback_pending', 'Confirmação de reserva bem sucedida, aguardando confirmação(você também receberá um e-mail uma vez confirmado).', 'yes'); 
INSERT INTO `wp_options` VALUES ('621', 'dbem_booking_feedback', 'Reserva  feita com sucesso.', 'yes'); 
INSERT INTO `wp_options` VALUES ('622', 'dbem_booking_feedback_full', 'A sua reserva não pode ser efetuada, não há lugares disponíveis!', 'yes'); 
INSERT INTO `wp_options` VALUES ('623', 'dbem_booking_feedback_log_in', 'Você deve fazer login ou registre-se para fazer uma reserva.', 'yes'); 
INSERT INTO `wp_options` VALUES ('624', 'dbem_booking_feedback_nomail', 'No entanto, tivemos problemas ao enviar um e-mail de confirmação para você e / ou a pessoa de contacto evento. Você também pode entrar em contato diretamente, informando sobre o erro.', 'yes'); 
INSERT INTO `wp_options` VALUES ('625', 'dbem_booking_feedback_error', 'Reserva não  pôde  ser criada:', 'yes'); 
INSERT INTO `wp_options` VALUES ('626', 'dbem_booking_feedback_email_exists', 'Este e-mail já existe em nosso sistema, faça o login para registar-se e prosseguir com a sua reserva.', 'yes'); 
INSERT INTO `wp_options` VALUES ('627', 'dbem_booking_feedback_new_user', 'Uma nova conta de usuário foi criado para você. Por favor verifique seu e-mail para detalhes de acesso.', 'yes'); 
INSERT INTO `wp_options` VALUES ('628', 'dbem_booking_feedback_reg_error', 'Houve um problema ao criar uma conta de usuário, por favor entre em com o administrador do site.', 'yes'); 
INSERT INTO `wp_options` VALUES ('629', 'dbem_booking_feedback_already_booked', 'Você já tem reservado um lugar neste evento.', 'yes'); 
INSERT INTO `wp_options` VALUES ('630', 'dbem_booking_feedback_min_space', 'Você deve solicitar pelo menos um espaço para reservar um evento.', 'yes'); 
INSERT INTO `wp_options` VALUES ('631', 'dbem_booking_feedback_spaces_limit', 'You cannot book more than %d spaces for this event.', 'yes'); 
INSERT INTO `wp_options` VALUES ('632', 'dbem_booking_button_msg_book', 'Reserve agora', 'yes'); 
INSERT INTO `wp_options` VALUES ('633', 'dbem_booking_button_msg_booking', 'Reserva ...', 'yes'); 
INSERT INTO `wp_options` VALUES ('634', 'dbem_booking_button_msg_booked', 'Reserva Submitted', 'yes'); 
INSERT INTO `wp_options` VALUES ('635', 'dbem_booking_button_msg_already_booked', 'Already Booked', 'yes'); 
INSERT INTO `wp_options` VALUES ('636', 'dbem_booking_button_msg_error', 'Reserva Error. Try again?', 'yes'); 
INSERT INTO `wp_options` VALUES ('637', 'dbem_booking_button_msg_full', 'Sold Out', 'yes'); 
INSERT INTO `wp_options` VALUES ('638', 'dbem_booking_button_msg_cancel', 'Cancelar', 'yes'); 
INSERT INTO `wp_options` VALUES ('639', 'dbem_booking_button_msg_canceling', 'Canceling...', 'yes'); 
INSERT INTO `wp_options` VALUES ('640', 'dbem_booking_button_msg_cancelled', 'Cancelado', 'yes'); 
INSERT INTO `wp_options` VALUES ('641', 'dbem_booking_button_msg_cancel_error', 'Cancellation Error. Try again?', 'yes'); 
INSERT INTO `wp_options` VALUES ('642', 'dbem_bookings_notify_admin', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('643', 'dbem_bookings_contact_email', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('644', 'dbem_bookings_contact_email_subject', 'New Booking', 'yes'); 
INSERT INTO `wp_options` VALUES ('645', 'dbem_bookings_contact_email_body', '#_BOOKINGNAME (#_BOOKINGEMAIL) will attend #_EVENTNAME on #_EVENTDATES. He wants to reserve #_BOOKINGSPACES spaces.

 Now there are #_BOOKEDSPACES spaces reserved, #_AVAILABLESPACES are still available.

Yours faithfully,

Events Manager - http://wp-events-plugin.com


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('646', 'dbem_contactperson_email_cancelled_subject', 'Reserva cancelada', 'yes'); 
INSERT INTO `wp_options` VALUES ('647', 'dbem_contactperson_email_cancelled_body', '#_BOOKINGNAME (#_BOOKINGEMAIL) cancelled his booking at #_EVENTNAME on #_EVENTDATES. He wanted to reserve #_BOOKINGSPACES spaces.

 Now there are #_BOOKEDSPACES spaces reserved, #_AVAILABLESPACES are still available.

Yours faithfully,

Events Manager - http://wp-events-plugin.com


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('648', 'dbem_bookings_email_pending_subject', 'Reserva Pendente', 'yes'); 
INSERT INTO `wp_options` VALUES ('649', 'dbem_bookings_email_pending_body', 'Dear #_BOOKINGNAME, 

You have requested #_BOOKINGSPACES space/spaces for #_EVENTNAME.

When : #_EVENTDATES @ #_EVENTTIMES

Where : #_LOCATIONNAME - #_LOCATIONFULLLINE

Your booking is currently pending approval by our administrators. Once approved you will receive an automatic confirmation.

Yours faithfully,

#_CONTACTNAME


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('650', 'dbem_bookings_email_rejected_subject', 'Reserva Rejeitada', 'yes'); 
INSERT INTO `wp_options` VALUES ('651', 'dbem_bookings_email_rejected_body', 'Dear #_BOOKINGNAME, 

Your requested booking for #_BOOKINGSPACES spaces at #_EVENTNAME on #_EVENTDATES has been rejected.

Yours faithfully,

#_CONTACTNAME


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('652', 'dbem_bookings_email_confirmed_subject', 'Reserva Confirmada', 'yes'); 
INSERT INTO `wp_options` VALUES ('653', 'dbem_bookings_email_confirmed_body', 'Dear #_BOOKINGNAME, 

You have successfully reserved #_BOOKINGSPACES space/spaces for #_EVENTNAME.

When : #_EVENTDATES @ #_EVENTTIMES

Where : #_LOCATIONNAME - #_LOCATIONFULLLINE

Yours faithfully,

#_CONTACTNAME


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('654', 'dbem_bookings_email_cancelled_subject', 'Reserva cancelada', 'yes'); 
INSERT INTO `wp_options` VALUES ('655', 'dbem_bookings_email_cancelled_body', 'Dear #_BOOKINGNAME, 

Your requested booking for #_BOOKINGSPACES spaces at #_EVENTNAME on #_EVENTDATES has been cancelled.

Yours faithfully,

#_CONTACTNAME


-------------------------------

Powered by Events Manager - http://wp-events-plugin.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('656', 'dbem_bookings_email_registration_subject', '[Asug | SAP NetWeaver Portal] O seu nome de usuário e senha', 'yes'); 
INSERT INTO `wp_options` VALUES ('657', 'dbem_bookings_email_registration_body', 'You have successfully created an account at Asug | SAP NetWeaver Portal

You can log into our site here : http://127.0.0.1/asug/wp-login.php

Nome de Usuário : %username%

Senha : %password%

To view your bookings, please visit http://127.0.0.1/asug/eventos/minhas-reservas/ after logging in.', 'yes'); 
INSERT INTO `wp_options` VALUES ('658', 'dbem_bookings_tickets_orderby', 'ticket_price DESC, ticket_name ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('659', 'dbem_bookings_tickets_priority', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('660', 'dbem_bookings_tickets_show_unavailable', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('661', 'dbem_bookings_tickets_show_loggedout', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('662', 'dbem_bookings_tickets_single', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('663', 'dbem_bookings_tickets_single_form', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('664', 'dbem_bookings_my_title_format', 'Minhas Reservas', 'yes'); 
INSERT INTO `wp_options` VALUES ('665', 'dbem_bp_events_list_format_header', '<ul class="em-events-list">', 'yes'); 
INSERT INTO `wp_options` VALUES ('666', 'dbem_bp_events_list_format', '<li>#_EVENTLINK - #_EVENTDATES - #_EVENTTIMES<ul><li>#_LOCATIONLINK - #_LOCATIONADDRESS, #_LOCATIONTOWN</li></ul></li>', 'yes'); 
INSERT INTO `wp_options` VALUES ('667', 'dbem_bp_events_list_format_footer', '</ul>', 'yes'); 
INSERT INTO `wp_options` VALUES ('668', 'dbem_bp_events_list_none_format', '<p class="em-events-list">Nenhum Eventos</p>', 'yes'); 
INSERT INTO `wp_options` VALUES ('669', 'dbem_css_editors', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('670', 'dbem_css_rsvp', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('671', 'dbem_css_rsvpadmin', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('672', 'dbem_css_evlist', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('673', 'dbem_css_search', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('674', 'dbem_css_loclist', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('675', 'dbem_css_catlist', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('676', 'dbem_css_taglist', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('677', 'dbem_cp_events_slug', 'events', 'yes'); 
INSERT INTO `wp_options` VALUES ('678', 'dbem_cp_locations_slug', 'locations', 'yes'); 
INSERT INTO `wp_options` VALUES ('679', 'dbem_taxonomy_category_slug', 'events/categories', 'yes'); 
INSERT INTO `wp_options` VALUES ('680', 'dbem_taxonomy_tag_slug', 'events/tags', 'yes'); 
INSERT INTO `wp_options` VALUES ('681', 'dbem_cp_events_template', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('682', 'dbem_cp_events_body_class', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('683', 'dbem_cp_events_post_class', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('684', 'dbem_cp_events_formats', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('685', 'dbem_cp_events_has_archive', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('686', 'dbem_events_default_archive_orderby', '_start_ts', 'yes'); 
INSERT INTO `wp_options` VALUES ('687', 'dbem_events_default_archive_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('688', 'dbem_events_archive_scope', 'past', 'yes'); 
INSERT INTO `wp_options` VALUES ('689', 'dbem_cp_events_archive_formats', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('690', 'dbem_cp_events_search_results', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('691', 'dbem_cp_events_custom_fields', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('692', 'dbem_cp_events_comments', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('693', 'dbem_cp_locations_template', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('694', 'dbem_cp_locations_body_class', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('695', 'dbem_cp_locations_post_class', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('696', 'dbem_cp_locations_formats', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('697', 'dbem_cp_locations_has_archive', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('698', 'dbem_locations_default_archive_orderby', 'title', 'yes'); 
INSERT INTO `wp_options` VALUES ('699', 'dbem_locations_default_archive_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('700', 'dbem_cp_locations_archive_formats', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('701', 'dbem_cp_locations_search_results', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('702', 'dbem_cp_locations_custom_fields', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('703', 'dbem_cp_locations_comments', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('704', 'dbem_cp_categories_formats', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('705', 'dbem_categories_default_archive_orderby', '_start_ts', 'yes'); 
INSERT INTO `wp_options` VALUES ('706', 'dbem_categories_default_archive_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('707', 'dbem_cp_tags_formats', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('708', 'dbem_tags_default_archive_orderby', '_start_ts', 'yes'); 
INSERT INTO `wp_options` VALUES ('709', 'dbem_tags_default_archive_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('710', 'dbem_credits', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('711', 'dbem_time_24h', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('712', 'dbem_version', '5.52', 'yes'); 
INSERT INTO `wp_options` VALUES ('718', 'tchpcs_displayimage', 'YES', 'yes'); 
INSERT INTO `wp_options` VALUES ('719', 'tchpcs_word_limit', '9', 'yes'); 
INSERT INTO `wp_options` VALUES ('720', 'tchpcs_query_posts_showposts', '3', 'yes'); 
INSERT INTO `wp_options` VALUES ('721', 'tchpcs_query_posts_orderby', 'date', 'yes'); 
INSERT INTO `wp_options` VALUES ('722', 'tchpcs_query_posts_order', 'DESC', 'yes'); 
INSERT INTO `wp_options` VALUES ('723', 'tchpcs_query_posts_category', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('796', 'category_children', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('871', '_site_transient_timeout_browser_a1881c808a1e05a63fe1764418422689', '1395680170', 'yes'); 
INSERT INTO `wp_options` VALUES ('872', '_site_transient_browser_a1881c808a1e05a63fe1764418422689', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"33.0.1750.154";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('920', '_transient_timeout_plugin_slugs', '1395429812', 'no'); 
INSERT INTO `wp_options` VALUES ('921', '_transient_plugin_slugs', 'a:25:{i:0;s:29:"ads-by-datafeedrcom/dfads.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:19:"akismet/akismet.php";i:3;s:51:"auto-excerpt-everywhere/auto-excerpt-everywhere.php";i:4;s:41:"better-wp-security/better-wp-security.php";i:5;s:43:"broken-link-checker/broken-link-checker.php";i:6;s:85:"carousel-horizontal-posts-content-slider/carousel-horizontal-posts-content-slider.php";i:7;s:25:"cloudflare/cloudflare.php";i:8;s:36:"contact-form-7/wp-contact-form-7.php";i:9;s:33:"events-manager/events-manager.php";i:10;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:11;s:43:"google-analytics-dashboard-for-wp/gadwp.php";i:12;s:50:"google-analytics-for-wordpress/googleanalytics.php";i:13;s:36:"google-sitemap-generator/sitemap.php";i:14;s:9:"hello.php";i:15;s:29:"ready-backup/backup-ready.php";i:16;s:33:"seo-image/seo-friendly-images.php";i:17;s:33:"smart-slider-2/smart-slider-2.php";i:18;s:37:"user-role-editor/user-role-editor.php";i:19;s:29:"user-status-manager/start.php";i:20;s:33:"w3-total-cache/w3-total-cache.php";i:21;s:37:"widgets-on-pages/widgets_on_pages.php";i:22;s:27:"woocommerce/woocommerce.php";i:23;s:27:"wp-optimize/wp-optimize.php";i:24;s:31:"wp-backupware/wp-backupware.php";}', 'no'); 
INSERT INTO `wp_options` VALUES ('932', 'woocommerce_default_country', 'GB', 'yes'); 
INSERT INTO `wp_options` VALUES ('933', 'woocommerce_allowed_countries', 'all', 'yes'); 
INSERT INTO `wp_options` VALUES ('934', 'woocommerce_specific_allowed_countries', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('935', 'woocommerce_demo_store', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('936', 'woocommerce_demo_store_notice', 'This is a demo store for testing purposes &mdash; no orders shall be fulfilled.', 'no'); 
INSERT INTO `wp_options` VALUES ('937', 'woocommerce_api_enabled', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES ('938', 'woocommerce_currency', 'GBP', 'yes'); 
INSERT INTO `wp_options` VALUES ('939', 'woocommerce_currency_pos', 'left', 'yes'); 
INSERT INTO `wp_options` VALUES ('940', 'woocommerce_price_thousand_sep', ',', 'yes'); 
INSERT INTO `wp_options` VALUES ('941', 'woocommerce_price_decimal_sep', '.', 'yes'); 
INSERT INTO `wp_options` VALUES ('942', 'woocommerce_price_num_decimals', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('943', 'woocommerce_enable_lightbox', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES ('944', 'woocommerce_enable_chosen', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('945', 'woocommerce_shop_page_id', '96', 'yes'); 
INSERT INTO `wp_options` VALUES ('946', 'woocommerce_shop_page_display', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('947', 'woocommerce_category_archive_display', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('948', 'woocommerce_default_catalog_orderby', 'title', 'yes'); 
INSERT INTO `wp_options` VALUES ('949', 'woocommerce_cart_redirect_after_add', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('950', 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES ('951', 'woocommerce_weight_unit', 'kg', 'yes'); 
INSERT INTO `wp_options` VALUES ('952', 'woocommerce_dimension_unit', 'cm', 'yes'); 
INSERT INTO `wp_options` VALUES ('953', 'woocommerce_enable_review_rating', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('954', 'woocommerce_review_rating_required', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('955', 'woocommerce_review_rating_verification_label', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('956', 'woocommerce_review_rating_verification_required', 'no', 'no'); 
INSERT INTO `wp_options` VALUES ('957', 'shop_catalog_image_size', 'a:3:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";b:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('958', 'shop_single_image_size', 'a:3:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('959', 'shop_thumbnail_image_size', 'a:3:{s:5:"width";s:2:"90";s:6:"height";s:2:"90";s:4:"crop";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('960', 'woocommerce_file_download_method', 'force', 'no'); 
INSERT INTO `wp_options` VALUES ('961', 'woocommerce_downloads_require_login', 'no', 'no'); 
INSERT INTO `wp_options` VALUES ('962', 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('963', 'woocommerce_manage_stock', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES ('964', 'woocommerce_hold_stock_minutes', '60', 'no'); 
INSERT INTO `wp_options` VALUES ('965', 'woocommerce_notify_low_stock', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('966', 'woocommerce_notify_no_stock', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('967', 'woocommerce_stock_email_recipient', 'contato@montarsite.com.br', 'no'); 
INSERT INTO `wp_options` VALUES ('968', 'woocommerce_notify_low_stock_amount', '2', 'no'); 
INSERT INTO `wp_options` VALUES ('969', 'woocommerce_notify_no_stock_amount', '0', 'no'); 
INSERT INTO `wp_options` VALUES ('970', 'woocommerce_hide_out_of_stock_items', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('971', 'woocommerce_stock_format', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('972', 'woocommerce_calc_taxes', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('973', 'woocommerce_prices_include_tax', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('974', 'woocommerce_tax_based_on', 'shipping', 'yes'); 
INSERT INTO `wp_options` VALUES ('975', 'woocommerce_default_customer_address', 'base', 'yes'); 
INSERT INTO `wp_options` VALUES ('976', 'woocommerce_shipping_tax_class', 'title', 'yes'); 
INSERT INTO `wp_options` VALUES ('977', 'woocommerce_tax_round_at_subtotal', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('978', 'woocommerce_tax_classes', 'Reduced Rate
Zero Rate', 'yes'); 
INSERT INTO `wp_options` VALUES ('979', 'woocommerce_tax_display_shop', 'excl', 'yes'); 
INSERT INTO `wp_options` VALUES ('980', 'woocommerce_price_display_suffix', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('981', 'woocommerce_tax_display_cart', 'excl', 'no'); 
INSERT INTO `wp_options` VALUES ('982', 'woocommerce_tax_total_display', 'itemized', 'no'); 
INSERT INTO `wp_options` VALUES ('983', 'woocommerce_enable_coupons', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('984', 'woocommerce_enable_guest_checkout', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('985', 'woocommerce_force_ssl_checkout', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('986', 'woocommerce_unforce_ssl_checkout', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('987', 'woocommerce_cart_page_id', '97', 'yes'); 
INSERT INTO `wp_options` VALUES ('988', 'woocommerce_checkout_page_id', '98', 'yes'); 
INSERT INTO `wp_options` VALUES ('989', 'woocommerce_terms_page_id', '', 'no'); 
INSERT INTO `wp_options` VALUES ('990', 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'); 
INSERT INTO `wp_options` VALUES ('991', 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'); 
INSERT INTO `wp_options` VALUES ('992', 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'); 
INSERT INTO `wp_options` VALUES ('993', 'woocommerce_calc_shipping', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES ('994', 'woocommerce_enable_shipping_calc', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('995', 'woocommerce_shipping_cost_requires_address', 'no', 'no'); 
INSERT INTO `wp_options` VALUES ('996', 'woocommerce_shipping_method_format', '', 'no'); 
INSERT INTO `wp_options` VALUES ('997', 'woocommerce_ship_to_billing', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('998', 'woocommerce_ship_to_billing_address_only', 'no', 'no'); 
INSERT INTO `wp_options` VALUES ('999', 'woocommerce_ship_to_countries', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1000', 'woocommerce_specific_ship_to_countries', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1001', 'woocommerce_myaccount_page_id', '99', 'yes'); 
INSERT INTO `wp_options` VALUES ('1002', 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'); 
INSERT INTO `wp_options` VALUES ('1003', 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'); 
INSERT INTO `wp_options` VALUES ('1004', 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'); 
INSERT INTO `wp_options` VALUES ('1005', 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'); 
INSERT INTO `wp_options` VALUES ('1006', 'woocommerce_logout_endpoint', 'customer-logout', 'yes'); 
INSERT INTO `wp_options` VALUES ('1007', 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('1008', 'woocommerce_enable_myaccount_registration', 'no', 'no'); 
INSERT INTO `wp_options` VALUES ('1009', 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('1010', 'woocommerce_registration_generate_username', 'yes', 'no'); 
INSERT INTO `wp_options` VALUES ('1011', 'woocommerce_registration_generate_password', 'no', 'no'); 
INSERT INTO `wp_options` VALUES ('1012', 'woocommerce_email_from_name', 'Asug | SAP NetWeaver Portal', 'no'); 
INSERT INTO `wp_options` VALUES ('1013', 'woocommerce_email_from_address', 'contato@montarsite.com.br', 'no'); 
INSERT INTO `wp_options` VALUES ('1014', 'woocommerce_email_header_image', '', 'no'); 
INSERT INTO `wp_options` VALUES ('1015', 'woocommerce_email_footer_text', 'Asug | SAP NetWeaver Portal - Powered by WooCommerce', 'no'); 
INSERT INTO `wp_options` VALUES ('1016', 'woocommerce_email_base_color', '#557da1', 'no'); 
INSERT INTO `wp_options` VALUES ('1017', 'woocommerce_email_background_color', '#f5f5f5', 'no'); 
INSERT INTO `wp_options` VALUES ('1018', 'woocommerce_email_body_background_color', '#fdfdfd', 'no'); 
INSERT INTO `wp_options` VALUES ('1019', 'woocommerce_email_text_color', '#505050', 'no'); 
INSERT INTO `wp_options` VALUES ('1020', '_transient_woocommerce_processing_order_count', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1022', 'woocommerce_db_version', '2.1.5', 'yes'); 
INSERT INTO `wp_options` VALUES ('1023', 'woocommerce_version', '2.1.5', 'yes'); 
INSERT INTO `wp_options` VALUES ('1028', '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1030', 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1031', '_transient_woocommerce_cache_excluded_uris', 'a:6:{i:0;s:4:"p=97";i:1;s:4:"p=98";i:2;s:4:"p=99";i:3;s:9:"/carrinho";i:4;s:17:"/finalizar-compra";i:5;s:12:"/minha-conta";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1036', 'user_role_editor', 'a:4:{s:17:"ure_caps_readable";i:0;s:24:"ure_show_deprecated_caps";i:0;s:19:"ure_hide_pro_banner";i:1;s:15:"show_admin_role";s:1:"1";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1037', 'wp_backup_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:138:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:57:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:20:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:15:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:12:{s:4:"read";b:1;s:7:"level_0";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:3:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"delete_posts";b:0;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:93:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'no'); 
INSERT INTO `wp_options` VALUES ('1040', '_transient_timeout_feed_761bc2b7ca033de73fa7b3a5a0ffb39a', '1395236713', 'no'); 
INSERT INTO `wp_options` VALUES ('1041', '_transient_feed_761bc2b7ca033de73fa7b3a5a0ffb39a', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:50:"
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:6:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"iThemes » WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:18:"http://ithemes.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:62:"Your one-stop shop for WordPress themes, plugins and training.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 19:23:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"Better WP Security Changing To iThemes Security: What You Need To Know";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://ithemes.com/2014/03/17/better-wp-security-plugin-changing-ithemes-security-need-know/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:101:"http://ithemes.com/2014/03/17/better-wp-security-plugin-changing-ithemes-security-need-know/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Mar 2014 19:01:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:18:"Better WP Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Homepage";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:16:"iThemes Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=22237";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:601:"<p>I’m very excited to share that next week, Better WP Security, the uber-popular security plugin developed by Chris Wiegman, will be getting a big, highly-anticipated update. One reason I’m so excited about this next update is because I found Better WP Security because I needed help locking down my own personal site. So I’m a [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/03/17/better-wp-security-plugin-changing-ithemes-security-need-know/">Better WP Security Changing To iThemes Security: What You Need To Know</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Cory Miller";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:8467:"<p>I’m very excited to share that next week, <a title="better wp security" href="http://wordpress.org/plugins/better-wp-security/"><strong>Better WP Security</strong></a>, the uber-popular security plugin developed by Chris Wiegman, will be getting a big, highly-anticipated update.</p>
<p>One reason I’m so excited about this next update is because I found Better WP Security because I needed help locking down my own personal site. So I’m a fan and user of BWPS just like you and know how it’s helped me personally (and want to continue doing that for others).</p>
<p>Over the years, we’ve seen increased attacks in the WordPress community and have sought to help our community by providing resources and tips, like <a href="http://ithemes.com/2013/04/15/ongoing-wordpress-attacks-details-and-solutions/">this post</a> last year.</p>
<p>Security isn&#8217;t going away. It&#8217;s only heating up as more and more people seek to exploit WP.</p>
<p>And we want to be part of the solution.</p>
<p>With that, I wanted to let you know about some things changing (and not changing) with Better WP Security (BWPS), soon to be iThemes Security.</p>
<h1>FOUR THINGS CHANGING</h1>
<h3 style="margin-top: 40px;">1. THE NAME IS CHANGING</h3>
<p>This is the biggest reason for this early announcement.</p>
<p><strong>With the new rollout, we’re changing the name from Better WP Security to iThemes Security to better reflect its role and future in the iThemes family.</strong> We hired Chris full-time in December 2013 to focus solely on making BWPS ( iThemes Security) better for you.</p>
<p>One important note about the name change, you’ll notice next week …</p>
<p><strong>Because of the way the WordPress.org plugin repository system is set up, changing the name of the plugin will cause it to show an error (as shown below) and deactivate the upgraded plugin.</strong></p>
<p style="text-align: center;"><img class="aligncenter  wp-image-22243" alt="better-wp-security-update-error" src="http://ithemes.com/wp-content/uploads/2014/03/better-wp-security-update-error.png" width="1287" height="724" /></p>
<p style="text-align: left;">The error will look like this after you&#8217;ve upgraded the plugin.</p>
<p><img class="aligncenter size-full wp-image-22244" alt="better-wp-security-error" src="http://ithemes.com/wp-content/uploads/2014/03/better-wp-security-error.png" width="901" height="57" /></p>
<p>But it has a very simple and easy fix:</p>
<blockquote><p><strong>Simply reactivate the “iThemes Security” plugin in your WP Dashboard after upgrading. </strong></p></blockquote>
<p>After upgrading, all you’ll have to do is simply “Activate” the new version titled “iThemes Security” plugin in your Dashboard after upgrade and you’re good to go. Your settings and setup will be saved.</p>
<p>We tried hard to find ways to work around this particular issue with changing the name, but unfortunately reactivation after updating the plugin is what has to be done to receive the new version.</p>
<p>With this post, we’re trying to get the word out as broadly as possible to let the community know this is coming and what to do in advance. <strong>We&#8217;d appreciate your help in spreading the word, too, by sharing this post.</strong></p>
<h3 style="margin-top: 40px;">2. IT’S GETTING NEW FEATURES</h3>
<p>Here are some of the new features you’ll see in the next version of BWPS (iThemes Security):</p>
<ul>
<li>The jQuery scanner will tell you if your theme has an outdated and vulnerable version of jQuery</li>
<li>A new option to disable PHP execution in the uploads folder</li>
<li>The ability to prevent usernames from being discovered by forcing a unique nick name that is different from the username and by hiding the author archives with users who do not have a post)</li>
<li>Voluntary data collection via Google Analytics to help us make iThemes Security even better</li>
<li>The ability to add multiple reporting email addresses for backups and notifications</li>
<li>Streamlined settings for easier configuration</li>
<li>Full integration with <a href="http://ithemes.com/purchase/backupbuddy">BackupBuddy</a></li>
<li>A complete rewrite of existing features for faster, better, more secure sites.</li>
</ul>
<h3 style="margin-top: 40px;">3. IT’S GETTING REVAMPED CODE</h3>
<p>For all practical purposes, iThemes Security is more than just an upgrade, it’s a new plugin. Every single feature has been re-imagined and recreated for both a better user experience and a more secure site.</p>
<p>Again, Chris’ first priority since December 2013 at iThemes has been to completely rework this plugin from the ground up.</p>
<h3 style="margin-top: 40px;">4. NEW PROFESSIONAL SUPPORT OPTIONS AVAILABLE</h3>
<p>iThemes has been building, releasing and supporting commercial (and free) GPL plugins and themes to the WordPress community since 2008.</p>
<p>We are an established company with an awesome team of developers, designers and support techs committed to making your life awesome by building great solutions for you.</p>
<p><strong>As such, support for iThemes Security will now come exclusively through iThemes. We will be releasing those plans and packages with the new release next week.</strong></p>
<p>These will immediately be available to anyone, as well as in our <a title="wordpress plugins" href="http://ithemes.com/developer-suite/">Plugin Suite</a> and <a title="web design toolkit" href="http://ithemes.com/toolkit/">iThemes Toolkit</a> customers as part of their membership plans. (BIG BONUS!)</p>
<p>We are also working with highly-knowledgeable partners to provide hack repair and professional setup solution as well for the community.</p>
<p>***</p>
<h1>3 KEY THINGS <span style="text-decoration: underline;">NOT</span> CHANGING</h1>
<p>I know there will be many questions about the future of Better WP Security. And I want to share answers to the key ones we know you’ll be asking.</p>
<h3 style="margin-top: 40px;">1. IT’S STAYING FREE</h3>
<p><strong>The base plugin will still (and always) be free on the WordPress.org repo.</strong></p>
<p>We do have Pro only (i.e. paid) features in the works already to monetize and help sustain the continued maintenance of this awesome plugin into the future.</p>
<p>But we have no plans to discontinue the features you now see in BWPS and only hope to continue to enhance and improve them to work better for you.</p>
<p>Our intention all along was to give BWPS a future. Hiring Chris full-time to keep the project going is our commitment to its future.</p>
<h3 style="margin-top: 40px;">2. IT WILL STILL BE ACTIVELY MAINTAINED</h3>
<p>The base plugin will still be professionally maintained. Again, our commitment is to keep this awesome plugin maintained and active for as long as it’s useful and used by the WordPress community.</p>
<p>This is Chris’ chief role in our company — to maintain BWPS (iThemes Security).</p>
<p>In fact, prior to joining iThemes, Chris was maintaining Better WP Security part-time. Now it will be maintained FULL-TIME by him and our team.</p>
<h3 style="margin-top: 40px;">3. IT WILL KEEP GETTING BETTER</h3>
<p>We have plans to grow the base plugin as well. We have a number of free features already on our roadmap that we’ll be sharing, like improving notifications.</p>
<p>Chris and our entire team is excited about seeing where this plugin heads into the future as we help the WordPress community secure their sites.</p>
<p>***</p>
<p>As always, if you have other questions, or have further comments, please make a comment below (or hit our contact form), and we’ll help clarify anything we can.</p>
<div class="content-callout green">
<h4><a href="https://www2.gotomeeting.com/register/515312602">30+ Ways to Secure Your WP Site:<br />
A Walk-Through of the New iThemes Security Plugin</a><br />
Free Webinar &#8211; Thursday, March 27 @ 11am CDT</h4>
<p>In this webinar, Chris Wiegman, lead developer for iThemes Security (formerly known as Better WP Security) will give you a walk-through of how to lock down your WordPress site with this newly revamped plugin. <a href="https://www2.gotomeeting.com/register/515312602">REGISTER NOW</a></p>
</div>
<p>The post <a href="http://ithemes.com/2014/03/17/better-wp-security-plugin-changing-ithemes-security-need-know/">Better WP Security Changing To iThemes Security: What You Need To Know</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:97:"http://ithemes.com/2014/03/17/better-wp-security-plugin-changing-ithemes-security-need-know/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"59";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"Versioning Digital Goods with iThemes Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://ithemes.com/2014/03/14/versioning-digital-goods-ithemes-exchange/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:81:"http://ithemes.com/2014/03/14/versioning-digital-goods-ithemes-exchange/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Mar 2014 17:33:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:19:"WordPress Ecommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=22220";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:576:"<p>This week, we bring you a quick lesson over versioning digital goods with iThemes Exchange. We&#8217;ll also cover the difference between updating and upselling and the importance of keeping your customers informed of product updates in your ecommerce store. Updating Updating or versioning a product is when you want to simply upload a newer version [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/03/14/versioning-digital-goods-ithemes-exchange/">Versioning Digital Goods with iThemes Exchange</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Derek Viars";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4825:"<p>This week, we bring you a quick lesson over versioning digital goods with iThemes Exchange. We&#8217;ll also cover the difference between <em>updating</em> and <em>upselling</em> and the importance of keeping your customers informed of product updates in your ecommerce store.</p>
<h2 style="margin-top: 40px;">Updating</h2>
<p>Updating or <em>versioning</em> a product is when you want to simply upload a newer version of that existing product within Exchange. Versioning is an important technique in adding new features to your digital goods (like to plugins or themes) or adding updates (like to your ebooks). Updating is also helpful if you mistakenly uploaded the wrong file, or are putting up the same one with some minor fixes. Either way, this is why updating is useful.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-12-at-2.25.16-PM.png"><img class="alignnone size-full wp-image-22222" alt="exchange_update_url" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-12-at-2.25.16-PM.png" width="1410" height="298" /></a></p>
<p>In order to update a downloadable product, you must go to the product’s page within Exchange and replace the product’s Source URL under Product Files. You can do this by simply uploading the new or updated file into the same spot the previous one was. This will update the product for all past and future customers; they will simply need to re-download to receive the updated file.</p>
<h2 style="margin-top: 40px;">Adding New Product Files</h2>
<p>So we know that replacing the old product file with a new one will update that product for all your customers across your site, but what if you want to add another downloadable file to that product?</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-12-at-2.24.19-PM.png"><img class="alignnone size-full wp-image-22223" alt="exchange_add_download" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-12-at-2.24.19-PM.png" width="1404" height="406" /></a></p>
<p>Well, adding new downloadable files to pre-existing Exchange Digital Download products will allow new users who have not yet purchased the product to receive all files, but users who have already purchased the product in the past will only have access to the downloads that were part of the product when they purchased it.</p>
<p>A good general rule of thumb to remember with digital download products is that when a customer purchases a product, <strong>what they receive is what they purchased at the time</strong>.</p>
<p>This is important to keep in mind, as depending on what you are trying to do, you may accidentally deny content to previous customers that you were trying to give a free update. However, this does present you with some interesting marketing techniques, such as upselling your products, which we’ll discuss next.</p>
<h2 style="margin-top: 40px;">Upselling</h2>
<p>Have you ever seen a special promotion, perhaps something like “Purchase within the next 5 days and receive a bonus product free!”? This is <em>upselling</em>, and it can be a useful tool for making more sales for certain items, perhaps to entice customers who were on the fence before.</p>
<p>In this scenario, the customers who have already purchased the product would not get the added products, only the customers who purchase it after or during the period in which you add the additional products.</p>
<h2 style="margin-top: 40px;">Alerting Your Customers</h2>
<p>So now you’ve updated your product, either as a free upgrade or as an enticing upsell. How do you let your customers know? Exchange does not by default send your customers email alerts whenever you add or update your products. It does, however, offer options that you may want to utilize to get the word out.</p>
<p>Any time you sell a product, you should be getting that customer into a mailing list as part of your sales. We highly recommend using add-ons such as AWeber, MailChimp, or Mad Mimi to help get the word out.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-12-at-2.28.33-PM.png"><img class="alignnone size-full wp-image-22221" alt="exchange_email_add-ons" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-12-at-2.28.33-PM.png" width="2244" height="378" /></a></p>
<h2 style="margin-top: 40px;">Watch the Webinar: Versioning Digital Goods with iThemes Exchange</h2>
<p><iframe src="//www.youtube.com/embed/-LNUDDlim5c?list=UUhPXycSAGDUzBF-xMzMq6uA" height="315" width="560" allowfullscreen="" frameborder="0"></iframe></p>
<p>The post <a href="http://ithemes.com/2014/03/14/versioning-digital-goods-ithemes-exchange/">Versioning Digital Goods with iThemes Exchange</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:77:"http://ithemes.com/2014/03/14/versioning-digital-goods-ithemes-exchange/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"A Look Back on 4 Years of BackupBuddy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://ithemes.com/2014/03/12/look-back-4-years-backupbuddy/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:69:"http://ithemes.com/2014/03/12/look-back-4-years-backupbuddy/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 15:27:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"BackupBuddy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Homepage";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=22149";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:531:"<p>This month, BackupBuddy turns four years old. Birthdays are always a little sentimental, even for a WordPress backup plugin. So to celebrate, we thought we&#8217;d cover a few of the highlights of the past four years. When BackupBuddy first launched in 2010, none of us could have known how it would go. Sometimes products can [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/03/12/look-back-4-years-backupbuddy/">A Look Back on 4 Years of BackupBuddy</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Kristen Wright";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:13183:"<p style="text-align: center;"><img class="aligncenter  wp-image-22206" style="margin-top: 40px; margin-bottom: 60px;" alt="bb4-bacon" src="http://ithemes.com/wp-content/uploads/2014/03/bb4-bacon.png" width="360" height="382" /></p>
<p>This month, <a href="http://ithemes.com/backupbuddy">BackupBuddy</a> turns four years old. Birthdays are always a little sentimental, even for a WordPress backup plugin. So to celebrate, we thought we&#8217;d cover a few of the highlights of the past four years.</p>
<p>When BackupBuddy first launched in 2010, none of us could have known how it would go. Sometimes products can meet a need, but not really resonate with users. We just knew a WordPress backup solution was important work. When your livelihood is built online and you live, breathe and sweat WordPress, protection of your site is serious business. We knew this from experience.</p>
<p>Looking back, we couldn&#8217;t have imagined how BackupBuddy would grow from a solution we made after a server crash to protecting WordPress sites around the world. Since BackupBuddy launched, each year has included a major version release with new features to make your life easier as we continue to build and improve BackupBuddy.</p>
<h2 style="margin-top: 40px;">2009: From Server Crashes, Tacos, and Coffee — The Birth of BackupBuddy</h2>
<p>The idea for BackupBuddy started after we experienced a complete hard drive failure in November 2009. Later, Matt, our COO, provided this <a href="http://ithemes.com/2011/11/08/from-server-crashes-tacos-and-coffee-the-birth-of-backupbuddy/">in-depth analysis/pictorial history of the epic iThemes server fail</a>.</p>
<p><img class="alignnone  wp-image-16987" alt="mattckup-11" src="http://ithemes.com/wp-content/uploads/2011/11/mattckup-11.jpg" width="581" height="435" /></p>
<p>We lost everything. We mean<em> everything</em>. ALL of our sites went down, including several client sites. So for the next 48 hours, each site was rebuilt from scratch — fueled on nothing but coffee and bags of tacos.</p>
<p>At the time, WordPress didn’t offer any complete backup solutions. In both of our failure cases, we needed entire directory and file backups for complete site recovery.</p>
<h2 style="margin-top: 40px;">Building BackupBuddy: The Four Main Ingredients</h2>
<p>Based on our experience, we knew WordPress backups required four very important ingredients:</p>
<ol>
<li><strong><em>Complete</em> Database + Files:</strong> A database backup wasn&#8217;t enough because it wasn&#8217;t a <em>complete</em> backup. WordPress backups need to include all the files included in the site&#8217;s installation — including themes, plugins and actual media files — which aren&#8217;t covered by a database backup alone.</li>
<li><strong>Convenient to Create: </strong>Sure, it&#8217;s possible to manually make copies of your site&#8217;s files from the command line. But it&#8217;s a complicated process if you want more customization. Backups should be easy and convenient to create so 1) they actually happen and 2) you don&#8217;t waste time doing them.</li>
<li><strong>Quickly + Easy Restore: </strong>What good is a backup if you can&#8217;t actually restore your site? Restoring is an important component of backups, but it shouldn&#8217;t be difficult or hard to get a site up again.</li>
<li><strong>Trustworthy + Reliable: </strong>Backups aren&#8217;t something you can get wrong. Backups protect you from risk of a site loss, so they better be dependable.</li>
</ol>
<p>The development for BackupBuddy started in January of 2010, and in just two months, lead developer Dustin Bolton built the first release candidate for BackupBuddy.</p>
<p>Check out one of the original concepts for the BackupBuddy logo.</p>
<p><img class="aligncenter size-full wp-image-22213" style="margin-top: 20px;" alt="original-backupbuddy-logo" src="http://ithemes.com/wp-content/uploads/2014/03/original-backupbuddy-logo.png" width="458" height="413" /></p>
<h2 style="margin-top: 60px;">Official BackupBuddy Launch &#8211; March 2010</h2>
<p><a href="http://ithemes.com/2010/03/04/pluginbuddy-is-live-2/">BackupBuddy officially launched</a> on March 4, 2010 with the ability to run complete backups, restore and schedule backups. We dug up the <a href="http://vimeo.com/moogaloop.swf?clip_id=9940726&amp;amp;server=vimeo.com&amp;amp;show_title=0&amp;amp">official BackupBuddy launch video</a> with Cory, Dustin and Matt (from the old iThemesTV studio).</p>
<p style="text-align: center;"><a href="http://vimeo.com/moogaloop.swf?clip_id=9940726&amp;amp;server=vimeo.com&amp;amp;show_title=0&amp;amp"><img class="aligncenter  wp-image-22167" alt="Screen Shot 2014-03-11 at 12.47.15 PM" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-11-at-12.47.15-PM.png" width="1415" height="794" /></a></p>
<blockquote><p>The idea of BackupBuddy was to create a plugin that finally made backing up an entire WordPress install as simple as possible, to make restoring that backup possible and just as simple, and to make migrating the WordPress site no more difficult than restoring a backup.<br />
— Chris Jean, <a href="http://ithemes.com/2010/03/08/backupbuddy-a-product-launch-story/">BackupBuddy: A Product Launch Story</a></p></blockquote>
<p>As with all product launches, BackupBuddy faced some initial challenges and bugs related to the diverse server configurations of users. Within four days of BackupBuddy&#8217;s launch, the team developed <a href="http://ithemes.com/2010/03/08/serverbuddy-to-help-identify-server-issues/">ServerBuddy</a> to help identify potential server problems for customers and speed up support for BackupBuddy. Today, ServerBuddy functionality is built into BackupBuddy (so it&#8217;s no longer a separate plugin), but it still remains an important way for our support team to identify server issues for customers.</p>
<h2 style="margin-top: 40px;">The First BackupBuddy Dashboard</h2>
<p>Fun fact: when BackupBuddy first launched, WordPress was at version <a href="https://codex.wordpress.org/Version_2.9.2">2.9.2</a>. The first BackupBuddy dashboard included the ability to run a complete backup, download the importbuddy.php script and run scheduled backups. Anyone remember this?</p>
<p style="text-align: center;"><img class="aligncenter  wp-image-22153" style="margin-bottom: 40px;" alt="Screen Shot 2014-03-11 at 12.12.28 PM" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-11-at-12.12.28-PM.png" width="1224" height="811" /></p>
<h2 style="margin-top: 60px;">BackupBuddy 2.0: Remote Destination Support and Server Tools</h2>
<p>The following April, BackupBuddy 2.0 released with a more streamlined flow &amp; better usability, all based on feedback from customers. Within the first year of release, BackupBuddy added support for remote destinations for your backups, like email, Amazon S3, Rackspace and FTP. Based on support requests, BackupBuddy&#8217;s server tools were implemented as a core BackupBuddy feature.</p>
<p style="text-align: center;"><img class="aligncenter  wp-image-22172" style="margin-bottom: 40px;" alt="Screen Shot 2014-03-11 at 2.32.57 PM" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-11-at-2.32.57-PM.png" width="1305" height="877" /></p>
<h2 style="margin-top: 60px;">From 2011 Archive: A BackupBuddy Promo Video</h2>
<p>We found this great promo video from 2011, starring Josh, Brad, Dustin and Cory. Enjoy.</p>
<p><iframe src="//www.youtube.com/embed/k6BYFkjW14k" height="315" width="420" allowfullscreen="" frameborder="0"></iframe></p>
<h2 style="margin-top: 60px;">BackupBuddy to the Rescue Photo Contest &#8211; March 2012</h2>
<p>One of our favorite BackupBuddy promos was the <a href="http://pluginbuddy.com/backupbuddy-to-the-rescue-photo-contest/">BackupBuddy to the Rescue Photo Content</a>. We got some hilarious entries that helped us celebrate BackupBuddy&#8217;s 2nd Birthday.</p>
<p style="text-align: center;"><img class="aligncenter size-full wp-image-22175" style="margin-bottom: 40px;" alt="month" src="http://ithemes.com/wp-content/uploads/2014/03/month.jpg" width="517" height="987" /></p>
<h2 style="margin-top: 60px;">Magic Migration &#8211; June 2012</h2>
<p>Magic Migration arrived in June of 2012 with <a href="http://ithemes.com/2012/06/13/backup-buddy-3-0-is-out/">BackupBuddy 3.0</a>. With Magic Migration, BackupBuddy made it possible to move WordPress sites from within the Dashboard by automatically transferring the backup files and walking you through the migration steps.</p>
<p><img class="aligncenter size-full wp-image-22176" alt="bb3-arrived1" src="http://ithemes.com/wp-content/uploads/2014/03/bb3-arrived1.png" width="600" height="229" /></p>
<p style="text-align: center;"><img class="aligncenter  wp-image-22177" style="margin-bottom: 40px;" alt="Screen Shot 2014-03-11 at 2.32.11 PM" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-11-at-2.32.11-PM.png" width="1451" height="897" /></p>
<h2 style="margin-top: 60px;">BackupBuddy Crosses 100,000 Site Licenses &#8211; June 19, 2012</h2>
<p>Within a few days of launching 3.0, BackupBuddy crossed 100,000 site licenses.</p>
<p><img class="aligncenter size-full wp-image-22178" alt="100k" src="http://ithemes.com/wp-content/uploads/2014/03/100k.png" width="600" height="300" /></p>
<p>Back then, the sales page looked something like this.</p>
<p style="text-align: center;"><img class="aligncenter  wp-image-22181" style="margin-bottom: 40px;" alt="Screen Shot 2014-03-11 at 3.21.19 PM" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-11-at-3.21.19-PM.png" width="1055" height="956" /></p>
<h2 style="margin-top: 60px;">BackupBuddy Stash Arrives &#8211; Oct 2012</h2>
<p><a href="http://ithemes.com/2012/10/29/backupbuddy-3-1-is-here-plus-backupbuddy-stash/">BackupBuddy 3.1 launched</a> with support for <a href="http://ithemes.com/backupbuddy-stash/">BackupBuddy Stash</a>, our own secure, off-site and easy storage destination for your BackupBuddy backups.</p>
<p>Remote storage of your backup files has always been an important component of a solid backup strategy. By providing BackupBuddy Stash, all BackupBuddy users could automatically have a way to send their backups off-site with their free BackupBuddy Stash storage space.</p>
<p style="text-align: center;"><img class="aligncenter size-full wp-image-22186" style="margin-bottom: 40px;" alt="bb-stash" src="http://ithemes.com/wp-content/uploads/2014/03/bb-stash.png" width="379" height="184" /></p>
<h2 style="margin-top: 60px;">Individual File Restores &#8211; June 2013</h2>
<p>To make restoring from backups even easier and more convenient, BackupBuddy 4.0 included <a href="http://ithemes.com/2013/06/11/backupbuddy-4-0-part-1-individual-file-restores/">individual file restore capabilities</a>.</p>
<p>The BackupBuddy 4.0 update made it possible to view a listing of files and directories backed up in backup archives (along with size and the date last modified), view contents of text-based files (.php, .html, .htaccess, etc.) and restore files to their original location (undelete or “roll back” a file).</p>
<p style="text-align: center;"><img class="aligncenter size-full wp-image-22190" style="margin-bottom: 40px;" alt="bb-indiv" src="http://ithemes.com/wp-content/uploads/2014/03/bb-indiv.png" width="330" height="317" /></p>
<h2 style="margin-top: 60px;">Remote Backups with iThemes Sync &#8211; Feb. 2014</h2>
<p>BackupBuddy integration with iThemes Sync made it possible to <a href="http://ithemes.com/2014/02/03/make-remote-wordpress-backups-ithemes-sync-backupbuddy/">make remote backups from the Sync Dashboard</a>. With this integration, Sync made it possible to view number of edits since your last backup, download your latest backup zip files and more and manage your BackupBuddy Stash storage space.</p>
<p style="text-align: center;"><img class="aligncenter  wp-image-22189" style="margin-bottom: 40px;" alt="Screen-Shot-2014-01-30-at-9.01.40-AM" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-01-30-at-9.01.40-AM.png" width="1281" height="872" /></p>
<h2 style="margin-top: 60px;">What&#8217;s Next for BackupBuddy?</h2>
<p>BackupBuddy is central to our 2014 goal to <a href="http://ithemes.com/go-far-together/">Go Far Together.</a> We&#8217;re committed to helping protect your online assets with BackupBuddy and also our soon-to-be released iThemes Security plugin. We also want to help you be more productive by providing tools that help you do more (or less) faster and better.</p>
<p>Today, we&#8217;re really proud to say that BackupBuddy is running on over 300,000 WordPress sites. Stay tuned for new improvements to BackupBuddy like database rollback (currently in beta now), an overhaul of the ImportBuddy UI and our new Sync iPhone App that will integrate with BackupBuddy functionality.</p>
<h4>Thanks for an incredible 4 years — here&#8217;s to many more!</h4>
<p>The post <a href="http://ithemes.com/2014/03/12/look-back-4-years-backupbuddy/">A Look Back on 4 Years of BackupBuddy</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://ithemes.com/2014/03/12/look-back-4-years-backupbuddy/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"11";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"iThemes Builder 101: Building Your Site With Builder Views";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://ithemes.com/2014/03/10/ithemes-builder-101-building-site-builder-views/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://ithemes.com/2014/03/10/ithemes-builder-101-building-site-builder-views/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 10 Mar 2014 15:39:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:13:"Builder Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:12:"Builder Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=22132";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:566:"<p>If you use Builder a lot, chances are you’re pretty familiar with Layouts … but what about Views? A surprising number of people haven’t used Builder Views or don’t understand how they work. This week, we’ll break it down so you can get the most out of your Builder theme by utilizing Views. Understanding iThemes [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/03/10/ithemes-builder-101-building-site-builder-views/">iThemes Builder 101: Building Your Site With Builder Views</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Derek Viars";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6208:"<p>If you use Builder a lot, chances are you’re pretty familiar with Layouts … but what about <em>Views</em>? A surprising number of people haven’t used Builder Views or don’t understand how they work. This week, we’ll break it down so you can get the most out of your Builder theme by utilizing Views.</p>
<h2>Understanding iThemes Builder Views</h2>
<p>Chances are, you’ve seen the Views tab inside your theme’s Layouts &amp; Views page (it’s in the name, after all), but may not have ever used it.</p>
<p style="text-align: center;"><img class="aligncenter size-full wp-image-22138" style="margin-top: 40px; margin-bottom: 40px;" alt="ithemes-builder-views" src="http://ithemes.com/wp-content/uploads/2014/03/ithemes-builder-views.png" width="353" height="250" /></p>
<p>Layouts are pretty straightforward, but what are “Views” exactly? To put it simply, <strong>Views are a method of assigning a default Layout to specific content across your site</strong>.</p>
<p>Think of Views like email filters; by setting them up ahead of time, any new emails of that predefined type will be dealt with in a specific way. In much the same way, creating new Views allows you to apply specific Layouts and Extensions in order to make default content styling easy for your clients, customers or yourself.</p>
<h2 style="margin-top: 40px;">Setting the View</h2>
<p>To create a new View, all you need to do is go into the Views tab within your Builder theme’s Layouts &amp; Views menu and click Add View.</p>
<p>There are lots of default page types you can apply Views to, including posts, pages, and home. You can even set Views to individual Authors or Categories.</p>
<p style="text-align: center;"><a href="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-07-at-2.00.43-PM.png"><img class="wp-image-22134 aligncenter" style="margin-top: 40px; margin-bottom: 40px;" alt="builder_views_list" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-07-at-2.00.43-PM.png" width="447" height="684" /></a></p>
<p>After you’ve chosen the specific View you wish to change, you can select a Layout and/or Extension you wish to be applied to it. For instance, if you set the View as “Post” and the Layout as “Left Sidebar”, every post on your site would display the Left Sidebar Layout without the need to set it as the default layout for the whole site, or manually override the layout for each individual post.</p>
<h2 style="margin-top: 40px;">Using Categories</h2>
<p>To further illustrate the usefulness of using Views, lets take a look at how they can be used in conjunction with Categories. By default, you can set a View to effect all categories, but you can also assign specific views for posts with specific categories.</p>
<p style="text-align: center;"><img class="wp-image-22133 aligncenter" style="margin-top: 40px; margin-bottom: 40px;" alt="builder_views_categories" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-07-at-2.01.53-PM.png" width="562" height="393" /></p>
<p>This can be an extremely useful option when creating a site for clients. You can create different Views that will automatically be applied for your client depending on the post category they use, possibly saving both you and your client from a lot of potential headaches and miscommunication later down the road.</p>
<h2 style="margin-top: 40px;">Priority and Overriding Views</h2>
<p>When using Layouts &amp; Views, there is a basic hierarchy. At the lowest end of this hierarchy is the Default Layout set within the Layouts tab, which will be applied to all site content unless otherwise specified. Views are the second step in this hierarchy, and will override the default layout on any posts or pages that they target. Finally, a specifically set Custom Builder Layout designated at the bottom of a specific post or page will override the default layout or any associated views.</p>
<p style="text-align: center;"><img class="wp-image-22135 aligncenter" style="margin-top: 40px; margin-bottom: 40px;" alt="builder_custom_layout" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-07-at-2.06.03-PM.png" width="369" height="327" /></p>
<h2 style="margin-top: 40px;">Pro-tip: Finding Which View a Page Uses</h2>
<p>Not sure which View a specific page is using? Those who watched <a title="iThemes Builder 101: Styling Widgets with CSS" href="http://ithemes.com/2014/03/07/ithemes-builder-101-widget-css/" target="_blank">last week’s Builder 101</a> should already be familiar with this tip to help with identifying widget CSS classes, but it’s useful for identifying Views as well.</p>
<p>When you’re logged in as an administrator, you can right click anywhere on the page and click “View Page Source”. This will pop up a new window displaying your site’s source code. Scroll down a bit until you see a large comment block between the page’s closing head tag and opening body tag. This section contains lots of useful meta data about your page, but what we’re interested here is the line that starts with “Views”. This line will display the View the page you’re currently on is using.</p>
<p><img class="alignnone size-medium wp-image-22111" style="margin-top: 20px; margin-bottom: 20px;" alt="builder_widgets_view_source" src="http://ithemes.com/wp-content/uploads/2014/03/view_source-540x229.png" width="540" height="229" /></p>
<h2 style="margin-top: 40px;">Further Information</h2>
<p>The <a title="Builder - iThemes Codex" href="http://ithemes.com/codex/page/Builder" target="_blank">iThemes Codex</a> provides much more information about Views, including a video overview and information pertaining to each supported type of View.</p>
<h2 style="margin-top: 40px;">Watch the Webinar: Working with Builder Views</h2>
<p><iframe src="//www.youtube.com/embed/x2fPrO_F5rg?list=UUhPXycSAGDUzBF-xMzMq6uA" height="315" width="560" allowfullscreen="" frameborder="0"></iframe></p>
<p>The post <a href="http://ithemes.com/2014/03/10/ithemes-builder-101-building-site-builder-views/">iThemes Builder 101: Building Your Site With Builder Views</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://ithemes.com/2014/03/10/ithemes-builder-101-building-site-builder-views/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"iThemes Builder 101: Styling Widgets with CSS";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://ithemes.com/2014/03/07/ithemes-builder-101-widget-css/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:70:"http://ithemes.com/2014/03/07/ithemes-builder-101-widget-css/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 07 Mar 2014 17:42:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:13:"Builder Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:12:"Builder Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:16:"Builder Training";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=22108";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:511:"<p>Builder gives you the ability to create layouts with tons of widgets just the way you want. But what if you want to give your widgets some very specific style customizations of your own? How can you edit exactly which ones you want? What if you want to target widgets across multiple pages? It may [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/03/07/ithemes-builder-101-widget-css/">iThemes Builder 101: Styling Widgets with CSS</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Derek Viars";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:7996:"<p>Builder gives you the ability to create layouts with tons of widgets just the way you want. But what if you want to give your widgets some very specific style customizations of your own? How can you edit exactly which ones you want? What if you want to target widgets across multiple pages? It may seem complicated, but it’s actually a lot easier than you may think it is.</p>
<h2>Understanding the Structure of Builder</h2>
<p>Within Builder, you can create limitless combinations of custom content for your site. So how does it keep track of what’s what? Well, Builder applies CSS classes on multiple levels within its layouts to style content. This styling is applied to Builder in general, as well as to individual layouts, modules, and widgets. Classes are good for styling things on the whole, but what about when you want to get really specific. If you made two modules that were exactly alike, how would Builder know the difference? That’s where IDs come into play.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/ids.png"><img class="alignnone size-full wp-image-22115" alt="builder_widgets_ids" src="http://ithemes.com/wp-content/uploads/2014/03/ids.png" width="1306" height="560" /></a></p>
<p>IDs are similar to classes, but much more specific, and can only be used once each on a page. When you create a new module in Builder, a unique ID is automatically created for it. A module’s ID will always remain the same, unless the module is deleted. If you delete a module and create an identical one, even in the exact same place, the ID generated for it will be different. This makes selecting an individual module easy, as you know it will be the only area on your site with that specific ID. So now that we know what IDs are, how can we find them?</p>
<h2>Viewing the Source Code</h2>
<p>If you are logged into an administrator account and viewing your site, you can right click anywhere on the page and click “View Page Source”. This launches a new tab in which you can view the actual source code that makes up your site. Between the head and body tags of the page you will see a large comment block that displays the IDs of each individual module, in the order that they appear on the page. Any modules that you add in the future will be inserted into the list as well.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/view_source.png"><img class="alignnone size-full wp-image-22111" alt="builder_widgets_view_source" src="http://ithemes.com/wp-content/uploads/2014/03/view_source.png" width="1504" height="638" /></a></p>
<h2>Using Inspect Element</h2>
<p>You can also right click on the page and hit Inspect Element to view both your HTML source code and the CSS that styles it at the same time. Viewing this code can be a little intimidating, due to the number of classes that Builder uses to style content on the page. Don’t let this discourage you, though; If you’re having trouble reading, try copy and pasting it into a separate document, so you can separate each class out onto its own line.</p>
<h2>Module Classes</h2>
<p>Getting to know these classes can be very helpful, as they will show you at which level that specific styling is coming from. For example, the class “builder-module-background-wrapper” affects all Builder modules across your site, while “builder-module-widget-bar-background-wrapper” would affect all widget bars. There are also specific classes for when multiple types of the same modules exist on the page, such as “builder-module-3-background-wrapper”. This class, for example, would target all modules that are the 3rd from the top of the page. A class of “builder-module-widget-bar-2-background-wrapper” would target the second widget bar module of every page using the layout.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/module_class.png"><img class="alignnone size-full wp-image-22119" alt="builder_widgets_module_class" src="http://ithemes.com/wp-content/uploads/2014/03/module_class.png" width="1380" height="194" /></a></p>
<p>As you can see, Builder classes provide an extremely powerful and versatile way of styling content across your site. The are also a great way to cut down on the size of your code and style several occurrences of similar modules without needing to get each one’s specific ID.</p>
<h2>Widget Classes</h2>
<p>Just like the modules that contain them, widgets themselves also have specific classes that style them. In addition to those similar to the modules that contain them, widgets also feature a few other classes of their own that you should definitely be familiar with.</p>
<h3>Left and Right</h3>
<p>As the name suggests, these classes pull widgets to either the left or the right within their parent module. When there are two or more widgets inside a module, the furthest widgets to the left or the right will utilize these classes.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/left.png"><img class="alignnone size-full wp-image-22121" alt="builder_widgets_left" src="http://ithemes.com/wp-content/uploads/2014/03/left.png" width="1316" height="440" /></a></p>
<h3>Middle</h3>
<p>Similarly to left and right, this is a class specifically for widgets that reside in the middle of their module. If there are multiple widgets in between ones with a left and a right class, they will all contain the middle class.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/middle.png"><img class="alignnone size-full wp-image-22122" alt="builder_widgets_middle" src="http://ithemes.com/wp-content/uploads/2014/03/middle.png" width="1318" height="440" /></a></p>
<h3>Column Numbers</h3>
<p>In case you were wondering how you would select a specific widget in a group of more than three, that’s where column number classes come in. If you wanted to select the third widget of a set of five, you can just use the appropriate class with column-3.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/columns.png"><img class="alignnone size-full wp-image-22125" alt="builder_widgets_columns" src="http://ithemes.com/wp-content/uploads/2014/03/columns.png" width="1316" height="438" /></a></p>
<h2>In Summary</h2>
<p>Targeting widgets is a lot easier than it appears to be. All you need to know is the class or ID of the specific module(s) you wish to target, and then the class of the widget you’re targeting within that. There are tons of ways to select various modules and widgets across any number of pages, so dig into your site and give it a try for yourself!</p>
<h2>Further Reading</h2>
<p>If you’re looking for more info about using custom CSS with Builder, here are some other resources to help get you going.</p>
<ul>
<li><a title="Web Developer Training Video Tutorials" href="http://ithemes.com/tutorial/category/web-developer-training/" target="_blank">Web Developer Training Video Tutorials</a></li>
<li><a title="Builder CSS Video Tutorials" href="http://ithemes.com/tutorial/category/builder-css/" target="_blank">Builder CSS Video Tutorials</a></li>
<li><a title="Builder CSS: Basic Structure" href="http://ithemes.com/codex/page/Builder_CSS:_Basic_Structure" target="_blank">Builder CSS: Basic Structure</a></li>
<li><a title="Builder CSS: Classes and IDs Overview" href="http://ithemes.com/codex/page/Builder_CSS:_Classes_and_IDs_Overview" target="_blank">Builder CSS: Classes and IDs Overview</a></li>
<li><a title="Builder CSS: Theme CSS Outline" href="http://ithemes.com/codex/page/Builder_CSS:_Theme_CSS_Outline" target="_blank">Builder CSS: Theme CSS Outline</a></li>
</ul>
<h2>Watch the Webinar: Styling Widgets with CSS in iThemes Builder</h2>
<p><iframe src="//www.youtube.com/embed/Ny7VXkpkeYQ?rel=0" height="360" width="640" allowfullscreen="" frameborder="0"></iframe></p>
<p>The post <a href="http://ithemes.com/2014/03/07/ithemes-builder-101-widget-css/">iThemes Builder 101: Styling Widgets with CSS</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:66:"http://ithemes.com/2014/03/07/ithemes-builder-101-widget-css/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:63:"
		
		
		
		
		
				
		
		
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"6 WordPress Remote Backup Solutions That Can Save Your Bacon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://ithemes.com/2014/03/06/6-wordpress-remote-backup-solutions/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://ithemes.com/2014/03/06/6-wordpress-remote-backup-solutions/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 06 Mar 2014 22:45:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:8:{i:0;a:5:{s:4:"data";s:11:"BackupBuddy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Protect";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:16:"WordPress Backup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"backup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:17:"BackupBuddy Stash";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:14:"offsite backup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:6;a:5:{s:4:"data";s:13:"remote backup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:7;a:5:{s:4:"data";s:23:"WordPress remote backup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=22087";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:565:"<p>When disaster strikes you need a safe backup. You need a WordPress remote backup solution that&#8217;s reliable, convenient and ready to save your butt. Backup Basics Before diving into the WordPress remote backup options, let’s cover the basics. Why Backup? Did you invest any time or money into your site? Yes. Then you need to [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/03/06/6-wordpress-remote-backup-solutions/">6 WordPress Remote Backup Solutions That Can Save Your Bacon</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:18:"Kevin D. Hendricks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:11915:"<p>When disaster strikes you need a safe backup. You need a WordPress remote backup solution that&#8217;s reliable, convenient and ready to save your butt.</p>
<h1 style="margin-top: 40px;">Backup Basics</h1>
<p>Before diving into the WordPress remote backup options, let’s cover the basics.</p>
<h2 style="margin-top: 40px;">Why Backup?</h2>
<p>Did you invest any time or money into your site?</p>
<p>Yes.</p>
<p>Then you need to protect that investment by backing up your website. What happens when your suddenly shady host disappears or your intern somehow pushes the wrong button or <a href="http://ithemes.com/2014/02/20/backupbuddy-backups-are-more-important-than-ever/">hackers delete your entire site</a> and replace it with mad props to themselves? Stuff happens.</p>
<p>So back it up.</p>
<p>We’ve been offering the <a href="http://ithemes.com/purchase/backupbuddy/">BackupBuddy</a> plugin for four years now as a way to keep your WordPress sites backed up and safe. It’s simple and easy. Do it. We believe <a href="http://ithemes.com/2013/05/17/why-every-freelance-developer-should-have-a-solid-backup-strategy/">every website should have a backup strategy</a>.</p>
<h2 style="margin-top: 40px;">Why Remote?</h2>
<p>Once you’re backing up your site you need to store those backups somewhere. Ideally multiple somewheres. You want <a href="http://ithemes.com/2014/02/24/importance-redundancy-wordpress-backups/">redundancy in your backup plan</a>.</p>
<p>Keeping a copy of your site on your server isn’t much help much. If your server has a problem, how are you going to get to your backup?</p>
<p>A backup on your own computer is good, but it’s not enough. Your hard drive could crash, it could be stolen or your house could burn down. Let’s hope none of things happen, but sometimes they do.</p>
<p>So you need a remote location to store your WordPress backups. Somewhere that isn’t your house, isn’t your computer and isn’t your server. A remote, off-site location gives you the redundancy you need.</p>
<p>Yes, it’s extreme. But it’s also smart. It’s why everyone in the presidential line of succession is never gathered in the same room at the same time. There’s always one cabinet member who has to skip out on the inauguration or State of the Union address. If the worst-case scenario ever happened, we’d still have a legitimate head of state to keep government functioning.</p>
<p>Don’t put all your eggs in one basket. Even the government knows that.</p>
<h1 style="margin-top: 40px;">The Variables of WordPress Remote Backup</h1>
<p>Before deciding on a WordPress remote backup solution you should consider the variables involved in backup. You’ve basically got four, interrelated variables to keep in mind:</p>
<ul>
<li><strong>Size</strong> – How large are your backups? Small sites won’t need a lot of storage space. But if you’ve got a huge site, maybe thousands of posts or loads of media files, then you’ll have bigger storage needs. Do a test backup with BackupBuddy to see how big your files are before you decide on a remote backup solution.</li>
<li><strong>Frequency</strong> – How often do you want to back up your site? There’s a big difference in storage needs for monthly, weekly and daily backups. It’s simple math—the more you back up your site, the more space you’ll need.</li>
<li><strong>Time Frame</strong> – How long do you want to keep your backups? Maybe you only need the most recent backups. Thankfully BackupBuddy will automatically delete older backups for you to save space, depending on your settings. But if you need to keep your backups longer, that’s going to require more space.</li>
<li><strong>Full vs. Database</strong> – What kind of backups are you doing? BackupBuddy gives you the option of doing full or database-only backups. Full backups get your entire site, including images, theme files, customizations, plugins and more. It’s a perfect snapshot of your site as it currently exists and what you need to fully restore your site. A database backup is just the database—it’s your blog posts (minus the media). Full backups are a lot bigger and take more time. You definitely want to do full backups, but you also might do database backups more often to protect your latest content without taking the time or space to grab everything.</li>
</ul>
<p>These variables all work together to determine how much space you need.</p>
<h1 style="margin-top: 40px;">Backup Strategy</h1>
<p>Now that you understand the variables involved, let’s talk backup strategy. You need to create a plan of action so you can pick the best remote storage option.</p>
<p>You need a full backup to do a complete restoration of your site, but a database backup is all you need to save your latest content.</p>
<p>A typical approach is to do a database backup once a week and a full backup twice a month. Content changes more frequently, so you should do a database back up more often. Your site’s plugins and theme change less frequently, so you shouldn’t need to do a full backup as often.</p>
<p>But it depends on your site. If you update your content several times a day, a weekly database backup might not be good enough. If you have lots of images and media or you’re always adding new customizations, then you might want to do a full backup more frequently.</p>
<p>Your WordPress remote backup strategy should also be <a href="http://ithemes.com/2014/02/24/importance-redundancy-wordpress-backups/">redundant</a>. Don’t rely on a single backup or a single remote location. Again, it’s extreme, but you never want to put all your eggs in one basket.</p>
<p>Create a plan that protects your content and would allow you to get your site up and running again with a minimum of effort and lost content. Once you’ve got a strategy you’re ready to pick your WordPress remote backup solution.</p>
<h1 style="margin-top: 40px;">WordPress Remote Backup Options</h1>
<h2 style="margin-top: 50px;">BackupBuddy Stash</h2>
<p><img class="alignnone size-full wp-image-22088" alt="WordPress Remote Backup Options: BackupBuddy Stash" src="http://ithemes.com/wp-content/uploads/2014/03/bbplustash1GB.png" width="482" height="184" /></p>
<p>Just by using BackupBuddy you get a free remote storage solution with <a href="http://ithemes.com/backupbuddy-stash/">BackupBuddy Stash</a>. Currently you get 1 GB of space for free. The account is already set up, just use your iThemes login info to get started.</p>
<p>Since Stash is already integrated into BackupBuddy, it’s quick and easy. If you need more space there are several affordable upgrade options.</p>
<h2 style="margin-top: 50px;">Amazon S3</h2>
<p><img class="alignnone size-full wp-image-22089" alt="WordPress Remote Backup Options: Amazon" src="http://ithemes.com/wp-content/uploads/2014/03/amazonwebservices.jpg" width="388" height="71" /></p>
<p>The ecommerce giant offers <a href="http://aws.amazon.com/s3/">Amazon Simple Storage Service</a> (Amazon S3). This is used for big time data needs, including companies like Netflix and Pinterest, but it can also work for simpler uses like backup.</p>
<p>Amazon currently has a free option and then charges based on usage, so depending on your needs it can be pretty affordable.</p>
<h2 style="margin-top: 50px;">Dropbox</h2>
<p><img class="alignnone size-full wp-image-22090" alt="WordPress Remote Backup Options: Dropbox" src="http://ithemes.com/wp-content/uploads/2014/03/Dropbox.png" width="406" height="112" /></p>
<p><a href="https://www.dropbox.com/">Dropbox</a> is a popular online storage provider that offers some free space (currently 2 GB) and premium upgrades if you need more. If you’re already using Dropbox for other uses this can be a convenient solution.</p>
<p>But watch out for their API upload limit of 150 MB. If your backup files are bigger than that you’ll need something else.</p>
<h2 style="margin-top: 40px;">Rackspace Cloud</h2>
<p><img class="alignnone  wp-image-22091" alt="WordPress Remote Backup Options: Rackspace" src="http://ithemes.com/wp-content/uploads/2014/03/rackspace.jpg" width="571" height="101" /></p>
<p><a href="http://www.rackspace.com/cloud/files/">Rackspace</a> is another big time solution for scalable storage in the cloud. They have a GB per month plan where you pay for what you need.</p>
<h2 style="margin-top: 50px;">FTP Server</h2>
<p>You can also send your backups to an FTP server. This assumes you have some extra server space separate from where you host your WordPress site. If you’ve got extra space like that, why not use it for backup?</p>
<h2 style="margin-top: 50px;">Email</h2>
<p>A final option for remote backup is to email yourself the files. This isn’t ideal for a few reasons, one of the big ones being that most email servers limit attachments to about 10 MB, which means you could only use it for small backups.</p>
<p>Another downside is that your email storage could be limited. Providers like Gmail and some hosts claim unlimited space, but others have limits or default quotas in place. At the very least you’ll want to check to see if any limits exist before you fill your space and shut down your email address.</p>
<p>A final downside is retrieval. Email isn’t exactly designed to be a file storage system, so you’re putting some odd demands on the system.</p>
<p>Email can be cheap and effective for small backups, but it’s probably not going to work for everybody.</p>
<p><strong>Tip:</strong> Email can work if you get creative. One option is to set up a Gmail account just for backups. Gmail currently allows attachments up to 25 MB, so you could get slightly larger files and then rely on Gmail’s search feature to find the backup file you need.</p>
<h1 style="margin-top: 40px;">Weighing Your WordPress Remote Backup Options</h1>
<p>That’s a lot of options. Here are some things to consider as you make your WordPress remote backup decision:</p>
<ul>
<li><strong>Cost</strong> &#8211; It always comes down to money. But in this case storage space is cheap. There are several free options and even if you need to pay, you can get 100 GB for less than $120 per year.</li>
<li><strong>Space</strong> &#8211; How much space do you need? Look at all the variables in your backup strategy and calculate how much space you need. While cost is important, this might be the deciding factor.</li>
<li><strong>Convenience</strong> &#8211; Backup is supposed to be something you don’t think about. Set it and forget it. So look for something easy. That might mean sticking with what you have, such as your Dropbox account or the integrated BackupBuddy Stash. Or it might mean going with a scalable solution so you don’t have to worry about space.</li>
<li><strong>Think Long Term</strong> &#8211; Pick a solution that’s going to work over the long haul. You don’t want to mess with your backup system in six months because you ran out of space. You also don’t want to rethink it in two years when you realize how much you’re paying in monthly costs. Make sure you can live with your solution months and even years down the road.</li>
</ul>
<h1 style="margin-top: 40px;">Pick One</h1>
<p>In the end what really matters is finding a WordPress remote backup solution that works for you. BackupBuddy Stash might be ideal because it’s already set up and it’s free. Or maybe you need more space and Amazon S3 is the way to go. Or maybe you already use Dropbox so it just makes sense.</p>
<p>Whichever solution you pick for your WordPress remote backup solution, what really matters is having one. Get your off-site backup going and rest easy knowing your WordPress site is safe.</p>
<p>The post <a href="http://ithemes.com/2014/03/06/6-wordpress-remote-backup-solutions/">6 WordPress Remote Backup Solutions That Can Save Your Bacon</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://ithemes.com/2014/03/06/6-wordpress-remote-backup-solutions/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"Invoicing Clients From Your WordPress Site With iThemes Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://ithemes.com/2014/03/05/invoice-clients-wordpress-ithemes-exchange/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:82:"http://ithemes.com/2014/03/05/invoice-clients-wordpress-ithemes-exchange/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 05 Mar 2014 22:03:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"WordPress Tips";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=21985";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:609:"<p>iThemes Exchange makes creating, maintaining and sending your clients invoices simple. With the Exchange Invoices Add-on, you can create custom invoices and emails to bill your client. Even without the Invoices Add-on, Exchange provides viable solutions to make invoicing clients as easy as possible. Creating Invoices Without the Invoices Add-on If you do not own [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/03/05/invoice-clients-wordpress-ithemes-exchange/">Invoicing Clients From Your WordPress Site With iThemes Exchange</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Derek Viars";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:5153:"<p>iThemes Exchange makes creating, maintaining and sending your clients invoices simple. With the <a href="http://ithemes.com/purchase/invoices/">Exchange Invoices Add-on</a>, you can create custom invoices and emails to bill your client. Even without the Invoices Add-on, Exchange provides viable solutions to make invoicing clients as easy as possible.</p>
<h2 style="margin-top: 40px;">Creating Invoices Without the Invoices Add-on</h2>
<p>If you do not own the Invoices Add-on, here is a method you can try using only the free version of Exchange. After you have downloaded and installed Exchange, <strong>create a new digital download product</strong> to serve as your invoice. After filling out the details, <strong>enable Product Inventory</strong> in the Advanced Settings below and <strong>set it to 1</strong>.</p>
<p><img class="aligncenter size-full wp-image-21990" alt="wordpress-invoice-1" src="http://ithemes.com/wp-content/uploads/2014/02/wordpress-invoice-1.png" width="805" height="389" /></p>
<p>You will want to upload a pre-stamped “paid” .PDF invoice for the client as the actual Product File.</p>
<p><img class="aligncenter size-full wp-image-21991" alt="wordpress-invoice-2" src="http://ithemes.com/wp-content/uploads/2014/02/wordpress-invoice-2.png" width="807" height="167" /></p>
<p>Email the product link to your client, and after they&#8217;ve paid, they will be able to download the .PDF invoice, which will double as a receipt for them.</p>
<h2 style="margin-top: 40px;">Creating Invoices With the Invoices Add-on</h2>
<p>The Invoices Add-on is a fully robust invoicing solution, built on top of Exchange. The Invoices Add-on is available to owners of the Exchange Pro Pack, Toolkit, or Dev Suite packages, or can be purchased on its own.</p>
<p>Once Invoices is activated, a new product type will display within the Exchange menu.</p>
<p>After you’ve set the title and price, you must assign the invoice to a client. If you already have client accounts on your site, selecting Existing Client will reveal a drop-down menu you can use to easily assign them the invoice.</p>
<p>If your client does not already have an account, you will be able to create one for them. This option also allows you to create a custom username and password for them. If not, they will be generated automatically.</p>
<p><img class="alignnone size-full wp-image-22076" alt="wordpress-invoice-3" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-03-at-3.27.56-PM.png" width="1424" height="1384" /></p>
<p>Invoices also allows you to set when the invoice will be sent, custom invoice and P.O. numbers, and your terms of how long you expect payment after the invoice has been received.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-03-at-3.44.25-PM.png"><img class="alignnone size-full wp-image-22077" alt="wordpress-invoice-4" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-03-at-3.44.25-PM.png" width="1654" height="1048" /></a></p>
<p>The invoice will be viewable to your client on its own, neatly styled page. At the bottom they will have the option to pay using any payment gateways you have set up within Exchange, such as Stripe or Paypal.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-03-at-3.59.58-PM.png"><img class="alignnone  wp-image-22078" alt="wordpress-invoice-5" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-03-at-3.59.58-PM.png" width="490" height="804" /></a></p>
<h2 style="margin-top: 40px;">Formatting the Invoice</h2>
<p>Within the Add-ons page from the Exchange menu, you’ll find a gear next to Invoices that allows you to change its settings. This allows you to format the email sent to your client however you like. There is a list of possible data keys below that you can use to truly customize the email for your client.</p>
<p><a href="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-03-at-4.12.53-PM.png"><img class="alignnone size-full wp-image-22079" alt="Screen Shot 2014-03-03 at 4.12.53 PM" src="http://ithemes.com/wp-content/uploads/2014/03/Screen-Shot-2014-03-03-at-4.12.53-PM.png" width="1624" height="1486" /></a></p>
<h2 style="margin-top: 40px;">Keeping Track of Invoices</h2>
<p>By logging into their customer account on your site, your clients will be able to access any and all invoices you’ve sent to them via the Dashboard. This is a handy way for them to easily keep track of their invoices, and refer to them again if need be. You will also be able to look through clients accounts as well, in order to keep track of invoices or edit payment statuses.</p>
<h2 style="margin-top: 40px;">Watch the Webinar: Invoicing Clients with Exchange</h2>
<p><iframe src="//www.youtube.com/embed/Y6TRDS9aw-A?list=UUhPXycSAGDUzBF-xMzMq6uA" height="360" width="640" allowfullscreen="" frameborder="0"></iframe></p>
<p>The post <a href="http://ithemes.com/2014/03/05/invoice-clients-wordpress-ithemes-exchange/">Invoicing Clients From Your WordPress Site With iThemes Exchange</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:78:"http://ithemes.com/2014/03/05/invoice-clients-wordpress-ithemes-exchange/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"Just Released: Carter, a Builder Theme for Image-Based Blogs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://ithemes.com/2014/03/03/just-released-carter-new-builder-theme-image-based-blogs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:96:"http://ithemes.com/2014/03/03/just-released-carter-new-builder-theme-image-based-blogs/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 03 Mar 2014 20:50:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Builder Theme";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=22002";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:656:"<p>Builder Theme Carter just arrived with a grid-based (masonry) layout for your blog and Exchange-powered store. With built-in Exchange styles, Carter also includes custom alternate modules and a mobile-responsive design. View the Demo What&#8217;s a Masonry Layout? Masonry Layouts have become popular for image-driven blogs, portfolios, ecommerce stores and social media sites (like Pinterest). For a [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/03/03/just-released-carter-new-builder-theme-image-based-blogs/">Just Released: Carter, a Builder Theme for Image-Based Blogs</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Kristen Wright";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:5010:"<p><a href="http://demos.ithemes.com/carter/"><img class=" wp-image-22003 alignnone" alt="carter" src="http://ithemes.com/wp-content/uploads/2014/03/carter.png" width="600" height="387" /></a></p>
<p><a href="http://ithemes.com/purchase/carter/">Builder Theme Carter</a> just arrived with a grid-based (masonry) layout for your blog and Exchange-powered store. With built-in Exchange styles, Carter also includes custom alternate modules and a mobile-responsive design.</p>
<p><a class="btn blue" href="http://demos.ithemes.com/carter/">View the Demo</a></p>
<h2 style="margin-top: 60px;">What&#8217;s a <em>Masonry Layout?</em></h2>
<p>Masonry Layouts have become popular for image-driven blogs, portfolios, ecommerce stores and social media sites (like <a href="http://www.pinterest.com">Pinterest</a>).</p>
<p>For a basic definition:</p>
<blockquote><p>A masonry layout is a grid layout based on columns. Unlike other grid layouts, it doesn’t have fixed height rows. Basically, a masonry layout optimizes the use of space inside the web page by reducing any unnecessary gaps.</p>
<p>— <a href="http://www.sitepoint.com/understanding-masonry-layout/"><em>Understanding Masonry Layouts</em></a></p></blockquote>
<p>Carter takes care of the complicated code and styling required by the design of masonry layouts, so you can focus more on adding the actual content of your site.</p>
<h2 style="margin-top: 60px;">Carter&#8217;s Blog Styling</h2>
<p>Carter&#8217;s blog uses featured images from standard blog posts, plus different post format styles for images, quotes and status posts — all rendered in a responsive masonry layout.</p>
<p style="text-align: center;"><a href="http://demos.ithemes.com/carter/"><img class="aligncenter  wp-image-22009" style="margin-top: 40px; margin-bottom: 40px;" alt="carter-blog" src="http://ithemes.com/wp-content/uploads/2014/03/carter-blog.png" width="745" height="1242" /></a></p>
<p>To apply formats to your posts, use the <strong>Format</strong> box on the right side of the WordPress post editor screen.</p>
<p style="text-align: center;"><img class="aligncenter  wp-image-22011" style="margin-top: 40px; margin-bottom: 40px;" alt="format-posts" src="http://ithemes.com/wp-content/uploads/2014/03/format-posts.png" width="1272" height="544" /></p>
<p>Check out the <a href="http://demos.ithemes.com/carter/">Carter Theme Demo</a> to see the blog in action.</p>
<h2 style="margin-top: 60px;">Carter&#8217;s Ecommerce Styling</h2>
<p>Carter also uses featured images from your Exchange store products to render the same grid-based layout styling for your store.</p>
<p style="text-align: center;"><a href="http://demos.ithemes.com/carter/store/"><img class="aligncenter  wp-image-22016" style="margin-top: 40px; margin-bottom: 40px;" alt="exchange-store-carter" src="http://ithemes.com/wp-content/uploads/2014/03/exchange-store-carter.png" width="1125" height="1034" /></a></p>
<p>Again, check out the <a href="http://demos.ithemes.com/carter/store/">Carter Theme Store Demo</a> to see the store in action. To get your online shop up and running quickly, <a href="http://ithemes.com/exchange">download Exchange</a>, our free ecommerce plugin.</p>
<h2 style="margin-top: 60px;">Build Your Own Page Layouts</h2>
<p>All Builder themes include the ability to build your own page layouts. Using the Builder Layout Editor, you can add/arrange modules for the header, navigation, content, widgets, images and footer.</p>
<p style="text-align: center;"><img class="aligncenter  wp-image-22017" style="margin-top: 40px; margin-bottom: 40px;" alt="builder-layout-editor" src="http://ithemes.com/wp-content/uploads/2014/03/builder-layout-editor.png" width="793" height="816" /></p>
<p>Carter also comes packaged with these pre-built page layouts:</p>
<ul>
<li>Email Signup</li>
<li>Hero Banner</li>
<li>Landing Page</li>
<li>Full Width</li>
<li>Full Width &#8211; Narrow</li>
<li>Left Sidebar</li>
<li>Right Sidebar</li>
</ul>
<h2 style="margin-top: 60px;">Download and Purchase Info</h2>
<p>Carter is available for purchase as part of the <a href="http://ithemes.com/purchase/builder-theme/#theme-pricing">Builder Developer Pack</a>, <a href="http://ithemes.com/all-access-pass/">All Access Theme Pass</a> and <a href="http://ithemes.com/toolkit/">WordPress Web Designer&#8217;s Toolkit</a>. Carter is also available as a <a href="http://demos.ithemes.com/carter/">stand-alone Builder theme</a>.</p>
<div class="content-callout green">All current Builder Developer Pack, All Access Theme Pass and Toolkit members will find Carter available now for immediate download from the <a href="http://ithemes.com/member/">iThemes Member Panel</a>.</div>
<p><a class="btn green" href="http://demos.ithemes.com/carter/">Get Carter now</a></p>
<p>The post <a href="http://ithemes.com/2014/03/03/just-released-carter-new-builder-theme-image-based-blogs/">Just Released: Carter, a Builder Theme for Image-Based Blogs</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:92:"http://ithemes.com/2014/03/03/just-released-carter-new-builder-theme-image-based-blogs/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"Membership Upgrades Made Simple – New for Exchange Membership Add-on";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://ithemes.com/2014/02/27/membership-upgrades-made-simple-exchange-wordpress-membership-plugin/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:108:"http://ithemes.com/2014/02/27/membership-upgrades-made-simple-exchange-wordpress-membership-plugin/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Feb 2014 17:56:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:20:"WordPress Membership";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=21947";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:628:"<p>If you&#8217;re running a WordPress membership site and you have multiple membership product tiers, you&#8217;ve probably wished that you could make it simple for your customers to upgrade their membership to the next level. Making the membership upgrade process easy and simple for your customers also makes life easier for you, the site owner, since [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/02/27/membership-upgrades-made-simple-exchange-wordpress-membership-plugin/">Membership Upgrades Made Simple – New for Exchange Membership Add-on</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Kristen Wright";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6400:"<p>If you&#8217;re running a WordPress membership site and you have multiple membership product tiers, you&#8217;ve probably wished that you could make it simple for your customers to upgrade their membership to the next level.</p>
<p>Making the membership upgrade process easy and simple for your customers also makes life easier for you, the site owner, since you&#8217;re not manually calculating membership upgrade costs or delaying the process because upgrades can&#8217;t be more automated.</p>
<p>Our latest update for the Exchange Membership Add-on, our <a href="http://ithemes.com/purchase/membership-add-on/">WordPress membership plugin</a>, features a better way for members to upgrade (and downgrade) their memberships.</p>
<p>This update automatically calculates how much money the customer has paid into their current membership and applies that amount as a credit to the purchase of the next membership level at checkout.</p>
<h2 style="margin-top: 40px;">Getting Started</h2>
<p>To take advantage of the new Exchange membership upgrade feature, you&#8217;ll need the following plugins (with the minimum versions listed below) installed on your WordPress site:</p>
<ul>
<li><a href="http://ithemes.com/exchange/" target="_blank">Exchange (v1.7.18)</a></li>
<li><a href="http://ithemes.com/purchase/membership-add-on/" target="_blank">Exchange Membership Add-on (v.1.1.1)</a></li>
<li><a href="http://ithemes.com/purchase/recurring-payments-add-on/" target="_blank">Exchange Recurring Payments Add-on (v.1.0.17)</a></li>
<li><a href="http://ithemes.com/purchase/stripe-add-on/" target="_blank">Exchange Stripe Add-on (v1.2.22)</a> or <a href="http://ithemes.com/exchange/features/" target="_blank">PayPal (default/core add-on)</a> enabled. <strong>Note:</strong> This feature currently only supports these two payment gateways.</li>
</ul>
<h2 style="margin-top: 60px;">Setting Up Membership Tiers</h2>
<p>If you haven&#8217;t already set up membership tiers, or levels, here&#8217;s an example. With four membership products (Free Trial, Bronze, Silver, and Gold), your customers could subscribe to the Free Trial and then later upgrade to the Bronze, Silver or Gold tiers. If they purchase a Bronze, they could also easily upgrade to Silver or Gold.</p>
<p><img class="aligncenter size-full wp-image-21949" alt="membership-tiers" src="http://ithemes.com/wp-content/uploads/2014/02/membership-tiers.png" width="766" height="682" /></p>
<p>To set these membership product tiers up in Exchange, add all of them as new membership products.</p>
<h2 style="margin-top: 40px;">Applying Membership Hierarchies</h2>
<p><em>For the membership upgrade/downgrade path to work, each of the memberships must be related. </em>In the Advanced settings area, you&#8217;ll see a new <strong>Membership Hierarchy</strong> menu item.</p>
<p>The <strong>Membership Hierarchy</strong> section allows you to apply<strong> Child Memberships</strong> (additional memberships available to this membership level) and<strong> Parent Membership</strong> (memberships that include content from this membership and all the children of it). The Parent/Child Memberships are really another way of thinking which memberships are above and below the current membership level.</p>
<h4 style="margin-top: 60px;">For the Free Trial membership:</h4>
<ul>
<li><strong>Parent memberships</strong>: Gold, Silver and Bronze</li>
</ul>
<p style="text-align: center;"><img class="aligncenter size-large wp-image-21950" alt="membership-relationship" src="http://ithemes.com/wp-content/uploads/2014/02/membership-relationship-1024x562.png" width="1024" height="562" /></p>
<h4 style="margin-top: 60px;">For the Bronze Level Membership:</h4>
<ul>
<li>Child Memberships: Free Trial</li>
<li>Parent Memberships: Gold and Silver</li>
</ul>
<p style="text-align: center;"><img class="aligncenter size-large wp-image-21951" alt="bronze-level" src="http://ithemes.com/wp-content/uploads/2014/02/bronze-level-1024x560.png" width="1024" height="560" /></p>
<h4 style="margin-top: 60px;">For the Silver Level Membership:</h4>
<ul>
<li>Child Memberships: Bronze and Free Trial</li>
<li>Parent Memberships: Gold</li>
</ul>
<p style="text-align: center;"><img class="aligncenter size-full wp-image-21978" alt="silver-membership" src="http://ithemes.com/wp-content/uploads/2014/02/silver-membership.png" width="1042" height="593" /></p>
<h4 style="margin-top: 60px;">For the Gold Level Membership:</h4>
<ul>
<li>Child Memberships: Silver, Bronze and Free Trial membership</li>
</ul>
<p style="text-align: center;"><img class="aligncenter size-full wp-image-21977" alt="gold-membership" src="http://ithemes.com/wp-content/uploads/2014/02/gold-membership.png" width="1032" height="565" /></p>
<h2 style="margin-top: 60px;">The Upgrading/Downgrading Process</h2>
<p>After a customer has purchased a lower-level membership (in this case, Bronze), the Gold Level membership product page will display their upgrade credit and a revised cart total based on their previous membership purchase.</p>
<p><img class="aligncenter size-full wp-image-21956" alt="gold-purchase" src="http://ithemes.com/wp-content/uploads/2014/02/gold-purchase.png" width="1016" height="606" /></p>
<p><strong>Note:</strong> If you have your memberships set to auto-renew, customers will get free days (instead of a credit) applied to the purchase of a higher-tiered membership, until their remaining balance is used up.</p>
<h2 style="margin-top: 60px;">Learn More about Creating a Membership Site with Exchange</h2>
<p>Check out these posts and resources for more info on how to set up your WordPress membership site with Exchange.</p>
<ul>
<li><a href="http://ithemes.com/2013/10/09/start-a-membership-site-with-ithemes-exchange/">Start a WordPress Membership Site with iThemes Exchange</a></li>
<li><a href="http://ithemes.com/publishing/join-the-club-how-to-create-a-membership-site/">[Free Ebook] Join the Club: How to Create a Membership Site</a></li>
<li><a href="http://ithemes.com/2013/11/26/a-better-way-to-organize-membership-content/">A Better Way of Organizing Membership Content</a></li>
</ul>
<p>The post <a href="http://ithemes.com/2014/02/27/membership-upgrades-made-simple-exchange-wordpress-membership-plugin/">Membership Upgrades Made Simple – New for Exchange Membership Add-on</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:104:"http://ithemes.com/2014/02/27/membership-upgrades-made-simple-exchange-wordpress-membership-plugin/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"Addressing Better WP Security 3.6.3 Vulnerabilities";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ithemes.com/2014/02/25/better-wp-security-3-x-vulnerability/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"http://ithemes.com/2014/02/25/better-wp-security-3-x-vulnerability/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 25 Feb 2014 20:09:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:27:"http://ithemes.com/?p=21904";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:588:"<p>Everyone makes mistakes, no doubt about it, and recently two vulnerabilities were reported to us in the previous (3.6.3) version of Better WP Security. The following issues have been addressed in today&#8217;s update (3.6.4), namely to remove in-dashboard access to support (the primary reason for this version update). But to address the specific concerns about [&#8230;]</p><p>The post <a href="http://ithemes.com/2014/02/25/better-wp-security-3-x-vulnerability/">Addressing Better WP Security 3.6.3 Vulnerabilities</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3291:"<p>Everyone makes mistakes, no doubt about it, and recently two vulnerabilities were reported to us in the previous (3.6.3) version of <a href="https://wordpress.org/plugins/better-wp-security/">Better WP Security</a>. The following issues have been addressed in today&#8217;s update (3.6.4), namely to remove in-dashboard access to support (the primary reason for this version update).</p>
<p>But to address the specific concerns about vulnerabilities in 3.6.3, here are the details. We assure you our top priority is always the safety of your site and no vulnerability risks currently exist in Better WP Security.</p>
<h2>1. InfiniteWP Compatibility and Persistant XSS</h2>
<p>First, Jon Cave from WordPress.org&#8217;s team pointed out an issue with our <a title="InfiniteWP" href="http://infinitewp.com" target="_blank">InfiniteWP</a> compatibility a few weeks ago. This issue is related to how InfiniteWP connects with sites. The data they sent was encoded to, presumably, shorten it.</p>
<p>To check the data the InfiniteWP code used, a PHP function called <a title="unserialize on PHP Codex" href="http://php.net/manual/en/function.unserialize.php" target="_blank">unserialize</a> was used to evaluate what data from the server had been sent. This function actually executes the code as it scans the received data, leading to a potential <a title="XSS on Owasp" href="https://www.owasp.org/index.php/Cross-site_Scripting_%28XSS%29" target="_blank">XSS</a> issue if someone was to send a harmful piece of code in the same manner as the InfiniteWP call.</p>
<h2>2. Removal of In-Dashboard Support Form</h2>
<p>The second reason for the 3.6.4 update is the removal of the in-dashboard support form. As some users have learned, the support form within Better WP Security had been broken, so we removed the form temporarily as we work out a better solution at iThemes.</p>
<h2>3. FooPlugins Support Form Code</h2>
<p>Third was a problem with the <a title="FooPlugins.com" href="http://fooplugins.com" target="_blank">FooPlugins</a> support form code. This code could have led to a potential XSS vulnerability (when the form was actually working), because JavaScript could have been potentially injected (and executed) in this form.</p>
<p><strong>Note: To inject JavaScript into the form, the user would have to be <em>logged in on the site with Administrator credentials to access the Better WP Security settings </em>to insert the code into the form (when the form was actually working).</strong></p>
<p>Still, we acknowledge a vulnerability in this scenario, so FooPlugins has been notified of the issue and <a title="Link to the code in question" href="https://github.com/fooplugins/foolic_validation" target="_blank">is already updating the code</a> in their other plugins. In the meantime, all FooPlugins integration has been removed from Better WP Security.</p>
<p>Update Feb 26th, 2014:</p>
<p>David over on the InfiniteWP team came up with a satisfactory solution eliminating the risk previously present. InfiniteWP compatibility has been restored in version 3.6.5.</p>
<p>The post <a href="http://ithemes.com/2014/02/25/better-wp-security-3-x-vulnerability/">Addressing Better WP Security 3.6.3 Vulnerabilities</a> appeared first on <a href="http://ithemes.com">iThemes</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"http://ithemes.com/2014/02/25/better-wp-security-3-x-vulnerability/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:29:"http://ithemes.com/blog/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:4:"date";s:29:"Wed, 19 Mar 2014 01:45:11 GMT";s:6:"server";s:6:"Apache";s:4:"vary";s:6:"Cookie";s:10:"x-pingback";s:29:"http://ithemes.com/xmlrpc.php";s:13:"last-modified";s:29:"Tue, 18 Mar 2014 23:59:15 GMT";s:4:"etag";s:34:""7527bd2760706cfcbfe9b7d2e28cbfb2"";s:10:"set-cookie";a:2:{i:0;s:57:"FirstTimeVisitor=1; expires=Tue, 19-Mar-2024 01:45:12 GMT";i:1;s:57:"FirstTimeVisitor=1; expires=Tue, 19-Mar-2024 01:45:12 GMT";}s:12:"x-robots-tag";s:14:"noindex,follow";s:10:"connection";s:5:"close";s:12:"content-type";s:23:"text/xml; charset=UTF-8";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('1042', '_transient_timeout_feed_mod_761bc2b7ca033de73fa7b3a5a0ffb39a', '1395236713', 'no'); 
INSERT INTO `wp_options` VALUES ('1043', '_transient_feed_mod_761bc2b7ca033de73fa7b3a5a0ffb39a', '1395193513', 'no'); 
INSERT INTO `wp_options` VALUES ('1066', '_transient_timeout_feed_0efdeb3e2b5ac73f1fef517fedaadeae', '1395277300', 'no'); 
INSERT INTO `wp_options` VALUES ('1067', '_transient_feed_0efdeb3e2b5ac73f1fef517fedaadeae', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:27:"
		
		
		
		
		

		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Plugins by Janis Elsts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://w-shadow.com/files/blc-plugin-links.rss";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:22:"Plugins by Janis Elsts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:3:{i:0;a:6:{s:4:"data";s:15:"
			
			
			
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Raw HTML Pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://w-shadow.com/RawHTML/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:12:"raw-html-pro";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:15:"
			
			
			
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Admin Menu Editor";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/extend/plugins/admin-menu-editor/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:17:"admin-menu-editor";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:15:"
			
			
			
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Error Log Monitor";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/extend/plugins/error-log-monitor/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:17:"error-log-monitor";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"http://w-shadow.com/files/blc-plugin-links.rss";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:4:"date";s:29:"Wed, 19 Mar 2014 13:01:40 GMT";s:6:"server";s:6:"Apache";s:13:"last-modified";s:29:"Thu, 06 Dec 2012 13:52:33 GMT";s:13:"accept-ranges";s:5:"bytes";s:14:"content-length";s:3:"953";s:4:"vary";s:10:"User-Agent";s:10:"connection";s:5:"close";s:12:"content-type";s:19:"application/rss+xml";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('1068', '_transient_timeout_feed_mod_0efdeb3e2b5ac73f1fef517fedaadeae', '1395277300', 'no'); 
INSERT INTO `wp_options` VALUES ('1069', '_transient_feed_mod_0efdeb3e2b5ac73f1fef517fedaadeae', '1395234100', 'no'); 
INSERT INTO `wp_options` VALUES ('1070', 'dbem_thumbnails_enabled', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1071', 'dbem_js_limit', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1072', 'dbem_js_limit_general', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1073', 'dbem_js_limit_search', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1074', 'dbem_js_limit_events_form', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1075', 'dbem_js_limit_edit_bookings', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1076', 'dbem_css_limit', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1077', 'dbem_css_limit_include', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1078', 'dbem_css_limit_exclude', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1079', 'dbem_disable_timthumb', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1080', 'dbem_pro_dev_updates', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1081', 'dbem_disable_title_rewrites', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1082', 'dbem_title_html', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1083', 'dbem_events_current_are_past', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1084', 'dbem_bookings_default_orderby', 'event_name', 'yes'); 
INSERT INTO `wp_options` VALUES ('1085', 'dbem_bookings_default_order', 'ASC', 'yes'); 
INSERT INTO `wp_options` VALUES ('1086', 'dbem_edit_events_page', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1087', 'dbem_edit_locations_page', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1088', 'dbem_edit_bookings_page', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1089', 'dbem_event_list_groupby', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1090', 'dbem_event_list_groupby_format', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1091', 'dbem_display_calendar_day_single', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1092', 'dbem_bookings_tickets_show_member_tickets', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1093', 'dbem_mail_sender_address', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1094', 'dbem_smtp_username', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1095', 'dbem_smtp_password', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1160', 'M_Installed', '14', 'yes'); 
INSERT INTO `wp_options` VALUES ('1161', 'membership_options', 'a:13:{s:17:"registration_page";i:102;s:12:"account_page";i:103;s:14:"nocontent_page";i:104;s:25:"membershipadminshortcodes";a:1:{i:0;s:12:"contact-form";}s:24:"membershipdownloadgroups";a:1:{i:0;s:7:"default";}s:10:"masked_url";s:9:"downloads";s:13:"strangerlevel";i:2;s:15:"paymentcurrency";s:3:"BRL";s:13:"upgradeperiod";s:1:"0";s:13:"renewalperiod";s:3:"365";s:16:"registration_tos";s:0:"";s:20:"freeusersubscription";i:1;s:23:"enableincompletesignups";s:0:"";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1162', 'M_Newsstream_Installed', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('1165', 'membership_active', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES ('1166', 'membership_activated_gateways', 'a:1:{i:0;s:10:"paypalsolo";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1167', 'membership_wizard_visible', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('1168', 'membership_simpleinvite_options', 'a:3:{s:11:"invitecodes";s:0:"";s:14:"inviterequired";s:0:"";s:12:"inviteremove";s:0:"";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1175', '_site_transient_timeout_ure_caps_readable', '1395283926', 'yes'); 
INSERT INTO `wp_options` VALUES ('1176', '_site_transient_ure_caps_readable', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1187', 'rewrite_rules', 'a:228:{s:28:"eventos/(\d{4}-\d{2}-\d{2})$";s:52:"index.php?pagename=eventos/&calendar_day=$matches[1]";s:14:"eventos/rss/?$";s:35:"index.php?post_type=event&feed=feed";s:15:"eventos/feed/?$";s:35:"index.php?post_type=event&feed=feed";s:19:"eventos/event/(.+)$";s:64:"index.php?pagename=eventos/&em_redirect=1&event_slug=$matches[1]";s:22:"eventos/location/(.+)$";s:67:"index.php?pagename=eventos/&em_redirect=1&location_slug=$matches[1]";s:22:"eventos/category/(.+)$";s:67:"index.php?pagename=eventos/&em_redirect=1&category_slug=$matches[1]";s:10:"eventos/?$";s:26:"index.php?pagename=eventos";s:22:"events/([^/]+)/ical/?$";s:34:"index.php?event=$matches[1]&ical=1";s:25:"locations/([^/]+)/ical/?$";s:37:"index.php?location=$matches[1]&ical=1";s:33:"events/categories/([^/]+)/ical/?$";s:45:"index.php?event-categories=$matches[1]&ical=1";s:27:"events/tags/([^/]+)/ical/?$";s:39:"index.php?event-tags=$matches[1]&ical=1";s:24:"locations/([^/]+)/rss/?$";s:36:"index.php?location=$matches[1]&rss=1";s:14:"^wc-api\/v1/?$";s:24:"index.php?wc-api-route=/";s:16:"^wc-api\/v1(.*)?";s:34:"index.php?wc-api-route=$matches[1]";s:12:"locations/?$";s:28:"index.php?post_type=location";s:42:"locations/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=location&feed=$matches[1]";s:37:"locations/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=location&feed=$matches[1]";s:29:"locations/page/([0-9]{1,})/?$";s:46:"index.php?post_type=location&paged=$matches[1]";s:9:"events/?$";s:25:"index.php?post_type=event";s:39:"events/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:34:"events/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=event&feed=$matches[1]";s:26:"events/page/([0-9]{1,})/?$";s:43:"index.php?post_type=event&paged=$matches[1]";s:7:"loja/?$";s:27:"index.php?post_type=product";s:37:"loja/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:32:"loja/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:24:"loja/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:52:"events/tags/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?event-tags=$matches[1]&feed=$matches[2]";s:47:"events/tags/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?event-tags=$matches[1]&feed=$matches[2]";s:40:"events/tags/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?event-tags=$matches[1]&paged=$matches[2]";s:22:"events/tags/([^/]+)/?$";s:32:"index.php?event-tags=$matches[1]";s:56:"events/categories/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?event-categories=$matches[1]&feed=$matches[2]";s:51:"events/categories/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:55:"index.php?event-categories=$matches[1]&feed=$matches[2]";s:44:"events/categories/(.+?)/page/?([0-9]{1,})/?$";s:56:"index.php?event-categories=$matches[1]&paged=$matches[2]";s:26:"events/categories/(.+?)/?$";s:38:"index.php?event-categories=$matches[1]";s:37:"locations/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:47:"locations/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:67:"locations/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"locations/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:62:"locations/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"locations/([^/]+)/trackback/?$";s:35:"index.php?location=$matches[1]&tb=1";s:50:"locations/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?location=$matches[1]&feed=$matches[2]";s:45:"locations/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?location=$matches[1]&feed=$matches[2]";s:38:"locations/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?location=$matches[1]&paged=$matches[2]";s:45:"locations/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?location=$matches[1]&cpage=$matches[2]";s:35:"locations/([^/]+)/wc-api(/(.*))?/?$";s:49:"index.php?location=$matches[1]&wc-api=$matches[3]";s:41:"locations/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:52:"locations/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:30:"locations/([^/]+)(/[0-9]+)?/?$";s:47:"index.php?location=$matches[1]&page=$matches[2]";s:26:"locations/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:36:"locations/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:56:"locations/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"locations/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:51:"locations/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:34:"events/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"events/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"events/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"events/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"events/([^/]+)/trackback/?$";s:32:"index.php?event=$matches[1]&tb=1";s:47:"events/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:42:"events/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?event=$matches[1]&feed=$matches[2]";s:35:"events/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&paged=$matches[2]";s:42:"events/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&cpage=$matches[2]";s:32:"events/([^/]+)/wc-api(/(.*))?/?$";s:46:"index.php?event=$matches[1]&wc-api=$matches[3]";s:38:"events/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:49:"events/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:27:"events/([^/]+)(/[0-9]+)?/?$";s:44:"index.php?event=$matches[1]&page=$matches[2]";s:23:"events/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"events/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"events/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"events/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"events-recurring/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:54:"events-recurring/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:74:"events-recurring/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"events-recurring/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"events-recurring/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"events-recurring/([^/]+)/trackback/?$";s:42:"index.php?event-recurring=$matches[1]&tb=1";s:45:"events-recurring/([^/]+)/page/?([0-9]{1,})/?$";s:55:"index.php?event-recurring=$matches[1]&paged=$matches[2]";s:52:"events-recurring/([^/]+)/comment-page-([0-9]{1,})/?$";s:55:"index.php?event-recurring=$matches[1]&cpage=$matches[2]";s:42:"events-recurring/([^/]+)/wc-api(/(.*))?/?$";s:56:"index.php?event-recurring=$matches[1]&wc-api=$matches[3]";s:48:"events-recurring/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:59:"events-recurring/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:37:"events-recurring/([^/]+)(/[0-9]+)?/?$";s:54:"index.php?event-recurring=$matches[1]&page=$matches[2]";s:33:"events-recurring/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"events-recurring/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"events-recurring/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"events-recurring/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"events-recurring/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:56:"categoria-produto/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:51:"categoria-produto/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:44:"categoria-produto/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:26:"categoria-produto/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:57:"produto-etiqueta/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:52:"produto-etiqueta/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:45:"produto-etiqueta/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:27:"produto-etiqueta/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:35:"produto/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"produto/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"produto/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"produto/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"produto/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"produto/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"produto/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"produto/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"produto/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"produto/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"produto/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:39:"produto/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"produto/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:28:"produto/([^/]+)(/[0-9]+)?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"produto/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"produto/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"produto/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"produto/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"produto/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:45:"product_variation/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"product_variation/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"product_variation/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"product_variation/([^/]+)/trackback/?$";s:44:"index.php?product_variation=$matches[1]&tb=1";s:46:"product_variation/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&paged=$matches[2]";s:53:"product_variation/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&cpage=$matches[2]";s:43:"product_variation/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?product_variation=$matches[1]&wc-api=$matches[3]";s:49:"product_variation/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"product_variation/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:38:"product_variation/([^/]+)(/[0-9]+)?/?$";s:56:"index.php?product_variation=$matches[1]&page=$matches[2]";s:34:"product_variation/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"product_variation/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"product_variation/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:52:"dfads_group/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?dfads_group=$matches[1]&feed=$matches[2]";s:47:"dfads_group/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?dfads_group=$matches[1]&feed=$matches[2]";s:40:"dfads_group/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?dfads_group=$matches[1]&paged=$matches[2]";s:22:"dfads_group/([^/]+)/?$";s:33:"index.php?dfads_group=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1198', '_transient_timeout_wc_report_f0af875801ed958fd83e11ca17a8a51c', '1395415353', 'no'); 
INSERT INTO `wp_options` VALUES ('1199', '_transient_wc_report_f0af875801ed958fd83e11ca17a8a51c', 'a:0:{}', 'no'); 
INSERT INTO `wp_options` VALUES ('1204', '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1395372164', 'no'); 
INSERT INTO `wp_options` VALUES ('1205', '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:39:"http://wordpress.org/?v=3.9-beta1-27615";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:309:"WordPress 3.9 Beta 2 is now available for testing! We&#8217;ve made more than a hundred changes since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1901:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&amp;stop_rev=27500&amp;limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 13:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3083";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"I&#8217;m excited to announce that the first beta of WordPress 3.9 is now available for testing. WordPress 3.9 is due out next month &#8212; but in order to hit that goal, we need your help testing all of the goodies we&#8217;ve added: We updated TinyMCE, the software powering the visual editor, to the latest version. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6065:"<p>I&#8217;m excited to announce that the <strong>first beta of WordPress 3.9</strong> is now available for testing.</p>
<p>WordPress 3.9 is due out next month &#8212; but in order to hit that goal, <strong>we need your help</strong> testing all of the goodies we&#8217;ve added:</p>
<ul>
<li>We updated TinyMCE, the software powering the visual editor, to the latest version. Be on the lookout for cleaner markup. Also try the new paste handling &#8212; if you paste in a block of text from Microsoft Word, for example, it will no longer come out terrible. (The &#8220;Paste from Word&#8221; button you probably never noticed has been removed.) It&#8217;s possible some plugins that added stuff to the visual editor (like a new toolbar button) no longer work, so we&#8217;d like to hear about them (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>). (And be sure to <a href="http://wordpress.org/support/">open a support thread</a> for the plugin author.)</li>
<li>We&#8217;ve added <strong>widget management to live previews</strong> (the customizer). Please test editing, adding, and rearranging widgets! (<a href="https://core.trac.wordpress.org/ticket/27112">#27112</a>) We&#8217;ve also added the ability to upload, crop, and manage header images, without needing to leave the preview. (<a href="https://core.trac.wordpress.org/ticket/21785">#21785</a>)</li>
<li>We brought 3.8&#8242;s beautiful new theme browsing experience to the <strong>theme installer</strong>. Check it out! (<a title="View ticket" href="https://core.trac.wordpress.org/ticket/27055">#27055</a>)</li>
<li><strong>Galleries</strong> now receive a live preview in the editor. Upload some photos and insert a gallery to see this in action. (<a href="https://core.trac.wordpress.org/ticket/26959">#26959</a>)</li>
<li>You can now <strong>drag-and-drop</strong> images directly onto the editor to upload them. It can be a bit finicky, so try it and help us work out the kinks. (<a href="https://core.trac.wordpress.org/ticket/19845">#19845</a>)</li>
<li>Some things got improved around <strong>editing images</strong>. It&#8217;s a lot easier to make changes to an image after you insert it into a post (<a class="closed" title="View ticket" href="https://core.trac.wordpress.org/ticket/24409">#24409</a>) and you no longer get kicked to a new window when you need to crop or rotate an image (<a href="https://core.trac.wordpress.org/ticket/21811">#21811</a>).</li>
<li>New <strong>audio/video playlists</strong>. Upload a few audio or video files to test these. (<a href="https://core.trac.wordpress.org/ticket/26631">#26631</a>)</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We&#8217;d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip">download the beta here</a> (zip).</p>
<hr />
<p><strong>DEVELOPERS!</strong> Hello! There&#8217;s lots for you, too.</p>
<p><strong>Please test your plugins and themes!</strong> There&#8217;s a lot of great stuff under the hood in 3.9 and we hope to blog a bit about them in the coming days. If you haven&#8217;t been reading the awesome <a href="http://make.wordpress.org/core/tag/week-in-core/">weekly summaries</a> on the <a href="http://make.wordpress.org/core/">main core development blog</a>, that&#8217;s a great place to start. (You should definitely follow that blog.) For now, here are some things to watch out for when testing:</p>
<ul>
<li>The <strong>load process in multisite</strong> got rewritten. If you notice any issues with your network, see <a href="https://core.trac.wordpress.org/ticket/27003">#27003</a>.</li>
<li>We now use the <strong>MySQL Improved (mysqli) database extension</strong> if you&#8217;re running a recent version of PHP (<a href="https://core.trac.wordpress.org/ticket/21663">#21663</a>). Please test your plugins and see that everything works well, and please make sure you&#8217;re not calling <code>mysql_*</code> functions directly.</li>
<li><strong>Autosave</strong> was refactored, so if you see any issues related to autosaving, heartbeat, etc., let us know (<a href="https://core.trac.wordpress.org/ticket/25272">#25272</a>).</li>
<li>Library updates, in particular Backbone 1.1 and Underscore 1.6 (<a href="https://core.trac.wordpress.org/ticket/26799">#26799</a>). Also Masonry 3 (<a href="https://core.trac.wordpress.org/ticket/25351">#25351</a>), PHPMailer (<a href="https://core.trac.wordpress.org/ticket/25560">#25560</a>), Plupload (<a href="https://core.trac.wordpress.org/ticket/25663">#25663</a>), and TinyMCE (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>).</li>
<li>TinyMCE 4.0 is a <em>major</em> update. Please see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">upgrade guide</a> and our <a href="https://core.trac.wordpress.org/ticket/24067">implementation ticket</a> for more. If you have any questions or problems, please <a href="http://wordpress.org/support/forum/alphabeta">open a thread in the support forums</a>.</li>
</ul>
<p>Happy testing!</p>
<p><em><em>Lots of improvements<br />
Little things go a long way</em><br />
Please test beta one<br />
</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/01/wordpress-3-8-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/01/wordpress-3-8-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3063";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:358:"After six weeks and more than 9.3 million downloads of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3809:"<p>After six weeks and more than <a href="http://wordpress.org/download/counter/">9.3 million downloads</a> of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available.</p>
<p>Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query was resolved. And if you&#8217;ve been frustrated by submit buttons that won&#8217;t do anything when you click on them (or thought you were going crazy, like some of us), we&#8217;ve found and fixed this &#8220;dead zone&#8221; on submit buttons.</p>
<p>It also contains a fix for <strong>embedding tweets</strong> (by placing the URL to the tweet on its own line), which was broken due to a recent Twitter API change. (For more on Embeds, see <a href="http://codex.wordpress.org/Embeds">the Codex</a>.)</p>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.8.1">list of tickets</a> and <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=27018&amp;stop_rev=26862">the changelog</a>. There&#8217;s also a <a href="http://make.wordpress.org/core/2014/01/22/wordpress-3-8-1-release-candidate/">detailed summary</a> for developers on the development blog.</p>
<p>If you are one of the millions already running WordPress 3.8, we will start rolling out automatic background updates for WordPress 3.8.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.8.1:</p>
<p><a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="#">José Pino</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p><em>WordPress three eight one<br />
We heard you didn&#8217;t like bugs<br />
So we took them out</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/01/wordpress-3-8-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WordPress 3.8 “Parker”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://wordpress.org/news/2013/12/parker/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/12/parker/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Dec 2013 17:00:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2765";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:354:"Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:18740:"<p>Version 3.8 of WordPress, named “Parker” in honor of <a href="http://en.wikipedia.org/wiki/Charlie_Parker">Charlie Parker</a>, bebop innovator, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet.</p>
<div id="v-6wORgoGb-1" class="video-player"><embed id="v-6wORgoGb-1-video" src="http://s0.videopress.com/player.swf?v=1.03&amp;guid=6wORgoGb&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<h2 class="aligncenter">Introducing a modern new design</h2>
<p><img class="wp-image-2951 aligncenter" alt="overview" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/overview.jpg?resize=623%2C193" data-recalc-dims="1" /></p>
<p>WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. Gone are overbearing gradients and dozens of shades of grey — bring on a bigger, bolder, more colorful design!</p>
<p><img class="aligncenter  wp-image-2856" style="margin-left: 0;margin-right: 0" alt="about-modern-wordpress" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/design.png?resize=623%2C151" data-recalc-dims="1" /></p>
<h3>Modern aesthetic</h3>
<p>The new WordPress dashboard has a fresh, uncluttered design that embraces clarity and simplicity.</p>
<h3>Clean typography</h3>
<p>The Open Sans typeface provides simple, friendly text that is optimized for both desktop and mobile viewing. It’s even open source, just like WordPress.</p>
<h3>Refined contrast</h3>
<p>We think beautiful design should never sacrifice legibility. With superior contrast and large, comfortable type, the new design is easy to read and a pleasure to navigate.</p>
<hr />
<h2 class="aligncenter">WordPress on every device</h2>
<p><img class="alignright  wp-image-2984" alt="responsive" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/responsive.jpg?resize=255%2C255" data-recalc-dims="1" />We all access the internet in different ways. Smartphone, tablet, notebook, desktop — no matter what you use, WordPress will adapt and you’ll feel right at home.</p>
<h3>High definition at high speed</h3>
<p>WordPress is sharper than ever with new vector-based icons that scale to your screen. By ditching pixels, pages load significantly faster, too.</p>
<hr />
<h2 class="aligncenter">Admin color schemes to match your personality</h2>
<p><img class="aligncenter  wp-image-2954" alt="colors" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/colors.jpg?resize=623%2C339" data-recalc-dims="1" /></p>
<p>WordPress just got a colorful new update. We’ve included eight new admin color schemes so you can pick the one that suits you best.</p>
<p>Color schemes can be previewed and changed from your Profile page.</p>
<hr />
<h2 class="aligncenter">Refined theme management</h2>
<p><img class="alignright  wp-image-2967" alt="themes" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/themes.jpg?resize=360%2C344" data-recalc-dims="1" />The new themes screen lets you survey your themes at a glance. Or want more information? Click to discover more. Then sit back and use your keyboard’s navigation arrows to flip through every theme you’ve got.</p>
<h3>Smoother widget experience</h3>
<p>Drag-drag-drag. Scroll-scroll-scroll. Widget management can be complicated. With the new design, we’ve worked to streamline the widgets screen.</p>
<p>Have a large monitor? Multiple widget areas stack side-by-side to use the available space. Using a tablet? Just tap a widget to add it.</p>
<hr />
<h2 class="aligncenter">Twenty Fourteen, a sleek new magazine theme</h2>
<p><img class="aligncenter size-large wp-image-2789" alt="The new Twenty Fourteen theme displayed on a laptop. tablet and phone" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/twentyfourteen.jpg?resize=692%2C275" data-recalc-dims="1" /></p>
<h3>Turn your blog into a magazine</h3>
<p>Create a beautiful magazine-style site with WordPress and Twenty Fourteen. Choose a grid or a slider to display featured content on your homepage. Customize your site with three widget areas or change your layout with two page templates.</p>
<p>With a striking design that does not compromise our trademark simplicity, Twenty Fourteen is our most intrepid default theme yet.</p>
<hr />
<h2>Beginning of a new era</h2>
<p>This release was led by Matt Mullenweg. This is our second release using the new plugin-first development process, with a much shorter timeframe than in the past. We think it’s been going great. You can check out the features currently in production on the <a title="Make WordPress Core" href="http://make.wordpress.org/core/" target="_blank">make/core blog</a>.</p>
<p>There are 188 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/admiralthrawn">admiralthrawn</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aralbald">Andrey Kabakchiev</a>, <a href="http://profiles.wordpress.org/apeatling">Andy Peatling</a>, <a href="http://profiles.wordpress.org/ankitgadertcampcom">Ankit Gade</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/fliespl">Arkadiusz Rzadkowolski</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/binarymoon">binarymoon</a>, <a href="http://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/calin">Calin Don</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="http://profiles.wordpress.org/caspie">Caspie</a>, <a href="http://profiles.wordpress.org/chrisbliss18">Chris Jean</a>, <a href="http://profiles.wordpress.org/iblamefish">Clinton Montague</a>, <a href="http://profiles.wordpress.org/cojennin">cojennin</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/dbernar1">Dan Bernardic</a>, <a href="http://profiles.wordpress.org/danieldudzic">Daniel Dudzic</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/datafeedrcom">datafeedr</a>, <a href="http://profiles.wordpress.org/lessbloat">Dave Martin</a>, <a href="http://profiles.wordpress.org/drw158">Dave Whitley</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/dziudek">dziudek</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gnarf37">gnarf37</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/isaackeyet">Isaac Keyet</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="http://profiles.wordpress.org/janhenckens">janhenckens</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jblz">Jeff Bowen</a>, <a href="http://profiles.wordpress.org/jeffr0">Jeff Chandler</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jeherve">Jeremy Herve</a>, <a href="http://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jhned">jhned</a>, <a href="http://profiles.wordpress.org/jim912">jim912</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joen">Joen Asmussen</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/nukaga">Junko Nukaga</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K. Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/codebykat">Kat Hagan</a>, <a href="http://profiles.wordpress.org/littlethingsstudio">Kate Whitley</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/koki4a">Konstantin Dankov</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lite3">lite3</a>, <a href="http://profiles.wordpress.org/lucp">Luc Princen</a>, <a href="http://profiles.wordpress.org/latz">Lutz Schroer</a>, <a href="http://profiles.wordpress.org/mako09">Mako</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/megane9988">megane9988</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/micahwave">micahwave</a>, <a href="http://profiles.wordpress.org/cainm">Michael Cain</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">Michael Erlewine</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/chellycat">Michelle Langston</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mt8biz">moto hachi</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/ninio">ninio</a>, <a href="http://profiles.wordpress.org/ninnypants">ninnypants</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="http://profiles.wordpress.org/odysseygate">odyssey</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/swissspidy">Pascal Birchler</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/senlin">Piet</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/bamadesigner">Rachel Carden</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/radices">Radices</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/defries">Remkus de Vries</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/wet">Robert Wetzlmayr, PHP-Programmierer</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood</a>, <a href="http://profiles.wordpress.org/sanchothefat">sanchothefat</a>, <a href="http://profiles.wordpress.org/sboisvert">sboisvert</a>, <a href="http://profiles.wordpress.org/scottbasgaard">Scott Basgaard</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/designsimply">Sheri Bigelow (designsimply)</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirbrillig">sirbrillig</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/thomasguillot">Thomas Guillot</a>, <a href="http://profiles.wordpress.org/tierra">tierra</a>, <a href="http://profiles.wordpress.org/tillkruess">Till Krüss</a>, <a href="http://profiles.wordpress.org/tlamedia">TLA Media</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tommcfarlin">tommcfarlin</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/taupecat">Tracy Rotton</a>, <a href="http://profiles.wordpress.org/trishasalas">trishasalas</a>, <a href="http://profiles.wordpress.org/mbmufffin">Tyler Smith</a>, <a href="http://profiles.wordpress.org/grapplerulrich">Ulrich</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/l10n">Vladimir</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yonasy">yonasy</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, and <a href="http://profiles.wordpress.org/tollmanz">Zack Tollman</a>. Also thanks to <a href="http://benmorrison.org/">Ben Morrison</a> and <a href="http://christineswebb.com/">Christine Webb</a> for help with the video.</p>
<p>Thanks for choosing WordPress. See you soon for version 3.9!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"http://wordpress.org/news/2013/12/parker/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"3.8 RC2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://wordpress.org/news/2013/12/3-8-rc2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/news/2013/12/3-8-rc2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Dec 2013 01:08:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2805";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:343:"Release candidate 2 of WordPress 3.8 is now available for download. This is the last pre-release, and we expect it to be effectively identical to what&#8217;s officially released to the public on Thursday. This means if you are a plugin or theme developer, start your engines! (If they&#8217;re not going already.) Lots of admin code [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1180:"<p>Release candidate 2 of WordPress 3.8 is <a href="http://wordpress.org/wordpress-3.8-RC2.zip">now available for download</a>. This is the last pre-release, and we expect it to be effectively identical to what&#8217;s officially released to the public on Thursday.</p>
<p>This means if you are a plugin or theme developer, start your engines! (If they&#8217;re not going already.) Lots of admin code has changed so it&#8217;s especially important to see if your plugin works well within the new admin design and layout, and update <a href="http://wordpress.org/plugins/about/readme.txt">the &#8220;Tested up to:&#8221; part of your plugin readme.txt</a>.</p>
<p>If there is something in your plugin that you&#8217;re unable to fix, or if you think you&#8217;ve found a bug, join us <a href="http://codex.wordpress.org/IRC">in #wordpress-dev in IRC</a>, especially if you&#8217;re able to join during the dev chat on Wednesday, or post in the <a href="http://wordpress.org/support/forum/alphabeta">alpha/beta forum</a>. The developers and designers who worked on this release are happy to help anyone update their code before the 3.8 release.</p>
<p>Happy hacking, everybody!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/news/2013/12/3-8-rc2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"WordPress 3.8 RC1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/12/3-8-almost/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/news/2013/12/3-8-almost/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Dec 2013 09:54:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2760";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:345:"We&#8217;re entering the quiet but busy part of a release, whittling down issues to bring you all of the new features you&#8217;re excited about with the stability you expect from WordPress. There are just a few days from the &#8220;code freeze&#8221; for our 3.8 release, which includes a number of exciting enhancements, so the focus [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1873:"<p>We&#8217;re entering the quiet but busy part of a release, whittling down issues to bring you all of the new features you&#8217;re excited about with the stability you expect from WordPress. There are just a few days from the &#8220;code freeze&#8221; for our 3.8 release, <a href="http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/">which includes a number of exciting enhancements</a>, so the focus is on identifying any major issues and resolving them as soon as possible.</p>
<p>If you&#8217;ve ever wondered about how to contribute to WordPress, here&#8217;s a time you can: download this release candidate and use it in as many ways as you can imagine. Try to break it, and if you do, let us know how you did it so we can make sure it never happens again. If you work for a web host, this is the release you should test as much as possible and start getting your automatic upgrade systems and 1-click installers ready.</p>
<p><a href="http://wordpress.org/wordpress-3.8-RC1.zip">Download WordPress 3.8 RC1</a> (zip) or use the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;).</p>
<p>If you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.8">everything we’ve fixed</a> so far.</p>
<p><em>We&#8217;re so close to the</em><br />
<em>finish line, jump in and help</em><br />
<em>good karma is yours.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/12/3-8-almost/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.8 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Nov 2013 05:21:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2754";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:307:"The first beta of the 3.8 is now available, and the next dates to watch out for are code freeze on December 5th and a final release on December 12th. 3.8 brings together several of the features as plugins projects and while this isn&#8217;t our first rodeo, expect this to be more beta than usual. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2236:"<p>The first beta of the 3.8 is now available, and the next dates to watch out for are code freeze on December 5th and a final release on December 12th.</p>
<p>3.8 brings together <a href="http://make.wordpress.org/core/features-as-plugins/">several of the features as plugins projects</a> and while this isn&#8217;t our first rodeo, expect this to be more beta than usual. The headline things to test out in this release are:</p>
<ul>
<li>The new admin design, especially the responsive aspect of it. Try it out on different devices and browsers, see how it goes, especially the more complex pages like widgets or seldom-looked-at-places like Press This. Color schemes, which you can change on your profile, have also been spruced up.</li>
<li>The dashboard homepage has been refreshed, poke and prod it.</li>
<li>Choosing themes under Appearance is completely different, try to break it however possible.</li>
<li>There&#8217;s a new default theme, Twenty Fourteen.</li>
<li>Over 250 issues closed already.</li>
</ul>
<p>Given how many things in the admin have changed it&#8217;s extra super duper important to test as many plugins and themes with admin pages against the new stuff. Also if you&#8217;re a developer consider how you can make your admin interface fit the MP6 aesthetic better.</p>
<p>As always, if you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.8">everything we’ve fixed</a> so far.</p>
<p><a href="http://wordpress.org/wordpress-3.8-beta-1.zip">Download WordPress 3.8 Beta 1</a> (zip) or use the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;).</p>
<p><em>Alphabet soup of</em><br />
<em>Plugins as features galore</em><br />
<em>The future is here</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.7.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/10/wordpress-3-7-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/10/wordpress-3-7-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Oct 2013 21:04:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2745";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:371:"WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling some [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1594:"<p>WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including:</p>
<ul>
<li>Images with captions no longer appear broken in the visual editor.</li>
<li>Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org.</li>
<li>Avoid fatal errors with certain plugins that were incorrectly calling some WordPress functions too early.</li>
<li>Fix hierarchical sorting in get_pages(), exclusions in wp_list_categories(), and in_category() when called with empty values.</li>
<li>Fix a warning that may occur in certain setups while performing a search, and a few other notices.</li>
</ul>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.7.1">list of tickets</a> and <a href="http://core.trac.wordpress.org/log/branches/3.7?stop_rev=25914&amp;rev=25986">the changelog</a>.</p>
<p>If you are one of the <a href="http://wordpress.org/download/counter/">nearly two million</a> already running WordPress 3.7, we will start rolling out the all-new <a href="http://wordpress.org/news/2013/10/basie/">automatic background updates</a> for WordPress 3.7.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.7.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p><em>Just a few fixes<br />
Your new update attitude:<br />
Zero clicks given</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/wordpress-3-7-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.7 “Basie”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2013/10/basie/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2013/10/basie/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Oct 2013 22:35:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2736";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:357:"Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don&#8217;t have to lift a finger to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:17229:"<p>Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of <a href="http://en.wikipedia.org/wiki/Count_basie">Count Basie</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones:</p>
<ul>
<li><strong>Updates while you sleep</strong>: With WordPress 3.7, you don&#8217;t have to lift a finger to apply maintenance and security updates. Most sites are now able to automatically apply these updates in the background. The update process also has been made even more reliable and secure, with dozens of new checks and safeguards.</li>
<li><strong>Stronger password recommendations</strong>: Your password is your site&#8217;s first line of defense. It&#8217;s best to create passwords that are complex, long, and unique. To that end, our password meter has been updated in WordPress 3.7 to recognize common mistakes that can weaken your password: dates, names, keyboard patterns (123456789), and even pop culture references.</li>
<li><strong>Better global support</strong>: Localized versions of WordPress will receive faster and more complete translations. WordPress 3.7 adds support for automatically installing the right language files and keeping them up to date, a boon for the many millions who use WordPress in a language other than English.</li>
</ul>
<p>For developers there are lots of options around how to control the new updates feature, including allowing it to handle major upgrades as well as minor ones, more sophisticated date query support, and multisite improvements. As always, if you&#8217;re hungry for more <a href="http://codex.wordpress.org/Version_3.7">dive into the Codex</a> or browse the <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.7">over 400 closed tickets on Trac</a>.</p>
<h3>A New Wave</h3>
<p>This release was led by Andrew Nacin, backed up by Dion Hulse and Jon Cave. This is our first release using the new plugin-first development process, with a much shorter timeframe than in the past. (3.6 was released in August.) The 3.8 release, due in December, will continue this plugin-led development cycle that gives much more autonomy to plugin leads and allows us to decouple feature development from a release. You can follow this grand experiment, and what we&#8217;re learning from it, <a href="http://make.wordpress.org/core/">on the make/core blog</a>. There are 211 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/technosailor">Aaron Brazell</a>, <a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/andg">andg</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/andrewspittle">Andrew Spittle</a>, <a href="http://profiles.wordpress.org/askapache">askapache</a>, <a href="http://profiles.wordpress.org/atimmer">atimmer</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/beaulebens">Beau Lebens</a>, <a href="http://profiles.wordpress.org/benmoody">ben.moody</a>, <a href="http://profiles.wordpress.org/bhengh">Ben Miller</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bftrick">BFTrick</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/bmb">bmb</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brianhogg">brianhogg</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/charlesclarkson">CharlesClarkson</a>, <a href="http://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisrudzki">Chris Rudzki</a>, <a href="http://profiles.wordpress.org/aeg0125">coderaaron</a>, <a href="http://profiles.wordpress.org/coenjacobs">Coen Jacobs</a>, <a href="http://profiles.wordpress.org/crrobi01">Colin Robinson</a>, <a href="http://profiles.wordpress.org/andreasnrb">cyonite</a>, <a href="http://profiles.wordpress.org/daankortenbach">Daan Kortenbach</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/convissor">Daniel Convissor</a>, <a href="http://profiles.wordpress.org/dartiss">dartiss</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/csixty4">Dave Ross</a>, <a href="http://profiles.wordpress.org/davidjlaietta">David Laietta</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/dllh">dllh</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling (ocean90)</a>, <a href="http://profiles.wordpress.org/dpash">dpash</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/dzver">dzver</a>, <a href="http://profiles.wordpress.org/cais">Edward Caissie</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faishal">faishal</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/foofy">Foofy</a>, <a href="http://profiles.wordpress.org/fjarrett">Frankie Jarrett</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/gayadesign">Gaya Kessler</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gizburdt">Gizburdt</a>, <a href="http://profiles.wordpress.org/goldenapples">goldenapples</a>, <a href="http://profiles.wordpress.org/gradyetc">gradyetc</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/webord">Gustavo Bordoni</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/creativeinfusion">itinerant</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jakubtyrcha">jakub.tyrcha</a>, <a href="http://profiles.wordpress.org/jamescollins">James Collins</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="http://profiles.wordpress.org/johnnyb">John Beales</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn (johnbillion)</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/jchristopher">Jonathan Christopher</a>, <a href="http://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jonlynch">Jon Lynch</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/josephscott">Joseph Scott</a>, <a href="http://profiles.wordpress.org/betzster">Josh Betz</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/ketwaroo">Ketwaroo</a>, <a href="http://profiles.wordpress.org/kevinb">kevinB</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/koopersmith">koopersmith</a>, <a href="http://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis (leewillis77)</a>, <a href="http://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="http://profiles.wordpress.org/layotte">Lew Ayotte</a>, <a href="http://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="http://profiles.wordpress.org/iworks">Marcin Pietrzak</a>, <a href="http://profiles.wordpress.org/cimmo">Marco Cimmino</a>, <a href="http://profiles.wordpress.org/marco_teethgrinder">Marco Galasso</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/naomicbush">Naomi</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/natejacobs">NateJacobs</a>, <a href="http://profiles.wordpress.org/nathanrice">nathanrice</a>, <a href="http://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nickmomrik">Nick Momrik</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/noahsilverstein">noahsilverstein</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nukaga">nukaga</a>, <a href="http://profiles.wordpress.org/nullvariable">nullvariable</a>, <a href="http://profiles.wordpress.org/butuzov">Oleg Butuzov</a>, <a href="http://profiles.wordpress.org/paolal">Paolo Belcastro</a>, <a href="http://profiles.wordpress.org/xparham">Parham</a>, <a href="http://profiles.wordpress.org/pbiron">Paul Biron</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/peterjaap">peterjaap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/plocha">plocha</a>, <a href="http://profiles.wordpress.org/pollett">Pollett</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="http://profiles.wordpress.org/rasheed">Rasheed Bydousi</a>, <a href="http://profiles.wordpress.org/raybernard">RayBernard</a>, <a href="http://profiles.wordpress.org/rboren">rboren</a>, <a href="http://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="http://profiles.wordpress.org/rfair404">rfair404</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/r3df">Rick Radko</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/wpmuguru">Ron Rennick</a>, <a href="http://profiles.wordpress.org/rpattillo">rpattillo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/hotchkissconsulting">Sam Hotchkiss</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/scottsweb">scottsweb</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/scruffian">scruffian</a>, <a href="http://profiles.wordpress.org/tenpura">Seisuke Kuraishi (tenpura)</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sillybean">Stephanie Leary</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar (@netweb)</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/strangerstudios">strangerstudios</a>, <a href="http://profiles.wordpress.org/sweetie089">sweetie089</a>, <a href="http://profiles.wordpress.org/swissspidy">swissspidy</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tivnet">tivnet</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/toscho">toscho</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/sorich87">Ulrich Sossou</a>, <a href="http://profiles.wordpress.org/vericgar">vericgar</a>, <a href="http://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wikicms">wikicms</a>, <a href="http://profiles.wordpress.org/willnorris">Will Norris</a>, <a href="http://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="http://profiles.wordpress.org/wycks">wycks</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p>Enjoy what may be one of your last few manual updates. See you soon for version 3.8!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/10/basie/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.7 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 00:05:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2729";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:417:"The second release candidate of WordPress 3.7 is now available for testing! Those of you already testing WordPress 3.7 will be updated automatically to RC2. (Nice.) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”) or download the release candidate here (zip). Please post to the Alpha/Beta [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1183:"<p>The second release candidate of WordPress 3.7 is now available for testing!</p>
<p>Those of you already testing WordPress 3.7 will be updated automatically to RC2. (<em>Nice.</em>) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”) or <a href="http://wordpress.org/wordpress-3.7-RC2.zip">download the release candidate here</a> (zip). Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a> if you think you&#8217;ve found a bug, and if any known issues are raised, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>Developers, please test your plugins and themes against WordPress 3.7. If there is a compatibility issue, let us know as soon as possible so we can deal with it before the final release.</p>
<p>For more on WordPress 3.7, check out the <a href="http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/">announcement post for Release Candidate 1</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 20 Mar 2014 15:22:44 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 20 Mar 2014 05:01:25 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('1206', '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1395372164', 'no'); 
INSERT INTO `wp_options` VALUES ('1207', '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1395328964', 'no'); 
INSERT INTO `wp_options` VALUES ('1208', '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1395372166', 'no'); 
INSERT INTO `wp_options` VALUES ('1209', '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: CreativeMarket Acquired By The Makers Of AutoCAD";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19380";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:160:"http://wptavern.com/creativemarket-acquired-by-the-makers-of-autocad?utm_source=rss&utm_medium=rss&utm_campaign=creativemarket-acquired-by-the-makers-of-autocad";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2482:"<p><a href="http://wptavern.com/wp-content/uploads/2014/03/CreativeMarketlogo.png" rel="prettyphoto[19380]"><img class="alignright size-full wp-image-19381" alt="CreativeMarket Logo" src="http://wptavern.com/wp-content/uploads/2014/03/CreativeMarketlogo.png" width="159" height="97" /></a>CreativeMarket, one of the first WordPress theme marketplaces to fully support the GPL license <a title="https://creativemarket.com/blog/2014/03/19/building-the-worlds-marketplace-for-design" href="https://creativemarket.com/blog/2014/03/19/building-the-worlds-marketplace-for-design">has been acquired</a> by <a title="http://www.autodesk.com/" href="http://www.autodesk.com/">Autodesk</a>, for an undisclosed amount. The marketplace sells everything from themes to templates to fonts. The site became one of the first marketplaces to be advertised on WordPress.org after <a title="https://creativemarket.com/blog/2013/02/19/all-wordpress-themes-now-100-gpl" href="https://creativemarket.com/blog/2013/02/19/all-wordpress-themes-now-100-gpl">they announced</a> they would only sell WordPress themes that are 100% GPL. It&#8217;s worth noting that Matt Mullenweg <a title="https://angel.co/creative-market" href="https://angel.co/creative-market">is an investor</a> of  CreativeMarket.</p>
<p>According to the announcement, the entire team will join <a title="http://www.autodesk.com/" href="http://www.autodesk.com/">Autodesk</a> with the company&#8217;s co-founders moving to San Francisco to continue their goal of selling creative products.</p>
<blockquote><p>What does this mean for the community? For customers, it means access to even more high quality content at affordable prices, as we’re able to grow more quickly. For shop owners, it means we’ll have a larger platform to get your products in front of an even larger audience of customers.</p></blockquote>
<p>The acquisition is just one of a few that&#8217;s happened within the WordPress community as of late. The most recent acquisition was <a title="http://crowdfavorite.com/blog/2014/01/welcome-pixel-jar/" href="http://crowdfavorite.com/blog/2014/01/welcome-pixel-jar/">Crowd Favorite acquiring Pixel Jar</a>. Does this mean we&#8217;ll start seeing modeling products and three-dimensional themes for sale on CreativeMarket or will the marketplace expand to include more categories of products? Only time will tell.</p>
<p>What do you think of the acquisition? Does it make sense to you? Let us know in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 10:51:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: WordPress Plugin Repository Now Hosts Over 30,000 Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19384";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:176:"http://wptavern.com/wordpress-plugin-repository-now-hosts-over-30000-plugins?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-plugin-repository-now-hosts-over-30000-plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1388:"<p>Early this morning, the <a title="http://wordpress.org/plugins/" href="http://wordpress.org/plugins/">WordPress.org plugin repository</a> set a mile stone by hosting the 30,000th plugin. I didn&#8217;t think it would happen until a few weeks from now but it shows you how many plugins are approved and added to the repository every day.  Jan Reimers on Twitter celebrated with a whoop! I second that remark.</p>
<blockquote class="twitter-tweet" width="550"><p>30.000 Plugins on <a href="https://t.co/xg9XCQo6am">https://t.co/xg9XCQo6am</a> whoop! <a href="http://t.co/IAAFgp2SpG">pic.twitter.com/IAAFgp2SpG</a></p>
<p>&mdash; jan reimers (@reimersjan) <a href="https://twitter.com/reimersjan/statuses/446571430516248576">March 20, 2014</a></p></blockquote>
<p></p>
<p>The honors go to a plugin called <a title="http://wordpress.org/plugins/bws-google-maps/" href="http://wordpress.org/plugins/bws-google-maps/">BestWebSoft Google Maps</a> for being the 30,000th plugin to be added to the repository. According to the plugin&#8217;s description, it allows you to configure Google Maps and add them to your site quickly and easily.</p>
<p>Congratulations to the WordPress plugin repository and especially to the WordPress community for continuing to share your problem solving plugins with the rest of the world.</p>
<p>Any guesses on when the repository will cross 40,000 plugins?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 10:36:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Dev Blog: WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1884:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&stop_rev=27500&limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&group=component&milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"Dougal Campbell: Pantheon Platform Adds WordPress Support";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"http://dougal.gunters.org/?p=76811";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://dougal.gunters.org/blog/2014/03/19/pantheon-platform-adds-wordpress-support/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2755:"<div class="featured-image align-right"><img width="240" height="240" src="http://dougal.gunters.org/wordpress/wp-content/uploads/2014/03/pantheon_logo-240x240.png" class="attachment-post-thumbnail wp-post-image" alt="Pantheon Logo" /></div><p><a href="https://www.getpantheon.com/">Pantheon</a>, long known as a platform provider for Drupal hosting, has now added <a href="http://techcrunch.com/2014/03/19/website-platform-pantheon-launches-wordpress-support/">official support for WordPress</a>, as well. Pantheon provides a scalable web platform with devops-friendly dashboards and tools for deployment and management.</p>
<blockquote><p>The first and most obvious thing we did was ensure the platform was WordPress-friendly. This is the only piece of work that wasn’t on our roadmap already, but luckily it wasn’t very hard. The requirements for running Drupal vs. WordPress are quite similar.</p>
<p>The upside is that WordPress developers can expect tuned and friendly configurations for php, nginx, Varnish, mysql and Redis, with a stock set of Plugins to make the most of everything the platform has to offer.</p>
<p><a href="https://www.getpantheon.com/blog/wordpress-developers-rejoice-pantheon-has-your-back">WordPress Developers Rejoice! Pantheon Has Your Back</a></p>
</blockquote>
<p>Interestingly, Pantheon already had a CLI (Command-Line Interface) tool called Terminus for managing services, which they originally implemented as a drush extension (drush is the &#8220;drupal shell&#8221;, a CLI for Drupal). In modifying their platform for WordPress support, they rewrote it as a stand-alone tool, borrowing a lot of ideas from wp-cli in the process.</p>
<blockquote><p>We actually borrowed quite a lot from the wp-cli toolkit in this refactor. Our library code was largely portable from Drush, but we took their object structure and docstring-parsing magic, which is pretty strong stuff. As a result, we have a more robust CLI tool to build off in the future.</p></blockquote>
<p>If you&#8217;re interested, <a href="https://www.getpantheon.com/pricing">they offer a free account</a> to let you check things out (no custom domain on the free level). Paid offerings begin at just $25/month.</p>
<p>(I have no affiliation with Pantheon, if anyone is wondering)</p>
<p>Original Article: <a rel="nofollow" href="http://dougal.gunters.org/blog/2014/03/19/pantheon-platform-adds-wordpress-support/">Pantheon Platform Adds WordPress Support</a><br />
<a rel="nofollow" href="http://dougal.gunters.org">Dougal Campbell&#039;s geek ramblings - WordPress, web development, and world domination.</a></p>
<div class="yarpp-related-rss yarpp-related-none">
<img src="http://yarpp.org/pixels/5db43ee24c4f1e1d0e45d08cc91b0130" alt="YARPP" />
</div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 02:43:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Dougal Campbell";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"Alex King: I’m live now on the DradCast – tune in!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=19686";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://alexking.org/blog/2014/03/19/19686";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:106:"<div>
<p>I&#8217;m live now on the <a href="http://dradcast.com/">DradCast</a> &#8211; tune in!</p>
</div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 00:00:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: WordPress.com Formally Opens Its Marketplace to Theme Developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19204";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:192:"http://wptavern.com/wordpress-com-formally-opens-its-marketplace-to-theme-developers?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-com-formally-opens-its-marketplace-to-theme-developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:12554:"<p>In 2011, <a title="http://en.blog.wordpress.com/2011/02/03/introducing-premium-themes/" href="http://en.blog.wordpress.com/2011/02/03/introducing-premium-themes/">WordPress.com </a>began offering commercial themes to its users. The service now has <strong>105 commercial themes</strong> to choose from. In order to sell themes on WordPress.com, you either had to be invited or reach out to Automattic. Those days are over now that they have <a title="http://theme.wordpress.com/join/" href="http://theme.wordpress.com/join/">launched a new landing page</a> for theme sellers interested in tapping into the WordPress.com market.</p>
<p>WordPress.com is a huge market and considering there are less than <strong>300 themes in total to choose from</strong>, now seems like the perfect time to get involved. It&#8217;s hard to say how much income commercial theme sellers have made selling on WordPress.com since the sales figures are not publicly available.</p>
<div id="attachment_19316" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/WPdotComPremiumThemes.png" rel="prettyphoto[19204]"><img class="size-large wp-image-19316" alt="105 Premium Themes Available On WordPress.com" src="http://wptavern.com/wp-content/uploads/2014/03/WPdotComPremiumThemes-500x416.png" width="500" height="416" /></a><p class="wp-caption-text">105 Premium Themes Available On WordPress.com</p></div>
<p>I reached out to two companies selling themes on WordPress.com to see how well they&#8217;re doing and what advice they have for those looking to join the WordPress.com marketplace.</p>
<h3>UpThemes Experiences Exponential Growth</h3>
<p>Since UpThemes relaunched, <a title="https://upthemes.com/themes/" href="https://upthemes.com/themes/">three of their four themes</a> available are sold on WordPress.com. Chris Wallace, founder of UpThemes told me WordPress.com is its largest source of income. The company has experience exponential growth since launching its latest theme, <a title="http://theme.wordpress.com/themes/photolia/" href="http://theme.wordpress.com/themes/photolia/">Photolia,</a> in December of last year.</p>
<div id="attachment_19308" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/PhotoliaByUpThemes.png" rel="prettyphoto[19204]"><img class="size-large wp-image-19308" alt="Photolia By UpThemes" src="http://wptavern.com/wp-content/uploads/2014/03/PhotoliaByUpThemes-500x319.png" width="500" height="319" /></a><p class="wp-caption-text">Photolia By UpThemes</p></div>
<p>When UpThemes <a title="http://wptavern.com/upthemes-publishes-open-letter-sounds-wakeup-call-to-other-wordpress-theme-shops" href="http://wptavern.com/upthemes-publishes-open-letter-sounds-wakeup-call-to-other-wordpress-theme-shops">published its open letter</a> to the community back in February, one thing was clear. The company would no longer create themes filled with options, shortcodes, and sliders. The open letter was the company&#8217;s renewed commitment to keeping things simple. As it turns out, their new focus on simplicity is aligned with how themes are created on WordPress.com.</p>
<blockquote><p>When we relaunched UpThemes, one of the main goals was to make it extremely easy to get up and running with our themes. WordPress.com lines up perfectly with that strategy. It allows us to sell, distribute, and update our themes very easily, ensuring that all customers are running the current version of each theme and have not made destructive changes that would render future updates unusable. This is the absolute best scenario for both our customers and our team.</p></blockquote>
<div id="attachment_19328" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/YumblogOnWPdotComByUpthemes.png" rel="prettyphoto[19204]"><img class="size-full wp-image-19328" alt="Yumblog On WordPress.com By UpThemes" src="http://wptavern.com/wp-content/uploads/2014/03/YumblogOnWPdotComByUpthemes.png" width="587" height="440" /></a><p class="wp-caption-text">Yumblog On WordPress.com By UpThemes</p></div>
<p>I asked Wallace what advice does he have for theme authors wanting to sell themes on WordPress.com. He said, &#8220;You should bring your best design skills because these premium themes can’t be overblown with shortcodes, widgets, custom post types, and option frameworks.&#8221;</p>
<p>Themes on WordPress.com don&#8217;t have the luxury of having a million options and according to Wallace, customers don&#8217;t want those types of themes, &#8220;Bloggers don’t care about options, they care about getting noticed and making an impact. They don’t need 40 alternate homepage templates, they need a theme that makes a bold statement and works flawlessly&#8221;.</p>
<p>Wallace is excited to see the marketplace open up and wants to see more theme authors join in. &#8220;I look forward to seeing more theme authors jump on board with WordPress.com because it would validate our thought that simplicity is the correct path for themes in 2014&#8243;.</p>
<h3>MH Themes Has A Positive Impact On Sales</h3>
<p>Michael Hebenstreit is the founder of <a title="http://www.mhthemes.com/" href="http://www.mhthemes.com/">MHThemes.com,</a> a company with the goal of creating magazine type themes which are suitable for News Websites, Online Magazines and other editorial Projects. MH Themes only sells one theme on WordPress.com called <a title="http://theme.wordpress.com/themes/mh-magazine/" href="http://theme.wordpress.com/themes/mh-magazine/">MH Magazine</a> but Hebenstreit told me it&#8217;s done very well for the company.</p>
<div id="attachment_19311" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/MHMagazineTheme.png" rel="prettyphoto[19204]"><img class="size-large wp-image-19311" alt="MH Magazine by MH Themes" src="http://wptavern.com/wp-content/uploads/2014/03/MHMagazineTheme-500x313.png" width="500" height="313" /></a><p class="wp-caption-text">MH Magazine by MH Themes</p></div>
<p>He said, &#8220;Selling on WordPress.com has had a positive impact on theme sales&#8221;. Since WordPress.com only has 250 themes available with 105 being commercial, it&#8217;s more likely users will notice a commercial theme. When asked how difficult it was to join, Hebenstreit replied, &#8220;The team behind <a href="http://WordPress.com">WordPress.com</a> is amazing, provide great support and do their best to help you launch your theme on <a href="http://WordPress.com">WordPress.com</a>.&#8221;<br />
Hebenstreit offers this advice to new sellers:</p>
<blockquote><p>My advice to potential theme sellers on <a href="http://WordPress.com">WordPress.com</a> is to provide something unique which isn’t available yet. Due to the fact that there currently are not many themes available, unique items are still possible and will sell better.</p></blockquote>
<h3>It&#8217;s Not As Hard As You Think To Sell Themes On WordPress.com</h3>
<p>Sami Keijonen who runs <a title="https://foxnet-themes.fi/" href="https://foxnet-themes.fi/">FoxnetThemes.com</a> recently <a title="https://foxnet-themes.fi/2014/03/13/becoming-a-theme-author-in-wordpress-com/" href="https://foxnet-themes.fi/2014/03/13/becoming-a-theme-author-in-wordpress-com/">published his story</a> describing what it was like to go through the process of becoming a theme seller on WordPress.com. There are a lot of interesting tidbits from his story such as what&#8217;s not allowed:</p>
<ul>
<li>CSS Frameworks</li>
<li>Theme Frameworks</li>
<li>Shortcodes</li>
<li>Widgets</li>
<li>Custom post types</li>
<li>Metaboxes</li>
</ul>
<p>He also includes some educational information on how to properly escape strings, remove defaults, and using the theme customizer. While I initially thought it would be difficult to sell a theme on WordPress.com, Keijonen&#8217;s experience proves it&#8217;s not as hard as I thought.</p>
<h3>Advice From An Automattic Theme Wrangler</h3>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/NickHamze">@NickHamze</a> <a href="https://twitter.com/MacManXcom">@MacManXcom</a> so, this happened. <a href="http://t.co/DJ0uEuWrpZ">pic.twitter.com/DJ0uEuWrpZ</a></p>
<p>&mdash; Karen Arnold (@karenalma) <a href="https://twitter.com/karenalma/statuses/444545838757339136">March 14, 2014</a></p></blockquote>
<p></p>
<p>I asked Automattic Theme Wrangler, Ian Stewart, what advice would he tell sellers before submitting an application. He said &#8220;We&#8217;re looking for amazingly beautiful themes inside and out. My advice on getting there is to start with <a title="http://underscores.me/" href="http://underscores.me/">_s</a> and make it easy for WordPress users to understand your theme.&#8221;</p>
<div id="attachment_19360" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/UnderscoresHeader.png" rel="prettyphoto[19204]"><img class="size-full wp-image-19360" alt="A Starter Theme Created by Automattic" src="http://wptavern.com/wp-content/uploads/2014/03/UnderscoresHeader.png" width="650" height="200" /></a><p class="wp-caption-text">A Starter Theme Created by Automattic</p></div>
<p>_s is short for <a title="http://underscores.me/" href="http://underscores.me/">Underscores</a>, a WordPress starter theme created by Automattic that is the foundation of every theme built on WordPress.com. While basing your theme on Underscores may raise the odds of being selected to be part of the WordPress.com marketplace, it&#8217;s not a requirement.</p>
<h3>Open Registration Will Hasten The Trend Of Simplifying Themes</h3>
<p>During the past few months, <a title="http://wptavern.com/justin-tadlock-publishes-the-results-of-his-themeforest-experiment" href="http://wptavern.com/justin-tadlock-publishes-the-results-of-his-themeforest-experiment">we&#8217;ve written about</a> the trend of WordPress theme authors creating simpler themes without <a title="http://wptavern.com/wordpress-theme-shops-move-towards-preserving-data-portability" href="http://wptavern.com/wordpress-theme-shops-move-towards-preserving-data-portability">locking users in</a> through the use of shortcodes, custom post types, etc. These are the types of themes perfectly suited to be sold on WordPress.com. Opening registration will hasten the trend of which the entire WordPress community will benefit.</p>
<h3>ThemeForest and WordPress.com Have A Potential Customer Base That Is Unmatched</h3>
<p>One of the biggest reasons theme authors use ThemeForest is the size of its audience. Until now, it was the place to go to sell themes to the widest possible audience. Since WordPress.com <a title="http://en.wordpress.com/stats/" href="http://en.wordpress.com/stats/">hosts over 76 million websites</a>,  that&#8217;s 76 million potential customers all in one place. However, nothing stops sellers from utilizing both marketplaces as WordPress.com requires no exclusivity to sell on its platform.</p>
<p>ThemeForest and WordPress.com give sellers the chance to have their products in front of millions of people. This is an audience that even the most popular commercial theme companies can&#8217;t match. In fact, companies like <a title="http://theme.wordpress.com/themes/by/studiopress/" href="http://theme.wordpress.com/themes/by/studiopress/">StudioPress</a>, <a title="http://theme.wordpress.com/themes/by/the-theme-foundry/" href="http://theme.wordpress.com/themes/by/the-theme-foundry/">The Theme Foundry</a>, and <a title="http://theme.wordpress.com/themes/by/woothemes/" href="http://theme.wordpress.com/themes/by/woothemes/">WooThemes</a> are already benefiting from being listed on WordPress.com.</p>
<p>I encourage you to <a title="http://theme.wordpress.com/join/" href="http://theme.wordpress.com/join/">submit your request</a> to WordPress.com. There are few opportunities to sell WordPress themes to a relevant audience of millions without having a huge marketing campaign. Currently, commercial theme authors would be competing against less than 300 themes. Since sellers can determine the price and keep 50% of the sale, not doing so seems like it wouldn&#8217;t make much sense.</p>
<p>If selling themes is not your cup of tea, consider <a title="http://automattic.com/work-with-us/" href="http://automattic.com/work-with-us/">putting in a job application</a> to be a <a title="http://automattic.com/work-with-us/theme-wrangler/" href="http://automattic.com/work-with-us/theme-wrangler/">theme wrangler</a> for Automattic. They&#8217;re hiring.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Mar 2014 23:36:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WPTavern: JustWrite: A Free WordPress Magazine Theme With a Bold Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19312";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:184:"http://wptavern.com/justwrite-a-free-wordpress-magazine-theme-with-a-bold-design?utm_source=rss&utm_medium=rss&utm_campaign=justwrite-a-free-wordpress-magazine-theme-with-a-bold-design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3766:"<p>Most of the free WordPress themes out there are geared toward single-author blogs. It&#8217;s rare to find a decent option for magazines, because these types of themes take a little more effort to design and build, given the massive amount of content typically included on the homepage.</p>
<p><a href="http://wordpress.org/themes/justwrite" target="_blank">JustWrite</a> is a new magazine theme on WordPress.org that presents posts in an elegant way. Designed by Alexandru Cosmin, JustWrite nicely displays featured posts, categories and widgets without making your eyes bleed. Many publications are afflicted with a claustrophobia-inducing layout that causes readers to abandon the page after it loads. The JustWrite theme, however, achieves that coveted balance between space and content.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/justwrite.png" rel="prettyphoto[19312]"><img src="http://wptavern.com/wp-content/uploads/2014/03/justwrite.png" alt="justwrite" width="880" height="660" class="aligncenter size-full wp-image-19351" /></a></p>
<h3>Customizing JustWrite</h3>
<p>This theme packs an impressive number of options into WordPress&#8217; native customizer, including the following:</p>
<ul>
<li><strong>Custom Header</strong> &#8211; Specify logo image/font color, background image/color, and header border color</li>
<li><strong>Top Menu</strong> &#8211; Enable/disable fixed positioning, customize border and background colors</li>
<li><strong>Top Menu Colors</strong> &#8211; Specify link and hover colors</li>
<li><strong>Global</strong> &#8211; Customize global background, border, link and font colors</li>
<li><strong>Typography</strong> &#8211; Select from four font families</li>
<li><strong>Mini Sidebar Configuration</strong> &#8211; Set featured menus</li>
<li><strong>Site Text</strong> &#8211; Customize footer, site title, tagline text</li>
</ul>
<p>With a few changes in the customizer, you can easily alter the theme to have a dark design, if you choose:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/justwrite-dark.jpg" rel="prettyphoto[19312]"><img src="http://wptavern.com/wp-content/uploads/2014/03/justwrite-dark.jpg" alt="justwrite-dark" width="1280" height="1121" class="aligncenter size-full wp-image-19362" /></a></p>
<p>In addition to all the options built into the customizer, JustWrite has its own options page for configuring the slider, adding a favicon, adding social buttons, setting up advertising and enabling the author box.</p>
<p>One particularly awesome thing about the <a href="http://demo.acosmin.com/?theme=acosminblogger" target="_blank">JustWrite demo</a> is that it contains a live example for virtually every permutation of the options, i.e. examples with mini-sidebar disabled, <a href="http://demo.acosmin.com/themes/acosminblogger/header-background-img/" target="_blank">header background image enabled</a>, <a href="http://demo.acosmin.com/themes/acosminblogger/index-example/" target="_blank">dark colors</a>, all available font styles, <a href="http://demo.acosmin.com/themes/acosminblogger/fixed-menu/" target="_blank">fixed menu disabled</a>, etc.</p>
<p>JustWrite includes support for Font Awesome icons, multiple sidebars and page templates, as well as a host of widgets tailored for magazines: featured, popular and recent posts, latest tweets, and advertising. Check out the theme&#8217;s <a href="http://www.acosmin.com/theme/justwrite/" target="_blank">homepage</a> for more information and a <a href="http://demo.acosmin.com/?theme=acosminblogger" target="_blank">live demo</a>. You can <a href="http://wordpress.org/themes/justwrite" target="_blank">download JustWrite</a> for free from WordPress.org via your site&#8217;s theme administration page.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Mar 2014 22:50:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WordPress.tv: Dre Armeda and Tony Perez: Real WordPress Security – Kill The Noise!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33242";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:96:"http://wordpress.tv/2014/03/19/dre-armeda-and-tony-perez-real-wordpress-security-kill-the-noise/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:716:"<div id="v-8EzN5ZBC-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33242/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33242/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33242&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/19/dre-armeda-and-tony-perez-real-wordpress-security-kill-the-noise/"><img alt="Dre Armeda and Tony Perez: Real WordPress Security &#8211; Kill The Noise!" src="http://videos.videopress.com/8EzN5ZBC/video-f5ede10501_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Mar 2014 19:56:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:99:"WordPress.tv: Mika Epstein: Managing Your Site’s Community: Don’t Make Commenting A Crime Scene";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33246";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:109:"http://wordpress.tv/2014/03/19/mika-epstein-managing-your-sites-community-dont-make-commenting-a-crime-scene/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:740:"<div id="v-op0CE6UT-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33246/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33246/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33246&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/19/mika-epstein-managing-your-sites-community-dont-make-commenting-a-crime-scene/"><img alt="Mika Epstein: Managing Your Site’s Community: Don’t Make Commenting A Crime Scene" src="http://videos.videopress.com/op0CE6UT/video-db202b87d0_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Mar 2014 19:11:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Matt: FiveThirtyEight and Facebook";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43664";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://ma.tt/2014/03/538-fb/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:429:"<p>Two cool new WordPresses launched on <a href="http://vip.wordpress.com/">VIP</a>: Nate Silver&#8217;s new FiveThirtyEight site, and <a href="http://newsroom.fb.com/">the Facebook Newsroom</a>, which I believe is the first WP-powered Facebook site. (Hopefully the first of many!) Also congrats to <a href="http://10up.com/">10up</a> and <a href="http://bynd.com/">Beyond</a> respectively for working on each of these sites.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Mar 2014 18:59:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: Spotlight On GavickPro: Unique BuddyPress Themes With Support For Third-Party Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19273";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:232:"http://wptavern.com/spotlight-on-gavickpro-unique-buddypress-themes-with-support-for-third-party-plugins?utm_source=rss&utm_medium=rss&utm_campaign=spotlight-on-gavickpro-unique-buddypress-themes-with-support-for-third-party-plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7117:"<p>BuddyPress themes are still few and far between, despite the popularity of the social networking plugin for WordPress. After <a href="http://codex.buddypress.org/themes/theme-compatibility-1-7/a-quick-look-at-1-7-theme-compatibility/" target="_blank">theme compatibility</a> was introduced, effectively making BuddyPress able to work with nearly any WordPress theme, the market slowed its production of new products tailored specifically for BuddyPress.</p>
<p>When you see a theme that highlights BuddyPress features in a big way, it&#8217;s worth taking note. <a href="http://www.gavick.com/wordpress-themes/m-social,135.html" target="_blank">(M) Social</a> is one such theme from the folks at <a href="http://www.gavick.com/" target="_blank">GavickPro</a>. Although new to the WordPress theme space, the GavickPro team is well established in the Joomla community with more than seven years of design experience.</p>
<p>(M) Social puts the BuddyPress activity component in the spotlight with its grid style image header. It creates a seamless mix of content from both the blog and the community. Check out the <a href="http://www.gavick.com/demo/wordpress/msocial/" target="_blank">live demo</a>.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/msocial.jpg" rel="prettyphoto[19273]"><img src="http://wptavern.com/wp-content/uploads/2014/03/msocial.jpg" alt="msocial" width="1327" height="620" class="aligncenter size-full wp-image-19275" /></a></p>
<p>Because the grid widget makes up the majority of the homepage with its large, responsive, tile-based design, reading and navigating the site is easy for users on tablets and other mobile devices. A design that works well on mobile keeps the community connected on the go.</p>
<h3>The Challenges of Supporting Third-Party Plugins in WordPress Themes</h3>
<p>With the help of the <a href="http://wordpress.org/plugins/buddypress-media/" target="_blank">rtMedia plugin</a>, (M) Social incorporates BuddyPress gallery content into the design. I spoke to GavickPro&#8217;s consumer support specialist, Lee Batten, about the choice to support rtMedia. The Joomla version of the (M) Social theme is built for <a href="http://www.jomsocial.com/" target="_blank">JomSocial</a> which has support for images and photo uploads. Batten said they wanted to make sure that their BuddyPress version included this feature.</p>
<blockquote><p>BuddyPress has no support for image galleries, yet galleries are an important part of social websites. We researched many similar plugins, and rtMedia seemed to be the simplest solution to achieve the effect required; it&#8217;s smoothly integrated with BuddyPress and allows users to upload media files from the front-end and sort them into albums, plus it has privacy controls and it&#8217;s responsive.</p></blockquote>
<p>Including rtMedia support gave the team the freedom to design with gallery images in mind. It also provided the opportunity for them to create an additional BP Latest Photos widget to display community images posted to the activity stream.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/latest-pictures-widget.jpg" rel="prettyphoto[19273]"><img src="http://wptavern.com/wp-content/uploads/2014/03/latest-pictures-widget.jpg" alt="latest-pictures-widget" width="716" height="348" class="aligncenter size-full wp-image-19285" /></a></p>
<p>GavickPro is a good example of the trend for companies building themes around third-party plugins. Batten said, <strong>&#8220;Our experience in theme development in general has taught us that support for popular third-party extensions is extremely important and can make a theme much more attractive to customers.&#8221;</strong></p>
<p>However, this approach isn&#8217;t without its unique challenges. For example, as it relates to the (M) Social theme, the team behind rtMedia release updates often. &#8220;On the one hand this is great for users, as these updates fix issues or add new features,&#8221; Batten said. &#8220;But often we must make some CSS changes to the theme after any updates to maintain the overall &#8216;feel&#8217;.&#8221;</p>
<p>Keeping themes updated to support new versions of third-party extensions is a normal part of GavickPro&#8217;s maintenance process, but it&#8217;s also the most challenging, as their customers also have to update their themes more often to keep pace with the plugins.</p>
<p>&#8220;Unfortunately, small plugins don&#8217;t usually have public beta or RC versions so there&#8217;s no way to ensure the theme is compatible with the update in advance,&#8221; Batten said. &#8220;Instead we must wait til after the update is released.&#8221; This is undoubtedly a struggle shared by many other WordPress theme shops that support smaller plugins with no public betas.</p>
<h3>Competing in Both the Joomla and WordPress Theme Markets</h3>
<p>The GavickPro team specializes in creating social themes, which is what attracted them to BuddyPress in the first place. Batten says that demand for social themes continues to grow. &#8220;According to our stats, our social themes are on the upper end of the scale with regards to popularity, alongside our e-commerce templates.&#8221; He believes that this category is on the rise. <strong>&#8220;Social interaction is now a cornerstone of most users&#8217; internet experience and the ability to share and discuss can really make the difference if you&#8217;re trying to build a community.&#8221;</strong></p>
<p>Despite the fact that the company originally started out as a Joomla-exclusive theme shop and are more well-known in that space, their WordPress theme sales are growing at a faster rate than the Joomla themes. &#8220;Last year WordPress accounted for only one-tenth of our total sales, but currently they account for one-third, which is quite a major jump!&#8221;</p>
<p>GavickPro started developing WordPress themes a year ago, after recognizing the opportunity, but it&#8217;s more of an uphill climb to get noticed in this space. <strong>&#8220;The WordPress market dwarfs Joomla&#8217;s, so it has been challenging to achieve a degree of market penetration,&#8221;</strong> Batten said. &#8220;There&#8217;s so much information and competition out there that even great designs can sadly go unnoticed, especially from unfamiliar developers.&#8221;</p>
<p>Even so, the team at GavickPro is off to an excellent start with its unique BuddyPress themes. The theme framework and all of the widgets are open source and free to download from the <a href="https://github.com/GavickPro" target="_blank">GavickPro Github account.</a> They&#8217;re working on adding the widgets to the WordPress Plugin Directory as well. Check out their growing collection of <a href="http://www.gavick.com/wordpress-themes.html" target="_blank">WordPress Themes</a>, which integrate with <a href="http://www.gavick.com/wordpress-themes/tagwp,BuddyPress.html" target="_blank">BuddyPress</a>, <a href="http://www.gavick.com/wordpress-themes/tagwp,WooCommerce.html" target="_blank">WooCommerce</a> and <a href="http://wpml.org/" target="_blank">WPML</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Mar 2014 17:47:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WordPress.tv: Russell Aaron: Your Theme Can Do That Too";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33240";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.tv/2014/03/19/russell-aaron-your-theme-can-do-that-too/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:659:"<div id="v-uIfjY0hy-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33240/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33240/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33240&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/19/russell-aaron-your-theme-can-do-that-too/"><img alt="Russell Aaron: Your Theme Can Do That Too" src="http://videos.videopress.com/uIfjY0hy/video-4ee45e532f_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 19 Mar 2014 10:49:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: WordPress.com Developer Site Gets a Fresh Look and Updated Documentation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19209";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:208:"http://wptavern.com/wordpress-com-developer-site-gets-a-fresh-look-and-updated-documentation?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-com-developer-site-gets-a-fresh-look-and-updated-documentation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5057:"<p>WordPress.com has relaunched its <a href="https://developer.wordpress.com/" target="_blank">Developer Site</a> with a new focus on making information easier to find for third-party developers. The site is now sporting a modernized design with a call to action that goes straight to the newly updated documentation, outlining how to get started creating apps for WordPress.com.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/wordpressdotcom-developer-site-redesigned.jpg" rel="prettyphoto[19209]"><img src="http://wptavern.com/wp-content/uploads/2014/03/wordpressdotcom-developer-site-redesigned.jpg" alt="wordpressdotcom-developer-site-redesigned" width="888" height="744" class="aligncenter size-full wp-image-19257" /></a></p>
<p>I spoke with Automattic employee <a href="https://twitter.com/jkudish">Joey Kudish</a> who said that there are actually <strong>27,000 apps</strong> currently registered on WordPress.com. &#8220;A large handful of those are test or development-only applications,&#8221; Kudish said, but that gives you an idea of how many developers are looking to integrate with WordPress.com. Many commonly-used applications have partnered with them to integrate data, including Facebook, Twitter, Google+, Pocket, Pinterest, IFFFT, Mixcloud, Soundcloud and others.</p>
<p>Developers who want to integrate with WordPress.com can do so via its <a href="https://developer.wordpress.com/docs/api/" target="_blank">REST API</a>, which provides endpoints for tapping into Publishing, Stats, Likes, Notifications, Insights, Reader and more. The docs include query parameters and an example query/response for each endpoint.</p>
<p>In addition to the updated REST API documentation, a few extra highlights from the docs include:</p>
<p><strong><a href="https://developer.wordpress.com/docs/oembed-provider-api/" target="_blank">oEmbed Provider API</a>:</strong><br />
The Developer Site has information about the <a href="https://developer.wordpress.com/docs/oembed-provider-api/" target="_blank">oEmbed Provider API</a>, which enables you to embed any post, page and attachment hosted on WordPress.com or via Jetpack.</p>
<p><strong><a href="https://developer.wordpress.com/docs/sharing-buttons/" target="_blank">Sharing Button Creation</a>:</strong><br />
Developers can find information on adding new buttons to WordPress.com&#8217;s <a href="http://en.support.wordpress.com/sharing/" target="_blank">Sharing</a> buttons. If you have a service that is not currently supported, there is a step-by-step guide for triggering the service creation process for a user.</p>
<p><strong><a href="https://developer.wordpress.com/docs/embedded-timelines/" target="_blank">Embedded Timelines</a>:</strong><br />
The site includes a dedicated page for helping users create <a href="https://developer.wordpress.com/timeline-creation/" target="_blank">embeddable timelines</a>. The timeline generator gives you a single line of code for displaying recent posts on any site. It works for both WordPress.com blogs and Jetpack blogs with the JSON API feature enabled.</p>
<p><strong><a href="https://developer.wordpress.com/themes/" target="_blank">Theme Guide</a>:</strong><br />
Theme developers who are interested in building for WordPress.com will be delighted to discover the newly-designed <a href="https://developer.wordpress.com/themes/" target="_blank">Theme Guide</a>, which includes information on escaping data, internationalization, queries, how to properly enqueue scripts and styles, data portability and everything else you need to know about developing a theme to meet WordPress.com standards.</p>
<h3>Automattic is Putting a Higher Priority on Developer Resources</h3>
<p>With the new <a href="https://twitter.com/AutomatticEng" target="_blank">@AutomatticEng</a> Twitter account and an updated developer site, Automattic is putting developer resources and communication on a higher priority. Kudish said that this is the result of new initiatives to help developers. &#8220;In November 2013 we formed a new team at Automattic under the leadership of Raanan Bar-Cohen,&#8221; he said. &#8220;This team is focused on third-party integrations with WordPress.com and Jetpack. Part of what we work on are these initiatives to promote our development resources and APIs.&#8221;</p>
<p>With WordPress now powering more than 21% of the web, it&#8217;s critical that developers have easy access to information on integrating with WordPress.com, which makes up a large chunk of that 21%. Much of the information on the new <a href="https://developer.wordpress.com" target="_blank">Developer Site</a> was already available in one form or another, but the documentation is now better designed and easier to navigate. In the future, the team plans to add forums to help developers find answers and interact with one another. For now, the best way to get in touch is via the <a href="https://developer.wordpress.com/contact/" target="_blank">contact form</a> or <a href="https://twitter.com/AutomatticEng" target="_blank">Twitter</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 23:24:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WordPress.tv: Chris Lema and Steve Zehngut: Pricing Your Next WordPress Project";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33285";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:96:"http://wordpress.tv/2014/03/18/chris-lema-and-steve-zehngut-pricing-your-next-wordpress-project/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:707:"<div id="v-4keUiZV1-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33285/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33285/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33285&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/18/chris-lema-and-steve-zehngut-pricing-your-next-wordpress-project/"><img alt="Chris Lema and Steve Zehngut: Pricing Your Next WordPress Project" src="http://videos.videopress.com/4keUiZV1/video-15042e947b_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 22:47:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: How To Bulk Install All Your Favorite WordPress Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19100";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:174:"http://wptavern.com/how-to-bulk-install-all-your-favorite-wordpress-plugins?utm_source=rss&utm_medium=rss&utm_campaign=how-to-bulk-install-all-your-favorite-wordpress-plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6830:"<div id="attachment_19216" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/bulk-install.jpg" rel="prettyphoto[19100]"><img src="http://wptavern.com/wp-content/uploads/2014/03/bulk-install.jpg" alt="photo credit: -pdp- - cc" width="974" height="524" class="size-full wp-image-19216" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/51553705@N00/8191743/">-pdp-</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a></p></div>
<p>Not every WordPress website is the same. But if you build with WordPress often enough, you might find that you prefer using the same set of plugins to provide basic functionality like contact forms, sharing buttons, SEO, caching, etc. It&#8217;s handy to have a set list of plugins that you can bulk-install whenever necessary.</p>
<p>A question posed by Angie Meeker on Twitter inspired me to dig deeper into the best options available for doing this:</p>
<blockquote class="twitter-tweet" width="550"><p>Can we tag a bunch of plugins in the repo through our own profiles, then install those tagged plugins all at once? as a collection?</p>
<p>&mdash; Angie Meeker (@angiemeeker) <a href="https://twitter.com/angiemeeker/statuses/445597703037124608">March 17, 2014</a></p></blockquote>
<p></p>
<h3>Favoriting Plugins on WordPress.org</h3>
<p>If you have an account with WordPress.org, you can aggregate all of your most-used plugins by favoriting each of them. This will give you access to them in the WordPress admin. Input your WordPress.org username and your favorites will appear below.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/wordpress-plugin-favorites.jpg" rel="prettyphoto[19100]"><img src="http://wptavern.com/wp-content/uploads/2014/03/wordpress-plugin-favorites.jpg" alt="wordpress-plugin-favorites" width="569" height="253" class="aligncenter size-full wp-image-19179" /></a></p>
<p>However, there are a couple of drawbacks here. First, you won&#8217;t be able to include any plugins that are not hosted on WordPress.org. Second, it&#8217;s not yet possible to bulk install your favorite plugins. You&#8217;ll need to install them one by one. This method of getting your favorites works well if you only have a handful of plugins that you routinely install from WordPress.org.</p>
<h3>Create an Installation Profile for WordPress</h3>
<p>The best way to create a collection of WordPress plugins that can be bulk-installed is to customize your own installation profile. While these aren&#8217;t terribly common in WordPress, the Drupal community has several well-maintained <a href="https://drupal.org/developing/distributions" target="_blank">installation profiles and distributions</a> that are tailored to provide site features and functions for a specific type of site as a single download.</p>
<h5>WP Install Profiles</h5>
<p>There are a couple of solutions that make it easy for you to create your own custom installation profiles. <a href="http://wordpress.org/plugins/install-profiles/" target="_blank">WP Install Profiles</a> is a plugin that enables you to define a group of plugins from WordPress.org and bulk install them to any site with a single click.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/wp-install-profile.jpg" rel="prettyphoto[19100]"><img src="http://wptavern.com/wp-content/uploads/2014/03/wp-install-profile.jpg" alt="wp-install-profile" width="700" height="428" class="aligncenter size-full wp-image-19183" /></a></p>
<p>Those who use the WP Install Profile plugin can also share their installation profiles by uploading them to the plugin&#8217;s <a href="http://plugins.ancillaryfactory.com/" target="_blank">homepage</a> where other users can copy them to use on their own sites. You are, however, limited to plugins hosted on WordPress.org.</p>
<h5>WP Roller</h5>
<p><a href="http://wproller.com/" target="_blank">WP Roller</a> is another option that Jeff Chandler <a href="http://wptavern.com/rolling-your-own-wordpress-with-wproller" target="_blank">wrote about</a> last year. This service allows for more flexibility in the extensions you include in your installation profile. It allows you to:</p>
<ul>
<li>Include WordPress core</li>
<li>Add plugins from WordPress.org and GitHub</li>
<li>Upload your own plugins and themes</li>
<li>Customize and save WordPress Installer Bundles</li>
</ul>
<p>Once you&#8217;ve made all your selections, the service lets you roll it up into one convenient download:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/wp-roller.jpg" rel="prettyphoto[19100]"><img src="http://wptavern.com/wp-content/uploads/2014/03/wp-roller.jpg" alt="wp-roller" width="607" height="323" class="aligncenter size-full wp-image-19192" /></a></p>
<p>A nightly cron job runs to make sure that you&#8217;ll have the latest versions of themes and plugins ready to go in your installation zip file.</p>
<p>One extra feature of WP Roller is that it allows you to quickly customize some common settings in your rollup:</p>
<ul>
<li>WordPress site title</li>
<li>WordPress site description</li>
<li>Remove the &#8220;Hello Dolly&#8221; plugin</li>
<li>Remove the &#8220;Hello Post&#8221;</li>
<li>Remove the &#8220;About Page&#8221;</li>
<li>Remove the &#8220;Sample Comment&#8221;</li>
<li>Set your timezone</li>
</ul>
<p>This saves you from having to click through to all of these places in the WordPress admin to put your settings in place.</p>
<h5>DesktopServer</h5>
<p><a href="http://serverpress.com/products/desktopserver/" target="_blank">DesktopServer</a> is a product from ServerPress that lets you easily create WordPress development environments. The commercial version of the product includes a &#8220;Blueprints&#8221; feature for automated WordPress configurations.</p>
<p>The blueprints you customize contain pre-configured WordPress themes, plugins and set-ups that you might use regularly so that you can instantly create a site to your specifications.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/blueprints.jpg" rel="prettyphoto[19100]"><img src="http://wptavern.com/wp-content/uploads/2014/03/blueprints.jpg" alt="blueprints" width="608" height="461" class="aligncenter size-full wp-image-19207" /></a></p>
<p>When setting up new sites with DesktopServer, you&#8217;ll have the option to select from among your blueprints in the dropdown, which will copy the contents of your blueprint to your development website. From there you can deploy it to a live site or continue working on it.</p>
<p>The solution you select will depend entirely on where your plugins are hosted and whether or not you want to include themes and common settings. Do you know of any other ways to bulk install a set list of WordPress plugins? Please share them in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 20:29:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Better WP Security To Be Renamed, Undergoes Major Changes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19152";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:176:"http://wptavern.com/better-wp-security-to-be-renamed-undergoes-major-changes?utm_source=rss&utm_medium=rss&utm_campaign=better-wp-security-to-be-renamed-undergoes-major-changes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3379:"<p>If you use the <a title="http://wordpress.org/plugins/better-wp-security/" href="http://wordpress.org/plugins/better-wp-security/">Better WP Security</a> plugin, keep an eye out for an <a title="http://ithemes.com/2014/03/17/better-wp-security-plugin-changing-ithemes-security-need-know/" href="http://ithemes.com/2014/03/17/better-wp-security-plugin-changing-ithemes-security-need-know/">important update next week</a>. According to iThemes, the plugin will be renamed to iThemes Security to be more in line with the other products in the iThemes family. Because of the name change, users will need to re-activate the plugin after upgrading or else you&#8217;ll see the following error.</p>
<div id="attachment_19186" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/iThemesSecurityRenameError.png" rel="prettyphoto[19152]"><img class="size-large wp-image-19186" alt="Just Re-activate The Plugin To Fix This Error" src="http://wptavern.com/wp-content/uploads/2014/03/iThemesSecurityRenameError-500x145.png" width="500" height="145" /></a><p class="wp-caption-text">Just Re-activate The Plugin To Fix This Error</p></div>
<p>Besides the name change, a number of features will be added such as:</p>
<ul>
<li>The ability to add multiple reporting email addresses for backups and notifications</li>
<li>Streamlined settings for easier configuration</li>
<li>Full integration with <a href="http://ithemes.com/purchase/backupbuddy">BackupBuddy</a></li>
<li>A complete rewrite of existing features for faster, better, more secure sites.</li>
</ul>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/BetterWPSecurityFeaturedImage.png" rel="prettyphoto[19152]"><img class="aligncenter size-large wp-image-19190" alt="Better WP Security Featured Image" src="http://wptavern.com/wp-content/uploads/2014/03/BetterWPSecurityFeaturedImage-500x159.png" width="500" height="159" /></a></p>
<p>Hired in 2013, Chris Wiegman has been in charge of completely revamping the plugin. Between the name change, features, and rewriting of code, Better WP Security will be a completely new plugin. The revamp is not limited to just code as iThemes Security will have professional support options available through iThemes.</p>
<blockquote><p>Support for iThemes Security will now come exclusively through iThemes. We will be releasing those plans and packages with the new release next week.</p></blockquote>
<p>Users will be happy to know the plugin will remain free of charge and available on the WordPress plugin repository. In the near future, iThemes plans on incorporating pro features to help monetize, fund development, and maintain the plugin. Cory Miller, CEO of iThemes said, &#8220;Current features will remain with no plans to discontinue them&#8221;. Last but not least, the free version will continue to be maintained as long as it&#8217;s useful to the WordPress community.</p>
<p>This is a huge transition and considering Better WP Security is among the most popular plugins on the repository with over 1.7 million downloads, it will be hard to get users on the same page prior to upgrading, despite being warned a week in advance. Hopefully, none of them will think they&#8217;ve been hacked and instead upgrade without any problems.</p>
<p>If you have questions or concerns about the changes, feel free to share them in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 19:27:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: Akismet Update Adds Security and Anti-Spam Improvements";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19166";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:174:"http://wptavern.com/akismet-update-adds-security-and-anti-spam-improvements?utm_source=rss&utm_medium=rss&utm_campaign=akismet-update-adds-security-and-anti-spam-improvements";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3429:"<p><a href="http://wptavern.com/wp-content/uploads/2011/11/akismetlogo.png" rel="prettyphoto[19166]"><img class="alignright size-full wp-image-5792" alt="akismet logo" src="http://wptavern.com/wp-content/uploads/2011/11/akismetlogo.png" width="187" height="43" /></a>Last week, we <a title="http://wptavern.com/how-to-prevent-wordpress-from-participating-in-pingback-denial-of-service-attacks" href="http://wptavern.com/how-to-prevent-wordpress-from-participating-in-pingback-denial-of-service-attacks">wrote about</a> a report published by Sucuri that explained how 162,000 clean WordPress sites were used in a DDoS attack through the pingback functionality of XML-RPC. Alex Shiels who works on Akismet mentioned on Twitter the security team was working on a solution.</p>
<p>An update to Akismet is <a title="http://blog.akismet.com/2014/03/18/akismet-plugin-2-6/" href="http://blog.akismet.com/2014/03/18/akismet-plugin-2-6/">now available</a> containing bug fixes, security, and anti-spam improvements. Notably:</p>
<ul>
<li>Include X-Pingback-Forwarded-For header in outbound WordPress pingback verifications.</li>
<li>Add a pre-check for pingbacks, to stop spam before an outbound verification request is made.</li>
</ul>
<p>According to Shiels, anti-spam checks were performed after a pingback was verified and WordPress didn&#8217;t pass on who made the request that caused it to verify a pingback effectively cloaking the true source. Shiels also stated the fixes applied to Akismet may find their way into the core of WordPress in a future update: &#8220;<em>We think a similar approach may be appropriate for core in a future release.</em>&#8221;</p>
<h3>How To Disable Pingbacks On Content Already Published</h3>
<p>While the security improvements in Akismet will have the widest impact, I still maintain that trackbacks and pingbacks have lost their luster. You can easily stop pingbacks in the <strong>Settings &#8211; Discussion</strong> area but to remove them from content already published involves using a MySQL query. Thankfully, there&#8217;s a plugin that bypasses the need to use the query called <a title="http://wordpress.org/plugins/autoclose/" href="http://wordpress.org/plugins/autoclose/">Auto-Close Comments, Pingbacks and Trackbacks</a> by <a title="http://profiles.wordpress.org/ajay/" href="http://profiles.wordpress.org/ajay/">Ajay</a>.</p>
<div id="attachment_19170" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/AutoCloseSettings.png" rel="prettyphoto[19166]"><img class="size-large wp-image-19170" alt="Auto Close Pingbacks/Trackbacks Settings Page" src="http://wptavern.com/wp-content/uploads/2014/03/AutoCloseSettings-500x177.png" width="500" height="177" /></a><p class="wp-caption-text">Auto Close Pingbacks/Trackbacks Settings Page</p></div>
<p>Auto-close gives users flexibility in determining which posts and pages ping/trackbacks will be disabled. There&#8217;s no option to disable them on every post or page. However, I was able to shut them off on most of my content by closing ping/trackbacks on posts older than one day. If you have a lot of content already published, you&#8217;ll want to use the built-in scheduler to avoid using too many resources on the server.</p>
<p>The plugin works as advertised and is the only one I could find that has the ability to turn trackback and pingbacks off in bulk without using a database query.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 18:16:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WordPress.tv: John Lynn: Can You Make Money Blogging?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33166";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.tv/2014/03/18/john-lynn-can-you-make-money-blogging/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:654:"<div id="v-gTtgGqKl-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33166/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33166/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33166&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/18/john-lynn-can-you-make-money-blogging/"><img alt="John Lynn: Can You Make Money Blogging?" src="http://videos.videopress.com/gTtgGqKl/video-329c8bc3ee_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 18:01:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WPTavern: Video Explains Open Source Using LEGO Blocks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19154";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:140:"http://wptavern.com/video-explains-open-source-using-legos?utm_source=rss&utm_medium=rss&utm_campaign=video-explains-open-source-using-legos";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1887:"<p>WordPress has benefited greatly from being Open Source software licensed under the GPL. But what does Open Source actually mean? The folks over at <a title="http://bitblueprint.com/" href="http://bitblueprint.com/">Bit Blueprint</a> in partnership with <a title="http://www.movingmonday.com" href="http://www.movingmonday.com">Moving Monday</a> released a video using LEGO bricks and toys to explain the subject.</p>
<div id="attachment_19162" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/OpenSourceLegosFeaturedImage.png" rel="prettyphoto[19154]"><img class="size-full wp-image-19162" alt="Open Source Explained By LEGO" src="http://wptavern.com/wp-content/uploads/2014/03/OpenSourceLegosFeaturedImage.png" width="639" height="217" /></a><p class="wp-caption-text">Open Source Explained By LEGOs</p></div>
<p>While the video is not 100% accurate since Free Software and Open Source are two different movements with different ideological motives, it does a great job of introducing people to the subject.</p>
<blockquote><p>We are aware of the fact that the Free Software and Open Source movements have both similarities and differences. Both in terms of individuals and ideological motives. We wanted to have our video tell a simple story for everyone to understand, so we included a character, Richard Stallman, as a symbol of the origin of the movements. History is rarely this simple &#8211; the complex (and historically correct) reality is of course that the founders of the movements are a lot of different individuals.</p></blockquote>
<p>The video also does a good job to dispel common myths associated with open source software such as:</p>
<ul>
<li>Not having any control over your work (False)</li>
<li>Open equals unsafe (False)</li>
<li>Everything is or must be free (False)</li>
</ul>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 16:31:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"Dougal Campbell: 13 Sources For Free Public Domain and CC0-Licensed Images";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"http://dougal.gunters.org/?p=76775";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"http://dougal.gunters.org/blog/2014/03/18/13-sources-for-free-public-domain-and-cc0-licensed-images/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:712:"<p><i>These sources of completely free-for-use images are better than I expected. /ht wptavern.com</i></p>
<p><a href="http://ift.tt/1oR8kvA">13 Sources For Free Public Domain and CC0-Licensed Images</a></p>
<p>Original Article: <a rel="nofollow" href="http://dougal.gunters.org/blog/2014/03/18/13-sources-for-free-public-domain-and-cc0-licensed-images/">13 Sources For Free Public Domain and CC0-Licensed Images</a><br />
<a rel="nofollow" href="http://dougal.gunters.org">Dougal Campbell&#039;s geek ramblings - WordPress, web development, and world domination.</a></p>
<div class="yarpp-related-rss yarpp-related-none">
<img src="http://yarpp.org/pixels/5db43ee24c4f1e1d0e45d08cc91b0130" alt="YARPP" />
</div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 14:42:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Dougal Campbell";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WordPress.tv: Patrick Rauland: How to Build a Sustainable Business Using the Freemium Model";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32877";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:108:"http://wordpress.tv/2014/03/18/patrick-rauland-how-to-build-a-sustainable-business-using-the-freemium-model/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:720:"<div id="v-CmL3J2re-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32877/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32877/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32877&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/18/patrick-rauland-how-to-build-a-sustainable-business-using-the-freemium-model/"><img alt="How to Build a Sustainable Business Using the Freemium Model" src="http://videos.videopress.com/CmL3J2re/video-805613cb32_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 08:38:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Akismet: Akismet WordPress plugin 2.6.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1253";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://blog.akismet.com/2014/03/18/akismet-plugin-2-6/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1724:"<p>The Akismet plugin version 2.6.0 for WordPress is now available.</p>
<p>It includes some incremental bugfixes since 2.5.9, plus some security and anti-spam improvements to how pingbacks work. <a href="http://wordpress.org/plugins/akismet/changelog/">Key changes</a> since the last release:</p>
<ul>
<li>Optimize javascript and add localization support.</li>
<li>Fix bug in link to spam comments from right now dashboard widget.</li>
<li>Fix bug with deleting old comments to avoid timeouts dealing with large volumes of comments.</li>
<li>Include X-Pingback-Forwarded-For header in outbound WordPress pingback verifications.</li>
<li>Add a pre-check for pingbacks, to stop spam before an outbound verification request is made.</li>
</ul>
<p>There was a news cycle a few days ago about &#8220;WordPress pingbacks being used to DDOS sites&#8221; which had a lot of misinformation and hyperbole, but there were two valid issues which the last two bullet points address: anti-spam checks were done after a pingback was verified, and WP didn&#8217;t pass on who made the request that caused it to verify a pingback (effectively cloaking the true source). This update to Akismet addresses both, and we think a similar approach may be appropriate for core in a future release.</p>
<p><span>To update, just visit the Updates tab of your WordPress dashboard.</span></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1253/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1253/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1253&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Mar 2014 02:50:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WPTavern: Guide To Starting And Maintaining A WordPress Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19057";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/guide-to-starting-and-maintaining-a-wordpress-meetup?utm_source=rss&utm_medium=rss&utm_campaign=guide-to-starting-and-maintaining-a-wordpress-meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8840:"<p>One of my favorites things to do every month is attend my <a title="http://www.meetup.com/NEOWordPress/" href="http://www.meetup.com/NEOWordPress/">local WordPress meetup</a>. I&#8217;ve helped put the meeting together since 2009. Usually, we&#8217;ll have 10-25 people show up depending on the weather or if the event is on a holiday. Meetups are like a smaller version of WordCamps where individuals present on specific topics each month. Now that we have a healthy nucleus of regular attendees, the meetups almost run themselves.</p>
<h3>Using Meetup.com To Start A Meetup</h3>
<div id="attachment_19139" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/UsingMeetup.png" rel="prettyphoto[19057]"><img class="size-large wp-image-19139" alt="A Lot Of Meetups Happening In My Area" src="http://wptavern.com/wp-content/uploads/2014/03/UsingMeetup-500x164.png" width="500" height="164" /></a><p class="wp-caption-text">A Lot Of Meetups Happening In My Area</p></div>
<p>I recently saw someone ask how they can start a WordPress meetup. They lived in a city with a population of 75,000 people and according to Meetup.com, a WordPress group didn&#8217;t exist in their area. Launched in 2002, <a title="http://www.meetup.com/" href="http://www.meetup.com/">Meetup.com</a> is the most popular website for getting people with like-minded ideas together. The site has meetups for any topic under the sun.</p>
<p>Meetup organizers need to pay organizer dues before the meetup can be established on the site. Meetup.com has three pricing plans available and each plan allows you to run up to three separate meetups.</p>
<ul>
<li>$12 a month for 6 months (a single $72 charge)</li>
<li>$15 a month for 3 months (a single $45 charge)</li>
<li>$19 per month</li>
</ul>
<p>The WordPress foundation has a <a title="http://make.wordpress.org/community/meetup-interest-form/" href="http://make.wordpress.org/community/meetup-interest-form/">program in place</a> that will pay membership dues so long as the group follows a few guidelines. In a nutshell:</p>
<ul>
<li>WordPress meetups are for the benefit of the local community and are not to be used primarily for business purposes.</li>
<li>The <a title="http://wordpressfoundation.org/trademark-policy/" href="http://wordpressfoundation.org/trademark-policy/">WordPress and WordCamp trademarks</a> should be respected.</li>
<li>The meetup should foster an accepting environment which is free of discrimination, incitement to violence, promotion of hate, and general jerk-like behavior.</li>
</ul>
<p>If you&#8217;re organizing a WordPress meetup solely for the purpose of meeting potential clients, you&#8217;re missing the point of what a community organized event is.</p>
<h3>Try Not To Start A Meetup Alone</h3>
<p>If possible, try to find one or two other people in your local area interested in having a WordPress meetup. In 2009, I asked on Twitter  if anyone in the North East Ohio area would be interested in attending a WordPress meetup. I discovered <a title="http://thecodecave.com/" href="http://thecodecave.com/">Brian Layman </a>who is a respected WordPress developer was just a short drive away from me as was <a title="http://kimparsell.com/" href="http://kimparsell.com/">Kim Parsell</a> and <a title="http://jefflee.co/" href="http://jefflee.co/">Jeff Lee</a>. I coordinated with them over Twitter and email to establish the core meetup group.</p>
<p>Once we had a small dedicated group of individuals attending the meetup, we used our collective social media presence to announce and recruit interested members to the meetup. Keep in mind Meetup.com will notify registered users in the area when a new meetup is created that matches their interests. Also consider using the <a title="http://wordpress.org/support/topic/about-the-meetups-forum" href="http://wordpress.org/support/topic/about-the-meetups-forum">WordPress.org Meetup Forum</a> to tell others about the meetup.</p>
<div id="attachment_19137" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/NEOWPMeetup1.jpeg" rel="prettyphoto[19057]"><img class="size-full wp-image-19137" alt="Brian Layman Sharing Knowledge" src="http://wptavern.com/wp-content/uploads/2014/03/NEOWPMeetup1.jpeg" width="600" height="450" /></a><p class="wp-caption-text">Brian Layman Sharing Knowledge</p></div>
<p>I was lucky to have two to three people help me kick-start our meetup. If you can&#8217;t find attendees on Twitter or Facebook, try attending meetups in your area that are similar to WordPress. For instance, meetups on web design, content management, SEO, etc. will likely have a few WordPress people in attendance.</p>
<h3>Finding A Venue</h3>
<p>Finding a venue to host a meetup can be difficult. I recommend a place that has good WiFi, is somewhat quiet and set up for presentations. Co-working spaces are a great option to host a meetup since most of them contain the amenities I&#8217;ve outlined above. They have the side benefit of sometimes hosting workers that have an interest in WordPress. If you end up using a co-working space, ask around to see if anyone has an interest in WordPress. They could be your newest members to your meetup!</p>
<h3>Immediately Establish Consistency</h3>
<p>One of the biggest lessons learned while organizing a meetup is how important it is for the event to happen consistently at the same time. In the past, our meetup didn&#8217;t have a specific day of the month and was created when we felt like meeting up. This left people questioning whether or not there would be another meetup the following month.</p>
<div id="attachment_19141" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/MeetupConsistency.png" rel="prettyphoto[19057]"><img class="size-full wp-image-19141" alt="Schedule The Meetup To Happen At The Same Time Every Month" src="http://wptavern.com/wp-content/uploads/2014/03/MeetupConsistency.png" width="523" height="242" /></a><p class="wp-caption-text">Make Your Meetup Predictable</p></div>
<p>By immediately establish consistency, you&#8217;re giving attendees a chance to plan around your meetup. For example, ours is held on the fourth Thursday of every month. The only time it changes is during inclement weather or during a holiday. It&#8217;s important you communicate schedule changes as soon as possible to give attendees a chance to change their plans.</p>
<h3>How Long Should The Meetup Be?</h3>
<p>You don&#8217;t need to have a time limit unless the venue requires you to leave at a certain time. Our meetup is typically two hours long with the first hour dedicated to a topic. Topics are decided either from the previous meeting or from users in our meetup.com group. If you&#8217;re thinking about doing a presentation at a WordCamp, meetups are an excellent opportunity to hone your skills. Presenting in front of 15-30 people is less stressful than a room of 50-100.</p>
<h3>WordCamps Usually Start As Meetups First</h3>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/WordCampDayton2014Logo.jpg" rel="prettyphoto[19057]"><img class="alignright size-thumbnail wp-image-12640" alt="WordCamp Dayton 2014" src="http://wptavern.com/wp-content/uploads/2013/12/WordCampDayton2014Logo-150x150.jpg" width="150" height="150" /></a>When I asked Nathan Driver how <a title="http://wptavern.com/first-wordcamp-dayton-a-flying-success" href="http://wptavern.com/first-wordcamp-dayton-a-flying-success">WordCamp Dayton, Ohio</a> started, he told me it began with their local meetup. After visiting WordCamps throughout the state of Ohio, he discovered many of the attendees were from Southwest Ohio and wanted an event closer to home. He created a meetup around the Dayton area to gauge interest. “<em>After a couple of months of debating we went for it and had our first MeetUp in October 2012″.</em> After managing the meetup for a couple of months, Driver noticed interest grew along with memberships which is when he decided to begin the process of creating a WordCamp.</p>
<h3>Starting A Meetup Is Not Hard But Requires Work and Dedication</h3>
<p>Meetups require dedication and consistency to develop a community of their own. Don&#8217;t be discouraged if only three to five people show up. Use your meetup.com page as a hub and encourage attendees to leave feedback after every meeting. Make sure communication channels are open between the organizer and the attendees so everyone within the group is on the same page.</p>
<p>Last but not least, have fun. Meetups don&#8217;t have to be serious and in my opinion, shouldn&#8217;t be. They are informal gatherings of people from all backgrounds united by an interest in WordPress.  If you have any suggestions for new WordPress meetup organizers, please add them in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Mar 2014 21:57:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WPTavern: Treehouse Expands WordPress Education to Include BuddyPress Beginners Course";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19096";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:216:"http://wptavern.com/treehouse-expands-wordpress-education-to-include-buddypress-beginners-course?utm_source=rss&utm_medium=rss&utm_campaign=treehouse-expands-wordpress-education-to-include-buddypress-beginners-course";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3358:"<p>Just one month after launching its <a href="http://wptavern.com/high-demand-for-wordpress-education-prompts-treehouse-to-launch-new-beginners-course" target="_blank">WordPress beginner&#8217;s course</a>, Treehouse has added BuddyPress education to its collection of interactive learning resources. The &#8220;<a href="http://teamtreehouse.com/library/learn-buddypress-social-networks-with-wordpress" target="_blank">Learn BuddyPress</a>&#8221; course is geared toward BuddyPress beginners and covers all the basics of setup, user management, and core social components.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/buddypress-treehouse.png" rel="prettyphoto[19096]"><img src="http://wptavern.com/wp-content/uploads/2014/03/buddypress-treehouse.png" alt="buddypress-treehouse" width="640" height="480" class="aligncenter size-full wp-image-19116" /></a></p>
<p>After reviewing the course, I was impressed by how quickly Gordon is able to communicate all the basics for gaining competence with BuddyPress, including the following:</p>
<ul>
<li><strong>Getting Started With BuddyPress:</strong> How to Install BP and configure its settings, register users and use the codex</li>
<li><strong>BuddyPress Member Profiles:</strong> Setting up extended profile user fields, members page, status updates, etc.</li>
<li><strong>Social Interactions in BuddyPress:</strong> Friend connections, private messaging, mentioning users, notifications, activity, groups</li>
<li><strong>Customizing BuddyPress:</strong> BP plugins, themes and customizations</li>
</ul>
<p>Each component is covered in great detail from both a user and community manager perspective. If you learn best by watching videos, then this course may be a good option for you, as it also includes an accompanying video transcript for each section. The lessons include links to the <a href="http://codex.buddypress.org/" target="_blank">BuddyPress codex</a> for further reference on the topics discussed.</p>
<h3>Treehouse Plans to Add More BuddyPress Education Resources</h3>
<p><a href="http://zacgordon.com/" target="_blank">Zac Gordon</a>, Treehouse&#8217;s instructor for the course, said that they&#8217;ve been experiencing an increase in demand for BuddyPress education resources. He plans to create a BuddyPress Theme Development course to follow and may add a plugin development course sometime further down the road.</p>
<p>With Treehouse&#8217;s expansion into resources for major WordPress plugins, I asked him if other extensions will be featured. &#8220;bbPress is definitely on my radar, although I&#8217;ve had no requests for it,&#8221; Gordon said. &#8220;Jetpack would be a cool idea too, since we just did the WordPress.com course.&#8221; He&#8217;s currently experimenting with different course lengths and may produce a quick Jetpack resource within the next month or two.</p>
<p>The <a href="http://teamtreehouse.com/library/learn-buddypress-social-networks-with-wordpress" target="_blank">Learn BuddyPress</a> course is the first of its kind with in-depth video tutorials for every aspect of using BuddyPress. This is a great resource for teaching yourself the basics of BuddyPress over a weekend. The course is also a high quality option for BuddyPress developers to recommend to clients for basic support on how to use BuddyPress&#8217; core features.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Mar 2014 19:21:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress.tv: Chris Lema: WordCamp Las Vegas 2013 Opening Keynote";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33164";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2014/03/17/chris-lema-wordcamp-las-vegas-2013-opening-keynote/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:655:"<div id="v-jsJVSQLw-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33164/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33164/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33164&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/17/chris-lema-wordcamp-las-vegas-2013-opening-keynote/"><img alt="Chris Lema: Opening Keynote" src="http://videos.videopress.com/jsJVSQLw/video-e208f2e698_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Mar 2014 17:59:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: 10up Hires CEO To Help Take Company To The Next Level";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18705";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:170:"http://wptavern.com/10up-hires-ceo-to-help-take-company-to-the-next-level?utm_source=rss&utm_medium=rss&utm_campaign=10up-hires-ceo-to-help-take-company-to-the-next-level";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2756:"<p><a href="http://wptavern.com/wp-content/uploads/2013/12/10UpLogo.jpg" rel="prettyphoto[18705]"><img class="alignright size-full wp-image-13736" alt="10up Logo" src="http://wptavern.com/wp-content/uploads/2013/12/10UpLogo.jpg" width="139" height="164" /></a>WordPress development agency <a title="http://10up.com/" href="http://10up.com/">10up</a> has <a title="http://10up.com/blog/john-eckman-ceo/" href="http://10up.com/blog/john-eckman-ceo/">hired John Eckman</a> to take on the role of CEO. Eckman will work closely with Goldman and team leaders on the day-to-day operations of the company. Jake Goldman will remain as president and will focus on the products, strategic investments, and business development side of the company.</p>
<p>Eckman has spent the last 15 years in the CMS ecosystem with five different companies both in the open-source and non open-source space. Before 10up, he worked for <a title="http://www.isitedesign.com/" href="http://www.isitedesign.com/">iSite Design</a>, a company that has a portfolio filled with companies from start-ups to non-profits to fortune 25 industry leaders.</p>
<h3>Removing Obstacles To Enable More Efficient Employees</h3>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/obstaclesign.png" rel="prettyphoto[18705]"><img class="alignright size-medium wp-image-19066" alt="obstaclesign" src="http://wptavern.com/wp-content/uploads/2014/03/obstaclesign-249x300.png" width="249" height="300" /></a>In the short-term, Eckman will observe how the company functions, locate growing pains and determine any obstacles he can remove to help employees become more efficient. Sometimes, a hiring like this can lead to immediate and drastic changes but Eckman wants the transition to be as smooth as possible. He doesn&#8217;t want to change the company culture if it&#8217;s working. Longer term, he wants to &#8220;<em>Make the team as efficient as possible. Remove non-productive frustrations and empower employees to be as productive as possible</em>&#8220;.</p>
<h3>Executing The Vision</h3>
<p>The hiring enables 10up to continue growing and to take on bigger projects. However, Eckman noted he wants to see the company continue to take on smaller more nimble projects. The goal is to have a wide-ranging portfolio showcasing the strengths of the company no matter how small or large the project. When I asked Eckman to summarize his position in the company, he said, &#8220;<em>Jake will drive the vision, I&#8217;ll execute it</em>&#8220;.</p>
<p>Also check out Brian Krogsgard&#8217;s <a title="http://www.poststat.us/evolution-10up/" href="http://www.poststat.us/evolution-10up/">hour long interview </a>where he sat down and talked to Jake Goldman and 10up&#8217;s new CEO John Eckman.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Mar 2014 17:22:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WPTavern: How to Restrict a WordPress Author to Posting in One Category";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19061";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:186:"http://wptavern.com/how-to-restrict-a-wordpress-author-to-posting-in-one-category?utm_source=rss&utm_medium=rss&utm_campaign=how-to-restrict-a-wordpress-author-to-posting-in-one-category";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2726:"<div id="attachment_19081" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/writing-featured.jpg" rel="prettyphoto[19061]"><img src="http://wptavern.com/wp-content/uploads/2014/03/writing-featured.jpg" alt="photo credit: Nic\'s events - cc" width="1021" height="533" class="size-full wp-image-19081" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/nics_events/2349632625/">Nic&#8217;s events</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a></p></div>
<p>Multi-author WordPress blogs often have many authors working together to push out content, but not every author needs access to post to all categories on the site. In fact, there may be times when you want to limit an author to posting in just one assigned category for contributions.</p>
<p><a href="http://wordpress.org/plugins/restrict-author-posting/" target="_blank">Restrict Author Posting</a> is a new plugin that allows administrators to restrict authors, on an individual basis, to post in only one category. This is a lightweight, specific-use plugin that doesn&#8217;t alter any other capabilities or permissions.</p>
<p>Once you install it, administrators can navigate to each user that they want to restrict and assign a category.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/restrict-author-posting-1.png" rel="prettyphoto[19061]"><img src="http://wptavern.com/wp-content/uploads/2014/03/restrict-author-posting-1.png" alt="restrict-author-posting-1" width="709" height="283" class="aligncenter size-full wp-image-19088" /></a></p>
<p>When the author goes to create a new post, the meta box listing all of the categories will not be available. Instead, the author will see a notice of which category the post will fall under.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/restrict-author-posting-2.png" rel="prettyphoto[19061]"><img src="http://wptavern.com/wp-content/uploads/2014/03/restrict-author-posting-2.png" alt="restrict-author-posting-2" width="580" height="262" class="aligncenter size-full wp-image-19089" /></a></p>
<p>Restrict Author Posting is a plugin that you might never think of until you have a situation where you need it. Put it in place to streamline contributions on a multi-author site by herding authors into their assigned categories. This saves you the trouble of having to double check posts to make sure they fall under the correct category. It also helps to ensure that authors don&#8217;t go crazy creating new categories for every post. Download <a href="http://wordpress.org/plugins/restrict-author-posting/screenshots/" target="_blank">Restrict Author Posting</a> from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Mar 2014 16:17:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Benjamin Beck: WordPress SEO That Is Google Friendly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33156";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wordpress.tv/2014/03/16/benjamin-beck-wordpress-seo-that-is-google-friendly/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:681:"<div id="v-9qOedSvK-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33156/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33156/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33156&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/16/benjamin-beck-wordpress-seo-that-is-google-friendly/"><img alt="Benjamin Beck: WordPress SEO That Is Google Friendly" src="http://videos.videopress.com/9qOedSvK/video-1771ce6163_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Mar 2014 05:06:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress.tv: Andy Roberts: Best of Breed Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33154";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.tv/2014/03/16/andy-roberts-best-of-breed-plugins/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:647:"<div id="v-QHutxaiI-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33154/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33154/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33154&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/16/andy-roberts-best-of-breed-plugins/"><img alt="Andy Roberts: Best of Breed Plugins" src="http://videos.videopress.com/QHutxaiI/video-7c730e33ac_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Mar 2014 04:24:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WordPress.tv: Amanda Blum: Get Your Site Built Without Getting Burned";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33152";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wordpress.tv/2014/03/16/amanda-blum-get-your-site-built-without-getting-burned/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:687:"<div id="v-SPghJPIB-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33152/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33152/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33152&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/16/amanda-blum-get-your-site-built-without-getting-burned/"><img alt="Amanda Blum: Get Your Site Built Without Getting Burned" src="http://videos.videopress.com/SPghJPIB/video-bf68252ca0_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 17 Mar 2014 03:50:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"Lorelle on WP: WordPress For Writers: WordPress Author Sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=11559";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://lorelle.wordpress.com/2014/03/16/wordpress-for-writers-wordpress-author-sites/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:496:"In this part of my series on WordPress For Writers, I&#8217;ll cover the basic things to consider when using WordPress on site promoting the work of writers and authors. For more on the subject, see other articles in the WordPress for Writers and Authors series. This article assumes you have some basic familiarity with WordPress [&#8230;]<img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=lorelle.wordpress.com&blog=72&post=11559&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 16 Mar 2014 11:51:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: WPWeekly Episode 141 – One Million WordCamps In Ohio";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=19050&preview_id=19050";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:164:"http://wptavern.com/wpweekly-episode-141-one-million-wordcamps-in-ohio?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-141-one-million-wordcamps-in-ohio";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3018:"<p>We&#8217;ve kept this weeks edition of WordPress Weekly short and sweet. We talked about the news of week and I shared my experience attending the first ever WordCamp Dayton, Ohio. We discussed why there are so many WordCamps happening in the state of Ohio and how some of them came to fruition. We also, congratulated Nick Haskins on launching the first commercial theme for Aesop (Genji) and shared our thoughts on sites already using Aesop combined with Genji. We hope you enjoy the show!</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/wordpress-beta-testers-start-your-engines-3-9-beta-1-released" title="http://wptavern.com/wordpress-beta-testers-start-your-engines-3-9-beta-1-released">WordPress Beta Testers, Start Your Engines: 3.9 Beta 1 Released</a><br />
<a href="http://wptavern.com/how-to-prevent-wordpress-from-participating-in-pingback-denial-of-service-attacks" title="http://wptavern.com/how-to-prevent-wordpress-from-participating-in-pingback-denial-of-service-attacks">How To Prevent WordPress From Participating In Pingback Denial of Service Attacks</a><br />
<a href="http://wptavern.com/take-the-2014-bbpress-survey" title="http://wptavern.com/take-the-2014-bbpress-survey">Take The 2014 bbPress Survey</a><br />
<a href="http://wptavern.com/aesop-story-engine-launches-commercial-wordpress-themes" title="http://wptavern.com/aesop-story-engine-launches-commercial-wordpress-themes">Aesop Story Engine Launches Commercial WordPress Themes</a><br />
<a href="http://wptavern.com/why-company-culture-is-so-important-for-remote-wordpress-developers" title="http://wptavern.com/why-company-culture-is-so-important-for-remote-wordpress-developers">Why Company Culture Is So Important For Remote WordPress Developers</a><br />
<a href="http://wptavern.com/first-wordcamp-dayton-a-flying-success" title="http://wptavern.com/first-wordcamp-dayton-a-flying-success">First WordCamp Dayton A Flying Success</a><br />
<a href="http://wptavern.com/tickets-on-sale-for-wordcamp-north-canton-ohio" title="http://wptavern.com/tickets-on-sale-for-wordcamp-north-canton-ohio">Tickets On Sale For WordCamp North Canton, Ohio</a><br />
<a href="http://wptavern.com/sofia-bulgaria-to-host-wordcamp-europe-2014" title="http://wptavern.com/sofia-bulgaria-to-host-wordcamp-europe-2014">Sofia, Bulgaria To Host WordCamp Europe 2014</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, March 21st 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #141:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Mar 2014 22:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:104:"WPTavern: The Importance of Mentors: How a High School Student Became a Professional WordPress Developer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=19002";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:250:"http://wptavern.com/the-importance-of-mentors-how-a-high-school-student-became-a-professional-wordpress-developer?utm_source=rss&utm_medium=rss&utm_campaign=the-importance-of-mentors-how-a-high-school-student-became-a-professional-wordpress-developer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5644:"<p>Sunny Ratilal&#8217;s WordPress adventure started when he was 13 years old. While learning how to build a custom content management system, he stumbled upon WordPress and started fiddling around with it to learn more about its features. At the age of 14, he landed his first client. WordPress ticked all the boxes for the client&#8217;s requirements and Sunny launched his career as a professional WordPress developer.</p>
<div id="attachment_19010" class="wp-caption alignright"><a href="http://wptavern.com/wp-content/uploads/2014/03/Photo.jpg" rel="prettyphoto[19002]"><img src="http://wptavern.com/wp-content/uploads/2014/03/Photo-300x249.jpg" alt="Sunny Ratilal" /></a><p class="wp-caption-text">Sunny Ratilal<br /></p></div>
<p>Fast forward to three years later, Sunny is now 17 years old and currently in Sixth Form in London. When not busy studying, he enjoys developing custom plugins for clients and is also a prolific contributor to <a href="https://easydigitaldownloads.com" target="_blank">Easy Digital Downloads</a>, having logged an impressive <a href="https://github.com/easydigitaldownloads/Easy-Digital-Downloads/commits?author=sunnyratilal" target="_blank">1,097 commits</a> to the codebase.</p>
<h3>Learning By Contributing to Open Source Projects</h3>
<p>While contributing to EDD, Sunny said he has learned a great deal about working in remote teams. &#8220;Working alongside EDD developers, we&#8217;re scattered all around the World!  Some are based in the US, England and even New Zealand! Remote teams are fantastic because it always means someone is around whatever time of the day.&#8221;</p>
<p>Getting involved in EDD changed Sunny&#8217;s life and opened him up to a new world of collaboration. &#8220;<span class="pullquote alignleft">Open source software has empowered me to code</span>,&#8221; he said. &#8220;Contributing to EDD was my first open source project which gave me confidence to contribute to other smaller plugins and then eventually WordPress Core, submitting my first patch to WordPress last year.&#8221;</p>
<p>Since his first foray into commercial products involved building extensions for a popular plugin, I asked Sunny if he has any advice to others who want to be successful in that space. He said:</p>
<blockquote><p>Don&#8217;t build the extension because it&#8217;s something that&#8217;s required, build it because you want to build it. Build something you&#8217;re really passionate about; that&#8217;s what&#8217;ll give you the most pleasure whilst coding it. The key to success is not all about marketing the plugin, it&#8217;s about how the plugin is written.</p></blockquote>
<p>Sunny advises developers to keep it clean and simple. He offered five tips for building extensions:</p>
<ol>
<li>Write clean code</li>
<li>Document it very well</li>
<li>Make the code efficient, don&#8217;t have hundreds of WP_Query instances or load hundreds of JavaScript/CSS files.</li>
<li>Don&#8217;t give the customers a chance to complain, have a feature list built and always beta test</li>
<li>Provide excellent support to all customers</li>
</ol>
<h3>The Importance of WordPress Role Models</h3>
<p>While learning and working with WordPress, Sunny said that having good role models inspired him to further develop his skills. &#8220;I have three very important role models: all three are fellow WordPress developers: <a href="http://tommcfarlin.com/" target="_blank">Tom McFarlin</a>, <a href="http://pippinsplugins.com/" target="_blank">Pippin Williamson</a> and <a href="http://markjaquith.com/" target="_blank">Mark Jaquith</a>,&#8221; he said.</p>
<p>&#8220;They are exceptional developers who have a myriad of knowledge. <span class="pullquote alignleft">The plugins/themes they create are made with other developers in mind and their coding is by far some of the best you will ever see.</span>&#8221;</p>
<p>Sunny is hoping to advance his skills along the same path he&#8217;s seen forged by the aforementioned developers. &#8220;I can say with a great amount of certainty that you can learn something new from every single commit to plugins/themes/WordPress Tom, Mark and Pippin make.&#8221; As is the case in many technical professions, Sunny has learned the most by doing and by watching other high performing developers.</p>
<h3>A Bright Future for Sunny Ratilal</h3>
<p>What does the future hold for Sunny Ratilal? He&#8217;s got one more year before entering university. Meanwhile, he is studying Mathematics, Further Mathematics, Computer Science and Physics. He hopes to study Computer Science at University.</p>
<p>He also plans to continue his work with EDD and WordPress. At the moment, he&#8217;s taking a break from EDD contributions to focus on his schoolwork. Pursuing a career in WordPress is something he&#8217;s considered, and he plans to continue developing while getting his education. &#8220;I love building WordPress plugins and themes and have no intention to stop doing so,&#8221; he said.</p>
<p>In many ways Sunny Ratilal seems ahead of his time, with his mature knowledge of teamwork, building software and handling customers. Code mentors have made all the difference for him and his experiences highlight the importance of solid role models in the WordPress community.</p>
<p>Though you may often feel like you&#8217;re working alone in your small corner of the world, the quality of the code you produce and your interactions with other developers may actually be mentoring future WordPress professionals. A developer who works to help others learn and grow can be instrumental in swinging the doors open for newcomers to the WordPress community.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Mar 2014 22:11:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Matt: Shaer on Taibbi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43660";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:37:"http://ma.tt/2014/03/shaer-on-taibbi/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:200:"<p><a href="http://nymag.com/daily/intelligencer/2014/03/matt-taibbi-on-wall-street-first-look-media.html">Raging Against Hacks With Matt Taibbi</a>. I can&#8217;t wait to see his new publication.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Mar 2014 18:29:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WPTavern: Tickets On Sale For WordCamp North Canton, Ohio";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18969";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:156:"http://wptavern.com/tickets-on-sale-for-wordcamp-north-canton-ohio?utm_source=rss&utm_medium=rss&utm_campaign=tickets-on-sale-for-wordcamp-north-canton-ohio";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2369:"<p>Tickets have gone on sale for the 2nd annual <a href="http://2014.northcanton.wordcamp.org/" title="http://2014.northcanton.wordcamp.org/">WordCamp North Canton, Ohio</a>. This years event takes place on May 2nd and 3rd. Friday is dedicated to a marketing bootcamp while Saturday will feature speakers discussing a variety of topics. Organizers are in the process of sifting through topic submissions and will announce speakers soon. Since WordCamp North Canton is a two-day event, they have two separate ticket offers.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/WordCampNorthCanton2014.png" rel="prettyphoto[18969]"><img src="http://wptavern.com/wp-content/uploads/2014/03/WordCampNorthCanton2014.png" alt="WordCamp North Canton 2014 Header" width="650" height="200" class="aligncenter size-full wp-image-18995" /></a></p>
<p>You can buy a $10 Friday only ticket or a $20 Saturday only ticket. If you would like to attend both days, please buy a ticket for each day. The event is being held at the same venue as last year, <a href="http://2014.northcanton.wordcamp.org/attend/" title="http://2014.northcanton.wordcamp.org/attend/">Stark State College</a>. Last year, I attended the first ever WordCamp event for the area and it was a <a href="http://wptavern.com/first-wordcamp-north-canton-a-success" title="http://wptavern.com/first-wordcamp-north-canton-a-success">huge success</a>.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/05/120.jpg" rel="prettyphoto[18969]"><img src="http://wptavern.com/wp-content/uploads/2013/05/120-150x150.jpg" alt="120" width="150" height="150" class="alignright size-thumbnail wp-image-6799" /></a>Just like last year, WordCamp North Canton will have a zero waste strategy. Everything used during the event is either recyclable or fully bio-degradable. <a href="http://ermannospizza.com/" title="http://ermannospizza.com/">Ermanno&#8217;s pizza</a> will return with its signature pizzas and S&#8217;more ravioli to feed hungry WordCampers. The S&#8217;more ravioli were such a big hit with WordCampers that Ermanno&#8217;s added it to its menu as a regular item.</p>
<p>I enjoy meeting readers of WPTavern as well as listeners to the WordPress Weekly podcast. Let me know in the comments if you&#8217;re going to WordCamp North Canton, Ohio as I&#8217;ll be in attendance for this years event.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Mar 2014 18:05:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: WordPress Tip: How to Load Google Fonts Over SSL and Non-SSL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18971";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/wordpress-tip-how-to-load-google-fonts-over-ssl-and-non-ssl?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-tip-how-to-load-google-fonts-over-ssl-and-non-ssl";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1691:"<p>Here&#8217;s a quick tip for when you load Google fonts in WordPress. If you want the fonts to work over both SSL and non-SSL, you need to use the <a href="http://tools.ietf.org/html/rfc1808" target="_blank">protocol relative link</a>.</p>
<p>For example, if you&#8217;re loading Google fonts from your theme&#8217;s <em>functions.php</em> file, you might do it like this:</p>
<pre class="brush: php; light: true; title: ; notranslate">function mytheme_enqueue_styles() {
            wp_register_style(\'googleFonts\', \'http://fonts.googleapis.com/css?family=Copse\');
            wp_enqueue_style( \'googleFonts\');
        }</pre>
<p>However, this method breaks over HTTPS, which means that all your fancy custom fonts won&#8217;t work and the browser&#8217;s default will be loaded instead, ie. Times New Roman.</p>
<p>Removing the &#8220;http&#8221; protocol from the link will allow the visitor&#8217;s browser to determine the correct protocol to load.</p>
<pre class="brush: php; light: true; title: ; notranslate">function mytheme_enqueue_styles() {
            wp_register_style(\'googleFonts\', \'//fonts.googleapis.com/css?family=Copse\');
            wp_enqueue_style( \'googleFonts\');
        }</pre>
<p>There are many tutorials that claim to show you &#8220;The Right Way to Load Google Fonts in WordPress,&#8221; but most of them don&#8217;t use the protocol relative link. If you&#8217;ve ever forced SSL on pages then you know that all of your assets, including images, CSS, JS, fonts, etc., will be broken unless they are loaded via HTTPS. You should use the protocol relative links wherever possible when the assets or third-party links are available via both HTTP and HTTPS.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Mar 2014 06:19:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"WPTavern: Take The 2014 bbPress Survey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18954";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://wptavern.com/take-the-2014-bbpress-survey?utm_source=rss&utm_medium=rss&utm_campaign=take-the-2014-bbpress-survey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1652:"<p><a href="http://wptavern.com/wp-content/uploads/2014/03/BuddyCampMiami2013.jpeg" rel="prettyphoto[18954]"><img src="http://wptavern.com/wp-content/uploads/2014/03/BuddyCampMiami2013.jpeg" alt="BuddyCamp Miami 2013" width="194" height="259" class="alignright size-full wp-image-18957" /></a>Similar to BuddyPress, bbPress has <a href="http://bbpress.org/blog/2014/03/2014-bbpress-survey/" title="http://bbpress.org/blog/2014/03/2014-bbpress-survey/">announced its own survey</a> to help decide features and which direction bbPress development will go in 2014. The survey is three pages long and contains a mix of generalized questions. It doesn&#8217;t take long to complete and it&#8217;s nice to be able to have a say in which direction the project goes.</p>
<p>The only thing missing from the survey are social media links that I could use to spread the word about completing the survey. At the very least, I&#8217;d like to see a Twitter button to announce I took the survey and encourage my followers to do the same.</p>
<p>As part of WordCamp Miami 2014, the event will feature a <a href="http://2014.miami.wordcamp.org/announcing-buddycamp-miami-2014/" title="http://2014.miami.wordcamp.org/announcing-buddycamp-miami-2014/">BuddyCamp</a>. BuddyCamp focuses on both BuddyPress and bbPress and provides an opportunity to learn and contribute to both projects. <a href="http://2014.miami.wordcamp.org/tickets/" title="http://2014.miami.wordcamp.org/tickets/">Tickets for WordCamp Miami</a> are still available but you better hurry, only a limited number are left. Sarah Gooding and I will be in attendance so be sure to say hi if you see us.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 23:48:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: 13 Sources For Free Public Domain and CC0-Licensed Images";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18904";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/13-sources-for-free-public-domain-and-cc0-licensed-images?utm_source=rss&utm_medium=rss&utm_campaign=13-sources-for-free-public-domain-and-cc0-licensed-images";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7385:"<p>Yesterday, we featured <a href="http://wptavern.com/wp-inject-makes-it-easy-to-add-free-creative-commons-images-to-wordpress-posts" target="_blank">WP Inject</a>, a plugin that makes it easy to insert <a href="http://creativecommons.org" target="_blank">Creative Commons</a> licensed images into WordPress content. High quality CC-licensed images are incredibly easy to find these days. The vast majority of the collections include images that fall under the <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/deed.en" target="_blank">Creative Commons Attribution-Sharealike 2.0 license</a>. While these images are fine for blogging, they cannot be distributed with GPL-licensed software.</p>
<h3>Why Creative Commons 2.0 Is Not Compatible With the GPL</h3>
<p>When I submitted <a href="http://wptavern.com/introducing-ex-astris-a-free-wordpress-child-theme-for-stargazer" target="_blank">my first theme</a> to the WordPress Themes Directory, I learned that most CC-licensed images are not compatible with the GPL. At first it seemed odd to me that they wouldn&#8217;t be compatible, given that they both offer so much freedom.</p>
<p>Samuel &#8220;Otto&#8221; Wood explained why certain Creative Commons licenses are not compatible in <a href="http://wordpress.org/support/topic/creative-commons-verses-gpl?replies=18#post-2981463" target="_blank">an answer</a> on the WordPress.org support forums:</p>
<blockquote><p>Because CC-BY-SA cannot be sublicensed, then that means it cannot be distributed in a work under the terms of the GPL. So it cannot be included in a GPL-compatible work-as-a-whole.</p></blockquote>
<p>If you want to include images in a GPL-licensed work, you&#8217;ll need to select from those that fall under a <a href="http://www.gnu.org/licenses/license-list.html#GPLCompatibleLicenses" target="_blank">compatible license</a>.</p>
<p>According to the <a href="http://www.gnu.org/licenses/license-list.html#CC0" target="_blank">GNU licensing classifications</a>, CC0 is the only Creative Commons license that is compatible with the GPL:</p>
<blockquote><p>CC0 is a public domain dedication from Creative Commons. A work released under CC0 is dedicated to the public domain to the fullest extent permitted by law. If that is not possible for any reason, CC0 also provides a lax, permissive license as a fallback. Both public domain works and the lax license provided by CC0 are compatible with the GNU GPL.</p></blockquote>
<p>If you are distributing a GPL-licensed product with images, such as a WordPress theme or plugin, your best bet is to opt for using images with the <a href="http://creativecommons.org/choose/zero/" target="_blank">CC0</a> or Public Domain license.</p>
<h3>13 High Quality Sources for CC0 and Public Domain Licensed Images</h3>
<p><a href="http://directory.fsf.org/wiki/License:CC0" target="_blank">CC0</a> and Public Domain licensed images are not as easy to find as those that fall under the CC 2.0 license. Nevertheless, I was able to locate 13 high quality sources for finding images that are suitable for inclusion in GPL-licensed works. All of the following sites explicitly state a Public Domain or CC0 license for the images collected.</p>
<h3><a href="http://unsplash.com/" target="_blank">Unsplash</a></h3>
<p><a href="http://unsplash.com/"><img src="http://wptavern.com/wp-content/uploads/2014/03/unsplash1.jpg" alt="unsplash" width="1500" height="1000" class="aligncenter size-full wp-image-18935" /></a></p>
<h3><a href="http://www.publicdomainpictures.net/" target="_blank">PublicDomainPictures</a></h3>
<p><a href="http://www.publicdomainpictures.net/"><img src="http://wptavern.com/wp-content/uploads/2014/03/publicdomainpictures.jpg" alt="publicdomainpictures" width="1280" height="842" class="aligncenter size-full wp-image-18928" /></a></p>
<h3><a href="http://pixabay.com/" target="_blank">Pixabay</a></h3>
<p><a href="http://pixabay.com/"><img src="http://wptavern.com/wp-content/uploads/2014/03/pixabay.jpg" alt="pixabay" width="1280" height="853" class="aligncenter size-full wp-image-18930" /></a></p>
<h3><a href="http://splitshire.com/" target="_blank">SplitShire</a></h3>
<p><a href="http://splitshire.com/"><img src="http://wptavern.com/wp-content/uploads/2014/03/SplitShire.jpg" alt="SplitShire" width="1280" height="853" class="aligncenter size-full wp-image-18932" /></a></p>
<h3><a href="http://www.1millionfreepictures.com/" target="_blank">1 Million Free Pictures</a></h3>
<p><a href="http://www.1millionfreepictures.com/"><img src="http://wptavern.com/wp-content/uploads/2014/03/1millionfreepictures.jpg" alt="1millionfreepictures" width="1280" height="850" class="aligncenter size-full wp-image-18934" /></a></p>
<h3><a href="http://viintage.com/" target="_blank">Viintage</a></h3>
<p><a href="http://viintage.com/"><img src="http://wptavern.com/wp-content/uploads/2014/03/vintage.jpg" alt="vintage" width="760" height="598" class="aligncenter size-full wp-image-18936" /></a></p>
<h3><a href="http://www.gratisography.com/" target="_blank">Gratisography</a></h3>
<p><a href="http://www.gratisography.com/"><img src="http://wptavern.com/wp-content/uploads/2014/03/gratisography.jpg" alt="gratisography" width="1280" height="859" class="aligncenter size-full wp-image-18938" /></a></p>
<h3><a href="http://littlevisuals.co/" target="_blank">Little Visuals</a></h3>
<p><a href="http://littlevisuals.co/"><img src="http://wptavern.com/wp-content/uploads/2014/03/littlevisuals.jpg" alt="littlevisuals" width="1280" height="853" class="aligncenter size-full wp-image-18939" /></a></p>
<h3><a href="http://www.pdpics.com/" target="_blank">PDpics</a></h3>
<p><a href="http://www.pdpics.com/"><img src="http://wptavern.com/wp-content/uploads/2014/03/pdpics.jpg" alt="pdpics" width="640" height="426" class="aligncenter size-full wp-image-18941" /></a></p>
<h3><a href="http://www.flickr.com/photos/britishlibrary/" target="_blank">The British Library</a></h3>
<p><a href="http://www.flickr.com/photos/britishlibrary/"><img src="http://wptavern.com/wp-content/uploads/2014/03/britishlibrary.jpg" alt="britishlibrary" width="800" height="568" class="aligncenter size-full wp-image-18943" /></a></p>
<h3><a href="http://nos.twnsnd.co/" target="_blank">New Old Stock</a></h3>
<p><a href="http://nos.twnsnd.co/"><img src="http://wptavern.com/wp-content/uploads/2014/03/nos.jpg" alt="nos" width="1000" height="724" class="aligncenter size-full wp-image-18945" /></a></p>
<h3><a href="http://pickupimage.com/" target="_blank">Pickup Image</a></h3>
<p><a href="http://pickupimage.com/"><img src="http://wptavern.com/wp-content/uploads/2014/03/A-lake-near-the-base-of-Copahue-volcano-031214D6BC845BA9.jpg" alt="-A-lake-near-the-base-of-Copahue-volcano-031214D6BC845BA9" width="960" height="720" class="aligncenter size-full wp-image-18947" /></a></p>
<h3><a href="http://publicdomainarchive.com/" target="_blank">Public Domain Archive</a></h3>
<p><a href="http://publicdomainarchive.com/"><img src="http://wptavern.com/wp-content/uploads/2014/03/publicdomainarchive.jpg" alt="publicdomainarchive" width="1000" height="563" class="aligncenter size-full wp-image-18948" /></a></p>
<p>You&#8217;ll want to bookmark these sites for the next time you&#8217;re building a WordPress theme or plugin for distribution on WordPress.org. Do you have any other favorites to recommend? Please share them in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 21:09:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: WordPress’ Personality Shines Through Again";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18879";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:148:"http://wptavern.com/wordpress-personality-shines-through-again?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-personality-shines-through-again";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5511:"<p>A few years ago, there was an <a href="http://wptavern.com/should-easter-eggs-in-wordpress-be-removed" title="http://wptavern.com/should-easter-eggs-in-wordpress-be-removed">important discussion</a> within the WordPress community on whether Easter eggs should be in WordPress or not. Specifically, the Matrix style Easter egg which appeared when a post revision was compared to itself. It wasn&#8217;t long after the discussion when plugins started showing up on the repository to <a href="https://wordpress.org/plugins/disable-matrix-easter-egg/" title="https://wordpress.org/plugins/disable-matrix-easter-egg/">disable it</a>.</p>
<p><span class="embed-youtube"></span></p>
<p>A few days ago, Fred Myer of WPShout.com <a href="http://wpshout.com/wordpress-core-needs-writing-style-guide/" title="http://wpshout.com/wordpress-core-needs-writing-style-guide/">published his idea</a> to create a WordPress writing style guide. He describes how some error messages in WordPress are written tongue-in-cheek without providing any useful information as to why the error occurred. Take the default 404 error message in WordPress for example:</p>
<blockquote><p>This is somewhat embarrassing, isn’t it? It seems we can’t find what you’re looking for. Perhaps searching can help.</p></blockquote>
<p>It&#8217;s embarrassing that WordPress couldn&#8217;t find what I was looking for and then proceeds to tell me that searching can help. Maybe a search should happen automatically with a list of results in the content area of the page? Regardless, it&#8217;s the wording of the message that rubs some people the wrong way. Myer advocates a more helpful approach:</p>
<blockquote><p>When software breaks, it should not impose emotions, like an imaginary shared experience of embarrassment, on the user. It should explain what went wrong in as much detail as is helpful, and alert the user to any resources that may help address the problem.</p></blockquote>
<p>Myer mentions the default post content in WordPress makes it seem trivial and cheap. He suggests the text should be eloquent and reflect the foundational mission of WordPress.</p>
<p>The personality of WordPress runs deep. From core committ messages to hidden Easter eggs to the inclusion of Hello Dolly, WordPress is not your typical piece of boring software. According to Myer:</p>
<blockquote><p>Words have power: power to define new users’ impression of the seriousness of WordPress and its creators; power to alleviate users’ frustration or aggravate it; power to provide information or smugly withhold it. WordPress’s current written content sporadically disregards that power, making WordPress seem like a cheaper, more irritating, and less well-executed project than it really is.</p></blockquote>
<p>I don&#8217;t have a problem with WordPress&#8217; personality but if changes could be made so that translations are easier and error messages become helpful, I&#8217;d support them. Matt Mullenweg <a href="http://wpshout.com/wordpress-core-needs-writing-style-guide/#comment-264374" title="http://wpshout.com/wordpress-core-needs-writing-style-guide/#comment-264374">commented on the article</a> and his remarks indicate that a change in WordPress’ wording isn’t likely.</p>
<blockquote><p>WP has always been opinionated software with a lot of personality. Every year or two people try to neuter it, remove a bit of its soul, and sometimes it gets through. There are always convincing reasons, like this post, but it’s sad nonetheless. If anyone is going to stop using the software over these we probably didn’t create something very compelling in the first place. You could also create a “dry” localization of the software and see if it gets much traction.</p></blockquote>
<div id="attachment_18909" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/HowdyDoodyFeaturedImage.png" rel="prettyphoto[18879]"><img src="http://wptavern.com/wp-content/uploads/2014/03/HowdyDoodyFeaturedImage.png" alt="Howdy Doody Featured Image" width="639" height="200" class="size-full wp-image-18909" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/23748404@N00/2292044151/">A.Currell</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc/2.0/">cc</a></p></div>
<p>No one is advocating for the demise of WordPress or telling people to stop using it over the howdy-doody verbiage within the software. There&#8217;s also not a mass exodus of people leaving the project over it. If anything, Myer&#8217;s article highlights the fact that WordPress can still be cute and funny as long as the verbiage is straight forward.</p>
<p>I wonder how long the clash between software personality and straight forward thinking will continue? It&#8217;s been part of WordPress for years but WordPress has yet to cave in to the demands of the vocal minority. WordPress is being used on 20% of the web and continues to grow without showing any signs of slowing down. It&#8217;s not the end of the world if the verbiage of error messages and default post content are not changed but if they can be improved, then why not do it?</p>
<h3>How To Help With The Style Guide</h3>
<p>If you&#8217;d like to get involved with creating a WordPress writing style guide, <a href="http://wpshout.com/contact/" title="http://wpshout.com/contact/">get in touch with Fred Myer at fred at pressupinc.com</a>. He&#8217;ll send you updates and the next steps of the process when he has them.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 18:45:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: Aesop Story Engine Launches Commercial WordPress Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18843";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:174:"http://wptavern.com/aesop-story-engine-launches-commercial-wordpress-themes?utm_source=rss&utm_medium=rss&utm_campaign=aesop-story-engine-launches-commercial-wordpress-themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3875:"<div id="attachment_18899" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/aesop.jpg" rel="prettyphoto[18843]"><img src="http://wptavern.com/wp-content/uploads/2014/03/aesop.jpg" alt="photo credit: s2art - cc" width="800" height="392" class="size-full wp-image-18899" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/s2art/187604478/">s2art</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a></p></div>
<p>Shortly after New Year&#8217;s, Nick Haskins caught the eye of WordPress publishers with his <a href="http://wptavern.com/aesop-story-engine-an-open-source-wordpress-plugin-for-storytelling" target="_blank">open source story telling plugin</a>. The prospect of building feature-rich, interactive stories within WordPress, without having to touch any code, was so promising that the project&#8217;s <a href="https://aesop.crowdhoster.com/storytelling-engine" target="_blank">Crowdhoster campaign</a> was <a href="http://wptavern.com/aesop-wordpress-storytelling-plugin-is-now-fully-funded" target="_blank">fully-funded</a> by the end of January.</p>
<p>The buzz around the Aesop plugin proved that the art of storytelling is not dead. Publishers are eager to have more tools at their disposal to create stories that capture readers&#8217; attention. While Aesop brings a user-friendly implementation of storytelling features into the WordPress admin, the task of theming the plugin remained a real obstacle.</p>
<p>Haskins had originally hoped to focus on the hosted version of Aesop after getting funded, but he temporarily scrapped that plan in favor of getting the plugin ready for showtime. Now that Aesop is available on <a href="http://wordpress.org/plugins/aesop-story-engine/" target="_blank">WordPress.org</a>, Haskin&#8217;s team is moving full steam ahead to develop themes that will bring the plugin to life.</p>
<h3>Genji: A Lean WordPress Theme With Just 2 Files</h3>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/genji1.png" rel="prettyphoto[18843]"><img src="http://wptavern.com/wp-content/uploads/2014/03/genji1-300x279.png" alt="genji1" width="300" height="279" class="alignright size-medium wp-image-18874" /></a>The first official theme for Aesop is now in the wild. Inspired by <a href="http://www.nytimes.com/projects/2012/snow-fall/" target="_blank">NY Times Snowfall</a>, the <a href="http://nickhaskins.co/products/genji/" target="_blank">Genji</a> theme was designed to load quickly and keep the spotlight on the story.</p>
<p>Haskin&#8217;s team aimed for simplicity with their first product. <a href="http://aesopthemes.com/genji/" target="_blank">Genji</a> loads only two files. It includes a handful of options for uploading a logo and changing the background, text and link colors. All of the magic, however, is powered by the media that users add via the story engine.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/genji2.jpg" rel="prettyphoto[18843]"><img src="http://wptavern.com/wp-content/uploads/2014/03/genji2-300x192.jpg" alt="genji2" width="300" height="192" class="alignleft size-medium wp-image-18876" /></a>With the first product released, the  team is focusing on Jorgen, the next theme on deck for the story engine. Jorgen will incorporate the &#8220;cover&#8221; feature found on the Aesop Story Engine <a href="http://playground.aesopstories.com/" target="_blank">demo site</a>. The development team has received many requests for the theme behind the story engine demo site and they are currently working on making that available to the public.</p>
<p>All future Aesop themes will be sold on ThemeForest, as Haskins is now <a href="http://aesopstories.com/themes/the-release-of-genji/" target="_blank">partnering with Envato</a> to make it easy for consumers to find themes for the plugin.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 09:52:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Gravatar: Mobile Friendly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.gravatar.com/?p=503";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://blog.gravatar.com/2014/03/13/mobile-friendly/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:540:"<p>We just made the Gravatar.com website, blog, and all profile pages friendlier towards mobile devices. Additionally, you can now edit your profile on the go.</p>
<p>Enjoy!</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/gravatar.wordpress.com/503/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/gravatar.wordpress.com/503/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.gravatar.com&blog=1886259&post=503&subd=gravatar&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 08:52:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Joen A.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WordPress.tv: Rohini Lakshané, Rina Chhadwa, Katrina Viloria: Women on WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32923";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://wordpress.tv/2014/03/12/rohini-lakshane-rina-chhadwa-katrina-viloria-women-on-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:715:"<div id="v-UrN6XD8O-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32923/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32923/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32923&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/12/rohini-lakshane-rina-chhadwa-katrina-viloria-women-on-wordpress/"><img alt="Rohini Lakshané, Rina Chhadwa, Katrina Viloria: Women on WordPress!" src="http://videos.videopress.com/UrN6XD8O/video-2f99bc2bb9_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 13 Mar 2014 04:14:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WPTavern: What Theme: A New Website Theme Detector Powered By WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18827";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:184:"http://wptavern.com/what-theme-a-new-website-theme-detector-powered-by-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=what-theme-a-new-website-theme-detector-powered-by-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5150:"<p>In an era where many website designs are powered by popular themes, it&#8217;s become common for folks passing by to want to snoop under the hood to find out which theme a site is using. If the visitor is not capable of inspecting the code with his browser, he might resort to a service built to automatically detect theme details. This has resulted in a proliferation of websites and browser add-ons that detect this information.</p>
<p><a href="http://whattheme.com/" target="_blank">What Theme</a> is a new service that detects WordPress, Ghost and Shopify templates, even if the site is not using a commercial theme. For example, if you search WP Tavern, you&#8217;ll find that our site is using the Stargazer theme:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/what-theme-example.jpg" rel="prettyphoto[18827]"><img src="http://wptavern.com/wp-content/uploads/2014/03/what-theme-example.jpg" alt="what-theme-example" width="768" height="440" class="aligncenter size-full wp-image-18835" /></a></p>
<p>It does not yet reliably pick up on WordPress child themes, as I&#8217;ve discovered in this instance and a few others.</p>
<h3>How What Theme Works</h3>
<p>The engine itself is built on top of WordPress and in just a few weeks it has completed over 13,000 searches across over 4,000 unique sites. What Theme co-founder Jonny Schnittger gave us the details on how it works. &#8220;The current version of WhatTheme integrates with WordPress like a theme or plug-in would,&#8221; he said. &#8220;It gives us a lot of detail regarding what people are looking for and how successful they were.&#8221;</p>
<p>When a user searches for a site, What Theme checks its existing catalog and if it finds it, the results are returned instantly. &#8220;In this scenario we attempt to identify the theme using several different methods,&#8221; Schnittger said. &#8220;At this point we also gather a bunch of other information that we are currently not surfacing/using).&#8221; Once the engine has found the name, it attempts to identify across various catalogs and sites. &#8220;Sometimes we get multiple matches,&#8221; he said. &#8220;In this case we try and evaluate the best match and direct the user to it.&#8221;</p>
<p>When What Theme fails to identify a theme, Schnittger said they use various pattern matching algorithms to suggest themes from the same category, such as blog, portfolio, food, etc.</p>
<p>For example, if you search for &#8220;WordPress.com,&#8221; the engine fails to match it to a theme:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/what-theme-fail.jpg" rel="prettyphoto[18827]"><img src="http://wptavern.com/wp-content/uploads/2014/03/what-theme-fail.jpg" alt="what-theme-fail" width="624" height="432" class="aligncenter size-full wp-image-18845" /></a></p>
<p>As you can see, What Theme also offers an option for the visitor to sign up to be emailed when the theme is found. It also funnels you to its <a href="http://whattheme.com/top-themes/blog/" target="_blank">top selections</a> for themes in the &#8220;blog&#8221; category, all of which are Themeforest items with the What Theme affiliate ID. In the future, Schnittger hopes to expand the suggestions, based on fonts, colors and layout.</p>
<h3>What Theme Plans to Expand to a WordPress Installation and Customization Service</h3>
<p>What Theme currently has basic support for Drupal and Joomla and plans to expand to include more CMS&#8217;s, such as ModX, DotNetNuke, Umbraco, etc. They are working to improve the accuracy of results for all supported platforms.</p>
<p>Co-founder Catalin Zorzini let us in on some of their long-term goals. <strong>&#8220;We plan to become the go-to resource for web designers and developers being asked by friends and relatives to build a website for them on the cheap or for free,&#8221;</strong> he said. &#8220;So instead of being forced to say no or to make empty promises, now they can just send them to whattheme.com and we&#8217;ll take care of the rest.&#8221; What Theme will then ask them what site they would like theirs to look like and recommend an existing template based on that. &#8220;The next step is to integrate it with a WP install and customization service,&#8221; Zorzini said.</p>
<p>The What Theme site is another interesting take on services aimed at capitalizing on the millions of people searching for WordPress themes. Many services, such as <a href="http://wptavern.com/theme-friendly-helps-you-find-the-perfect-wordpress-theme" target="_blank">Theme Friendly</a>, are built around helping users shop for WordPress themes, with the primary monetization in the form of affiliate links.</p>
<p>What Theme is different in that it hooks into the fact that the consumer has already located a theme that he likes. The long-term strategy for building a customization service as an offshoot of the theme search seems to be more promising than depending on affiliate links for income. What do you think about the <a href="http://whattheme.com/" target="_blank">What Theme</a> search engine? Will they be able to leverage the traffic into a successful WordPress business?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 23:29:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: Why Company Culture Is So Important For Remote WordPress Developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18689";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:198:"http://wptavern.com/why-company-culture-is-so-important-for-remote-wordpress-developers?utm_source=rss&utm_medium=rss&utm_campaign=why-company-culture-is-so-important-for-remote-wordpress-developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5364:"<div id="attachment_18752" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/RemoteWordPressWorkerFeaturedImage.png" rel="prettyphoto[18689]"><img class="size-large wp-image-18752" alt="Remote WordPress Worker Featured Image" src="http://wptavern.com/wp-content/uploads/2014/03/RemoteWordPressWorkerFeaturedImage-500x156.png" width="500" height="156" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/icedsoul/2601694302/">icedsoul photography .:teymur madjderey</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>I follow a handful of people who work with WordPress on a daily basis and I often see WordPress agencies publishing news about their recent hiring. I&#8217;ve noticed a lot of employees for WordPress agencies don&#8217;t seem to be sticking around with one company for very long. When I think of an employee staying at one company for a long time, I&#8217;m talking about three to five years although it&#8217;s easy to forget agencies like <a title="http://10up.com/" href="http://10up.com/">10up</a> have only been around for three years.</p>
<p>Why does it seem like they are switching companies as if it&#8217;s no big deal? I sat back and pondered this question for a while and came up with the following conclusions.</p>
<h3>Tons Of Employment Opportunities</h3>
<p>Since WordPress powers 20% of the web, there are a multitude of employment opportunities.. If one company isn&#8217;t paying enough, chances are good that another company is. Of course, working for an agency isn&#8217;t required as sites like <a title="https://www.elance.com/" href="https://www.elance.com/">Elance</a> and <a title="https://www.odesk.com/" href="https://www.odesk.com/">oDesk</a> have proven there is high demand for individual freelancers who specialize in WordPress.</p>
<h3>Insight From A 6 Year Old WordPress Company</h3>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/WebDevStudiosLogo2.png" rel="prettyphoto[18689]"><img class="alignright size-full wp-image-18760" alt="WebDevStudios Logo " src="http://wptavern.com/wp-content/uploads/2014/03/WebDevStudiosLogo2.png" width="211" height="64" /></a>Founded in 2008, <a title="http://webdevstudios.com/" href="http://webdevstudios.com/">WebDevStudios</a> is one of the longest running WordPress development companies within the WordPress ecosystem. I asked co-owner Brad Williams what the attrition rate is for WebDevStudios. He told me very few employees have left the company since it was founded. He also told me they no longer hire contractors and every WebDevStudios employee is full-time.</p>
<p>When asked if he&#8217;s seeing a lot of people apply for jobs at the company, he said &#8220;<em>We get quite a few applications when we post a job opening.</em>&#8221; Overall, Brad has seen a few remote employees bounce around, but doesn&#8217;t really consider it to be a widespread issue.</p>
<h3>Switch Companies Without Ever Leaving Home</h3>
<p>Remote WordPress employees have a distinct advantage over their physical workplace counterparts. They can switch companies without ever leaving home. Employees working in a physical location sometimes have to move to a different city for a promotion or for a new job. Remote workers can perform their jobs from anywhere in the world as long as they have an Internet connection. I think this is the single biggest reason remote workers can move between multiple companies within a one to two year timeframe.</p>
<h3>Finding A Culture That Fits</h3>
<p><a href="http://wptavern.com/wp-content/uploads/2013/10/ithemeslogo2.jpg" rel="prettyphoto[18689]"><img class="alignright size-full wp-image-10776" alt="iThemes logo 2" src="http://wptavern.com/wp-content/uploads/2013/10/ithemeslogo2.jpg" width="255" height="53" /></a>Thanks to remote workers not being tied to a physical location, it&#8217;s easier to find a company culture where they fit in. Automattic has done a great job of making sure every one of its employees blends in with its culture.</p>
<p>For most companies, it&#8217;s not just about being an employee and getting work done. It&#8217;s about something larger than any one individual. When I&#8217;ve asked employees why they have switched between multiple companies within a year, the answer is usually the same. <em>It just wasn&#8217;t a good fit for me</em>.</p>
<p>Glenn Ansley who works for <a title="http://ithemes.com/" href="http://ithemes.com/">iThemes</a> says his company does a great job keeping him connected to the company:</p>
<blockquote><p>If you don&#8217;t feel connected to your team, the loyalty is probably closer to that of a freelance contractor than an employee. My guess is it&#8217;s harder to get full buy-in / ownership from a remote employee. iThemes does a great job keeping me connected.</p></blockquote>
<h3>Not As Big Of A Problem As I Thought</h3>
<p>After speaking with Cory Miller, Brad Williams, and Jake Goldman I&#8217;ve discovered the problem is not nearly as bad as I thought. Attrition rates for some of the largest, longest, running WordPress businesses are low and employees are sticking with them. However, for the reasons explained above, it&#8217;s easier to switch companies as a remote WordPress worker than a typical employee in a brick and mortar shop.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 21:23:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WPTavern: WP Inject Makes It Easy to Add Free Creative Commons Images to WordPress Posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18778";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:220:"http://wptavern.com/wp-inject-makes-it-easy-to-add-free-creative-commons-images-to-wordpress-posts?utm_source=rss&utm_medium=rss&utm_campaign=wp-inject-makes-it-easy-to-add-free-creative-commons-images-to-wordpress-posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5010:"<p>Last week, Getty Images announced its new <a href="http://www.gettyimages.com/Creative/Frontdoor/embed" target="_blank">open-embed program</a>, which removes the watermark from many of the images in its library for non-commercial use. In exchange, Getty&#8217;s iframed images are plastered with its logo and force a row of large, unattractive social sharing buttons on each embed. Getty reserves the right to remove content from the embedded viewer at any time, which could potentially leave a trail of gaping black holes throughout your blog.</p>
<p>Many <a href="http://www.theguardian.com/technology/2014/mar/07/photographers-getty-images" target="_blank">photographers</a> and <a href="http://www.poststat.us/getty-images-now-free-embed/" target="_blank">bloggers</a> are unimpressed with Getty&#8217;s implementation. Even with 35 million new &#8220;free&#8221; photos flooding the blogosphere, <a href="https://creativecommons.org/licenses/" target="_blank">Creative Commons</a> images are likely to remain the preferred option, as they provide more creative freedom in styling the attribution and can be used in galleries, videos, design, etc.</p>
<h3>WP Inject: A Homegrown Alternative to Getty&#8217;s Free Images</h3>
<p><a href="http://wordpress.org/plugins/wp-inject/" target="_blank">WP Inject</a> is a new free plugin that makes it easy to use CC-licensed images in your WordPress content with just a few clicks. In fact, you don&#8217;t even need to leave the admin. The plugin adds a search box to the post editor. The search is hooked up to <a href="http://www.flickr.com/creativecommons/" target="_blank">Flickr&#8217;s vast library of CC-licensed images</a>.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/wpinject.png" rel="prettyphoto[18778]"><img src="http://wptavern.com/wp-content/uploads/2014/03/wpinject.png" alt="wpinject" width="1395" height="1019" class="aligncenter size-full wp-image-18779" /></a></p>
<p>WP Inject lets you compare multiple keyword search results to find the best match. Adding an image to your content is as easy as clicking on the size you want. The plugin automatically places it within your content and adds the correct attribution. It also saves the image to your server.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2014/03/wpinject2.png" rel="prettyphoto[18778]"><img src="http://wptavern.com/wp-content/uploads/2014/03/wpinject2.png" alt="wpinject2" width="1244" height="1110" class="aligncenter size-full wp-image-18782" /></a></p>
<h3>Designed for Blogger Convenience</h3>
<p>WP Inject, although somewhat unfortunately named, does not fail to impress in the features department. Every aspect of the plugin was designed for the blogger&#8217;s convenience, including the following:</p>
<ul>
<li>Set the featured image for your post with a single click.</li>
<li>Insert multiple images at once and create whole galleries.</li>
<li>Sort by selected Creative Commons licenses.</li>
<li>Choose between several image sizes easily.</li>
<li>Modify the templates of WP Inject to change how images get displayed in your posts.</li>
<li>Images are saved to your own server and added to the WordPress media library.</li>
<li>Automatically populated ALT and title tags of the image for search engine optimization.</li>
<li>Can use and insert your focus keyword set in WordPress SEO by Yoast for easier image search optimization.</li>
</ul>
<p>Thomas Hoefter, the plugin&#8217;s developer, is also the author of the <a href="http://wprobot.net/" target="_blank">WP Robot</a> plugin and founder of <a href="http://cmscommander.com/" target="_blank">CMS Commander</a>. WP Inject is a side project that grew out of his personal need for a solution to add featured images to new posts as quickly as possible. He said:</p>
<blockquote><p>Since I think finding good images for their posts is a problem lots of bloggers face, I have polished the plugin up last week and then released it. While there are a few alternatives out in the wild already (e.g. Photodropper), I found that most of them lacked features (at least some of which I needed) and/or are not actively updated anymore.</p></blockquote>
<p>Hoefter plans to update WP Inject regularly and created a website with a <a href="http://wpinject.com/tutorial/" target="_blank">tutorial</a> on how to use the plugin. In the future, he intends to include more image sources in addition to Flickr. He also hopes to make it possible to inject other types of media, including videos, ads, products and news stories.</p>
<p>After testing the plugin, I found that the in-post search is fast and convenient, since you don&#8217;t have to leave the WordPress admin to locate images for your content. It keeps you in the flow while writing and removes the hassle of having to open more browser tabs to search. WP Inject is a solid alternative to Getty&#8217;s free images. <a href="http://wordpress.org/plugins/wp-inject/" target="_blank">Download</a> the plugin for free from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 18:34:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"Alex King: Is WordPress the Right Tool for the Job?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=19550";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://alexking.org/blog/2014/03/12/when-to-use-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2752:"<p>I recently got an email that asked:</p>
<blockquote><p>Do you ever question whether WordPress is the correct CMS for something?</p>
<p>I am a big WordPress fan too and I&#8217;ve solved some really cool content management challenges with it but there are times when I think, this site would probably be faster and more efficient if it were built using some MVC framework?</p>
<p>[...]</p>
<p>With small business sites, this isn&#8217;t really that big a deal but with some of the enterprise-level clients you work with I wonder whether it becomes an issue.</p></blockquote>
<p>Rather than replying via email, I thought this might be a good topic for a blog post.</p>
<p>First off, I should mention that when clients come to <a href="http://crowdfavorite.com">Crowd Favorite</a>, it is often because they have already made a technology choice to use WordPress and have found us because of our reputation in working with WordPress. That said, we believe in using the right tool for the job.</p>
<p>Most often that tool is WordPress, but there are times when we suggest alternative solutions that are a better fit for their specific problem. We&#8217;ve used our Oxygen MVC platform for a number of client projects, sometimes in conjunction with a WordPress powered site.</p>
<p>One of the great benefits to using WordPress vs. a custom solution is that scaling WordPress is generally a solved problem. There are lots of smart folks who have figured this out and shared their knowledge within the community. We are very comfortable deploying high traffic sites on WordPress.</p>
<p>Scaling a custom application is often a journey of discovery. Sometimes this journey can be a bit rocky, and lonely. You will need to solve most of your problems on your own. This makes WordPress a safer choice when all other things are equal.</p>
<p>I&#8217;m on record saying I don&#8217;t believe WordPress is a good general application platform, but I think it&#8217;s wonderful for certain types of apps. Our developer journal, <a href="http://crowdfavorite.com/capsule/">Capsule</a> is a great example of this. We created a distributed journal app that can sync back to a central server/hub &#8211; all on WordPress. I&#8217;ve also created an HR logging system using WordPress. These have worked quite nicely.</p>
<p>At the end of the day, I believe in a pragmatic approach. The things that go into this decision include:</p>
<ul>
<li>comparing site needs to what WordPress does out of the box</li>
<li>consider known and projected future enhancements</li>
<li>consider potential scaling concerns</li>
<li>consider the importance of the community and lack of vendor lock-in to the client</li>
</ul>
<p>Happily, that means we choose WordPress much of the time.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 17:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WPTavern: How To Prevent WordPress From Participating In Pingback Denial of Service Attacks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18691";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:226:"http://wptavern.com/how-to-prevent-wordpress-from-participating-in-pingback-denial-of-service-attacks?utm_source=rss&utm_medium=rss&utm_campaign=how-to-prevent-wordpress-from-participating-in-pingback-denial-of-service-attacks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5274:"<p><a href="http://wptavern.com/wp-content/uploads/2011/11/sucurilogo.png" rel="prettyphoto[18691]"><img src="http://wptavern.com/wp-content/uploads/2011/11/sucurilogo.png" alt="SucuriLogo" width="100" height="34" class="alignright size-full wp-image-5763" /></a>Security research firm Sucuri is reporting more than <a title="http://blog.sucuri.net/2014/03/more-than-162000-wordpress-sites-used-for-distributed-denial-of-service-attack.html" href="http://blog.sucuri.net/2014/03/more-than-162000-wordpress-sites-used-for-distributed-denial-of-service-attack.html">162,000 WordPress sites were used</a> in a distributed denial of service attack. Compromised machines or websites are generally used to facilitate these types of attacks but in this case, clean WordPress sites were used via XML-RPC.</p>
<p><a title="http://codex.wordpress.org/XML-RPC_Support" href="http://codex.wordpress.org/XML-RPC_Support">XML-RPC</a> is used in WordPress as an API for third-party clients such as WordPress mobile apps, popular weblog clients like Windows Writer and popular plugins such as Jetpack. XML-RPC is used for pingbacks and trackbacks which are a good thing but can be heavily misused to start DDoS attacks.</p>
<blockquote><p>Just in the course of a few hours, over 162,000 different and legitimate WordPress sites tried to attack his site. We would likely have detected a lot more sites, but we decided we had seen enough and blocked the requests at the edge firewall, mostly to avoid filling the logs with junk.</p>
<p>One attacker can use thousands of popular and clean WordPress sites to perform their DDoS attack, while being hidden in the shadows, and that all happens with a simple ping back request to the XML-RPC file.</p></blockquote>
<p>To see if your site was misused, Sucuri has a <a title="http://labs.sucuri.net/?is-my-wordpress-ddosing" href="http://labs.sucuri.net/?is-my-wordpress-ddosing">DDoS scanner available</a>. Enter your domain into the field provided and the scanner will try to locate it within their log files. If the domain doesn&#8217;t show up, you know the site wasn&#8217;t used to attack others. Thankfully, WPTavern was not used to attack any other websites.</p>
<div id="attachment_18768" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/03/SucuriDDoSScanner.png" rel="prettyphoto[18691]"><img class="size-large wp-image-18768" alt="WPTavern Was Not Used To Attack Other Sites" src="http://wptavern.com/wp-content/uploads/2014/03/SucuriDDoSScanner-500x148.png" width="500" height="148" /></a><p class="wp-caption-text">WPTavern Was Not Used To Attack Other Sites</p></div>
<h3>Not As Easy As Turning Off XML-RPC</h3>
<p>Unfortunately, disabling XML-RPC presents more problems than solutions. Jetpack uses it to authenticate with WordPress.com and then uses it after the fact to communicate with the Jetpack powered site. It would also disable the ability to use any of the WordPress mobile apps to communicate with the site.</p>
<p>Automattic employee Alex Shiels, <a title="http://blog.sucuri.net/2014/03/more-than-162000-wordpress-sites-used-for-distributed-denial-of-service-attack.html#comment-1279325795" href="http://blog.sucuri.net/2014/03/more-than-162000-wordpress-sites-used-for-distributed-denial-of-service-attack.html#comment-1279325795">responded in the comments</a> of the article that they&#8217;ve identified the source of the pingbacks, and are looking to see if the Akismet plugin can help to prevent it. He also mentioned on Twitter the security team is working on a solution.</p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/dialogCRM">@dialogCRM</a> the security team is working on solutions. It\'s tricky.</p>
<p>&mdash; Alex Shiels (@tellyworth) <a href="https://twitter.com/tellyworth/statuses/443212073967685632">March 11, 2014</a></p></blockquote>
<p></p>
<h3>How To Disable Only Pingbacks</h3>
<p>While Sucuri has a code snippet you can add to turn off only the pingback functionality of XML-RPC, I was told it will severely effect WordPress sites running on PHP 5.2 due to using an anonymous function. The following code snippet will work correctly without any adverse effects. It disables pingbacks while allowing things like Jetpack and WordPress mobile apps to function normally. Add the code to your theme&#8217;s functions.php file.</p>
<pre class="brush: php; title: ; notranslate">
add_filter( \'xmlrpc_methods\', \'remove_xmlrpc_pingback_ping\' );
function remove_xmlrpc_pingback_ping( $methods ) {
   unset( $methods[\'pingback.ping\'] );
   return $methods;
} ;
</pre>
<h3>Is It Time For Pingbacks and Trackbacks To Go?</h3>
<p>WPTavern is no stranger to denial of service attacks due to pingbacks and trackbacks. In 2010, I explained how <a title="http://wptavern.com/wptavern-was-trackbacked-to-death" href="http://wptavern.com/wptavern-was-trackbacked-to-death">WPTavern was trackbacked to death</a>. Shortly after the website came back online, I disabled both as I feared they might end up taking the site down again. A few years have gone by and I&#8217;ve re-enabled pingbacks and trackbacks with no ill effects. However, I wonder if it&#8217;s time to kill them once and for all, not just on WPTavern but in WordPress in general.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 17:06:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"Ping-O-Matic: Grow Your Traffic, Build Your Blog: A Free Ebook";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://blog.pingomatic.com/?p=103";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://blog.pingomatic.com/2014/03/12/growth-traffic-ebook/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1532:"<p>Are you looking for advice on how to grow your audience and attract new readers? Do you want to capitalize on your social networks and build a strategic online presence? Are you interested in honing your personal brand?</p>
<p>For those of you interested in blog and website growth, the folks at <em>The Daily Post </em>published a free ebook: <a href="http://dailypost.wordpress.com/postaday/ebook-grow-traffic/" target="_blank"><em>Grow Your Traffic, Build Your Blog</em></a>.</p>
<p>While the ebook is targeted to people with blogs and websites hosted on WordPress.com, it&#8217;s packed with lots of general information on growth and traffic &#8212; and is a great resource for people writing and publishing on any kind of site.</p>
<p>You can <a href="http://dailypost.wordpress.com/postaday/ebook-grow-traffic/" target="_blank">download it from the ebook page</a> in pdf, mobi, and epub formats.</p>
<p><a href="http://dailypost.wordpress.com/postaday/ebook-grow-traffic/"><img class="aligncenter size-large wp-image-104" alt="traffic-featured-image" src="http://pingomatic.files.wordpress.com/2014/03/traffic-featured-image.gif?w=600&h=380" /></a></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/pingomatic.wordpress.com/103/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/pingomatic.wordpress.com/103/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.pingomatic.com&blog=68432&post=103&subd=pingomatic&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 16:00:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:20:"Cheri Lucas Rowlands";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WordPress.tv: Troy Dean: 101 Ways to Elevate Yourself And Demand Higher Fees";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32885";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://wordpress.tv/2014/03/12/troy-dean-101-ways-to-elevate-yourself-and-demand-higher-fees-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:709:"<div id="v-r0utatEu-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32885/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32885/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32885&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/03/12/troy-dean-101-ways-to-elevate-yourself-and-demand-higher-fees-2/"><img alt="Troy Dean: 101 Ways to Elevate Yourself And Demand Higher Fees" src="http://videos.videopress.com/r0utatEu/video-4ab4922e33_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 12 Mar 2014 14:38:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: WordPress Beta Testers, Start Your Engines: 3.9 Beta 1 Released";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=18729";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:186:"http://wptavern.com/wordpress-beta-testers-start-your-engines-3-9-beta-1-released?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-beta-testers-start-your-engines-3-9-beta-1-released";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4613:"<div id="attachment_17801" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2014/02/wordpress-swag.jpg" rel="prettyphoto[18729]"><img src="http://wptavern.com/wp-content/uploads/2014/02/wordpress-swag.jpg" alt="photo credit: Huasonic - cc" width="1024" height="441" class="size-full wp-image-17801" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/huasonic/3008912290/">Huasonic</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc/2.0/">cc</a></p></div>
<p>If it&#8217;s true that the best gifts come in small packages, then WordPress 3.9 is set to be a stellar release. It&#8217;s full of tiny improvements that improve the publishing experience, especially when it comes to editing content. You can now check it out first-hand, since 3.9 Beta 1 was released today. The official release is <a href="http://make.wordpress.org/core/version-3-9-project-schedule/" target="_blank">scheduled</a> to drop during the week of April 14th. Andrew Nacin <a href="http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/" target="_blank">announced</a> the beta with the customary haiku, which nicely sums up what you&#8217;ll find in 3.9:</p>
<blockquote><p>Lots of improvements<br />
Little things go a long way<br />
Please test beta one</p></blockquote>
<p>There are some exciting new features coming in 3.9, but a good portion of core development has also been dedicated to iterating on features introduced in previous releases. Nacin summarized a few of the major new items that need testing:</p>
<ul>
<li>Updated to TinyMCE 4.0</li>
<li>Widget customizer now rolled into core for live previews while managing widgets</li>
<li>WP 3.8&#8242;s theme browsing experience extended to the theme installer</li>
<li>Live preview for galleries in the editor &#8211; no more placeholder</li>
<li>Drag-and-drop images directly onto the editor to upload</li>
<li>Multiple improvements to image editing</li>
<li>New audio/video playlists</li>
</ul>
<p>Nacin asked WordPress users what they&#8217;re most excited about for WordPress 3.9 and here are a few responses from the community:</p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/nacin">@nacin</a> it\'s small, but i love the improvements to editing images and no more new windows. sometimes it\'s the little things.</p>
<p>&mdash; David Bisset (@dimensionmedia) <a href="https://twitter.com/dimensionmedia/statuses/443468910806204416">March 11, 2014</a></p></blockquote>
<p></p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/nacin">@nacin</a> Bringing external js libraries up to their current release versions? <a href="https://twitter.com/search?q=%23butimjustweird&src=hash">#butimjustweird</a></p>
<p>&mdash; George Stephanis (@daljo628) <a href="https://twitter.com/daljo628/statuses/443468595360956417">March 11, 2014</a></p></blockquote>
<p></p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/nacin">@nacin</a> the ability to position cropped images. It\'s a small but very useful. I\'m sure others will point out the major features ;)</p>
<p>&mdash; Syed Balkhi (@syedbalkhi) <a href="https://twitter.com/syedbalkhi/statuses/443469606842556416">March 11, 2014</a></p></blockquote>
<p></p>
<h3>How to Test a WordPress Beta Release</h3>
<p>All of these enhancements need to be tested, as some are still a little rough around the edges. <strong>You don&#8217;t have to be an expert developer to get on board to test the upcoming 3.9 release.</strong> All you need is a test environment. Install the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/" target="_blank">WordPress Beta Tester</a> plugin and select &#8220;bleeding edge nightlies.&#8221; Alternatively, you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip" target="_blank">simply download the zip file for the beta</a>.</p>
<p>If you think you&#8217;ve found a bug, feel free to post it on the<a href="http://wordpress.org/support/forum/alphabeta" target="_blank"> Alpha/Beta forum</a>. That is the easiest entry point for testing the beta and being part of making it better. If you&#8217;re able to <a href="http://make.wordpress.org/core/handbook/reporting-bugs/" target="_blank">submit a bug</a> on <a href="https://make.wordpress.org/core/reports/" target="_blank">WordPress core trac</a>, that&#8217;s even better. For more details on the specific issues to test, make sure to check out the <a href="http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/" target="_blank">3.9 Beta 1 announcement post</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 20:08:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 20 Mar 2014 15:22:46 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"190714";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 20 Mar 2014 15:00:13 GMT";s:4:"x-nc";s:11:"HIT lax 249";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('1210', '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1395372167', 'no'); 
INSERT INTO `wp_options` VALUES ('1211', '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1395328967', 'no'); 
INSERT INTO `wp_options` VALUES ('1212', '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1395372167', 'no'); 
INSERT INTO `wp_options` VALUES ('1213', '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 14:59:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:120:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 9 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Better WP Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:107:"The easiest, most effective way to secure WordPress. Improve the security of any WordPress site in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Google Analytics for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2316@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:145:"Track your WordPress site easily and with lots of metadata: views per author &#38; category, automatic tracking of outbound clicks and pageviews.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:8:"Facebook";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/plugins/facebook/#post-37351";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 02 May 2012 19:36:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"37351@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Add Facebook social plugins and the ability to publish new posts to a Facebook Timeline or Facebook Page. Official Facebook plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:18:"Samuel Wood (Otto)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Captcha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/captcha/#post-26129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Apr 2011 05:53:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26129@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"This plugin allows you to implement super security captcha form into web forms.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"50539@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Displays Google Analytics Reports and Real-Time Statistics in your Dashboard. Automatically inserts the tracking code in every page of your website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 20 Mar 2014 15:22:49 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Thu, 20 Mar 2014 15:34:42 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Thu, 20 Mar 2014 14:59:42 +0000";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('1214', '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1395372168', 'no'); 
INSERT INTO `wp_options` VALUES ('1215', '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1395328968', 'no'); 
INSERT INTO `wp_options` VALUES ('1216', '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1395372168', 'no'); 
INSERT INTO `wp_options` VALUES ('1217', '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/\' title=\'WordPress 3.9 Beta 2 is now available for testing! We’ve made more than a hundred changes since Beta 1, but we still need your help if we’re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in […]\'>WordPress 3.9 Beta 2</a> <span class="rss-date">20 de março de 2014</span><div class=\'rssSummary\'>WordPress 3.9 Beta 2 is now available for testing! We’ve made more than a hundred changes since Beta 1, but we still need your help if we’re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in […]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/creativemarket-acquired-by-the-makers-of-autocad?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=creativemarket-acquired-by-the-makers-of-autocad\' title=\'CreativeMarket, one of the first WordPress theme marketplaces to fully support the GPL license has been acquired by Autodesk, for an undisclosed amount. The marketplace sells everything from themes to templates to fonts. The site became one of the first marketplaces to be advertised on WordPress.org after they announced they would only sell WordPress themes that are 100% GPL. It’s worth noting that Matt Mullenweg is an investor of  CreativeMarket. According to the announcement, the entire team will join Autodesk with the company’s co-founders moving to San Francisco to continue their goal of selling creative products. What does this mean for the community? For customers, it means access to even more high quality content at affordable prices, as we’re able to grow more quickly. For shop owners, it means we’ll have a larger platform to get your products in front of an even larger audience of customers. The acquisition is just one of a few that’s happened within the WordPress community as of late. The most recent acquisition was Crowd Favorite acquiring Pixel Jar. Does this mean we’ll start seeing modeling products and three-dimensional themes for sale on CreativeMarket or will the marketplace expand to include more categories of products? Only time will tell. What do you think of the acquisition? Does it make sense to you? Let us know in the comments.\'>WPTavern: CreativeMarket Acquired By The Makers Of AutoCAD</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/wordpress-plugin-repository-now-hosts-over-30000-plugins?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=wordpress-plugin-repository-now-hosts-over-30000-plugins\' title=\'Early this morning, the WordPress.org plugin repository set a mile stone by hosting the 30,000th plugin. I didn’t think it would happen until a few weeks from now but it shows you how many plugins are approved and added to the repository every day.  Jan Reimers on Twitter celebrated with a whoop! I second that remark. 30.000 Plugins on https://t.co/xg9XCQo6am whoop! pic.twitter.com/IAAFgp2SpG — jan reimers (@reimersjan) March 20, 2014  The honors go to a plugin called BestWebSoft Google Maps for being the 30,000th plugin to be added to the repository. According to the plugin’s description, it allows you to configure Google Maps and add them to your site quickly and easily. Congratulations to the WordPress plugin repository and especially to the WordPress community for continuing to share your problem solving plugins with the rest of the world. Any guesses on when the repository will cross 40,000 plugins?\'>WPTavern: WordPress Plugin Repository Now Hosts Over 30,000 Plugins</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/\' title=\'WordPress 3.9 Beta 2 is now available for testing! We’ve made more than a hundred changes since Beta 1, but we still need your help if we’re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in Beta 2 include:  Rendering of embedded audio and video players directly in the visual editor. Visual and functional improvements to the editor, the media manager, and theme installer. Various bug fixes to TinyMCE, the software behind the visual editor. Lots of fixes to widget management in the theme customizer.  As always, if you think you’ve found a bug, you can post to the Alpha/Beta area in the support forums. Or, if you’re comfortable writing a reproducible bug report, file one on the WordPress Trac. There, you can also find a list of known bugs and everything we’ve fixed so far. This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download the beta here (zip).\'>Dev Blog: WordPress 3.9 Beta 2</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Plugins populares:</span> <a href=\'http://wordpress.org/plugins/jetpack/\' class=\'dashboard-news-plugin-link\'>Jetpack by WordPress.com</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=jetpack&amp;_wpnonce=6f5af77697&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Jetpack by WordPress.com\'>Instalar</a>)</span></li></ul></div>', 'no'); 
INSERT INTO `wp_options` VALUES ('1241', 'widget_pages', 'a:2:{i:2;a:3:{s:5:"title";s:6:"TESSSS";s:6:"sortby";s:10:"post_title";s:7:"exclude";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1253', '_transient_is_multi_author', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1257', '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1395344958', 'yes'); 
INSERT INTO `wp_options` VALUES ('1258', '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1271', '_site_transient_timeout_theme_roots', '1395339413', 'yes'); 
INSERT INTO `wp_options` VALUES ('1272', '_site_transient_theme_roots', 'a:1:{s:12:"twentytwelve";s:7:"/themes";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1273', '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1395343408;s:7:"checked";a:25:{s:29:"ads-by-datafeedrcom/dfads.php";s:6:"1.0.10";s:30:"advanced-custom-fields/acf.php";s:5:"4.3.5";s:19:"akismet/akismet.php";s:5:"2.6.0";s:51:"auto-excerpt-everywhere/auto-excerpt-everywhere.php";s:3:"1.5";s:41:"better-wp-security/better-wp-security.php";s:5:"3.6.6";s:43:"broken-link-checker/broken-link-checker.php";s:5:"1.9.2";s:85:"carousel-horizontal-posts-content-slider/carousel-horizontal-posts-content-slider.php";s:3:"3.0";s:25:"cloudflare/cloudflare.php";s:6:"1.3.13";s:36:"contact-form-7/wp-contact-form-7.php";s:5:"3.7.2";s:33:"events-manager/events-manager.php";s:5:"5.5.2";s:45:"ewww-image-optimizer/ewww-image-optimizer.php";s:5:"1.8.4";s:43:"google-analytics-dashboard-for-wp/gadwp.php";s:6:"4.2.12";s:50:"google-analytics-for-wordpress/googleanalytics.php";s:5:"4.3.5";s:36:"google-sitemap-generator/sitemap.php";s:3:"3.4";s:9:"hello.php";s:3:"1.6";s:29:"ready-backup/backup-ready.php";s:5:"0.4.1";s:33:"seo-image/seo-friendly-images.php";s:5:"2.7.6";s:33:"smart-slider-2/smart-slider-2.php";s:5:"2.3.7";s:37:"user-role-editor/user-role-editor.php";s:4:"4.10";s:29:"user-status-manager/start.php";s:5:"2.1.2";s:33:"w3-total-cache/w3-total-cache.php";s:5:"0.9.3";s:37:"widgets-on-pages/widgets_on_pages.php";s:6:"0.0.12";s:27:"woocommerce/woocommerce.php";s:5:"2.1.5";s:27:"wp-optimize/wp-optimize.php";s:5:"1.6.1";s:31:"wp-backupware/wp-backupware.php";s:5:"1.2.1";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1274', 'wop_options_field', 'a:4:{s:10:"enable_css";s:1:"1";s:19:"num_of_wop_sidebars";s:1:"1";s:10:"wop_name_1";s:16:"Sidebar Esquerdo";s:10:"wop_name_2";s:15:"Sidebar Direito";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1285', 'wpbu_schedule_settings', 'a:2:{s:16:"backup_frequency";s:5:"daily";s:11:"backup_type";s:8:"database";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1286', '_transient_timeout_settings_errors', '1395343580', 'no'); 
INSERT INTO `wp_options` VALUES ('1287', '_transient_settings_errors', 'a:1:{i:0;a:4:{s:7:"setting";s:7:"general";s:4:"code";s:16:"settings_updated";s:7:"message";s:16:"Opções salvas.";s:4:"type";s:7:"updated";}}', 'no'); 
INSERT INTO `wp_options` VALUES ('1288', '_transient_doing_cron', '1395343552.9165298938751220703125', 'yes'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_postmeta`
--
DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=393 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_postmeta`
--
LOCK TABLES `wp_postmeta` WRITE;
INSERT INTO `wp_postmeta` VALUES ('1', '2', '_wp_page_template', 'page-templates/front-page.php'); 
INSERT INTO `wp_postmeta` VALUES ('2', '4', '_form', '<p>Seu nome (obrigatório)<br />
    [text* your-name] </p>

<p>Seu e-mail (obrigatório)<br />
    [email* your-email] </p>

<p>Assunto<br />
    [text your-subject] </p>

<p>Sua mensagem<br />
    [textarea your-message] </p>

<p>[submit "Enviar"]</p>'); 
INSERT INTO `wp_postmeta` VALUES ('3', '4', '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:201:"De: [your-name] <[your-email]>
Assunto: [your-subject]

Corpo da mensagem:
[your-message]

--
Este e-mail foi enviado de um formulário de contato em Asug | SAP NetWeaver Portal (http://127.0.0.1/asug)";s:9:"recipient";s:25:"contato@montarsite.com.br";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('4', '4', '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:145:"Corpo da mensagem:
[your-message]

--
Este e-mail foi enviado de um formulário de contato em Asug | SAP NetWeaver Portal (http://127.0.0.1/asug)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('5', '4', '_messages', 'a:6:{s:12:"mail_sent_ok";s:47:"Sua mensagem foi enviada com sucesso. Obrigado.";s:12:"mail_sent_ng";s:115:"Não foi possível enviar a sua mensagem. Por favor, tente mais tarde ou contate o administrador por outro método.";s:16:"validation_error";s:77:"Ocorreram erros de validação. Por favor confira os dados e envie novamente.";s:4:"spam";s:115:"Não foi possível enviar a sua mensagem. Por favor, tente mais tarde ou contate o administrador por outro método.";s:12:"accept_terms";s:43:"Por favor aceite os termos para prosseguir.";s:16:"invalid_required";s:43:"Por favor preencha este campo obrigatório.";}'); 
INSERT INTO `wp_postmeta` VALUES ('6', '4', '_additional_settings', ''); 
INSERT INTO `wp_postmeta` VALUES ('7', '4', '_locale', 'pt_BR'); 
INSERT INTO `wp_postmeta` VALUES ('8', '2', '_edit_lock', '1394945680:1'); 
INSERT INTO `wp_postmeta` VALUES ('9', '2', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('10', '2', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('11', '6', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('12', '6', '_edit_lock', '1394901177:1'); 
INSERT INTO `wp_postmeta` VALUES ('13', '6', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('14', '6', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('15', '8', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('16', '8', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('17', '8', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('18', '8', '_edit_lock', '1394901197:1'); 
INSERT INTO `wp_postmeta` VALUES ('19', '10', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('20', '10', '_edit_lock', '1394901225:1'); 
INSERT INTO `wp_postmeta` VALUES ('21', '10', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('22', '10', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('23', '12', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('24', '12', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('25', '12', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('26', '12', '_edit_lock', '1394901239:1'); 
INSERT INTO `wp_postmeta` VALUES ('27', '14', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('28', '14', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('29', '14', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('30', '14', '_edit_lock', '1394901253:1'); 
INSERT INTO `wp_postmeta` VALUES ('31', '16', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('32', '16', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('33', '16', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('34', '16', '_edit_lock', '1394901293:1'); 
INSERT INTO `wp_postmeta` VALUES ('35', '18', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('36', '18', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('37', '18', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('38', '18', '_edit_lock', '1394901318:1'); 
INSERT INTO `wp_postmeta` VALUES ('39', '20', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('40', '20', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('41', '20', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('42', '20', '_edit_lock', '1394901339:1'); 
INSERT INTO `wp_postmeta` VALUES ('43', '22', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('44', '22', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('45', '22', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('46', '22', '_edit_lock', '1394901388:1'); 
INSERT INTO `wp_postmeta` VALUES ('47', '24', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('48', '24', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('49', '24', '_menu_item_object_id', '2'); 
INSERT INTO `wp_postmeta` VALUES ('50', '24', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('51', '24', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('52', '24', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('53', '24', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('54', '24', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('55', '24', '_menu_item_orphaned', '1394901506'); 
INSERT INTO `wp_postmeta` VALUES ('56', '25', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('57', '25', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('58', '25', '_menu_item_object_id', '12'); 
INSERT INTO `wp_postmeta` VALUES ('59', '25', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('60', '25', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('61', '25', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('62', '25', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('63', '25', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('64', '25', '_menu_item_orphaned', '1394901506'); 
INSERT INTO `wp_postmeta` VALUES ('65', '26', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('66', '26', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('67', '26', '_menu_item_object_id', '8'); 
INSERT INTO `wp_postmeta` VALUES ('68', '26', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('69', '26', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('70', '26', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('71', '26', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('72', '26', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('73', '26', '_menu_item_orphaned', '1394901506'); 
INSERT INTO `wp_postmeta` VALUES ('74', '27', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('75', '27', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('76', '27', '_menu_item_object_id', '20'); 
INSERT INTO `wp_postmeta` VALUES ('77', '27', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('78', '27', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('79', '27', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('80', '27', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('81', '27', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('82', '27', '_menu_item_orphaned', '1394901506'); 
INSERT INTO `wp_postmeta` VALUES ('83', '28', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('84', '28', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('85', '28', '_menu_item_object_id', '22'); 
INSERT INTO `wp_postmeta` VALUES ('86', '28', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('87', '28', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('88', '28', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('89', '28', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('90', '28', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('91', '28', '_menu_item_orphaned', '1394901507'); 
INSERT INTO `wp_postmeta` VALUES ('92', '29', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('93', '29', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('94', '29', '_menu_item_object_id', '16'); 
INSERT INTO `wp_postmeta` VALUES ('95', '29', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('96', '29', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('97', '29', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('98', '29', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('99', '29', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('100', '29', '_menu_item_orphaned', '1394901507'); 
INSERT INTO `wp_postmeta` VALUES ('101', '30', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('102', '30', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('103', '30', '_menu_item_object_id', '14'); 
INSERT INTO `wp_postmeta` VALUES ('104', '30', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('105', '30', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('106', '30', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('107', '30', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('108', '30', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('109', '30', '_menu_item_orphaned', '1394901507'); 
INSERT INTO `wp_postmeta` VALUES ('110', '31', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('111', '31', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('112', '31', '_menu_item_object_id', '10'); 
INSERT INTO `wp_postmeta` VALUES ('113', '31', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('114', '31', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('115', '31', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('116', '31', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('117', '31', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('118', '31', '_menu_item_orphaned', '1394901508'); 
INSERT INTO `wp_postmeta` VALUES ('119', '32', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('120', '32', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('121', '32', '_menu_item_object_id', '2'); 
INSERT INTO `wp_postmeta` VALUES ('122', '32', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('123', '32', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('124', '32', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('125', '32', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('126', '32', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('127', '32', '_menu_item_orphaned', '1394901508'); 
INSERT INTO `wp_postmeta` VALUES ('128', '33', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('129', '33', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('130', '33', '_menu_item_object_id', '18'); 
INSERT INTO `wp_postmeta` VALUES ('131', '33', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('132', '33', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('133', '33', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('134', '33', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('135', '33', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('136', '33', '_menu_item_orphaned', '1394901508'); 
INSERT INTO `wp_postmeta` VALUES ('137', '34', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('138', '34', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('139', '34', '_menu_item_object_id', '6'); 
INSERT INTO `wp_postmeta` VALUES ('140', '34', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('141', '34', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('142', '34', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('143', '34', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('144', '34', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('145', '34', '_menu_item_orphaned', '1394901509'); 
INSERT INTO `wp_postmeta` VALUES ('146', '35', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('147', '35', '_edit_lock', '1394901437:1'); 
INSERT INTO `wp_postmeta` VALUES ('148', '35', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('149', '35', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('150', '37', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('151', '37', '_edit_lock', '1395343512:1'); 
INSERT INTO `wp_postmeta` VALUES ('152', '37', '_wp_page_template', 'page-templates/sidebar-esquerda.php'); 
INSERT INTO `wp_postmeta` VALUES ('153', '37', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('154', '39', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('155', '39', '_wp_page_template', 'page-templates/tres-colunas.php'); 
INSERT INTO `wp_postmeta` VALUES ('156', '39', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('157', '39', '_edit_lock', '1395337006:1'); 
INSERT INTO `wp_postmeta` VALUES ('158', '41', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('159', '41', '_edit_lock', '1395343282:1'); 
INSERT INTO `wp_postmeta` VALUES ('160', '41', '_wp_page_template', 'page-templates/sidebar-direita.php'); 
INSERT INTO `wp_postmeta` VALUES ('161', '41', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('162', '43', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('163', '43', '_edit_lock', '1395343283:1'); 
INSERT INTO `wp_postmeta` VALUES ('164', '43', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('165', '43', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('166', '45', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('167', '45', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('168', '45', '_menu_item_object_id', '2'); 
INSERT INTO `wp_postmeta` VALUES ('169', '45', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('170', '45', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('171', '45', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('172', '45', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('173', '45', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('175', '46', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('176', '46', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('177', '46', '_menu_item_object_id', '12'); 
INSERT INTO `wp_postmeta` VALUES ('178', '46', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('179', '46', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('180', '46', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('181', '46', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('182', '46', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('184', '47', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('185', '47', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('186', '47', '_menu_item_object_id', '8'); 
INSERT INTO `wp_postmeta` VALUES ('187', '47', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('188', '47', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('189', '47', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('190', '47', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('191', '47', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('193', '48', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('194', '48', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('195', '48', '_menu_item_object_id', '20'); 
INSERT INTO `wp_postmeta` VALUES ('196', '48', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('197', '48', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('198', '48', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('199', '48', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('200', '48', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('202', '49', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('203', '49', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('204', '49', '_menu_item_object_id', '22'); 
INSERT INTO `wp_postmeta` VALUES ('205', '49', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('206', '49', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('207', '49', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('208', '49', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('209', '49', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('211', '50', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('212', '50', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('213', '50', '_menu_item_object_id', '16'); 
INSERT INTO `wp_postmeta` VALUES ('214', '50', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('215', '50', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('216', '50', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('217', '50', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('218', '50', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('220', '51', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('221', '51', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('222', '51', '_menu_item_object_id', '14'); 
INSERT INTO `wp_postmeta` VALUES ('223', '51', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('224', '51', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('225', '51', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('226', '51', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('227', '51', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('229', '52', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('230', '52', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('231', '52', '_menu_item_object_id', '10'); 
INSERT INTO `wp_postmeta` VALUES ('232', '52', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('233', '52', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('234', '52', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('235', '52', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('236', '52', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('247', '54', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('248', '54', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('249', '54', '_menu_item_object_id', '18'); 
INSERT INTO `wp_postmeta` VALUES ('250', '54', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('251', '54', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('252', '54', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('253', '54', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('254', '54', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('256', '55', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('257', '55', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('258', '55', '_menu_item_object_id', '6'); 
INSERT INTO `wp_postmeta` VALUES ('259', '55', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('260', '55', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('261', '55', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('262', '55', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('263', '55', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('265', '56', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('266', '56', '_menu_item_menu_item_parent', '55'); 
INSERT INTO `wp_postmeta` VALUES ('267', '56', '_menu_item_object_id', '39'); 
INSERT INTO `wp_postmeta` VALUES ('268', '56', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('269', '56', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('270', '56', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('271', '56', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('272', '56', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('274', '57', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('275', '57', '_menu_item_menu_item_parent', '55'); 
INSERT INTO `wp_postmeta` VALUES ('276', '57', '_menu_item_object_id', '37'); 
INSERT INTO `wp_postmeta` VALUES ('277', '57', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('278', '57', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('279', '57', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('280', '57', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('281', '57', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('283', '58', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('284', '58', '_menu_item_menu_item_parent', '55'); 
INSERT INTO `wp_postmeta` VALUES ('285', '58', '_menu_item_object_id', '35'); 
INSERT INTO `wp_postmeta` VALUES ('286', '58', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('287', '58', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('288', '58', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('289', '58', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('290', '58', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('292', '59', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('293', '59', '_menu_item_menu_item_parent', '55'); 
INSERT INTO `wp_postmeta` VALUES ('294', '59', '_menu_item_object_id', '41'); 
INSERT INTO `wp_postmeta` VALUES ('295', '59', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('296', '59', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('297', '59', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('298', '59', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('299', '59', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('301', '60', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('302', '60', '_menu_item_menu_item_parent', '55'); 
INSERT INTO `wp_postmeta` VALUES ('303', '60', '_menu_item_object_id', '43'); 
INSERT INTO `wp_postmeta` VALUES ('304', '60', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('305', '60', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('306', '60', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('307', '60', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('308', '60', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('310', '61', '_wp_attached_file', '2014/03/asug-brasil.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('311', '61', '_wp_attachment_context', 'custom-header'); 
INSERT INTO `wp_postmeta` VALUES ('312', '61', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:229;s:6:"height";i:76;s:4:"file";s:23:"2014/03/asug-brasil.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:22:"asug-brasil-150x76.jpg";s:5:"width";i:150;s:6:"height";i:76;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('313', '61', '_wp_attachment_is_custom_header', 'twentytwelve'); 
INSERT INTO `wp_postmeta` VALUES ('314', '63', '_wp_attached_file', '2014/03/slider.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('315', '63', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:542;s:6:"height";i:250;s:4:"file";s:18:"2014/03/slider.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"slider-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:18:"slider-300x138.jpg";s:5:"width";i:300;s:6:"height";i:138;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('316', '64', '_wp_attached_file', '2014/03/banner03.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('317', '64', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:235;s:6:"height";i:121;s:4:"file";s:20:"2014/03/banner03.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"banner03-150x121.jpg";s:5:"width";i:150;s:6:"height";i:121;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('318', '65', '_wp_attached_file', '2014/03/banner04.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('319', '65', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:235;s:6:"height";i:121;s:4:"file";s:20:"2014/03/banner04.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"banner04-150x121.jpg";s:5:"width";i:150;s:6:"height";i:121;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('320', '66', '_wp_attached_file', '2014/03/banner01.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('321', '66', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:235;s:6:"height";i:122;s:4:"file";s:20:"2014/03/banner01.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"banner01-150x122.jpg";s:5:"width";i:150;s:6:"height";i:122;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('322', '67', '_wp_attached_file', '2014/03/banner02.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('323', '67', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:234;s:6:"height";i:122;s:4:"file";s:20:"2014/03/banner02.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"banner02-150x122.jpg";s:5:"width";i:150;s:6:"height";i:122;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('324', '68', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('325', '68', '_edit_lock', '1394950263:1'); 
INSERT INTO `wp_postmeta` VALUES ('326', '68', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('327', '68', '_dfads_start_date', '1394928000'); 
INSERT INTO `wp_postmeta` VALUES ('328', '68', '_dfads_end_date', '1430352000'); 
INSERT INTO `wp_postmeta` VALUES ('329', '68', '_dfads_impression_limit', '90000'); 
INSERT INTO `wp_postmeta` VALUES ('330', '68', '_dfads_impression_count', '190'); 
INSERT INTO `wp_postmeta` VALUES ('331', '70', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('332', '70', '_edit_lock', '1394950319:1'); 
INSERT INTO `wp_postmeta` VALUES ('333', '70', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('334', '70', '_dfads_impression_limit', '0'); 
INSERT INTO `wp_postmeta` VALUES ('335', '70', '_dfads_impression_count', '189'); 
INSERT INTO `wp_postmeta` VALUES ('336', '72', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('337', '72', '_edit_lock', '1394950356:1'); 
INSERT INTO `wp_postmeta` VALUES ('338', '72', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('339', '72', '_dfads_impression_limit', '0'); 
INSERT INTO `wp_postmeta` VALUES ('340', '74', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('341', '74', '_edit_lock', '1395233203:1'); 
INSERT INTO `wp_postmeta` VALUES ('342', '74', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('343', '74', '_dfads_impression_limit', '0'); 
INSERT INTO `wp_postmeta` VALUES ('344', '72', '_dfads_impression_count', '188'); 
INSERT INTO `wp_postmeta` VALUES ('345', '74', '_dfads_impression_count', '188'); 
INSERT INTO `wp_postmeta` VALUES ('346', '76', '_menu_item_type', 'custom'); 
INSERT INTO `wp_postmeta` VALUES ('347', '76', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('348', '76', '_menu_item_object_id', '76'); 
INSERT INTO `wp_postmeta` VALUES ('349', '76', '_menu_item_object', 'custom'); 
INSERT INTO `wp_postmeta` VALUES ('350', '76', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('351', '76', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('352', '76', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('353', '76', '_menu_item_url', '#'); 
INSERT INTO `wp_postmeta` VALUES ('355', '77', '_wp_attached_file', '2014/03/eventos01.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('356', '77', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:149;s:6:"height";i:90;s:4:"file";s:21:"2014/03/eventos01.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('357', '78', '_wp_attached_file', '2014/03/eventos02.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('358', '78', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:149;s:6:"height";i:90;s:4:"file";s:21:"2014/03/eventos02.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('359', '1', '_edit_lock', '1395013435:1'); 
INSERT INTO `wp_postmeta` VALUES ('360', '86', '_wp_attached_file', '2014/03/eventos011.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('361', '86', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:149;s:6:"height";i:90;s:4:"file";s:22:"2014/03/eventos011.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('362', '87', '_wp_attached_file', '2014/03/eventos021.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('363', '87', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:149;s:6:"height";i:90;s:4:"file";s:22:"2014/03/eventos021.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('364', '1', '_thumbnail_id', '87'); 
INSERT INTO `wp_postmeta` VALUES ('365', '1', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('368', '1', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('369', '1', '_wp_old_slug', 'ola-mundo'); 
INSERT INTO `wp_postmeta` VALUES ('370', '90', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('371', '90', '_edit_lock', '1395013464:1'); 
INSERT INTO `wp_postmeta` VALUES ('372', '90', '_thumbnail_id', '86'); 
INSERT INTO `wp_postmeta` VALUES ('375', '90', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('376', '92', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('377', '92', '_edit_lock', '1395013492:1'); 
INSERT INTO `wp_postmeta` VALUES ('378', '92', '_thumbnail_id', '77'); 
INSERT INTO `wp_postmeta` VALUES ('381', '92', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('382', '94', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('383', '94', '_edit_lock', '1395013632:1'); 
INSERT INTO `wp_postmeta` VALUES ('384', '94', '_thumbnail_id', '78'); 
INSERT INTO `wp_postmeta` VALUES ('387', '94', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('388', '106', '_edit_lock', '1395285520:1'); 
INSERT INTO `wp_postmeta` VALUES ('389', '107', '_edit_lock', '1395285587:1'); 
INSERT INTO `wp_postmeta` VALUES ('390', '108', '_edit_lock', '1395285387:1'); 
INSERT INTO `wp_postmeta` VALUES ('391', '109', '_edit_lock', '1395329147:1'); 
INSERT INTO `wp_postmeta` VALUES ('392', '110', '_edit_lock', '1395329908:1'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_posts`
--
DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_posts`
--
LOCK TABLES `wp_posts` WRITE;
INSERT INTO `wp_posts` VALUES ('1', '1', '2014-03-15 15:51:25', '2014-03-15 15:51:25', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG Day Porto Alegre 2013', '', 'publish', 'open', 'open', '', 'asug-day-porto-alegre-2013', '', '', '2014-03-16 23:45:36', '2014-03-16 23:45:36', '', '0', 'http://127.0.0.1/asug/?p=1', '0', 'post', '', '1'); 
INSERT INTO `wp_posts` VALUES ('2', '1', '2014-03-15 15:51:25', '2014-03-15 15:51:25', 'Esta é uma página de exemplo. É diferente de um post porque ela ficará em um local e será exibida na navegação do seu site (na maioria dos temas). A maioria das pessoas começa com uma página de introdução aos potenciais visitantes do site. Ela pode ser assim:
<blockquote>Olá! Eu sou um bike courrier de dia, ator amador à noite e este é meu blog. Eu moro em São Paulo, tenho um cachorro chamado Tonico e eu gosto de caipirinhas. (E de ser pego pela chuva.)</blockquote>
ou assim:
<blockquote>A XYZ foi fundada em 1971 e desde então vem proporcionando produtos de qualidade a seus clientes. Localizada em Valinhos, XYZ emprega mais de 2.000 pessoas e faz várias contribuições para a comunidade local.</blockquote>
Como um novo usuário do WordPress, você deve ir até o <a href="http://127.0.0.1/asug/wp-admin/">seu painel</a> para excluir essa página e criar novas páginas com seu próprio conteúdo. Divirta-se!', 'Home', '', 'publish', 'open', 'open', '', 'pagina-exemplo', '', '', '2014-03-16 04:44:31', '2014-03-16 04:44:31', '', '0', 'http://127.0.0.1/asug/?page_id=2', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('3', '1', '2014-03-15 15:51:55', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-03-15 15:51:55', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=3', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('4', '1', '2014-03-15 15:55:31', '2014-03-15 15:55:31', '<p>Seu nome (obrigatório)<br />
    [text* your-name] </p>

<p>Seu e-mail (obrigatório)<br />
    [email* your-email] </p>

<p>Assunto<br />
    [text your-subject] </p>

<p>Sua mensagem<br />
    [textarea your-message] </p>

<p>[submit "Enviar"]</p>
[your-subject]
[your-name] <[your-email]>
De: [your-name] <[your-email]>
Assunto: [your-subject]

Corpo da mensagem:
[your-message]

--
Este e-mail foi enviado de um formulário de contato em Asug | SAP NetWeaver Portal (http://127.0.0.1/asug)
contato@montarsite.com.br


0

[your-subject]
[your-name] <[your-email]>
Corpo da mensagem:
[your-message]

--
Este e-mail foi enviado de um formulário de contato em Asug | SAP NetWeaver Portal (http://127.0.0.1/asug)
[your-email]


0
Sua mensagem foi enviada com sucesso. Obrigado.
Não foi possível enviar a sua mensagem. Por favor, tente mais tarde ou contate o administrador por outro método.
Ocorreram erros de validação. Por favor confira os dados e envie novamente.
Não foi possível enviar a sua mensagem. Por favor, tente mais tarde ou contate o administrador por outro método.
Por favor aceite os termos para prosseguir.
Por favor preencha este campo obrigatório.', 'Formulário de contato 1', '', 'publish', 'open', 'open', '', 'formulario-de-contato-1', '', '', '2014-03-15 15:55:31', '2014-03-15 15:55:31', '', '0', 'http://127.0.0.1/asug/?post_type=wpcf7_contact_form&p=4', '0', 'wpcf7_contact_form', '', '0'); 
INSERT INTO `wp_posts` VALUES ('5', '1', '2014-03-15 16:34:13', '2014-03-15 16:34:13', 'Esta é uma página de exemplo. É diferente de um post porque ela ficará em um local e será exibida na navegação do seu site (na maioria dos temas). A maioria das pessoas começa com uma página de introdução aos potenciais visitantes do site. Ela pode ser assim:
<blockquote>Olá! Eu sou um bike courrier de dia, ator amador à noite e este é meu blog. Eu moro em São Paulo, tenho um cachorro chamado Tonico e eu gosto de caipirinhas. (E de ser pego pela chuva.)</blockquote>
ou assim:
<blockquote>A XYZ foi fundada em 1971 e desde então vem proporcionando produtos de qualidade a seus clientes. Localizada em Valinhos, XYZ emprega mais de 2.000 pessoas e faz várias contribuições para a comunidade local.</blockquote>
Como um novo usuário do WordPress, você deve ir até o <a href="http://127.0.0.1/asug/wp-admin/">seu painel</a> para excluir essa página e criar novas páginas com seu próprio conteúdo. Divirta-se!', 'Home', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-03-15 16:34:13', '2014-03-15 16:34:13', '', '2', 'http://127.0.0.1/asug/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('6', '1', '2014-03-15 16:34:43', '2014-03-15 16:34:43', '', 'Institucional', '', 'publish', 'open', 'open', '', 'institucional', '', '', '2014-03-15 16:34:43', '2014-03-15 16:34:43', '', '0', 'http://127.0.0.1/asug/?page_id=6', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('7', '1', '2014-03-15 16:34:43', '2014-03-15 16:34:43', '', 'Institucional', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-03-15 16:34:43', '2014-03-15 16:34:43', '', '6', 'http://127.0.0.1/asug/6-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('8', '1', '2014-03-15 16:35:03', '2014-03-15 16:35:03', '', 'Associe-se', '', 'publish', 'open', 'open', '', 'associe-se', '', '', '2014-03-15 16:35:03', '2014-03-15 16:35:03', '', '0', 'http://127.0.0.1/asug/?page_id=8', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('9', '1', '2014-03-15 16:35:03', '2014-03-15 16:35:03', '', 'Associe-se', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-03-15 16:35:03', '2014-03-15 16:35:03', '', '8', 'http://127.0.0.1/asug/8-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('10', '1', '2014-03-15 16:35:32', '2014-03-15 16:35:32', '', 'Grupo de estudo', '', 'publish', 'open', 'open', '', 'grupo-de-estudo', '', '', '2014-03-15 16:35:32', '2014-03-15 16:35:32', '', '0', 'http://127.0.0.1/asug/?page_id=10', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('11', '1', '2014-03-15 16:35:32', '2014-03-15 16:35:32', '', 'Grupo de estudo', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2014-03-15 16:35:32', '2014-03-15 16:35:32', '', '10', 'http://127.0.0.1/asug/10-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('12', '1', '2014-03-15 16:35:45', '2014-03-15 16:35:45', '', 'ABSG', '', 'publish', 'open', 'open', '', 'absg', '', '', '2014-03-15 16:35:45', '2014-03-15 16:35:45', '', '0', 'http://127.0.0.1/asug/?page_id=12', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('13', '1', '2014-03-15 16:35:45', '2014-03-15 16:35:45', '', 'ABSG', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2014-03-15 16:35:45', '2014-03-15 16:35:45', '', '12', 'http://127.0.0.1/asug/12-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('14', '1', '2014-03-15 16:36:00', '2014-03-15 16:36:00', '', 'DRQ', '', 'publish', 'open', 'open', '', 'drq', '', '', '2014-03-15 16:36:00', '2014-03-15 16:36:00', '', '0', 'http://127.0.0.1/asug/?page_id=14', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('15', '1', '2014-03-15 16:36:00', '2014-03-15 16:36:00', '', 'DRQ', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2014-03-15 16:36:00', '2014-03-15 16:36:00', '', '14', 'http://127.0.0.1/asug/14-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('16', '1', '2014-03-15 16:36:39', '2014-03-15 16:36:39', '', 'Conferência anual', '', 'publish', 'open', 'open', '', 'conferencia-anual', '', '', '2014-03-15 16:36:39', '2014-03-15 16:36:39', '', '0', 'http://127.0.0.1/asug/?page_id=16', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('17', '1', '2014-03-15 16:36:39', '2014-03-15 16:36:39', '', 'Conferência anual', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2014-03-15 16:36:39', '2014-03-15 16:36:39', '', '16', 'http://127.0.0.1/asug/16-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('18', '1', '2014-03-15 16:37:04', '2014-03-15 16:37:04', '', 'Impact awards', '', 'publish', 'open', 'open', '', 'impact-awards', '', '', '2014-03-15 16:37:04', '2014-03-15 16:37:04', '', '0', 'http://127.0.0.1/asug/?page_id=18', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('19', '1', '2014-03-15 16:37:04', '2014-03-15 16:37:04', '', 'Impact awards', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2014-03-15 16:37:04', '2014-03-15 16:37:04', '', '18', 'http://127.0.0.1/asug/18-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('20', '1', '2014-03-15 16:37:26', '2014-03-15 16:37:26', '', 'Asug Day', '', 'publish', 'open', 'open', '', 'asug-day', '', '', '2014-03-15 16:37:26', '2014-03-15 16:37:26', '', '0', 'http://127.0.0.1/asug/?page_id=20', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('21', '1', '2014-03-15 16:37:26', '2014-03-15 16:37:26', '', 'Asug Day', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2014-03-15 16:37:26', '2014-03-15 16:37:26', '', '20', 'http://127.0.0.1/asug/20-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('22', '1', '2014-03-15 16:37:42', '2014-03-15 16:37:42', '', 'Asug News', '', 'publish', 'open', 'open', '', 'asug-news', '', '', '2014-03-15 16:37:42', '2014-03-15 16:37:42', '', '0', 'http://127.0.0.1/asug/?page_id=22', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('23', '1', '2014-03-15 16:37:42', '2014-03-15 16:37:42', '', 'Asug News', '', 'inherit', 'open', 'open', '', '22-revision-v1', '', '', '2014-03-15 16:37:42', '2014-03-15 16:37:42', '', '22', 'http://127.0.0.1/asug/22-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('24', '1', '2014-03-15 16:38:25', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:25', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=24', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('25', '1', '2014-03-15 16:38:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:26', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=25', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('26', '1', '2014-03-15 16:38:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:26', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=26', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('27', '1', '2014-03-15 16:38:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:26', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=27', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('28', '1', '2014-03-15 16:38:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:26', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=28', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('29', '1', '2014-03-15 16:38:27', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:27', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=29', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('30', '1', '2014-03-15 16:38:27', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:27', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=30', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('31', '1', '2014-03-15 16:38:27', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:27', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=31', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('32', '1', '2014-03-15 16:38:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:28', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=32', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('33', '1', '2014-03-15 16:38:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:28', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=33', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('34', '1', '2014-03-15 16:38:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-03-15 16:38:28', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=34', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('35', '1', '2014-03-15 16:39:04', '2014-03-15 16:39:04', '', 'Diretoria', '', 'publish', 'open', 'open', '', 'diretoria', '', '', '2014-03-15 16:39:04', '2014-03-15 16:39:04', '', '6', 'http://127.0.0.1/asug/?page_id=35', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('36', '1', '2014-03-15 16:39:04', '2014-03-15 16:39:04', '', 'Diretoria', '', 'inherit', 'open', 'open', '', '35-revision-v1', '', '', '2014-03-15 16:39:04', '2014-03-15 16:39:04', '', '35', 'http://127.0.0.1/asug/35-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('37', '1', '2014-03-15 16:39:31', '2014-03-15 16:39:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Morbi in elementum justo. Aenean commodo sapien vulputate, vehicula lectus non, luctus augue. Nullam pulvinar tincidunt elementum. Integer ipsum neque, fermentum eu dignissim id, ultrices a augue. Integer eleifend neque in nisi euismod condimentum. Vestibulum mauris metus, hendrerit at lectus vel, sollicitudin semper libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla arcu dui, feugiat quis blandit id, elementum at est. Maecenas a nulla imperdiet, egestas est sit amet, cursus lacus. Nunc in ullamcorper mi. Nam purus nulla, cursus eu ornare ut, pellentesque in sapien. Sed ornare sapien nec erat pretium, mollis tincidunt nisl feugiat. Fusce at varius neque, ut vulputate ipsum. Duis sit amet odio lobortis, interdum turpis sit amet, tempor enim. Etiam justo urna, ullamcorper eget mollis vitae, hendrerit ut erat. Duis viverra malesuada consequat.

Nulla venenatis urna a massa suscipit feugiat. Nulla facilisi. Integer libero odio, ultrices et dui ac, cursus sollicitudin sem. Sed ut libero non nulla aliquam accumsan. Nam blandit purus sit amet turpis elementum tincidunt. Nunc quis ipsum sed mauris scelerisque varius at ut nisl. Duis tortor urna, ornare interdum quam at, iaculis lobortis elit. Pellentesque id consectetur felis. Mauris facilisis massa vitae elit consectetur venenatis.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Conselho administrativo', '', 'publish', 'open', 'open', '', 'conselho-administrativo', '', '', '2014-03-20 15:40:28', '2014-03-20 15:40:28', '', '6', 'http://127.0.0.1/asug/?page_id=37', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('38', '1', '2014-03-15 16:39:31', '2014-03-15 16:39:31', '', 'Conselho administrativo', '', 'inherit', 'open', 'open', '', '37-revision-v1', '', '', '2014-03-15 16:39:31', '2014-03-15 16:39:31', '', '37', 'http://127.0.0.1/asug/37-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('39', '1', '2014-03-15 16:39:51', '2014-03-15 16:39:51', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'publish', 'open', 'open', '', 'comite-estrategico', '', '', '2014-03-20 16:11:44', '2014-03-20 16:11:44', '', '6', 'http://127.0.0.1/asug/?page_id=39', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('40', '1', '2014-03-15 16:39:51', '2014-03-15 16:39:51', '', 'Comitê estratégico', '', 'inherit', 'open', 'open', '', '39-revision-v1', '', '', '2014-03-15 16:39:51', '2014-03-15 16:39:51', '', '39', 'http://127.0.0.1/asug/39-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('41', '1', '2014-03-15 16:40:22', '2014-03-15 16:40:22', '', 'Empresas associadas', '', 'publish', 'open', 'open', '', 'empresas-associadas', '', '', '2014-03-20 15:40:33', '2014-03-20 15:40:33', '', '6', 'http://127.0.0.1/asug/?page_id=41', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('42', '1', '2014-03-15 16:40:22', '2014-03-15 16:40:22', '', 'Empresas associadas', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-03-15 16:40:22', '2014-03-15 16:40:22', '', '41', 'http://127.0.0.1/asug/41-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('43', '1', '2014-03-15 16:40:46', '2014-03-15 16:40:46', '', 'Parceiros associados', '', 'publish', 'open', 'open', '', 'parceiros-associados', '', '', '2014-03-20 15:40:53', '2014-03-20 15:40:53', '', '6', 'http://127.0.0.1/asug/?page_id=43', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('44', '1', '2014-03-15 16:40:46', '2014-03-15 16:40:46', '', 'Parceiros associados', '', 'inherit', 'open', 'open', '', '43-revision-v1', '', '', '2014-03-15 16:40:46', '2014-03-15 16:40:46', '', '43', 'http://127.0.0.1/asug/43-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('45', '1', '2014-03-15 17:25:27', '2014-03-15 17:25:27', ' ', '', '', 'publish', 'open', 'open', '', '45', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=45', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('46', '1', '2014-03-15 17:25:27', '2014-03-15 17:25:27', ' ', '', '', 'publish', 'open', 'open', '', '46', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=46', '10', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('47', '1', '2014-03-15 17:25:27', '2014-03-15 17:25:27', ' ', '', '', 'publish', 'open', 'open', '', '47', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=47', '8', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('48', '1', '2014-03-15 17:25:27', '2014-03-15 17:25:27', ' ', '', '', 'publish', 'open', 'open', '', '48', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=48', '15', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('49', '1', '2014-03-15 17:25:28', '2014-03-15 17:25:28', ' ', '', '', 'publish', 'open', 'open', '', '49', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=49', '16', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('50', '1', '2014-03-15 17:25:28', '2014-03-15 17:25:28', ' ', '', '', 'publish', 'open', 'open', '', '50', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=50', '13', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('51', '1', '2014-03-15 17:25:28', '2014-03-15 17:25:28', ' ', '', '', 'publish', 'open', 'open', '', '51', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=51', '11', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('52', '1', '2014-03-15 17:25:28', '2014-03-15 17:25:28', ' ', '', '', 'publish', 'open', 'open', '', '52', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=52', '9', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('54', '1', '2014-03-15 17:25:28', '2014-03-15 17:25:28', ' ', '', '', 'publish', 'open', 'open', '', '54', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=54', '14', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('55', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '55', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=55', '2', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('56', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '56', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '6', 'http://127.0.0.1/asug/?p=56', '3', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('57', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '57', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '6', 'http://127.0.0.1/asug/?p=57', '4', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('58', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '58', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '6', 'http://127.0.0.1/asug/?p=58', '5', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('59', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '59', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '6', 'http://127.0.0.1/asug/?p=59', '6', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('60', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '60', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '6', 'http://127.0.0.1/asug/?p=60', '7', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('61', '1', '2014-03-15 18:29:14', '2014-03-15 18:29:14', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg', 'asug-brasil.jpg', '', 'inherit', 'closed', 'open', '', 'asug-brasil-jpg', '', '', '2014-03-15 18:29:14', '2014-03-15 18:29:14', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('63', '1', '2014-03-16 04:34:08', '2014-03-16 04:34:08', '', 'slider', '', 'inherit', 'closed', 'open', '', 'slider', '', '', '2014-03-16 04:34:08', '2014-03-16 04:34:08', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('64', '1', '2014-03-16 05:06:14', '2014-03-16 05:06:14', '', 'banner03', '', 'inherit', 'closed', 'open', '', 'banner03', '', '', '2014-03-16 05:06:14', '2014-03-16 05:06:14', '', '72', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner03.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('65', '1', '2014-03-16 05:06:17', '2014-03-16 05:06:17', '', 'banner04', '', 'inherit', 'closed', 'open', '', 'banner04', '', '', '2014-03-16 05:06:17', '2014-03-16 05:06:17', '', '74', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner04.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('66', '1', '2014-03-16 05:06:21', '2014-03-16 05:06:21', '', 'banner01', '', 'inherit', 'closed', 'open', '', 'banner01', '', '', '2014-03-16 05:06:21', '2014-03-16 05:06:21', '', '68', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('67', '1', '2014-03-16 05:06:24', '2014-03-16 05:06:24', '', 'banner02', '', 'inherit', 'closed', 'open', '', 'banner02', '', '', '2014-03-16 05:06:24', '2014-03-16 05:06:24', '', '70', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner02.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('68', '1', '2014-03-16 06:11:23', '2014-03-16 06:11:23', '<a href="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg" alt="banner01" width="235" height="122" class="alignnone size-full wp-image-66" /></a>', 'banner01', '', 'publish', 'closed', 'closed', '', 'banner01', '', '', '2014-03-16 06:12:50', '2014-03-16 06:12:50', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&#038;p=68', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('69', '1', '2014-03-16 06:11:23', '2014-03-16 06:11:23', '<a href="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg" alt="banner01" width="235" height="122" class="alignnone size-full wp-image-66" /></a>', 'banner01', '', 'inherit', 'closed', 'open', '', '68-revision-v1', '', '', '2014-03-16 06:11:23', '2014-03-16 06:11:23', '', '68', 'http://127.0.0.1/asug/68-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('70', '1', '2014-03-16 06:13:36', '2014-03-16 06:13:36', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner02.jpg" alt="banner02" width="234" height="122" class="alignnone size-full wp-image-67" /></a>', 'banner02', '', 'publish', 'closed', 'closed', '', 'banner02', '', '', '2014-03-16 06:13:36', '2014-03-16 06:13:36', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&#038;p=70', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('71', '1', '2014-03-16 06:13:36', '2014-03-16 06:13:36', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner02.jpg" alt="banner02" width="234" height="122" class="alignnone size-full wp-image-67" /></a>', 'banner02', '', 'inherit', 'closed', 'open', '', '70-revision-v1', '', '', '2014-03-16 06:13:36', '2014-03-16 06:13:36', '', '70', 'http://127.0.0.1/asug/70-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('72', '1', '2014-03-16 06:14:19', '2014-03-16 06:14:19', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner03.jpg" alt="banner03" width="235" height="121" class="alignnone size-full wp-image-64" /></a>', 'banner03', '', 'publish', 'closed', 'closed', '', 'banner03', '', '', '2014-03-16 06:14:19', '2014-03-16 06:14:19', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&#038;p=72', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('73', '1', '2014-03-16 06:14:19', '2014-03-16 06:14:19', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner03.jpg" alt="banner03" width="235" height="121" class="alignnone size-full wp-image-64" /></a>', 'banner03', '', 'inherit', 'closed', 'open', '', '72-revision-v1', '', '', '2014-03-16 06:14:19', '2014-03-16 06:14:19', '', '72', 'http://127.0.0.1/asug/72-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('74', '1', '2014-03-16 06:14:50', '2014-03-16 06:14:50', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner04.jpg" alt="banner04" width="235" height="121" class="alignnone size-full wp-image-65" /></a>', 'banner04', '', 'publish', 'closed', 'closed', '', 'banner04', '', '', '2014-03-16 06:14:50', '2014-03-16 06:14:50', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&#038;p=74', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('75', '1', '2014-03-16 06:14:50', '2014-03-16 06:14:50', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner04.jpg" alt="banner04" width="235" height="121" class="alignnone size-full wp-image-65" /></a>', 'banner04', '', 'inherit', 'closed', 'open', '', '74-revision-v1', '', '', '2014-03-16 06:14:50', '2014-03-16 06:14:50', '', '74', 'http://127.0.0.1/asug/74-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('76', '1', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', 'Fórum', '', 'publish', 'closed', 'open', '', 'forum', '', '', '2014-03-16 17:36:33', '2014-03-16 17:36:33', '', '0', 'http://127.0.0.1/asug/?p=76', '12', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('77', '1', '2014-03-16 19:59:29', '2014-03-16 19:59:29', '', 'eventos01', '', 'inherit', 'closed', 'open', '', 'eventos01', '', '', '2014-03-16 19:59:29', '2014-03-16 19:59:29', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/eventos01.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('78', '1', '2014-03-16 19:59:32', '2014-03-16 19:59:32', '', 'eventos02', '', 'inherit', 'closed', 'open', '', 'eventos02', '', '', '2014-03-16 19:59:32', '2014-03-16 19:59:32', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/eventos02.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('79', '1', '2014-03-16 22:38:16', '2014-03-16 22:38:16', 'CONTENTS', 'Eventos', 'CONTENTS', 'publish', 'closed', 'open', '', 'eventos', '', '', '2014-03-16 22:38:16', '2014-03-16 22:38:16', '', '0', 'http://127.0.0.1/asug/eventos/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('80', '1', '2014-03-16 22:38:17', '2014-03-16 22:38:17', 'CONTENTS', 'Locais', '', 'publish', 'closed', 'open', '', 'locais', '', '', '2014-03-16 22:38:17', '2014-03-16 22:38:17', '', '79', 'http://127.0.0.1/asug/eventos/locais/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('81', '1', '2014-03-16 22:38:17', '2014-03-16 22:38:17', 'CONTENTS', 'Categorias', '', 'publish', 'closed', 'open', '', 'categorias', '', '', '2014-03-16 22:38:17', '2014-03-16 22:38:17', '', '79', 'http://127.0.0.1/asug/eventos/categorias/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('82', '1', '2014-03-16 22:38:18', '2014-03-16 22:38:18', 'CONTENTS', 'Tags', '', 'publish', 'closed', 'open', '', 'tags', '', '', '2014-03-16 22:38:18', '2014-03-16 22:38:18', '', '79', 'http://127.0.0.1/asug/eventos/tags/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('83', '1', '2014-03-16 22:38:19', '2014-03-16 22:38:19', 'CONTENTS', 'Minhas Reservas', '', 'publish', 'closed', 'open', '', 'minhas-reservas', '', '', '2014-03-16 22:38:19', '2014-03-16 22:38:19', '', '79', 'http://127.0.0.1/asug/eventos/minhas-reservas/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('84', '1', '2014-03-16 23:02:36', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-16 23:02:36', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=84', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('85', '1', '2014-03-16 23:11:44', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-16 23:11:44', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=85', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('86', '1', '2014-03-16 23:39:19', '2014-03-16 23:39:19', '', 'eventos01', '', 'inherit', 'closed', 'open', '', 'eventos01-2', '', '', '2014-03-16 23:39:19', '2014-03-16 23:39:19', '', '1', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/eventos011.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('87', '1', '2014-03-16 23:39:21', '2014-03-16 23:39:21', '', 'eventos02', '', 'inherit', 'closed', 'open', '', 'eventos02-2', '', '', '2014-03-16 23:39:21', '2014-03-16 23:39:21', '', '1', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/eventos021.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('88', '1', '2014-03-16 23:45:29', '2014-03-16 23:45:29', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG Day Porto Alegre 2013', '', 'inherit', 'closed', 'open', '', '1-autosave-v1', '', '', '2014-03-16 23:45:29', '2014-03-16 23:45:29', '', '1', 'http://127.0.0.1/asug/1-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('89', '1', '2014-03-16 23:45:36', '2014-03-16 23:45:36', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG Day Porto Alegre 2013', '', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-03-16 23:45:36', '2014-03-16 23:45:36', '', '1', 'http://127.0.0.1/asug/1-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('90', '1', '2014-03-16 23:46:09', '2014-03-16 23:46:09', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY GOIÂNIA 2013', '', 'publish', 'closed', 'open', '', 'asug-day-goiania-2013', '', '', '2014-03-16 23:46:09', '2014-03-16 23:46:09', '', '0', 'http://127.0.0.1/asug/?p=90', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('91', '1', '2014-03-16 23:46:09', '2014-03-16 23:46:09', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY GOIÂNIA 2013', '', 'inherit', 'closed', 'open', '', '90-revision-v1', '', '', '2014-03-16 23:46:09', '2014-03-16 23:46:09', '', '90', 'http://127.0.0.1/asug/90-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('92', '1', '2014-03-16 23:46:37', '2014-03-16 23:46:37', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY SÃO PAULO 2014', '', 'publish', 'closed', 'open', '', 'asug-day-sao-paulo-2014', '', '', '2014-03-16 23:46:37', '2014-03-16 23:46:37', '', '0', 'http://127.0.0.1/asug/?p=92', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('93', '1', '2014-03-16 23:46:37', '2014-03-16 23:46:37', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY SÃO PAULO 2014', '', 'inherit', 'closed', 'open', '', '92-revision-v1', '', '', '2014-03-16 23:46:37', '2014-03-16 23:46:37', '', '92', 'http://127.0.0.1/asug/92-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('94', '1', '2014-03-16 23:47:08', '2014-03-16 23:47:08', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY CURITIBA 2014', '', 'publish', 'closed', 'open', '', 'asug-day-curitiba-2014', '', '', '2014-03-16 23:47:08', '2014-03-16 23:47:08', '', '0', 'http://127.0.0.1/asug/?p=94', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('95', '1', '2014-03-16 23:47:08', '2014-03-16 23:47:08', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY CURITIBA 2014', '', 'inherit', 'closed', 'open', '', '94-revision-v1', '', '', '2014-03-16 23:47:08', '2014-03-16 23:47:08', '', '94', 'http://127.0.0.1/asug/94-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('96', '1', '2014-03-19 01:29:33', '2014-03-19 01:29:33', '', 'Loja', '', 'publish', 'closed', 'open', '', 'loja', '', '', '2014-03-19 01:29:33', '2014-03-19 01:29:33', '', '0', 'http://127.0.0.1/asug/loja/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('97', '1', '2014-03-19 01:29:34', '2014-03-19 01:29:34', '[woocommerce_cart]', 'Carrinho', '', 'publish', 'closed', 'open', '', 'carrinho', '', '', '2014-03-19 01:29:34', '2014-03-19 01:29:34', '', '0', 'http://127.0.0.1/asug/carrinho/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('98', '1', '2014-03-19 01:29:34', '2014-03-19 01:29:34', '[woocommerce_checkout]', 'Finalizar compra', '', 'publish', 'closed', 'open', '', 'finalizar-compra', '', '', '2014-03-19 01:29:34', '2014-03-19 01:29:34', '', '0', 'http://127.0.0.1/asug/finalizar-compra/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('99', '1', '2014-03-19 01:29:34', '2014-03-19 01:29:34', '[woocommerce_my_account]', 'Minha conta', '', 'publish', 'closed', 'open', '', 'minha-conta', '', '', '2014-03-19 01:29:34', '2014-03-19 01:29:34', '', '0', 'http://127.0.0.1/asug/minha-conta/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('100', '1', '2014-03-19 13:06:37', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-19 13:06:37', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?post_type=event&p=100', '0', 'event', '', '0'); 
INSERT INTO `wp_posts` VALUES ('101', '1', '2014-03-19 13:06:42', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-19 13:06:42', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?post_type=event&p=101', '0', 'event', '', '0'); 
INSERT INTO `wp_posts` VALUES ('102', '1', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', 'Register', '', 'publish', 'closed', 'open', '', 'register', '', '', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', '0', 'http://127.0.0.1/asug/register/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('103', '1', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', 'Account', '', 'publish', 'closed', 'open', '', 'account', '', '', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', '0', 'http://127.0.0.1/asug/account/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('104', '1', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '<p>The content you are trying to access is only available to members. Sorry.</p>', 'Protected Content', '', 'publish', 'closed', 'open', '', 'protected', '', '', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', '0', 'http://127.0.0.1/asug/protected/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('105', '1', '2014-03-20 02:20:23', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-20 02:20:23', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?post_type=product&p=105', '0', 'product', '', '0'); 
INSERT INTO `wp_posts` VALUES ('106', '1', '2014-03-20 02:49:02', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-20 02:49:02', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?page_id=106', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('107', '1', '2014-03-20 03:12:05', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-20 03:12:05', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?post_type=event&p=107', '0', 'event', '', '0'); 
INSERT INTO `wp_posts` VALUES ('108', '1', '2014-03-20 03:14:23', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-20 03:14:23', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?post_type=event&p=108', '0', 'event', '', '0'); 
INSERT INTO `wp_posts` VALUES ('109', '1', '2014-03-20 15:22:50', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-20 15:22:50', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?page_id=109', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('110', '1', '2014-03-20 15:25:48', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-03-20 15:25:48', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?page_id=110', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('111', '1', '2014-03-20 15:39:45', '2014-03-20 15:39:45', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Morbi in elementum justo. Aenean commodo sapien vulputate, vehicula lectus non, luctus augue. Nullam pulvinar tincidunt elementum. Integer ipsum neque, fermentum eu dignissim id, ultrices a augue. Integer eleifend neque in nisi euismod condimentum. Vestibulum mauris metus, hendrerit at lectus vel, sollicitudin semper libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla arcu dui, feugiat quis blandit id, elementum at est. Maecenas a nulla imperdiet, egestas est sit amet, cursus lacus. Nunc in ullamcorper mi. Nam purus nulla, cursus eu ornare ut, pellentesque in sapien. Sed ornare sapien nec erat pretium, mollis tincidunt nisl feugiat. Fusce at varius neque, ut vulputate ipsum. Duis sit amet odio lobortis, interdum turpis sit amet, tempor enim. Etiam justo urna, ullamcorper eget mollis vitae, hendrerit ut erat. Duis viverra malesuada consequat.

Nulla venenatis urna a massa suscipit feugiat. Nulla facilisi. Integer libero odio, ultrices et dui ac, cursus sollicitudin sem. Sed ut libero non nulla aliquam accumsan. Nam blandit purus sit amet turpis elementum tincidunt. Nunc quis ipsum sed mauris scelerisque varius at ut nisl. Duis tortor urna, ornare interdum quam at, iaculis lobortis elit. Pellentesque id consectetur felis. Mauris facilisis massa vitae elit consectetur venenatis.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'inherit', 'closed', 'open', '', '39-revision-v1', '', '', '2014-03-20 15:39:45', '2014-03-20 15:39:45', '', '39', 'http://127.0.0.1/asug/39-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('112', '1', '2014-03-20 15:40:03', '2014-03-20 15:40:03', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Morbi in elementum justo. Aenean commodo sapien vulputate, vehicula lectus non, luctus augue. Nullam pulvinar tincidunt elementum. Integer ipsum neque, fermentum eu dignissim id, ultrices a augue. Integer eleifend neque in nisi euismod condimentum. Vestibulum mauris metus, hendrerit at lectus vel, sollicitudin semper libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla arcu dui, feugiat quis blandit id, elementum at est. Maecenas a nulla imperdiet, egestas est sit amet, cursus lacus. Nunc in ullamcorper mi. Nam purus nulla, cursus eu ornare ut, pellentesque in sapien. Sed ornare sapien nec erat pretium, mollis tincidunt nisl feugiat. Fusce at varius neque, ut vulputate ipsum. Duis sit amet odio lobortis, interdum turpis sit amet, tempor enim. Etiam justo urna, ullamcorper eget mollis vitae, hendrerit ut erat. Duis viverra malesuada consequat.

Nulla venenatis urna a massa suscipit feugiat. Nulla facilisi. Integer libero odio, ultrices et dui ac, cursus sollicitudin sem. Sed ut libero non nulla aliquam accumsan. Nam blandit purus sit amet turpis elementum tincidunt. Nunc quis ipsum sed mauris scelerisque varius at ut nisl. Duis tortor urna, ornare interdum quam at, iaculis lobortis elit. Pellentesque id consectetur felis. Mauris facilisis massa vitae elit consectetur venenatis.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Conselho administrativo', '', 'inherit', 'closed', 'open', '', '37-autosave-v1', '', '', '2014-03-20 15:40:03', '2014-03-20 15:40:03', '', '37', 'http://127.0.0.1/asug/37-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('113', '1', '2014-03-20 15:40:28', '2014-03-20 15:40:28', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Morbi in elementum justo. Aenean commodo sapien vulputate, vehicula lectus non, luctus augue. Nullam pulvinar tincidunt elementum. Integer ipsum neque, fermentum eu dignissim id, ultrices a augue. Integer eleifend neque in nisi euismod condimentum. Vestibulum mauris metus, hendrerit at lectus vel, sollicitudin semper libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla arcu dui, feugiat quis blandit id, elementum at est. Maecenas a nulla imperdiet, egestas est sit amet, cursus lacus. Nunc in ullamcorper mi. Nam purus nulla, cursus eu ornare ut, pellentesque in sapien. Sed ornare sapien nec erat pretium, mollis tincidunt nisl feugiat. Fusce at varius neque, ut vulputate ipsum. Duis sit amet odio lobortis, interdum turpis sit amet, tempor enim. Etiam justo urna, ullamcorper eget mollis vitae, hendrerit ut erat. Duis viverra malesuada consequat.

Nulla venenatis urna a massa suscipit feugiat. Nulla facilisi. Integer libero odio, ultrices et dui ac, cursus sollicitudin sem. Sed ut libero non nulla aliquam accumsan. Nam blandit purus sit amet turpis elementum tincidunt. Nunc quis ipsum sed mauris scelerisque varius at ut nisl. Duis tortor urna, ornare interdum quam at, iaculis lobortis elit. Pellentesque id consectetur felis. Mauris facilisis massa vitae elit consectetur venenatis.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Conselho administrativo', '', 'inherit', 'closed', 'open', '', '37-revision-v1', '', '', '2014-03-20 15:40:28', '2014-03-20 15:40:28', '', '37', 'http://127.0.0.1/asug/37-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('114', '1', '2014-03-20 15:43:28', '2014-03-20 15:43:28', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Morbi in elementum justo. Aenean commodo sapien vulputate, vehicula lectus non, luctus augue. Nullam pulvinar tincidunt elementum. Integer ipsum neque, fermentum eu dignissim id, ultrices a augue. Integer eleifend neque in nisi euismod condimentum. Vestibulum mauris metus, hendrerit at lectus vel, sollicitudin semper libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla arcu dui, feugiat quis blandit id, elementum at est. Maecenas a nulla imperdiet, egestas est sit amet, cursus lacus. Nunc in ullamcorper mi. Nam purus nulla, cursus eu ornare ut, pellentesque in sapien. Sed ornare sapien nec erat pretium, mollis tincidunt nisl feugiat. Fusce at varius neque, ut vulputate ipsum. Duis sit amet odio lobortis, interdum turpis sit amet, tempor enim. Etiam justo urna, ullamcorper eget mollis vitae, hendrerit ut erat. Duis viverra malesuada consequat.

Nulla venenatis urna a massa suscipit feugiat. Nulla facilisi. Integer libero odio, ultrices et dui ac, cursus sollicitudin sem. Sed ut libero non nulla aliquam accumsan. Nam blandit purus sit amet turpis elementum tincidunt. Nunc quis ipsum sed mauris scelerisque varius at ut nisl. Duis tortor urna, ornare interdum quam at, iaculis lobortis elit. Pellentesque id consectetur felis. Mauris facilisis massa vitae elit consectetur venenatis.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'inherit', 'closed', 'open', '', '39-autosave-v1', '', '', '2014-03-20 15:43:28', '2014-03-20 15:43:28', '', '39', 'http://127.0.0.1/asug/39-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('115', '1', '2014-03-20 15:44:13', '2014-03-20 15:44:13', '', 'Parceiros associados', '', 'inherit', 'closed', 'open', '', '43-autosave-v1', '', '', '2014-03-20 15:44:13', '2014-03-20 15:44:13', '', '43', 'http://127.0.0.1/asug/43-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('116', '1', '2014-03-20 16:11:44', '2014-03-20 16:11:44', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'inherit', 'closed', 'open', '', '39-revision-v1', '', '', '2014-03-20 16:11:44', '2014-03-20 16:11:44', '', '39', 'http://127.0.0.1/asug/39-revision-v1/', '0', 'revision', '', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_term_relationships`
--
DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_term_relationships`
--
LOCK TABLES `wp_term_relationships` WRITE;
INSERT INTO `wp_term_relationships` VALUES ('1', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('1', '4', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('45', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('46', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('47', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('48', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('49', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('50', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('51', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('52', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('54', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('55', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('56', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('57', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('58', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('59', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('60', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('68', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('70', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('72', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('74', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('76', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('90', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('90', '4', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('92', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('92', '4', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('94', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('94', '4', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_term_taxonomy`
--
DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_term_taxonomy`
--
LOCK TABLES `wp_term_taxonomy` WRITE;
INSERT INTO `wp_term_taxonomy` VALUES ('1', '1', 'category', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('2', '2', 'nav_menu', '', '0', '16'); 
INSERT INTO `wp_term_taxonomy` VALUES ('3', '3', 'dfads_group', 'Banners Home', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('4', '4', 'category', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('5', '5', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('6', '6', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('7', '7', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('8', '8', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('9', '9', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('10', '10', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('11', '11', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('12', '12', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('13', '13', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('14', '14', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('15', '15', 'shop_order_status', '', '0', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_terms`
--
DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_terms`
--
LOCK TABLES `wp_terms` WRITE;
INSERT INTO `wp_terms` VALUES ('1', 'Destaque', 'destaque', '0'); 
INSERT INTO `wp_terms` VALUES ('2', 'Topo', 'topo', '0'); 
INSERT INTO `wp_terms` VALUES ('3', 'Banners Home', 'banners-home', '0'); 
INSERT INTO `wp_terms` VALUES ('4', 'Eventos', 'eventos', '0'); 
INSERT INTO `wp_terms` VALUES ('5', 'simple', 'simple', '0'); 
INSERT INTO `wp_terms` VALUES ('6', 'grouped', 'grouped', '0'); 
INSERT INTO `wp_terms` VALUES ('7', 'variable', 'variable', '0'); 
INSERT INTO `wp_terms` VALUES ('8', 'external', 'external', '0'); 
INSERT INTO `wp_terms` VALUES ('9', 'pending', 'pending', '0'); 
INSERT INTO `wp_terms` VALUES ('10', 'failed', 'failed', '0'); 
INSERT INTO `wp_terms` VALUES ('11', 'on-hold', 'on-hold', '0'); 
INSERT INTO `wp_terms` VALUES ('12', 'processing', 'processing', '0'); 
INSERT INTO `wp_terms` VALUES ('13', 'completed', 'completed', '0'); 
INSERT INTO `wp_terms` VALUES ('14', 'refunded', 'refunded', '0'); 
INSERT INTO `wp_terms` VALUES ('15', 'cancelled', 'cancelled', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_user_status_manager`
--
DROP TABLE IF EXISTS `wp_user_status_manager`;
CREATE TABLE `wp_user_status_manager` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(9) NOT NULL,
  `user_name` text NOT NULL,
  `user_email` text NOT NULL,
  `status_from` text NOT NULL,
  `status_to` text NOT NULL,
  `status` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_user_status_manager`
--
LOCK TABLES `wp_user_status_manager` WRITE;
INSERT INTO `wp_user_status_manager` VALUES ('1', '4', 'pita', 'spynomak@hotmail.com', '', '', '1'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_usermeta`
--
DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_usermeta`
--
LOCK TABLES `wp_usermeta` WRITE;
INSERT INTO `wp_usermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('3', '1', 'nickname', 'adminasugms'); 
INSERT INTO `wp_usermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('10', '1', 'wp_capabilities', 'a:14:{s:13:"administrator";b:1;s:15:"membershipadmin";b:1;s:24:"membershipadmindashboard";b:1;s:22:"membershipadminmembers";b:1;s:21:"membershipadminlevels";b:1;s:28:"membershipadminsubscriptions";b:1;s:22:"membershipadmincoupons";b:1;s:24:"membershipadminpurchases";b:1;s:29:"membershipadmincommunications";b:1;s:21:"membershipadmingroups";b:1;s:20:"membershipadminpings";b:1;s:23:"membershipadmingateways";b:1;s:22:"membershipadminoptions";b:1;s:32:"membershipadminupdatepermissions";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('11', '1', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `wp_usermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `wp_usermeta` VALUES ('14', '1', 'wp_dashboard_quick_press_last_post_id', '3'); 
INSERT INTO `wp_usermeta` VALUES ('15', '1', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES ('16', '1', 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'); 
INSERT INTO `wp_usermeta` VALUES ('17', '1', 'wp_user-settings', 'imgsize=full&libraryContent=browse&urlbutton=custom'); 
INSERT INTO `wp_usermeta` VALUES ('18', '1', 'wp_user-settings-time', '1394950335'); 
INSERT INTO `wp_usermeta` VALUES ('19', '1', 'nav_menu_recently_edited', '2'); 
INSERT INTO `wp_usermeta` VALUES ('20', '1', 'manageedit-eventcolumnshidden', 'a:1:{i:0;s:8:"event-id";}'); 
INSERT INTO `wp_usermeta` VALUES ('21', '1', 'membership_permissions_updated', 'yes'); 
INSERT INTO `wp_usermeta` VALUES ('49', '4', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('50', '4', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('51', '4', 'nickname', 'pita'); 
INSERT INTO `wp_usermeta` VALUES ('52', '4', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('53', '4', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('54', '4', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('55', '4', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('56', '4', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('57', '4', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('58', '4', 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('59', '4', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('60', '4', 'default_password_nag', ''); 
INSERT INTO `wp_usermeta` VALUES ('61', '4', 'billing_first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('62', '4', 'billing_last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('63', '4', 'billing_company', ''); 
INSERT INTO `wp_usermeta` VALUES ('64', '4', 'billing_address_1', ''); 
INSERT INTO `wp_usermeta` VALUES ('65', '4', 'billing_address_2', ''); 
INSERT INTO `wp_usermeta` VALUES ('66', '4', 'billing_city', ''); 
INSERT INTO `wp_usermeta` VALUES ('67', '4', 'billing_postcode', ''); 
INSERT INTO `wp_usermeta` VALUES ('68', '4', 'billing_state', ''); 
INSERT INTO `wp_usermeta` VALUES ('69', '4', 'billing_country', ''); 
INSERT INTO `wp_usermeta` VALUES ('70', '4', 'billing_phone', ''); 
INSERT INTO `wp_usermeta` VALUES ('71', '4', 'billing_email', ''); 
INSERT INTO `wp_usermeta` VALUES ('72', '4', 'shipping_first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('73', '4', 'shipping_last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('74', '4', 'shipping_company', ''); 
INSERT INTO `wp_usermeta` VALUES ('75', '4', 'shipping_address_1', ''); 
INSERT INTO `wp_usermeta` VALUES ('76', '4', 'shipping_address_2', ''); 
INSERT INTO `wp_usermeta` VALUES ('77', '4', 'shipping_city', ''); 
INSERT INTO `wp_usermeta` VALUES ('78', '4', 'shipping_postcode', ''); 
INSERT INTO `wp_usermeta` VALUES ('79', '4', 'shipping_state', ''); 
INSERT INTO `wp_usermeta` VALUES ('80', '4', 'shipping_country', ''); 
INSERT INTO `wp_usermeta` VALUES ('81', '4', 'dbem_phone', ''); 
INSERT INTO `wp_usermeta` VALUES ('82', '4', 'manageedit-eventcolumnshidden', 'a:1:{i:0;s:8:"event-id";}'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_users`
--
DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_users`
--
LOCK TABLES `wp_users` WRITE;
INSERT INTO `wp_users` VALUES ('1', 'adminasugms', '$P$BoPNw4CMc/GAVk1olJyhHsV/qSVDiz/', 'adminasugms', 'contato@montarsite.com.br', '', '2014-03-15 15:51:25', '', '0', 'adminasugms'); 
INSERT INTO `wp_users` VALUES ('4', 'pita', '$P$BRqbQvJhgJUx754bqXeru4BtiQSPhO1', 'pita', 'spynomak@hotmail.com', '', '2014-03-20 02:57:27', '', '0', 'pita'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_usm_post_message`
--
DROP TABLE IF EXISTS `wp_usm_post_message`;
CREATE TABLE `wp_usm_post_message` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `post_message` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_usm_post_message`
--
LOCK TABLES `wp_usm_post_message` WRITE;
INSERT INTO `wp_usm_post_message` VALUES ('1', 'Ops'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_woocommerce_attribute_taxonomies`
--
DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;
CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL,
  `attribute_label` longtext,
  `attribute_type` varchar(200) NOT NULL,
  `attribute_orderby` varchar(200) NOT NULL,
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_woocommerce_attribute_taxonomies`
--
LOCK TABLES `wp_woocommerce_attribute_taxonomies` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_woocommerce_downloadable_product_permissions`
--
DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;
CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`,`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_woocommerce_downloadable_product_permissions`
--
LOCK TABLES `wp_woocommerce_downloadable_product_permissions` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--
DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;
CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_woocommerce_order_itemmeta`
--
LOCK TABLES `wp_woocommerce_order_itemmeta` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_woocommerce_order_items`
--
DROP TABLE IF EXISTS `wp_woocommerce_order_items`;
CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_woocommerce_order_items`
--
LOCK TABLES `wp_woocommerce_order_items` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_woocommerce_tax_rate_locations`
--
DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;
CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(255) NOT NULL,
  `tax_rate_id` bigint(20) NOT NULL,
  `location_type` varchar(40) NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_woocommerce_tax_rate_locations`
--
LOCK TABLES `wp_woocommerce_tax_rate_locations` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_woocommerce_tax_rates`
--
DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;
CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) NOT NULL DEFAULT '',
  `tax_rate` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) NOT NULL,
  `tax_rate_class` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`),
  KEY `tax_rate_class` (`tax_rate_class`),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_woocommerce_tax_rates`
--
LOCK TABLES `wp_woocommerce_tax_rates` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_woocommerce_termmeta`
--
DROP TABLE IF EXISTS `wp_woocommerce_termmeta`;
CREATE TABLE `wp_woocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `woocommerce_term_id` (`woocommerce_term_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_woocommerce_termmeta`
--
LOCK TABLES `wp_woocommerce_termmeta` WRITE;
UNLOCK TABLES;
