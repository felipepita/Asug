--
-- Table structure for table `wp_blc_filters`
--
DROP TABLE IF EXISTS `wp_blc_filters`;
CREATE TABLE `wp_blc_filters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_blc_filters`
--
LOCK TABLES `wp_blc_filters` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_blc_instances`
--
DROP TABLE IF EXISTS `wp_blc_instances`;
CREATE TABLE `wp_blc_instances` (
  `instance_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `link_id` int(10) unsigned NOT NULL,
  `container_id` int(10) unsigned NOT NULL,
  `container_type` varchar(40) NOT NULL DEFAULT 'post',
  `link_text` varchar(250) NOT NULL DEFAULT '',
  `parser_type` varchar(40) NOT NULL DEFAULT 'link',
  `container_field` varchar(250) NOT NULL DEFAULT '',
  `link_context` varchar(250) NOT NULL DEFAULT '',
  `raw_url` text NOT NULL,
  PRIMARY KEY (`instance_id`),
  KEY `link_id` (`link_id`),
  KEY `source_id` (`container_type`,`container_id`),
  KEY `parser_type` (`parser_type`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_blc_instances`
--
LOCK TABLES `wp_blc_instances` WRITE;
INSERT INTO `wp_blc_instances` VALUES ('39', '1', '1', 'comment', 'Sr. WordPress', 'url_field', 'comment_author_url', '', 'http://wordpress.org/'); 
INSERT INTO `wp_blc_instances` VALUES ('44', '7', '137', 'page', 'Funciona', 'link', 'post_content', '', '[boleto_usuario]'); 
INSERT INTO `wp_blc_instances` VALUES ('45', '8', '160', 'page', 'www.asug.com.br', 'link', 'post_content', '', 'http://www.asug.com.br'); 
INSERT INTO `wp_blc_instances` VALUES ('46', '9', '285', 'page', '<img class="alignnone size-full wp-image-255" alt="asug_recibo_rodape" src="http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg" width="1020" height="38" />', 'link', 'post_content', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg'); 
INSERT INTO `wp_blc_instances` VALUES ('47', '10', '285', 'page', '', 'image', 'post_content', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_cabecalho.jpg'); 
INSERT INTO `wp_blc_instances` VALUES ('48', '11', '285', 'page', '', 'image', 'post_content', '', 'http://fliporto.net/2013/wp-content/uploads/2013/11/JoseSaramagoAssinatura.png'); 
INSERT INTO `wp_blc_instances` VALUES ('49', '9', '285', 'page', '', 'image', 'post_content', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg'); 
INSERT INTO `wp_blc_instances` VALUES ('51', '12', '6', 'page', '', 'image', 'post_content', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/pilares.jpg'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_blc_links`
--
DROP TABLE IF EXISTS `wp_blc_links`;
CREATE TABLE `wp_blc_links` (
  `link_id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `first_failure` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_check` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_success` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_check_attempt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `check_count` int(4) unsigned NOT NULL DEFAULT '0',
  `final_url` text CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `redirect_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `log` text NOT NULL,
  `http_code` smallint(6) NOT NULL DEFAULT '0',
  `status_code` varchar(100) DEFAULT '',
  `status_text` varchar(250) DEFAULT '',
  `request_duration` float NOT NULL DEFAULT '0',
  `timeout` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `broken` tinyint(1) NOT NULL DEFAULT '0',
  `may_recheck` tinyint(1) NOT NULL DEFAULT '1',
  `being_checked` tinyint(1) NOT NULL DEFAULT '0',
  `result_hash` varchar(200) NOT NULL DEFAULT '',
  `false_positive` tinyint(1) NOT NULL DEFAULT '0',
  `dismissed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`),
  KEY `url` (`url`(150)),
  KEY `final_url` (`final_url`(150)),
  KEY `http_code` (`http_code`),
  KEY `broken` (`broken`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_blc_links`
--
LOCK TABLES `wp_blc_links` WRITE;
INSERT INTO `wp_blc_links` VALUES ('1', 'http://wordpress.org/', '0000-00-00 00:00:00', '2014-06-06 12:26:58', '2014-06-06 12:26:58', '2014-06-06 12:26:58', '0', 'http://wordpress.org/', '0', '=== Código HTTP : 200 ===

HTTP/1.1 200 OK
Server: nginx
Date: Fri, 06 Jun 2014 12:26:59 GMT
Content-Type: text/html; charset=utf-8
Connection: keep-alive
Vary: Accept-Encoding
X-nc: HIT lax 249


O link é válido.', '200', '', '', '0.422', '0', '0', '1', '0', '200|0|0|8e73c6b5bc5ba66d98238874d1d08cfb', '0', '0'); 
INSERT INTO `wp_blc_links` VALUES ('7', 'http://127.0.0.1/asug/e-mail-boleto-asug/[boleto_usuario]', '2014-03-23 22:27:44', '2014-06-06 12:26:51', '0000-00-00 00:00:00', '2014-06-06 12:26:51', '17', 'http://127.0.0.1/asug/e-mail-boleto-asug/%5Bboleto_usuario%5D', '0', '=== Código HTTP : 404 ===

HTTP/1.1 404 Not Found
Date: Fri, 06 Jun 2014 12:26:55 GMT
Server: Apache/2.4.7 (Win32) OpenSSL/1.0.1e PHP/5.5.9
X-Powered-By: PHP/5.5.9
Set-Cookie: PHPSESSID=aht1b0f41vqt6094kccqbr5g52; path=/
Expires: Wed, 11 Jan 1984 05:00:00 GMT
Cache-Control: no-cache, must-revalidate, max-age=0
Pragma: no-cache
X-CF-Powered-By: WP 1.3.14
X-Pingback: http://127.0.0.1/asug/xmlrpc.php
Transfer-Encoding: chunked
Content-Type: text/html; charset=UTF-8


O link está quebrado.', '404', '', '', '2.875', '0', '1', '1', '0', '404|broken|0|102e3d22e48d42ff66c7ff9dda5f7401', '0', '0'); 
INSERT INTO `wp_blc_links` VALUES ('8', 'http://www.asug.com.br', '0000-00-00 00:00:00', '2014-06-06 12:26:51', '2014-06-06 12:26:51', '2014-06-06 12:26:51', '0', 'http://www.asug.com.br/irj/portal/anonymous', '1', '=== Código HTTP : 200 ===

HTTP/1.1 302 Found
Location: http://www.asug.com.br/irj/portal/anonymous
Server: SAP J2EE Engine/7.00
Content-Length: 0
Date: Fri, 06 Jun 2014 12:26:52 GMT

HTTP/1.1 200 OK
Server: SAP J2EE Engine/7.00
Content-Type: text/html; charset=UTF-8
Connection: close
Content-Language: en-US
Date: Fri, 06 Jun 2014 12:26:52 GMT
Set-Cookie: PortalAlias=portal/anonymous; Path=/
Set-Cookie: saplb_*=(J2EE7563700)7563750; Version=1; Path=/
Set-Cookie: JSESSIONID=(J2EE7563700)ID1638266650DB71255c09379c842d367c91ca1220835c1d4b8e10End; Version=1; Domain=.asug.com.br; Path=/


O link é válido.', '200', '', '', '0.093', '0', '0', '1', '0', '200|0|0|1561d2ec40f2ba63fa6be2e9cad93f4d', '0', '0'); 
INSERT INTO `wp_blc_links` VALUES ('9', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg', '0000-00-00 00:00:00', '2014-06-06 12:26:57', '2014-06-06 12:26:57', '2014-06-06 12:26:57', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg', '0', '=== Código HTTP : 200 ===

HTTP/1.1 200 OK
Date: Fri, 06 Jun 2014 12:26:58 GMT
Server: Apache/2.4.7 (Win32) OpenSSL/1.0.1e PHP/5.5.9
Last-Modified: Fri, 30 May 2014 15:13:27 GMT
ETag: "1c16-4fa9f7cc79405"
Accept-Ranges: bytes
Content-Length: 7190
Content-Type: image/jpeg


O link é válido.', '200', '', '', '0.016', '0', '0', '1', '0', '200|0|0|06f5fc7295840e45d5a8b81b00d36af8', '0', '0'); 
INSERT INTO `wp_blc_links` VALUES ('10', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_cabecalho.jpg', '0000-00-00 00:00:00', '2014-06-06 12:26:58', '2014-06-06 12:26:58', '2014-06-06 12:26:58', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_cabecalho.jpg', '0', '=== Código HTTP : 200 ===

HTTP/1.1 200 OK
Date: Fri, 06 Jun 2014 12:27:00 GMT
Server: Apache/2.4.7 (Win32) OpenSSL/1.0.1e PHP/5.5.9
Last-Modified: Fri, 30 May 2014 15:13:27 GMT
ETag: "328e-4fa9f7cc7884b"
Accept-Ranges: bytes
Content-Length: 12942
Content-Type: image/jpeg


O link é válido.', '200', '', '', '0.047', '0', '0', '1', '0', '200|0|0|11626361f80de65d36a47e46bd8d1caa', '0', '0'); 
INSERT INTO `wp_blc_links` VALUES ('11', 'http://fliporto.net/2013/wp-content/uploads/2013/11/JoseSaramagoAssinatura.png', '0000-00-00 00:00:00', '2014-06-06 12:27:00', '2014-06-06 12:27:00', '2014-06-06 12:27:00', '0', 'http://fliporto.net/2013/wp-content/uploads/2013/11/JoseSaramagoAssinatura.png', '0', '=== Código HTTP : 200 ===

HTTP/1.1 200 OK
Date: Fri, 06 Jun 2014 12:27:01 GMT
Server: Apache/2.2.22 (Debian)
Last-Modified: Sat, 16 Nov 2013 16:13:07 GMT
ETag: "310-1edd-4eb4d972a2f33"
Accept-Ranges: bytes
Content-Length: 7901
Content-Type: image/png


O link é válido.', '200', '', '', '0.219', '0', '0', '1', '0', '200|0|0|49571ecdfc6dc4f39dd39c11cb32b45e', '0', '0'); 
INSERT INTO `wp_blc_links` VALUES ('12', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/pilares.jpg', '0000-00-00 00:00:00', '2014-06-04 16:38:08', '2014-06-04 16:38:08', '2014-06-04 16:38:08', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/pilares.jpg', '0', '=== Código HTTP : 200 ===

HTTP/1.1 200 OK
Date: Wed, 04 Jun 2014 16:38:08 GMT
Server: Apache/2.4.7 (Win32) OpenSSL/1.0.1e PHP/5.5.9
Last-Modified: Wed, 04 Jun 2014 16:36:07 GMT
ETag: "9ca0-4fb0539a51ecb"
Accept-Ranges: bytes
Content-Length: 40096
Content-Type: image/jpeg


O link é válido.', '200', '', '', '0.01031', '0', '0', '1', '0', '200|0|0|9858af886b07506f704bf22a01a88fa6', '0', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_blc_synch`
--
DROP TABLE IF EXISTS `wp_blc_synch`;
CREATE TABLE `wp_blc_synch` (
  `container_id` int(20) unsigned NOT NULL,
  `container_type` varchar(40) NOT NULL,
  `synched` tinyint(2) unsigned NOT NULL,
  `last_synch` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`container_type`,`container_id`),
  KEY `synched` (`synched`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_blc_synch`
--
LOCK TABLES `wp_blc_synch` WRITE;
INSERT INTO `wp_blc_synch` VALUES ('1', 'comment', '1', '2014-04-12 16:10:47'); 
INSERT INTO `wp_blc_synch` VALUES ('2', 'page', '1', '2014-04-22 21:21:58'); 
INSERT INTO `wp_blc_synch` VALUES ('6', 'page', '1', '2014-06-04 13:43:41'); 
INSERT INTO `wp_blc_synch` VALUES ('8', 'page', '1', '2014-04-12 16:10:48'); 
INSERT INTO `wp_blc_synch` VALUES ('16', 'page', '1', '2014-04-12 16:10:48'); 
INSERT INTO `wp_blc_synch` VALUES ('18', 'page', '1', '2014-04-12 16:10:48'); 
INSERT INTO `wp_blc_synch` VALUES ('20', 'page', '1', '2014-04-12 16:21:26'); 
INSERT INTO `wp_blc_synch` VALUES ('22', 'page', '1', '2014-04-12 16:22:01'); 
INSERT INTO `wp_blc_synch` VALUES ('35', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('37', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('39', 'page', '1', '2014-06-04 13:56:01'); 
INSERT INTO `wp_blc_synch` VALUES ('41', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('43', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('79', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('80', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('81', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('82', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('83', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('102', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('103', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('104', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('137', 'page', '1', '2014-04-12 16:10:49'); 
INSERT INTO `wp_blc_synch` VALUES ('160', 'page', '1', '2014-04-12 16:10:50'); 
INSERT INTO `wp_blc_synch` VALUES ('285', 'page', '1', '2014-04-12 16:10:50'); 
INSERT INTO `wp_blc_synch` VALUES ('291', 'page', '1', '2014-06-04 14:03:19'); 
INSERT INTO `wp_blc_synch` VALUES ('294', 'page', '1', '2014-04-12 16:17:50'); 
INSERT INTO `wp_blc_synch` VALUES ('329', 'page', '1', '2014-04-24 22:40:11'); 
INSERT INTO `wp_blc_synch` VALUES ('1', 'post', '1', '2014-04-12 16:10:50'); 
INSERT INTO `wp_blc_synch` VALUES ('90', 'post', '1', '2014-04-12 16:10:50'); 
INSERT INTO `wp_blc_synch` VALUES ('92', 'post', '1', '2014-04-12 16:10:50'); 
INSERT INTO `wp_blc_synch` VALUES ('94', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('213', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('222', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('226', 'post', '1', '2014-06-06 11:27:21'); 
INSERT INTO `wp_blc_synch` VALUES ('227', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('228', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('229', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('230', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('231', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('232', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('233', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('234', 'post', '1', '2014-04-12 16:10:51'); 
INSERT INTO `wp_blc_synch` VALUES ('309', 'post', '1', '2014-04-22 21:02:10'); 
INSERT INTO `wp_blc_synch` VALUES ('312', 'post', '1', '2014-04-22 21:15:50'); 
INSERT INTO `wp_blc_synch` VALUES ('313', 'post', '1', '2014-04-22 21:16:42'); 
INSERT INTO `wp_blc_synch` VALUES ('314', 'post', '1', '2014-04-22 21:17:51'); 
INSERT INTO `wp_blc_synch` VALUES ('364', 'post', '1', '2014-06-06 15:02:13'); 
INSERT INTO `wp_blc_synch` VALUES ('372', 'post', '1', '2014-04-26 22:04:05'); 
INSERT INTO `wp_blc_synch` VALUES ('373', 'post', '1', '2014-04-26 22:04:05'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_files`
--
DROP TABLE IF EXISTS `wp_bup_files`;
CREATE TABLE `wp_bup_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL,
  `date` datetime DEFAULT NULL,
  `download_limit` int(11) NOT NULL DEFAULT '0',
  `period_limit` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `type_id` smallint(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_files`
--
LOCK TABLES `wp_bup_files` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_bup_htmltype`
--
DROP TABLE IF EXISTS `wp_bup_htmltype`;
CREATE TABLE `wp_bup_htmltype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `label` (`label`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_htmltype`
--
LOCK TABLES `wp_bup_htmltype` WRITE;
INSERT INTO `wp_bup_htmltype` VALUES ('1', 'text', 'Text'); 
INSERT INTO `wp_bup_htmltype` VALUES ('2', 'password', 'Password'); 
INSERT INTO `wp_bup_htmltype` VALUES ('3', 'hidden', 'Hidden'); 
INSERT INTO `wp_bup_htmltype` VALUES ('4', 'checkbox', 'Checkbox'); 
INSERT INTO `wp_bup_htmltype` VALUES ('5', 'checkboxlist', 'Checkboxes'); 
INSERT INTO `wp_bup_htmltype` VALUES ('6', 'datepicker', 'Date Picker'); 
INSERT INTO `wp_bup_htmltype` VALUES ('7', 'submit', 'Button'); 
INSERT INTO `wp_bup_htmltype` VALUES ('8', 'img', 'Image'); 
INSERT INTO `wp_bup_htmltype` VALUES ('9', 'selectbox', 'Drop Down'); 
INSERT INTO `wp_bup_htmltype` VALUES ('10', 'radiobuttons', 'Radio Buttons'); 
INSERT INTO `wp_bup_htmltype` VALUES ('11', 'countryList', 'Countries List'); 
INSERT INTO `wp_bup_htmltype` VALUES ('12', 'selectlist', 'List'); 
INSERT INTO `wp_bup_htmltype` VALUES ('13', 'countryListMultiple', 'Country List with posibility to select multiple countries'); 
INSERT INTO `wp_bup_htmltype` VALUES ('14', 'block', 'Will show only value as text'); 
INSERT INTO `wp_bup_htmltype` VALUES ('15', 'statesList', 'States List'); 
INSERT INTO `wp_bup_htmltype` VALUES ('16', 'textFieldsDynamicTable', 'Dynamic table - multiple text options set'); 
INSERT INTO `wp_bup_htmltype` VALUES ('17', 'textarea', 'Textarea'); 
INSERT INTO `wp_bup_htmltype` VALUES ('18', 'checkboxHiddenVal', 'Checkbox with Hidden field'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_log`
--
DROP TABLE IF EXISTS `wp_bup_log`;
CREATE TABLE `wp_bup_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL,
  `data` text,
  `date_created` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_log`
--
LOCK TABLES `wp_bup_log` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_bup_modules`
--
DROP TABLE IF EXISTS `wp_bup_modules`;
CREATE TABLE `wp_bup_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `type_id` smallint(3) NOT NULL DEFAULT '0',
  `params` text,
  `has_tab` tinyint(1) NOT NULL DEFAULT '0',
  `label` varchar(128) DEFAULT NULL,
  `description` text,
  `ex_plug_dir` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_modules`
--
LOCK TABLES `wp_bup_modules` WRITE;
INSERT INTO `wp_bup_modules` VALUES ('1', 'adminmenu', '1', '1', '', '0', 'Admin Menu', '', ''); 
INSERT INTO `wp_bup_modules` VALUES ('2', 'options', '1', '1', '', '1', 'Options', '', ''); 
INSERT INTO `wp_bup_modules` VALUES ('3', 'log', '1', '1', '', '1', 'Log', 'Internal system module to log some actions on server', ''); 
INSERT INTO `wp_bup_modules` VALUES ('4', 'templates', '1', '1', '', '0', 'Templates for Plugin', '', ''); 
INSERT INTO `wp_bup_modules` VALUES ('5', 'backup', '1', '1', '', '1', 'Backup ready!', 'Backup ready!', ''); 
INSERT INTO `wp_bup_modules` VALUES ('6', 'schedule', '1', '1', '', '1', 'Schedule', 'Schedule', ''); 
INSERT INTO `wp_bup_modules` VALUES ('7', 'storage', '1', '1', '', '1', 'Storage', 'Storage', ''); 
INSERT INTO `wp_bup_modules` VALUES ('8', 'promo_ready', '1', '1', '', '0', 'Promo ready', '', ''); 
INSERT INTO `wp_bup_modules` VALUES ('9', 'logger', '1', '1', '', '0', 'System logger', '', ''); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_modules_type`
--
DROP TABLE IF EXISTS `wp_bup_modules_type`;
CREATE TABLE `wp_bup_modules_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_modules_type`
--
LOCK TABLES `wp_bup_modules_type` WRITE;
INSERT INTO `wp_bup_modules_type` VALUES ('1', 'system'); 
INSERT INTO `wp_bup_modules_type` VALUES ('2', 'addons'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_options`
--
DROP TABLE IF EXISTS `wp_bup_options`;
CREATE TABLE `wp_bup_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(64) CHARACTER SET latin1 NOT NULL,
  `value` longtext,
  `label` varchar(128) CHARACTER SET latin1 DEFAULT NULL,
  `description` text CHARACTER SET latin1,
  `htmltype_id` smallint(2) NOT NULL DEFAULT '1',
  `params` text,
  `cat_id` mediumint(3) DEFAULT '0',
  `sort_order` mediumint(3) DEFAULT '0',
  `value_type` varchar(16) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_options`
--
LOCK TABLES `wp_bup_options` WRITE;
INSERT INTO `wp_bup_options` VALUES ('1', 'full', '1', 'Full backup', 'on/off full backup', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('2', 'plugins', '0', 'Plugins', 'on/off backup plugins', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('3', 'themes', '0', 'Themes', 'on/off backup themes', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('4', 'uploads', '0', 'Uploads', 'on/off backup uploads', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('5', 'database', '0', 'Database', 'on/off backup database', '1', '', '0', '0', 'db_backup'); 
INSERT INTO `wp_bup_options` VALUES ('6', 'any_directories', '0', 'Any', 'Any other directories found inside wp-content', '1', '', '0', '0', 'dest_backup'); 
INSERT INTO `wp_bup_options` VALUES ('7', 'warehouse', '/wp-content/upready/', 'Warehouse', 'path to storage', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('8', 'warehouse_ignore', 'upready', 'Warehouse_ignore', 'Name ignore directory storage', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('9', 'safe_array', '', 'Safe array', 'Safe file array', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('10', 'count_folder', '', 'Count folder', 'Count folder', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('11', 'exclude', 'upgrade,cache', 'Exclude', 'Exclude directories', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('12', 'sch_enable', '0', 'Enable shedule', 'Enable shedule', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('13', 'sch_every_hour', '0', 'Schedule every hour', 'Schedule every hour', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('14', 'sch_every_day', '0', 'Schedule every day', 'Schedule every day', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('15', 'sch_every_day_twice', '0', 'Schedule every day twice', 'Schedule every day twice', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('16', 'sch_every_week', '0', 'Schedule every week', 'Schedule every week', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('17', 'sch_every_month', '0', 'Schedule every month', 'Schedule every month', '1', '', '0', '0', 'every'); 
INSERT INTO `wp_bup_options` VALUES ('18', 'sch_time', 'a:1:{i:1;i:0;}', 'Schedule time backup', 'Schedule time backup', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('19', 'sch_dest', '1', 'Destination backup', 'Destination backup', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('20', 'email', '', 'Email', 'Email', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('21', 'glb_dest', 'ftp', 'Manual destination', 'Manual destination', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('22', 'force_update', '0', 'Force Update', 'Force Update', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('23', 'safe_update', '1', 'Safe Update', 'Safe Update', '1', '', '0', '0', ''); 
INSERT INTO `wp_bup_options` VALUES ('24', 'replace_newer', '1', 'Replace Newer', 'Replace newer files or not', '1', '', '0', '0', ''); 

UNLOCK TABLES;
--
-- Table structure for table `wp_bup_options_categories`
--
DROP TABLE IF EXISTS `wp_bup_options_categories`;
CREATE TABLE `wp_bup_options_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_bup_options_categories`
--
LOCK TABLES `wp_bup_options_categories` WRITE;
INSERT INTO `wp_bup_options_categories` VALUES ('1', 'General'); 
INSERT INTO `wp_bup_options_categories` VALUES ('2', 'Template'); 
INSERT INTO `wp_bup_options_categories` VALUES ('3', 'Subscribe'); 
INSERT INTO `wp_bup_options_categories` VALUES ('4', 'Social'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_cadastro_eventos`
--
DROP TABLE IF EXISTS `wp_cadastro_eventos`;
CREATE TABLE `wp_cadastro_eventos` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `id_post` int(200) NOT NULL,
  `id_usuario` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `empresa` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefone` varchar(30) NOT NULL,
  `celular` varchar(30) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `perfil` varchar(110) NOT NULL,
  `cargo` varchar(200) NOT NULL,
  `data_de_inscricao` date NOT NULL,
  `status` int(2) NOT NULL,
  `boleto` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=490 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_cadastro_eventos`
--
LOCK TABLES `wp_cadastro_eventos` WRITE;
INSERT INTO `wp_cadastro_eventos` VALUES ('479', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'aeee', '0000-00-00', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/wireframe-interna-ASUG.pdf'); 
INSERT INTO `wp_cadastro_eventos` VALUES ('480', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'aeee', '0000-00-00', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/wireframe-interna-ASUG.pdf'); 
INSERT INTO `wp_cadastro_eventos` VALUES ('481', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'aeee', '0000-00-00', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/PASSEI_online_menor_1.pdf'); 
INSERT INTO `wp_cadastro_eventos` VALUES ('482', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'aeee', '0000-00-00', '0', ''); 
INSERT INTO `wp_cadastro_eventos` VALUES ('483', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'aeee', '0000-00-00', '1', ''); 
INSERT INTO `wp_cadastro_eventos` VALUES ('484', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'aeee', '0000-00-00', '1', ''); 
INSERT INTO `wp_cadastro_eventos` VALUES ('485', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'aeee', '0000-00-00', '1', ''); 
INSERT INTO `wp_cadastro_eventos` VALUES ('486', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'aeee', '0000-00-00', '1', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014036.pdf'); 
INSERT INTO `wp_cadastro_eventos` VALUES ('487', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'aeee', '0000-00-00', '0', ''); 
INSERT INTO `wp_cadastro_eventos` VALUES ('488', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '11975915007', 'Av Francisco Prestes Maia, 345', 'administrator', 'testaa', '0000-00-00', '1', ''); 
INSERT INTO `wp_cadastro_eventos` VALUES ('489', '364', '1', 'Nome Sobrenome', 'Montar Site', 'contato@montarsite.com.br', '1175915007', '98584-3772', 'Av Padre Anchieta, 176 - Jordanopolis', 'administrator', 'CEO', '0000-00-00', '0', ''); 

UNLOCK TABLES;
--
-- Table structure for table `wp_commentmeta`
--
DROP TABLE IF EXISTS `wp_commentmeta`;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_commentmeta`
--
LOCK TABLES `wp_commentmeta` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_comments`
--
DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_comments`
--
LOCK TABLES `wp_comments` WRITE;
INSERT INTO `wp_comments` VALUES ('1', '1', 'Sr. WordPress', '', 'http://wordpress.org/', '', '2014-03-15 15:51:25', '2014-03-15 15:51:25', 'Olá, Isto é um comentário.
Para excluir um comentário, faça o login e veja os comentários de posts. Lá você terá a opção de editá-los ou excluí-los.', '0', '1', '', '', '0', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_ewwwio_images`
--
DROP TABLE IF EXISTS `wp_ewwwio_images`;
CREATE TABLE `wp_ewwwio_images` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  `image_md5` varchar(55) DEFAULT NULL,
  `results` varchar(55) NOT NULL,
  `gallery` varchar(30) DEFAULT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_ewwwio_images`
--
LOCK TABLES `wp_ewwwio_images` WRITE;
INSERT INTO `wp_ewwwio_images` VALUES ('1', 'C:xampphtdocsasug/wp-content/uploads/2014/03/asug-brasil-150x76.jpg', '', 'No savings', '', '5539', '5539'); 
INSERT INTO `wp_ewwwio_images` VALUES ('2', 'C:xampphtdocsasug/wp-content/uploads/2014/03/asug-brasil.jpg', '', 'No savings', '', '7992', '7992'); 
INSERT INTO `wp_ewwwio_images` VALUES ('3', 'C:xampphtdocsasug/wp-content/uploads/2014/03/slider-150x150.jpg', '', 'No savings', '', '8444', '8444'); 
INSERT INTO `wp_ewwwio_images` VALUES ('4', 'C:xampphtdocsasug/wp-content/uploads/2014/03/slider-300x138.jpg', '', 'No savings', '', '14952', '14952'); 
INSERT INTO `wp_ewwwio_images` VALUES ('5', 'C:xampphtdocsasug/wp-content/uploads/2014/03/slider.jpg', '', 'No savings', '', '43712', '43712'); 
INSERT INTO `wp_ewwwio_images` VALUES ('6', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner03-150x121.jpg', '', 'No savings', '', '6771', '6771'); 
INSERT INTO `wp_ewwwio_images` VALUES ('7', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner03.jpg', '', 'No savings', '', '28264', '28264'); 
INSERT INTO `wp_ewwwio_images` VALUES ('8', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner04-150x121.jpg', '', 'No savings', '', '9955', '9955'); 
INSERT INTO `wp_ewwwio_images` VALUES ('9', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner04.jpg', '', 'No savings', '', '37298', '37298'); 
INSERT INTO `wp_ewwwio_images` VALUES ('10', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner01-150x122.jpg', '', 'No savings', '', '8160', '8160'); 
INSERT INTO `wp_ewwwio_images` VALUES ('11', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner01.jpg', '', 'No savings', '', '30840', '30840'); 
INSERT INTO `wp_ewwwio_images` VALUES ('12', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner02-150x122.jpg', '', 'No savings', '', '9855', '9855'); 
INSERT INTO `wp_ewwwio_images` VALUES ('13', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner02.jpg', '', 'No savings', '', '37694', '37694'); 
INSERT INTO `wp_ewwwio_images` VALUES ('14', 'C:xampphtdocsasug/wp-content/uploads/2014/03/eventos01.jpg', '', 'No savings', '', '7911', '7911'); 
INSERT INTO `wp_ewwwio_images` VALUES ('15', 'C:xampphtdocsasug/wp-content/uploads/2014/03/eventos02.jpg', '', 'No savings', '', '8019', '8019'); 
INSERT INTO `wp_ewwwio_images` VALUES ('16', 'C:xampphtdocsasug/wp-content/uploads/2014/03/eventos011.jpg', '', 'No savings', '', '7911', '7911'); 
INSERT INTO `wp_ewwwio_images` VALUES ('17', 'C:xampphtdocsasug/wp-content/uploads/2014/03/eventos021.jpg', '', 'No savings', '', '8019', '8019'); 
INSERT INTO `wp_ewwwio_images` VALUES ('18', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner-150x150.jpg', '', 'No savings', '', '8455', '8455'); 
INSERT INTO `wp_ewwwio_images` VALUES ('19', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner-300x73.jpg', '', 'No savings', '', '9936', '9936'); 
INSERT INTO `wp_ewwwio_images` VALUES ('20', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner-90x90.jpg', '', 'No savings', '', '3557', '3557'); 
INSERT INTO `wp_ewwwio_images` VALUES ('21', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner-300x248.jpg', '', 'No savings', '', '30758', '30758'); 
INSERT INTO `wp_ewwwio_images` VALUES ('22', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner-624x151.jpg', '', 'No savings', '', '34087', '34087'); 
INSERT INTO `wp_ewwwio_images` VALUES ('23', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner.jpg', '', 'No savings', '', '234001', '234001'); 
INSERT INTO `wp_ewwwio_images` VALUES ('24', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner_comite-150x150.jpg', '', 'No savings', '', '5446', '5446'); 
INSERT INTO `wp_ewwwio_images` VALUES ('25', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner_comite-300x73.jpg', '', 'No savings', '', '7998', '7998'); 
INSERT INTO `wp_ewwwio_images` VALUES ('26', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner_comite-90x90.jpg', '', 'No savings', '', '2705', '2705'); 
INSERT INTO `wp_ewwwio_images` VALUES ('27', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner_comite-300x248.jpg', '', 'No savings', '', '16411', '16411'); 
INSERT INTO `wp_ewwwio_images` VALUES ('28', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner_comite-624x151.jpg', '', 'No savings', '', '23769', '23769'); 
INSERT INTO `wp_ewwwio_images` VALUES ('29', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner_comite.jpg', '', 'No savings', '', '134225', '134225'); 
INSERT INTO `wp_ewwwio_images` VALUES ('30', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner1-150x150.jpg', '', 'No savings', '', '8455', '8455'); 
INSERT INTO `wp_ewwwio_images` VALUES ('31', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner1-300x73.jpg', '', 'No savings', '', '9936', '9936'); 
INSERT INTO `wp_ewwwio_images` VALUES ('32', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner1-90x90.jpg', '', 'No savings', '', '3557', '3557'); 
INSERT INTO `wp_ewwwio_images` VALUES ('33', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner1-300x248.jpg', '', 'No savings', '', '30758', '30758'); 
INSERT INTO `wp_ewwwio_images` VALUES ('34', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner1-624x151.jpg', '', 'No savings', '', '34087', '34087'); 
INSERT INTO `wp_ewwwio_images` VALUES ('35', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner1.jpg', '', 'No savings', '', '234001', '234001'); 
INSERT INTO `wp_ewwwio_images` VALUES ('36', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner1-96x96.jpg', '', 'No savings', '', '3689', '3689'); 
INSERT INTO `wp_ewwwio_images` VALUES ('37', 'C:xampphtdocsasug/wp-content/uploads/2014/03/banner1-32x32.jpg', '', 'No savings', '', '1028', '1028'); 
INSERT INTO `wp_ewwwio_images` VALUES ('38', 'C:xampphtdocsasug/wp-content/uploads/2014/03/capa-revista-hsm-management-01-150x150.jpg', '', 'No savings', '', '9910', '9910'); 
INSERT INTO `wp_ewwwio_images` VALUES ('39', 'C:xampphtdocsasug/wp-content/uploads/2014/03/capa-revista-hsm-management-01-226x300.jpg', '', 'No savings', '', '25956', '25956'); 
INSERT INTO `wp_ewwwio_images` VALUES ('40', 'C:xampphtdocsasug/wp-content/uploads/2014/03/capa-revista-hsm-management-01.jpg', '', 'No savings', '', '48801', '48801'); 
INSERT INTO `wp_ewwwio_images` VALUES ('41', 'C:xampphtdocsasug/wp-content/uploads/2014/04/capa-revista-gloss-150x150.jpg', '', 'No savings', '', '13992', '13992'); 
INSERT INTO `wp_ewwwio_images` VALUES ('42', 'C:xampphtdocsasug/wp-content/uploads/2014/04/capa-revista-gloss-229x300.jpg', '', 'No savings', '', '36036', '36036'); 
INSERT INTO `wp_ewwwio_images` VALUES ('43', 'C:xampphtdocsasug/wp-content/uploads/2014/04/capa-revista-gloss.jpg', '', 'No savings', '', '92196', '92196'); 
INSERT INTO `wp_ewwwio_images` VALUES ('44', 'C:xampphtdocsasug/wp-content/uploads/2014/03/revista-150x150.jpg', '', 'No savings', '', '7958', '7958'); 
INSERT INTO `wp_ewwwio_images` VALUES ('45', 'C:xampphtdocsasug/wp-content/uploads/2014/03/revista-300x73.jpg', '', 'No savings', '', '9728', '9728'); 
INSERT INTO `wp_ewwwio_images` VALUES ('46', 'C:xampphtdocsasug/wp-content/uploads/2014/03/revista-624x151.jpg', '', 'No savings', '', '31424', '31424'); 
INSERT INTO `wp_ewwwio_images` VALUES ('47', 'C:xampphtdocsasug/wp-content/uploads/2014/03/revista.jpg', '', 'No savings', '', '237535', '237535'); 
INSERT INTO `wp_ewwwio_images` VALUES ('48', 'C:xampphtdocsasug/wp-content/uploads/2014/04/asug_recibo_cabecalho-150x71.jpg', '', 'No savings', '', '1387', '1387'); 
INSERT INTO `wp_ewwwio_images` VALUES ('49', 'C:xampphtdocsasug/wp-content/uploads/2014/04/asug_recibo_cabecalho-300x20.jpg', '', 'No savings', '', '2637', '2637'); 
INSERT INTO `wp_ewwwio_images` VALUES ('50', 'C:xampphtdocsasug/wp-content/uploads/2014/04/asug_recibo_cabecalho-624x43.jpg', '', 'No savings', '', '6458', '6458'); 
INSERT INTO `wp_ewwwio_images` VALUES ('51', 'C:xampphtdocsasug/wp-content/uploads/2014/04/asug_recibo_cabecalho.jpg', '', 'No savings', '', '12942', '12942'); 
INSERT INTO `wp_ewwwio_images` VALUES ('52', 'C:xampphtdocsasug/wp-content/uploads/2014/04/asug_recibo_rodape-150x38.jpg', '', 'No savings', '', '1332', '1332'); 
INSERT INTO `wp_ewwwio_images` VALUES ('53', 'C:xampphtdocsasug/wp-content/uploads/2014/04/asug_recibo_rodape-300x11.jpg', '', 'No savings', '', '2021', '2021'); 
INSERT INTO `wp_ewwwio_images` VALUES ('54', 'C:xampphtdocsasug/wp-content/uploads/2014/04/asug_recibo_rodape-624x23.jpg', '', 'No savings', '', '4184', '4184'); 
INSERT INTO `wp_ewwwio_images` VALUES ('55', 'C:xampphtdocsasug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg', '', 'No savings', '', '7190', '7190'); 
INSERT INTO `wp_ewwwio_images` VALUES ('56', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/copy-asug-brasil-150x76.jpg', '', 'No savings', '', '5539', '5539'); 
INSERT INTO `wp_ewwwio_images` VALUES ('57', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/copy-asug-brasil.jpg', '', 'No savings', '', '7992', '7992'); 
INSERT INTO `wp_ewwwio_images` VALUES ('58', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/Technology-news1-150x150.jpg', '', 'No savings', '', '6809', '6809'); 
INSERT INTO `wp_ewwwio_images` VALUES ('59', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/Technology-news1-300x252.jpg', '', 'No savings', '', '14859', '14859'); 
INSERT INTO `wp_ewwwio_images` VALUES ('60', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/Technology-news1-624x525.jpg', '', 'No savings', '', '40840', '40840'); 
INSERT INTO `wp_ewwwio_images` VALUES ('61', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/Technology-news1.jpg', '', 'No savings', '', '474216', '474216'); 
INSERT INTO `wp_ewwwio_images` VALUES ('62', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/circuit-Sqr1-150x150.jpg', '', 'No savings', '', '11594', '11594'); 
INSERT INTO `wp_ewwwio_images` VALUES ('63', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/circuit-Sqr1-300x199.jpg', '', 'No savings', '', '25850', '25850'); 
INSERT INTO `wp_ewwwio_images` VALUES ('64', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/circuit-Sqr1-1024x682.jpg', '', 'No savings', '', '170092', '170092'); 
INSERT INTO `wp_ewwwio_images` VALUES ('65', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/circuit-Sqr1-624x415.jpg', '', 'No savings', '', '80310', '80310'); 
INSERT INTO `wp_ewwwio_images` VALUES ('66', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/circuit-Sqr1.jpg', '', 'No savings', '', '2085243', '2085243'); 
INSERT INTO `wp_ewwwio_images` VALUES ('67', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/technology-hand1-150x150.jpg', '', 'No savings', '', '7380', '7380'); 
INSERT INTO `wp_ewwwio_images` VALUES ('68', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/technology-hand1-300x199.jpg', '', 'No savings', '', '14578', '14578'); 
INSERT INTO `wp_ewwwio_images` VALUES ('69', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/technology-hand1-1024x682.jpg', '', 'No savings', '', '105408', '105408'); 
INSERT INTO `wp_ewwwio_images` VALUES ('70', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/technology-hand1-624x415.jpg', '', 'No savings', '', '47405', '47405'); 
INSERT INTO `wp_ewwwio_images` VALUES ('71', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/technology-hand1.jpg', '', 'No savings', '', '256385', '256385'); 
INSERT INTO `wp_ewwwio_images` VALUES ('72', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/cpuaroundworld_alpha1-150x150.png', '', 'No savings', '', '22176', '22176'); 
INSERT INTO `wp_ewwwio_images` VALUES ('73', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/cpuaroundworld_alpha1-300x225.png', '', 'No savings', '', '49283', '49283'); 
INSERT INTO `wp_ewwwio_images` VALUES ('74', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/cpuaroundworld_alpha1-1024x768.png', '', 'No savings', '', '387476', '387476'); 
INSERT INTO `wp_ewwwio_images` VALUES ('75', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/cpuaroundworld_alpha1-624x468.png', '', 'No savings', '', '166685', '166685'); 
INSERT INTO `wp_ewwwio_images` VALUES ('76', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/cpuaroundworld_alpha1.png', '', 'No savings', '', '842053', '842053'); 
INSERT INTO `wp_ewwwio_images` VALUES ('77', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/capa-revista-hsm-management-01-96x96.jpg', '', 'No savings', '', '4899', '4899'); 
INSERT INTO `wp_ewwwio_images` VALUES ('78', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/capa-revista-hsm-management-01-32x32.jpg', '', 'Reduced by 25.7% (326,0&nbsp;B&nbsp;)', '', '941', '1267'); 
INSERT INTO `wp_ewwwio_images` VALUES ('79', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/06/bn-ret-150x150.jpg', '', 'Reduced by 6.3% (502,0&nbsp;B&nbsp;)', '', '7438', '7940'); 
INSERT INTO `wp_ewwwio_images` VALUES ('80', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/06/bn-ret-300x156.jpg', '', 'Reduced by 6.3% (966,0&nbsp;B&nbsp;)', '', '14329', '15295'); 
INSERT INTO `wp_ewwwio_images` VALUES ('81', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/06/bn-ret.jpg', '', 'Reduced by 1.6% (580,0&nbsp;B&nbsp;)', '', '36298', '36878'); 
INSERT INTO `wp_ewwwio_images` VALUES ('82', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/pilares-150x150.jpg', '', 'Reduced by 10.5% (744,0&nbsp;B&nbsp;)', '', '6371', '7115'); 
INSERT INTO `wp_ewwwio_images` VALUES ('83', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/pilares-300x214.jpg', '', 'Reduced by 10.5% (1,5&nbsp;kB)', '', '13432', '15009'); 
INSERT INTO `wp_ewwwio_images` VALUES ('84', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/03/pilares.jpg', '', 'Reduced by 1.8% (743,0&nbsp;B&nbsp;)', '', '40096', '40839'); 
INSERT INTO `wp_ewwwio_images` VALUES ('85', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/banner-conf-150x150.jpg', '', 'Reduced by 7.9% (636,0&nbsp;B&nbsp;)', '', '7424', '8060'); 
INSERT INTO `wp_ewwwio_images` VALUES ('86', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/banner-conf-300x72.jpg', '', 'Reduced by 6.6% (615,0&nbsp;B&nbsp;)', '', '8768', '9383'); 
INSERT INTO `wp_ewwwio_images` VALUES ('87', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/banner-conf-624x151.jpg', '', 'Reduced by 8.2% (2,3&nbsp;kB)', '', '26543', '28929'); 
INSERT INTO `wp_ewwwio_images` VALUES ('88', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/banner-conf.jpg', '', 'Reduced by 2.7% (1,8&nbsp;kB)', '', '66780', '68632'); 
INSERT INTO `wp_ewwwio_images` VALUES ('89', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/bt-insc-150x33.gif', '', 'No savings', '', '618', '618'); 
INSERT INTO `wp_ewwwio_images` VALUES ('90', 'C:\xampp\htdocs\asug/wp-content/uploads/2014/04/bt-insc.gif', '', 'No savings', '', '1671', '1671'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_itsec_lockouts`
--
DROP TABLE IF EXISTS `wp_itsec_lockouts`;
CREATE TABLE `wp_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(20) DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_itsec_lockouts`
--
LOCK TABLES `wp_itsec_lockouts` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_itsec_log`
--
DROP TABLE IF EXISTS `wp_itsec_log`;
CREATE TABLE `wp_itsec_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) NOT NULL DEFAULT '',
  `log_function` varchar(255) NOT NULL DEFAULT '',
  `log_priority` int(2) NOT NULL DEFAULT '1',
  `log_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_host` varchar(20) DEFAULT NULL,
  `log_username` varchar(20) DEFAULT NULL,
  `log_user` bigint(20) unsigned DEFAULT NULL,
  `log_url` varchar(255) DEFAULT NULL,
  `log_referrer` varchar(255) DEFAULT NULL,
  `log_data` longtext NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_itsec_log`
--
LOCK TABLES `wp_itsec_log` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_itsec_temp`
--
DROP TABLE IF EXISTS `wp_itsec_temp`;
CREATE TABLE `wp_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(20) DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_itsec_temp`
--
LOCK TABLES `wp_itsec_temp` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_links`
--
DROP TABLE IF EXISTS `wp_links`;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_links`
--
LOCK TABLES `wp_links` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_communications`
--
DROP TABLE IF EXISTS `wp_m_communications`;
CREATE TABLE `wp_m_communications` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) DEFAULT NULL,
  `message` text,
  `periodunit` int(11) DEFAULT NULL,
  `periodtype` varchar(5) DEFAULT NULL,
  `periodprepost` varchar(5) DEFAULT NULL,
  `lastupdated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `active` int(11) DEFAULT '0',
  `periodstamp` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_communications`
--
LOCK TABLES `wp_m_communications` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_coupons`
--
DROP TABLE IF EXISTS `wp_m_coupons`;
CREATE TABLE `wp_m_coupons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) DEFAULT '0',
  `couponcode` varchar(250) DEFAULT NULL,
  `discount` decimal(11,2) DEFAULT '0.00',
  `discount_type` varchar(5) DEFAULT NULL,
  `discount_currency` varchar(5) DEFAULT NULL,
  `coupon_startdate` datetime DEFAULT NULL,
  `coupon_enddate` datetime DEFAULT NULL,
  `coupon_sub_id` bigint(20) DEFAULT '0',
  `coupon_uses` int(11) DEFAULT '0',
  `coupon_used` int(11) DEFAULT '0',
  `coupon_apply_to` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `couponcode` (`couponcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_coupons`
--
LOCK TABLES `wp_m_coupons` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_levelmeta`
--
DROP TABLE IF EXISTS `wp_m_levelmeta`;
CREATE TABLE `wp_m_levelmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_id` bigint(20) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_value` text,
  `meta_stamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `level_id` (`level_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_levelmeta`
--
LOCK TABLES `wp_m_levelmeta` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_member_payments`
--
DROP TABLE IF EXISTS `wp_m_member_payments`;
CREATE TABLE `wp_m_member_payments` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `member_id` bigint(20) DEFAULT NULL,
  `sub_id` bigint(20) DEFAULT NULL,
  `level_id` bigint(20) DEFAULT NULL,
  `level_order` int(11) DEFAULT NULL,
  `paymentmade` datetime DEFAULT NULL,
  `paymentexpires` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_member_payments`
--
LOCK TABLES `wp_m_member_payments` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_membership_levels`
--
DROP TABLE IF EXISTS `wp_m_membership_levels`;
CREATE TABLE `wp_m_membership_levels` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `level_title` varchar(250) DEFAULT NULL,
  `level_slug` varchar(250) DEFAULT NULL,
  `level_active` int(11) DEFAULT '0',
  `level_count` bigint(20) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_membership_levels`
--
LOCK TABLES `wp_m_membership_levels` WRITE;
INSERT INTO `wp_m_membership_levels` VALUES ('1', 'assinantes', 'assinantes', '1', '0'); 
INSERT INTO `wp_m_membership_levels` VALUES ('2', 'Visitors', 'visitors', '1', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_membership_news`
--
DROP TABLE IF EXISTS `wp_m_membership_news`;
CREATE TABLE `wp_m_membership_news` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `newsitem` text,
  `newsdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_membership_news`
--
LOCK TABLES `wp_m_membership_news` WRITE;
INSERT INTO `wp_m_membership_news` VALUES ('1', '<strong>pita</strong> has joined level <strong>assinantes</strong> on subscription <strong>assinantes</strong>', '2014-03-20 02:31:41'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_membership_relationships`
--
DROP TABLE IF EXISTS `wp_m_membership_relationships`;
CREATE TABLE `wp_m_membership_relationships` (
  `rel_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT '0',
  `sub_id` bigint(20) DEFAULT '0',
  `level_id` bigint(20) DEFAULT '0',
  `startdate` datetime DEFAULT NULL,
  `updateddate` datetime DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `order_instance` bigint(20) DEFAULT '0',
  `usinggateway` varchar(50) DEFAULT 'admin',
  PRIMARY KEY (`rel_id`),
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  KEY `usinggateway` (`usinggateway`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_membership_relationships`
--
LOCK TABLES `wp_m_membership_relationships` WRITE;
INSERT INTO `wp_m_membership_relationships` VALUES ('1', '2', '1', '1', '2014-03-20 02:31:41', '2014-03-20 02:31:41', '2015-03-20 02:31:41', '1', 'admin'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_membership_rules`
--
DROP TABLE IF EXISTS `wp_m_membership_rules`;
CREATE TABLE `wp_m_membership_rules` (
  `level_id` bigint(20) NOT NULL DEFAULT '0',
  `rule_ive` varchar(20) NOT NULL DEFAULT '',
  `rule_area` varchar(20) NOT NULL DEFAULT '',
  `rule_value` text,
  `rule_order` int(11) DEFAULT '0',
  PRIMARY KEY (`level_id`,`rule_ive`,`rule_area`),
  KEY `rule_area` (`rule_area`),
  KEY `rule_ive` (`rule_ive`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_membership_rules`
--
LOCK TABLES `wp_m_membership_rules` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_ping_history`
--
DROP TABLE IF EXISTS `wp_m_ping_history`;
CREATE TABLE `wp_m_ping_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ping_id` bigint(20) DEFAULT NULL,
  `ping_sent` timestamp NULL DEFAULT NULL,
  `ping_info` text,
  `ping_return` text,
  PRIMARY KEY (`id`),
  KEY `ping_id` (`ping_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_ping_history`
--
LOCK TABLES `wp_m_ping_history` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_pings`
--
DROP TABLE IF EXISTS `wp_m_pings`;
CREATE TABLE `wp_m_pings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pingname` varchar(250) DEFAULT NULL,
  `pingurl` varchar(250) DEFAULT NULL,
  `pinginfo` text,
  `pingtype` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_pings`
--
LOCK TABLES `wp_m_pings` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_subscription_transaction`
--
DROP TABLE IF EXISTS `wp_m_subscription_transaction`;
CREATE TABLE `wp_m_subscription_transaction` (
  `transaction_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_subscription_ID` bigint(20) NOT NULL DEFAULT '0',
  `transaction_user_ID` bigint(20) NOT NULL DEFAULT '0',
  `transaction_sub_ID` bigint(20) DEFAULT '0',
  `transaction_paypal_ID` varchar(30) DEFAULT NULL,
  `transaction_payment_type` varchar(20) DEFAULT NULL,
  `transaction_stamp` bigint(35) NOT NULL DEFAULT '0',
  `transaction_total_amount` bigint(20) DEFAULT NULL,
  `transaction_currency` varchar(35) DEFAULT NULL,
  `transaction_status` varchar(35) DEFAULT NULL,
  `transaction_duedate` date DEFAULT NULL,
  `transaction_gateway` varchar(50) DEFAULT NULL,
  `transaction_note` text,
  `transaction_expires` datetime DEFAULT NULL,
  PRIMARY KEY (`transaction_ID`),
  KEY `transaction_gateway` (`transaction_gateway`),
  KEY `transaction_subscription_ID` (`transaction_subscription_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_subscription_transaction`
--
LOCK TABLES `wp_m_subscription_transaction` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_m_subscriptionmeta`
--
DROP TABLE IF EXISTS `wp_m_subscriptionmeta`;
CREATE TABLE `wp_m_subscriptionmeta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub_id` bigint(20) DEFAULT NULL,
  `meta_key` varchar(250) DEFAULT NULL,
  `meta_value` text,
  `meta_stamp` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_id` (`sub_id`,`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_subscriptionmeta`
--
LOCK TABLES `wp_m_subscriptionmeta` WRITE;
INSERT INTO `wp_m_subscriptionmeta` VALUES ('1', '1', 'joining_ping', '', '0000-00-00 00:00:00'); 
INSERT INTO `wp_m_subscriptionmeta` VALUES ('2', '1', 'leaving_ping', '', '0000-00-00 00:00:00'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_subscriptions`
--
DROP TABLE IF EXISTS `wp_m_subscriptions`;
CREATE TABLE `wp_m_subscriptions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sub_name` varchar(200) DEFAULT NULL,
  `sub_active` int(11) DEFAULT '0',
  `sub_public` int(11) DEFAULT '0',
  `sub_count` bigint(20) DEFAULT '0',
  `sub_description` text,
  `sub_pricetext` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_subscriptions`
--
LOCK TABLES `wp_m_subscriptions` WRITE;
INSERT INTO `wp_m_subscriptions` VALUES ('1', 'assinantes', '1', '1', '0', '', ''); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_subscriptions_levels`
--
DROP TABLE IF EXISTS `wp_m_subscriptions_levels`;
CREATE TABLE `wp_m_subscriptions_levels` (
  `sub_id` bigint(20) DEFAULT NULL,
  `level_id` bigint(20) DEFAULT NULL,
  `level_period` int(11) DEFAULT NULL,
  `sub_type` varchar(20) DEFAULT NULL,
  `level_price` decimal(11,2) DEFAULT '0.00',
  `level_currency` varchar(5) DEFAULT NULL,
  `level_order` bigint(20) DEFAULT '0',
  `level_period_unit` varchar(1) DEFAULT 'd',
  KEY `sub_id` (`sub_id`),
  KEY `level_id` (`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_subscriptions_levels`
--
LOCK TABLES `wp_m_subscriptions_levels` WRITE;
INSERT INTO `wp_m_subscriptions_levels` VALUES ('1', '1', '1', 'finite', '1800.00', '', '1', 'y'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_m_urlgroups`
--
DROP TABLE IF EXISTS `wp_m_urlgroups`;
CREATE TABLE `wp_m_urlgroups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(250) DEFAULT NULL,
  `groupurls` text,
  `isregexp` int(11) DEFAULT '0',
  `stripquerystring` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_m_urlgroups`
--
LOCK TABLES `wp_m_urlgroups` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_nextend_smartslider_layouts`
--
DROP TABLE IF EXISTS `wp_nextend_smartslider_layouts`;
CREATE TABLE `wp_nextend_smartslider_layouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `slide` longtext,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_nextend_smartslider_layouts`
--
LOCK TABLES `wp_nextend_smartslider_layouts` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_nextend_smartslider_sliders`
--
DROP TABLE IF EXISTS `wp_nextend_smartslider_sliders`;
CREATE TABLE `wp_nextend_smartslider_sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `params` text NOT NULL,
  `generator` text NOT NULL,
  `slide` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_nextend_smartslider_sliders`
--
LOCK TABLES `wp_nextend_smartslider_sliders` WRITE;
INSERT INTO `wp_nextend_smartslider_sliders` VALUES ('2', 'Slide Home', 'simple', '{"size":"542|*|250|*|1","responsive":"1|*|0","globalfontsize":"12|*|16|*|20","margin":"0|*|0|*|0|*|0|*|px","simplebackgroundimage":"","simplebackgroundimagesize":"auto","simplepadding":"0|*|0|*|0|*|0","simpleborder":"0|*|3E3E3Eff","simpleborderradius":"0|*|0|*|0|*|0","simpleresponsivemaxwidth":"3000","improvedtouch":"horizontal","simpleskins":"","simpleslidercss":"","simpleanimation":"horizontal","simpleanimationproperties":"800|*|0|*|easeInOutQuad|*|1","simplebackgroundanimation":"0|*|bars||blocks","fadeonload":"1|*|0","playfirstlayer":"0","mainafterout":"0","inaftermain":"1","controls":"0|*|horizontal|*|0","blockrightclick":"0","imageload":"0|*|0","backgroundresize":"cover","randomize":"0","autoplay":"1|*|8000","autoplayfinish":"0|*|loop|*|current","stopautoplay":"1|*|1|*|1","resumeautoplay":"0|*|1|*|0","widgetarrow":"transition","widgetarrowdisplay":"1|*|always|*|0|*|0","previousposition":"left|*|0|*|%|*|top|*|height/2-previousheight/2|*|%","previous":"/plugins/smart-slider-2/plugins/nextendsliderwidgetarrow/transition/transition/previous/my-test.png","nextposition":"right|*|0|*|%|*|top|*|height/2-nextheight/2|*|%","next":"/plugins/smart-slider-2/plugins/nextendsliderwidgetarrow/transition/transition/next/my-test.png","arrowbackground":"00000080","arrowbackgroundhover":"7670c7ff","widgetbullet":"numbers","widgetbulletdisplay":"1|*|always|*|0|*|0","bulletposition":"left|*|0|*|%|*|bottom|*|5|*|%","bulletwidth":"100%","bulletorientation":"horizontal","bulletalign":"center","bullet":"/plugins/smart-slider-2/plugins/nextendsliderwidgetbullet/numbers/numbers/bullets/square.png","bulletbackground":"00000060","bulletbackgroundhover":"7670C7ff","fontclassnumber":"sliderfont7","bulletbar":"none","bulletshadow":"none","bulletbarcolor":"00000060","bullethumbnail":"0|*|top","thumbnailsizebullet":"100|*|60","bulletthumbnail":"00000060","widgets":"arrow"}', '{"enabled":"1","cachetime":"1","generateslides":"1000|*|1|*|1","generatorgroup":"1","images":"{"0":{"image":"http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg","title":"slider","url":"","description":""},"1":{"image":"http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg","title":"slider","url":"","description":""},"2":{"image":"http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg","title":"slider","url":"","description":""}}","source":"imagefromfolder_quickimage"}', '{"title":"{|title-1|}","description":"{|description-1|}","published":"1","publishdates":"|*|","thumbnail":"{|thumbnail-1|}","background":"00000000|*|{|image-1|}","link":"{|url-1|}|*|_self","slide":"","adminmode":"all"}'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_nextend_smartslider_slides`
--
DROP TABLE IF EXISTS `wp_nextend_smartslider_slides`;
CREATE TABLE `wp_nextend_smartslider_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `slider` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  `first` int(11) NOT NULL,
  `slide` longtext,
  `description` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `background` varchar(300) NOT NULL,
  `params` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `generator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_nextend_smartslider_slides`
--
LOCK TABLES `wp_nextend_smartslider_slides` WRITE;
INSERT INTO `wp_nextend_smartslider_slides` VALUES ('2', 'slider', '2', '2014-03-15 04:49:58', '2024-03-16 04:49:58', '1', '0', '', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '00000000|*|http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '{"slider":2,"publish_up":"0000-00-00 00:00:00","publish_down":"0000-00-00 00:00:00","params":"{"link":"#|*|_self","adminmode":"all"}","ordering":0,"link":"#|*|_self","adminmode":"all"}', '1', '0'); 
INSERT INTO `wp_nextend_smartslider_slides` VALUES ('3', 'slider', '2', '2014-03-15 04:49:58', '2024-03-16 04:49:58', '1', '0', '', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '00000000|*|http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '{"slider":2,"publish_up":"0000-00-00 00:00:00","publish_down":"0000-00-00 00:00:00","params":"{"link":"#|*|_self","adminmode":"all"}","ordering":1,"link":"#|*|_self","adminmode":"all"}', '2', '0'); 
INSERT INTO `wp_nextend_smartslider_slides` VALUES ('4', 'slider', '2', '2014-03-15 04:49:58', '2024-03-16 04:49:58', '1', '0', '', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '00000000|*|http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '{"slider":2,"publish_up":"0000-00-00 00:00:00","publish_down":"0000-00-00 00:00:00","params":"{"link":"#|*|_self","adminmode":"all"}","ordering":2,"link":"#|*|_self","adminmode":"all"}', '3', '0'); 
INSERT INTO `wp_nextend_smartslider_slides` VALUES ('5', 'slider', '2', '2014-03-15 04:50:28', '2024-03-16 04:50:28', '1', '0', '', '', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '00000000|*|http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '{"slider":2,"publish_up":"0000-00-00 00:00:00","publish_down":"0000-00-00 00:00:00","params":"{"link":"#|*|_self","adminmode":"desktop"}","ordering":0,"link":"#|*|_self","adminmode":"desktop"}', '4', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_nextend_smartslider_storage`
--
DROP TABLE IF EXISTS `wp_nextend_smartslider_storage`;
CREATE TABLE `wp_nextend_smartslider_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(200) NOT NULL,
  `value` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_nextend_smartslider_storage`
--
LOCK TABLES `wp_nextend_smartslider_storage` WRITE;
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('1', 'layout', '{"size":"1024|*|768"}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('2', 'settings', '{"debugmessages":"1","slideeditoralert":"1","translateurl":"|*|","externalcssfile":"","jquery":"1","translate3d":"1","placeholder":"http://www.nextendweb.com/static/placeholder.png","resizeremote":"0","responsivebasedon":"combined","responsivescreenwidth":"480|*|480","slideeditorratios":"1.0|*|1.0|*|0.7|*|0.5","generatordesignermode":"1","tidy-input-encoding":"utf8","tidy-output-encoding":"utf8"}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('3', 'font', '{"sliderfont1customlabel":"Heading light","sliderfont1":"{"firsttab":"Text","Text":{"color":"ffffffff","size":"320||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.3","bold":1,"italic":0,"underline":0,"align":"left","paddingleft":0},"Link":{"paddingleft":0,"size":"100||%"},"Link:Hover":{"paddingleft":0,"size":"100||%"}}","sliderfont2customlabel":"Heading dark","sliderfont2":"{"firsttab":"Text","Text":{"color":"000000db","size":"320||%","tshadow":"0|*|1|*|0|*|ffffff33","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.3","bold":1,"italic":0,"underline":0,"align":"left","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont3customlabel":"Subheading light","sliderfont3":"{"firsttab":"Text","Text":{"color":"ffffffff","size":"170||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.2","bold":0,"italic":0,"underline":0,"align":"left","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont4customlabel":"Subheading dark","sliderfont4":"{"firsttab":"Text","Text":{"color":"000000db","size":"170||%","tshadow":"0|*|1|*|0|*|ffffff33","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.2","bold":0,"italic":0,"underline":0,"align":"left","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont5customlabel":"Paragraph light","sliderfont5":"{"firsttab":"Text","Text":{"color":"ffffffff","size":"114||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.4","bold":0,"italic":0,"underline":0,"align":"justify","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont6customlabel":"Paragraph dark","sliderfont6":"{"firsttab":"Text","Text":{"color":"000000db","size":"114||%","tshadow":"0|*|1|*|0|*|ffffff33","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.4","bold":0,"italic":0,"underline":0,"align":"justify","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont7customlabel":"Small text light","sliderfont7":"{"firsttab":"Text","Text":{"color":"ffffffff","size":"90||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.2","bold":0,"italic":0,"underline":0,"align":"left","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont8customlabel":"Small text dark","sliderfont8":"{"firsttab":"Text","Text":{"color":"000000db","size":"90||%","tshadow":"0|*|1|*|0|*|ffffff33","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.1","bold":0,"italic":0,"underline":0,"align":"left","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont9customlabel":"Handwritten light","sliderfont9":"{"firsttab":"Text","Text":{"color":"ffffffff","size":"140||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Pacifico);),Arial","lineheight":"1.3","bold":0,"italic":0,"underline":0,"align":"left","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont10customlabel":"Handwritten dark","sliderfont10":"{"firsttab":"Text","Text":{"color":"000000db","size":"140||%","tshadow":"0|*|1|*|0|*|ffffff33","afont":"google(@import url(http://fonts.googleapis.com/css?family=Pacifico);),Arial","lineheight":"1.3","bold":0,"italic":0,"underline":0,"align":"left","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont11customlabel":"Button light","sliderfont11":"{"firsttab":"Text","Text":{"color":"ffffffff","size":"100||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.3","bold":0,"italic":0,"underline":0,"align":"center","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfont12customlabel":"Button dark","sliderfont12":"{"firsttab":"Text","Text":{"color":"000000db","size":"100||%","tshadow":"0|*|1|*|0|*|ffffff33","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.3","bold":0,"italic":0,"underline":0,"align":"center","paddingleft":0},"Link":{"paddingleft":0,"size":"100||%"},"Link:Hover":{"paddingleft":0,"size":"100||%"}}","sliderfontcustom1customlabel":"My first custom font","sliderfontcustom1":"{"firsttab":"Text","Text":{"color":"1abc9cff","size":"360||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Pacifico);),Arial","lineheight":"1.3","bold":0,"italic":0,"underline":0,"align":"left","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfontcustom2customlabel":"My second custom font","sliderfontcustom2":"{"firsttab":"Text","Text":{"color":"ffffffff","size":"140||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.2","bold":0,"italic":0,"underline":0,"align":"center","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfontcustom3customlabel":"My third custom font","sliderfontcustom3":"{"firsttab":"Text","Text":{"color":"1abc9cff","size":"120||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.2","bold":0,"italic":0,"underline":0,"align":"center","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}","sliderfontcustom4customlabel":"My fourthcustom font ","sliderfontcustom4":"{"firsttab":"Text","Text":{"color":"1abc9cff","size":"120||%","tshadow":"0|*|1|*|1|*|000000c7","afont":"google(@import url(http://fonts.googleapis.com/css?family=Open Sans);),Arial","lineheight":"1.2","bold":0,"italic":0,"underline":0,"align":"right","paddingleft":0},"Link":{"size":"100||%","paddingleft":0},"Link:Hover":{"size":"100||%","paddingleft":0}}"}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('4', 'sliderchanged1', '1'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('5', 'sliderchanged2', '0'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('6', 'font2', '{"sliderfont1customlabel":"Heading light","sliderfont1":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InBhZGRpbmdsZWZ0IjowLCJzaXplIjoiMTAwfHwlIn0sIkxpbms6SG92ZXIiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifX0=","sliderfont2customlabel":"Heading dark","sliderfont2":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont3customlabel":"Subheading light","sliderfont3":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont4customlabel":"Subheading dark","sliderfont4":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont5customlabel":"Paragraph light","sliderfont5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont6customlabel":"Paragraph dark","sliderfont6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont7customlabel":"Small text light","sliderfont7":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwxfCp8MDAwMDAwYzciLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont8customlabel":"Small text dark","sliderfont8":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwwfCp8ZmZmZmZmMzMiLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMSIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont9customlabel":"Handwritten light","sliderfont9":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont10customlabel":"Handwritten dark","sliderfont10":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont11customlabel":"Button light","sliderfont11":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont12customlabel":"Button dark","sliderfont12":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifSwiTGluazpIb3ZlciI6eyJwYWRkaW5nbGVmdCI6MCwic2l6ZSI6IjEwMHx8JSJ9fQ==","sliderfontcustom5customlabel":"Post generator title v1","sliderfontcustom5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNmI2YjZiZmYiLCJzaXplIjoiMjIwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6Ijg3ZDJjZWZmIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI4MmM3YzNmZiIsInNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom6customlabel":"Post generator categoryv1","sliderfontcustom6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiODc4Nzg3ZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9QXZlcmFnZSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJjb2xvciI6IjY5YmRiOWZmIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom7customlabel":"Post generator paragraph v1","sliderfontcustom7":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYTdhN2E3ZmYiLCJzaXplIjoiMTMwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9QXZlcmFnZSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjYiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6IjY5YmRiOWIzIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI2OWJkYjlmZiIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfontcustom8customlabel":"Post generator button v1","sliderfontcustom8":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNmNjOGMzZmYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNSIsImJvbGQiOjEsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImNlbnRlciIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiZmZmZmZmZWIiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom9customlabel":"Post generator title v2","sliderfontcustom9":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNmI2YjZiZmYiLCJzaXplIjoiMjIwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiI4N2QyY2VmZiJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiODJjN2MzZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom10customlabel":"Post generator categoryv2","sliderfontcustom10":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYWFhYWFhZmYiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMyIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJjb2xvciI6IjY5YmRiOWZmIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom11customlabel":"Post generator paragraph v2","sliderfontcustom11":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYTdhN2E3ZmYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6Imp1c3RpZnkiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6IjY5YmRiOWIzIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI2OWJkYjlmZiIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfontcustom12customlabel":"Post generator button v2","sliderfontcustom12":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNSIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImNlbnRlciIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiZmZmZmZmZWIiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom13customlabel":"Post generator title v3","sliderfontcustom13":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMjIwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiJmZmZmZmZlZCJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiODJjN2MzZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom14customlabel":"Post generator paragraph v3","sliderfontcustom14":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmYzQiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6Imp1c3RpZnkiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6IjY5YmRiOWIzIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI2OWJkYjlmZiIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfontcustom15customlabel":"Post generator title v4","sliderfontcustom15":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMjcwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6ImZmZmZmZmZmIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI4MmM3YzNmZiIsInNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom16customlabel":"Post generator paragraph v4","sliderfontcustom16":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmYzQiLCJzaXplIjoiMTIwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImNlbnRlciIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjAsImNvbG9yIjoiNjliZGI5YjMifSwiTGluazpIb3ZlciI6eyJjb2xvciI6IjY5YmRiOWZmIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom17customlabel":"Webshop generator title v1 ","sliderfontcustom17":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNDM1NjY0ZmYiLCJzaXplIjoiMjQwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiI0MzU2NjRmZiJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiOGU0NGFkZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom18customlabel":"Webshop generator subtitle v1 ","sliderfontcustom18":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiNjA3MjgwZmYiLCJzaXplIjoiMTMwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiI0MzU2NjRmZiJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiOGU0NGFkZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom19customlabel":"Webshop generator paragraph v1","sliderfontcustom19":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOGY5NTlkZTYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9T3BlbitTYW5zKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuNCIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6Imp1c3RpZnkiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowLCJjb2xvciI6IjQzNTY2NGZmIn0sIkxpbms6SG92ZXIiOnsiY29sb3IiOiI4ZTQ0YWRmZiIsInNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom20customlabel":"Webshop generator price v1 ","sliderfontcustom20":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOGU0NGFkZmYiLCJzaXplIjoiMjQwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJyaWdodCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjAsImNvbG9yIjoiNDM1NjY0ZmYifSwiTGluazpIb3ZlciI6eyJjb2xvciI6IjdmM2M5Y2ZmIiwic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfontcustom21customlabel":"Webshop generator title v2","sliderfontcustom21":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYjQ3MGEyZmYiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UmFsZXdheSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsImNvbG9yIjoiZjU4NzAwZmYiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom22customlabel":"Webshop generator price v2","sliderfontcustom22":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOGU0NGFkZmYiLCJzaXplIjoiMTYwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MCwiY29sb3IiOiI0MzU2NjRmZiJ9LCJMaW5rOkhvdmVyIjp7ImNvbG9yIjoiN2YzYzljZmYiLCJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom23customlabel":"Webshop generator paragraph v2","sliderfontcustom23":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOTk5OTk5ZmYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UmFsZXdheSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjYiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsImNvbG9yIjoiZjU4NzAwZmYiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom24customlabel":"Webshop generator price v3","sliderfontcustom24":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiYjQ3MGEyZmYiLCJzaXplIjoiMjYwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9QmViYXMpOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS41IiwiYm9sZCI6MSwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom25customlabel":"Webshop generator subtitle","sliderfontcustom25":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiOGE4YThhZmYiLCJzaXplIjoiMTEwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UmFsZXdheSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsImNvbG9yIjoiZjU4NzAwZmYiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom26customlabel":"Webshop generator title v3","sliderfontcustom26":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMjYwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UmFsZXdheSk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsImNvbG9yIjoiZmZmZmZmZDkiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom27customlabel":"Webshop generator price v4","sliderfontcustom27":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzgwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9QmViYXMpOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4yIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoicmlnaHQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ=="}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('7', 'generator2', '{"time":1394945378,"hash":"1a024e4efcbe0642b2e94a249bc37351","data":[{"image":"http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg","title":"slider","url":"#","description":"","thumbnail":"http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg","url_label":"View","author_name":"","author_url":"#"},{"image":"http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg","title":"slider","url":"#","description":"","thumbnail":"http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg","url_label":"View","author_name":"","author_url":"#"},{"image":"http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg","title":"slider","url":"#","description":"","thumbnail":"http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg","url_label":"View","author_name":"","author_url":"#"}]}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('8', 'slidercache2', '{"time":1397329717,"data":{"css":"http:\/\/127.0.0.1\/asug\/wp-content\/cache\/css\/static\/77b25944e339011508373c057ad4f71f.css","js":{"core":{"C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\assets\\js\\class.js":"C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\assets\\js\\class.js"}},"fonts":{"Montserrat":{"0":400,"1":"latin","400,latin":1},"Pacifico":{"0":400,"1":"latin","400,latin":1},"Average":{"0":400,"1":"latin","400,latin":1},"Open Sans":{"0":400,"1":"latin","400,latin":1},"Raleway":{"0":400,"1":"latin","400,latin":1},"Bebas":{"0":400,"1":"latin","400,latin":1}},"html":"<script type=\"text\/javascript\">\n    window[\'nextend-smart-slider-2-onresize\'] = [];\n<\/script>\n<div class=\"CentralizarS\">\n    <div id=\"nextend-smart-slider-2\" class=\"nextend-slider-fadeload nextend-desktop \" style=\"font-size: 12px;\" data-allfontsize=\"12\" data-desktopfontsize=\"12\" data-tabletfontsize=\"16\" data-phonefontsize=\"20\">\n        <div class=\"smart-slider-border1\" style=\"\">\n            <div class=\"smart-slider-border2\">\n                \n                                    <div class=\"smart-slider-canvas smart-slider-slide-active smart-slider-bg-colored\" style=\"\">\n                                                    <img src=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\" data-desktop=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-slide-bg\"\/>\n                                                                        <div class=\"smart-slider-canvas-inner\">\n                                                    <\/div>\n                                            <\/div>\n                                    <div class=\"smart-slider-canvas smart-slider-bg-colored\" style=\"\">\n                                                    <img src=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\" data-desktop=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-slide-bg\"\/>\n                                                                        <div class=\"smart-slider-canvas-inner\">\n                                                    <\/div>\n                                            <\/div>\n                                    <div class=\"smart-slider-canvas smart-slider-bg-colored\" style=\"\">\n                                                    <img src=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\" data-desktop=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-slide-bg\"\/>\n                                                                        <div class=\"smart-slider-canvas-inner\">\n                                                    <\/div>\n                                            <\/div>\n                                    <div class=\"smart-slider-canvas smart-slider-bg-colored\" style=\"\">\n                                                    <img src=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\" data-desktop=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-slide-bg\"\/>\n                                                                        <div class=\"smart-slider-canvas-inner\">\n                                                    <\/div>\n                                            <\/div>\n                            <\/div>\n        <\/div>\n        <div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'previous\');\" class=\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-arrow-previous nextend-transition nextend-transition-previous nextend-transition-previous-my-test\" style=\"position: absolute;left:0%;\" data-sstop=\"height\/2-previousheight\/2\" ><div class=\"smartslider-outer\"><\/div><div class=\"smartslider-inner\"><\/div><\/div><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'next\');\" class=\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-arrow-next nextend-transition nextend-transition-next nextend-transition-next-my-test\" style=\"position: absolute;right:0%;\" data-sstop=\"height\/2-nextheight\/2\" ><div class=\"smartslider-outer\"><\/div><div class=\"smartslider-inner\"><\/div><\/div><div style=\"position: absolute;left:0%;bottom:5%;visibility: hidden;z-index:10; line-height: 0;width:100%;text-align:center;\" class=\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-widget-bullet \" ><div class=\"nextend-bullet-container nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',0,false);\" data-thumbnail=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><span class=\"sliderfont7\">\n                1\n                <\/span><\/div><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',1,false);\" data-thumbnail=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><span class=\"sliderfont7\">\n                2\n                <\/span><\/div><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',2,false);\" data-thumbnail=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><span class=\"sliderfont7\">\n                3\n                <\/span><\/div><div onclick=\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',3,false);\" data-thumbnail=\"http:\/\/127.0.0.1\/asug\/wp-content\/uploads\/2014\/03\/slider.jpg\"  class=\"nextend-bullet nextend-bullet-numbers nextend-bullet-numbers-square nextend-bullet-horizontal\"><span class=\"sliderfont7\">\n                4\n                <\/span><\/div><\/div><\/div>    <\/div>\n<\/div>\n<script type=\"text\/javascript\">\n    njQuery(document).ready(function () {\n        njQuery(\'#nextend-smart-slider-2\').smartslider({\"translate3d\":1,\"playfirstlayer\":0,\"mainafterout\":0,\"inaftermain\":1,\"fadeonscroll\":0,\"autoplay\":1,\"autoplayConfig\":{\"duration\":8000,\"counter\":0,\"autoplayToSlide\":0,\"stopautoplay\":{\"click\":1,\"mouseenter\":1,\"slideplaying\":1},\"resumeautoplay\":{\"mouseleave\":0,\"slideplayed\":1,\"slidechanged\":0}},\"responsive\":{\"downscale\":1,\"upscale\":0,\"maxwidth\":3000,\"basedon\":\"combined\",\"screenwidth\":{\"tablet\":480,\"phone\":480},\"ratios\":[1,1,0.7,0.5]},\"controls\":{\"scroll\":0,\"touch\":\"horizontal\",\"keyboard\":0},\"blockrightclick\":0,\"lazyload\":0,\"lazyloadneighbor\":0,\"type\":\"ssSimpleSlider\",\"animation\":[\"horizontal\"],\"animationSettings\":{\"duration\":800,\"delay\":0,\"easing\":\"easeInOutQuad\",\"parallax\":1},\"flux\":[0,[\"bars\",\"blocks\"]],\"touchanimation\":\"horizontal\"});\n    });\n<\/script>\n<div style=\"clear: both;\"><\/div>\n<div id=\"nextend-smart-slider-2-placeholder\" ><img alt=\"\" style=\"width:100%; max-width: 3000px;\" src=\"data:image\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAh4AAAD6CAYAAADuiU73AAAEQklEQVR4nO3WMQEAIAzAMMC\/5+GiHCQKenbPAgBonNcBAMA\/jAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZIwHAJAxHgBAxngAABnjAQBkjAcAkDEeAEDGeAAAGeMBAGSMBwCQMR4AQMZ4AAAZ4wEAZC6jWgLztugg\/QAAAABJRU5ErkJggg==\" \/><\/div>","libraries":{"modernizr":{"jsfiles":["C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/modernizr\/modernizr.js"],"js":""},"jquery":{"jsfiles":["C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/njQuery.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jQuery.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/uacss.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jquery.unique-element-id.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jquery.unveil.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jquery.waitforimages.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jquery.touchSwipe.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/easing.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\nextend\\javascript\/jquery\/1.9.1\/jquery.transit.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\animationbase.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\smartsliderbase.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\mainslider.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\layers.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\no.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\nostatic.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\fade.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\fadestatic.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\slide.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\slidestatic.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\library\\smartslider\\assets\\js\\motions\\transit.js","C:\\xampp\\htdocs\\asug\\wp-content\\plugins\\smart-slider-2\\plugins\\nextendslidertype\\simple\\simple\\slider.js"],"js":""}}},"slideexpire":1710564598}'); 
INSERT INTO `wp_nextend_smartslider_storage` VALUES ('9', 'sliderchanged3', '1'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_options`
--
DROP TABLE IF EXISTS `wp_options`;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=18508 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_options`
--
LOCK TABLES `wp_options` WRITE;
INSERT INTO `wp_options` VALUES ('1', 'siteurl', 'http://127.0.0.1/asug', 'yes'); 
INSERT INTO `wp_options` VALUES ('2', 'blogname', 'Asug | SAP NetWeaver Portal', 'yes'); 
INSERT INTO `wp_options` VALUES ('3', 'blogdescription', 'Só mais um site WordPress', 'yes'); 
INSERT INTO `wp_options` VALUES ('4', 'users_can_register', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('5', 'admin_email', 'contato@montarsite.com.br', 'yes'); 
INSERT INTO `wp_options` VALUES ('6', 'start_of_week', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('7', 'use_balanceTags', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('8', 'use_smilies', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('9', 'require_name_email', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('10', 'comments_notify', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('11', 'posts_per_rss', '10', 'yes'); 
INSERT INTO `wp_options` VALUES ('12', 'rss_use_excerpt', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('13', 'mailserver_url', 'mail.example.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('14', 'mailserver_login', 'login@example.com', 'yes'); 
INSERT INTO `wp_options` VALUES ('15', 'mailserver_pass', 'password', 'yes'); 
INSERT INTO `wp_options` VALUES ('16', 'mailserver_port', '110', 'yes'); 
INSERT INTO `wp_options` VALUES ('17', 'default_category', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('18', 'default_comment_status', 'closed', 'yes'); 
INSERT INTO `wp_options` VALUES ('19', 'default_ping_status', 'open', 'yes'); 
INSERT INTO `wp_options` VALUES ('20', 'default_pingback_flag', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('21', 'posts_per_page', '10', 'yes'); 
INSERT INTO `wp_options` VALUES ('22', 'date_format', 'j de F de Y', 'yes'); 
INSERT INTO `wp_options` VALUES ('23', 'time_format', 'H:i', 'yes'); 
INSERT INTO `wp_options` VALUES ('24', 'links_updated_date_format', 'j de F de Y, H:i', 'yes'); 
INSERT INTO `wp_options` VALUES ('28', 'comment_moderation', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('29', 'moderation_notify', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('30', 'permalink_structure', '/%postname%/', 'yes'); 
INSERT INTO `wp_options` VALUES ('31', 'gzipcompression', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('32', 'hack_file', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('33', 'blog_charset', 'UTF-8', 'yes'); 
INSERT INTO `wp_options` VALUES ('34', 'moderation_keys', '', 'no'); 
INSERT INTO `wp_options` VALUES ('35', 'active_plugins', 'a:36:{i:0;s:56:"New-Media-Image-Uploader-master/tgm-new-media-plugin.php";i:1;s:51:"acf-field-date-time-picker/acf-date_time_picker.php";i:2;s:36:"acf-repeater-master/acf-repeater.php";i:3;s:45:"acf-role-selector-field/acf-role_selector.php";i:4;s:39:"admin-customizado/admin-customizado.php";i:5;s:29:"ads-by-datafeedrcom/dfads.php";i:6;s:63:"advanced-custom-fields-location-field-add-on/location-field.php";i:7;s:30:"advanced-custom-fields/acf.php";i:8;s:51:"auto-excerpt-everywhere/auto-excerpt-everywhere.php";i:9;s:32:"boleto-usuario/modulo_boleto.php";i:10;s:43:"broken-link-checker/broken-link-checker.php";i:11;s:85:"carousel-horizontal-posts-content-slider/carousel-horizontal-posts-content-slider.php";i:12;s:25:"cloudflare/cloudflare.php";i:13;s:36:"contact-form-7/wp-contact-form-7.php";i:14;s:38:"dashboard_usuario/dashbord_usuario.php";i:15;s:33:"duplicate-post/duplicate-post.php";i:16;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:17;s:37:"export-user-data/export-user-data.php";i:18;s:41:"flexi-pages-widget/flexi-pages-widget.php";i:19;s:43:"google-analytics-dashboard-for-wp/gadwp.php";i:20;s:50:"google-analytics-for-wordpress/googleanalytics.php";i:21;s:43:"google-font-manager/google-font-manager.php";i:22;s:36:"google-sitemap-generator/sitemap.php";i:23;s:45:"inscricao-de-eventos/inscricao-de-eventos.php";i:24;s:27:"issuu-embed/issue-embed.php";i:25;s:24:"log-user-stats/index.php";i:26;s:29:"ready-backup/backup-ready.php";i:27;s:33:"seo-image/seo-friendly-images.php";i:28;s:45:"simple-local-avatars/simple-local-avatars.php";i:29;s:33:"smart-slider-2/smart-slider-2.php";i:30;s:37:"user-role-editor/user-role-editor.php";i:31;s:29:"user-status-manager/start.php";i:32;s:39:"webriti-smtp-mail/webriti-smtp-mail.php";i:33;s:37:"widgets-on-pages/widgets_on_pages.php";i:34;s:31:"wp-backupware/wp-backupware.php";i:35;s:27:"wp-optimize/wp-optimize.php";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('36', 'home', 'http://127.0.0.1/asug', 'yes'); 
INSERT INTO `wp_options` VALUES ('37', 'category_base', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('38', 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'); 
INSERT INTO `wp_options` VALUES ('39', 'advanced_edit', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('40', 'comment_max_links', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('41', 'gmt_offset', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('42', 'default_email_category', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('43', 'recently_edited', 'a:2:{i:0;s:87:"C:xampphtdocsasug/wp-content/plugins/twenty-eleven-theme-extensions/moztheme2011.php";i:1;s:0:"";}', 'no'); 
INSERT INTO `wp_options` VALUES ('44', 'template', 'asug', 'yes'); 
INSERT INTO `wp_options` VALUES ('45', 'stylesheet', 'asug', 'yes'); 
INSERT INTO `wp_options` VALUES ('46', 'comment_whitelist', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('47', 'blacklist_keys', '', 'no'); 
INSERT INTO `wp_options` VALUES ('48', 'comment_registration', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('49', 'html_type', 'text/html', 'yes'); 
INSERT INTO `wp_options` VALUES ('50', 'use_trackback', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('51', 'default_role', 'subscriber', 'yes'); 
INSERT INTO `wp_options` VALUES ('52', 'db_version', '27916', 'yes'); 
INSERT INTO `wp_options` VALUES ('53', 'uploads_use_yearmonth_folders', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('54', 'upload_path', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('55', 'blog_public', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('56', 'default_link_category', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('57', 'show_on_front', 'page', 'yes'); 
INSERT INTO `wp_options` VALUES ('58', 'tag_base', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('59', 'show_avatars', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('60', 'avatar_rating', 'G', 'yes'); 
INSERT INTO `wp_options` VALUES ('61', 'upload_url_path', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('62', 'thumbnail_size_w', '150', 'yes'); 
INSERT INTO `wp_options` VALUES ('63', 'thumbnail_size_h', '150', 'yes'); 
INSERT INTO `wp_options` VALUES ('64', 'thumbnail_crop', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('65', 'medium_size_w', '300', 'yes'); 
INSERT INTO `wp_options` VALUES ('66', 'medium_size_h', '300', 'yes'); 
INSERT INTO `wp_options` VALUES ('67', 'avatar_default', 'mystery', 'yes'); 
INSERT INTO `wp_options` VALUES ('68', 'large_size_w', '1024', 'yes'); 
INSERT INTO `wp_options` VALUES ('69', 'large_size_h', '1024', 'yes'); 
INSERT INTO `wp_options` VALUES ('70', 'image_default_link_type', 'file', 'yes'); 
INSERT INTO `wp_options` VALUES ('71', 'image_default_size', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('72', 'image_default_align', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('73', 'close_comments_for_old_posts', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('74', 'close_comments_days_old', '14', 'yes'); 
INSERT INTO `wp_options` VALUES ('75', 'thread_comments', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('76', 'thread_comments_depth', '5', 'yes'); 
INSERT INTO `wp_options` VALUES ('77', 'page_comments', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('78', 'comments_per_page', '50', 'yes'); 
INSERT INTO `wp_options` VALUES ('79', 'default_comments_page', 'newest', 'yes'); 
INSERT INTO `wp_options` VALUES ('80', 'comment_order', 'asc', 'yes'); 
INSERT INTO `wp_options` VALUES ('81', 'sticky_posts', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('82', 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('83', 'widget_text', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:4:"text";s:2595:"<aside>
					<div id="post_recentes">
						<div class="table-responsive forum_home">
							<table class="table table-hover">
								<thead>
									<tr class="titulos">
										<th class="post_recentes" colspan="2">Fórum | Posts mais recentes</th>
										<th class="post_recentes_f">Ir para o fórum</th>
									</tr>
								</thead>
								<tbody class="textos">
									<tr class="topo">
										<td>Título</td>
										<td>Autor</td>
										<td>Data</td>
									</tr>
									<tr class="posts_recentes">
										<td class="posts">
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
									<tr class="posts_recentes">
										<td>
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
									<tr class="posts_recentes">
										<td>
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
									<tr class="posts_recentes">
										<td>
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
									<tr class="posts_recentes">
										<td>
											<a href="">
												<h3>Auditoria e GRC » Academia AIS</h3>
											</a>
											<p>> "Academia AIS", AIS e AM</p>
										</td>
										<td class="autor">
											<a href="">Adriano Siabno</a>
										</td>
										<td class="data">
											<time>06/05/2013</time>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</aside>";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('84', 'widget_rss', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('85', 'uninstall_plugins', 'a:6:{s:41:"better-wp-security/better-wp-security.php";a:2:{i:0;s:11:"ITSEC_Setup";i:1;s:12:"on_uninstall";}s:43:"google-analytics-dashboard-for-wp/gadwp.php";a:2:{i:0;s:16:"GADASH_Uninstall";i:1;s:9:"uninstall";}s:41:"simple-ads-manager/simple-ads-manager.php";a:2:{i:0;s:21:"SimpleAdsManagerAdmin";i:1;s:11:"onUninstall";}s:21:"adrotate/adrotate.php";s:18:"adrotate_uninstall";s:43:"google-font-manager/google-font-manager.php";s:27:"wp_googlefontmgr_deactivate";s:45:"simple-local-avatars/simple-local-avatars.php";s:30:"simple_local_avatars_uninstall";}', 'no'); 
INSERT INTO `wp_options` VALUES ('86', 'timezone_string', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('87', 'page_for_posts', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('88', 'page_on_front', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('89', 'default_post_format', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('90', 'link_manager_enabled', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('91', 'initial_db_version', '26691', 'yes'); 
INSERT INTO `wp_options` VALUES ('92', 'wp_user_roles', 'a:12:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:86:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;s:10:"copy_posts";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:58:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;s:10:"copy_posts";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:20:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:15:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:12:{s:4:"read";b:1;s:7:"level_0";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:13:"representante";a:2:{s:4:"name";s:13:"Representante";s:12:"capabilities";a:2:{s:4:"read";i:1;s:7:"level_0";i:1;}}s:15:"empresa_cliente";a:2:{s:4:"name";s:30:"Empresa Cliente Não Associada";s:12:"capabilities";a:2:{s:4:"read";i:1;s:7:"level_0";i:1;}}s:25:"empresa_cliente_associada";a:2:{s:4:"name";s:25:"Empresa Cliente Associada";s:12:"capabilities";a:2:{s:4:"read";i:1;s:7:"level_0";i:1;}}s:16:"empresa_parceira";a:2:{s:4:"name";s:31:"Empresa Parceira Não Associada";s:12:"capabilities";a:2:{s:4:"read";i:1;s:7:"level_0";i:1;}}s:26:"empresa_parceira_associada";a:2:{s:4:"name";s:26:"Empresa Parceira Associada";s:12:"capabilities";a:2:{s:4:"read";i:1;s:7:"level_0";i:1;}}s:17:"empresa_convidada";a:2:{s:4:"name";s:17:"Empresa Convidada";s:12:"capabilities";a:2:{s:4:"read";i:1;s:7:"level_0";i:1;}}s:22:"empresa_consultora_sap";a:2:{s:4:"name";s:22:"Empresa Consultora SAP";s:12:"capabilities";a:2:{s:4:"read";i:1;s:7:"level_0";i:1;}}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('93', 'widget_search', 'a:3:{i:2;a:1:{s:5:"title";s:0:"";}i:3;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('94', 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('95', 'widget_recent-comments', 'a:3:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}i:3;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('96', 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('97', 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('98', 'sidebars_widgets', 'a:8:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:1:{i:0;s:6:"text-2";}s:9:"sidebar-3";a:0:{}s:5:"wop-1";a:1:{i:0;s:7:"pages-2";}s:5:"wop-2";a:3:{i:0;s:8:"search-3";i:1;s:17:"recent-comments-3";i:2;s:10:"calendar-2";}s:5:"wop-3";a:1:{i:0;s:12:"flexipages-2";}s:13:"array_version";i:3;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('99', 'cron', 'a:15:{i:1402082820;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1402082901;a:1:{s:20:"blc_cron_check_links";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1402086019;a:1:{s:40:"membership_perform_cron_processes_hourly";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1402086501;a:2:{s:28:"blc_cron_email_notifications";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:19:"blc_cron_check_news";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1402090101;a:1:{s:13:"sm_ping_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1402099200;a:2:{s:15:"verificarcontas";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1402104859;a:2:{s:16:"itsec_purge_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:20:"itsec_purge_lockouts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1402104868;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1402113097;a:1:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1402113098;a:2:{s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1402156314;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1402158858;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1402169152;a:1:{s:17:"wpbu_backup_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1402345701;a:1:{s:29:"blc_cron_database_maintenance";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:9:"bimonthly";s:4:"args";a:0:{}s:8:"interval";i:936000;}}}s:7:"version";i:2;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('105', '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1402069913;s:7:"checked";a:1:{s:4:"asug";s:3:"1.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('131', 'wpcf7', 'a:1:{s:7:"version";s:5:"3.8.1";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('132', 'recently_activated', 'a:4:{s:24:"wp-issuu/issuu-embed.php";i:1402060368;s:33:"issuu-pdf-sync/issuu-pdf-sync.php";i:1401887777;s:39:"pdfjs-viewer-shortcode/pdfjs-viewer.php";i:1401884942;s:9:"hello.php";i:1401884928;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('133', 'Yoast_Google_Analytics', 'a:51:{s:16:"advancedsettings";b:0;s:11:"allowanchor";b:0;s:9:"allowhash";b:0;s:11:"allowlinker";b:0;s:11:"anonymizeip";b:0;s:10:"customcode";s:0:"";s:11:"cv_loggedin";b:0;s:13:"cv_authorname";b:0;s:11:"cv_category";b:0;s:17:"cv_all_categories";b:0;s:7:"cv_tags";b:0;s:7:"cv_year";b:0;s:12:"cv_post_type";b:0;s:5:"debug";b:0;s:12:"dlextensions";s:30:"doc,exe,js,pdf,ppt,tgz,zip,xls";s:6:"domain";s:0:"";s:11:"domainorurl";s:6:"domain";s:7:"extrase";b:0;s:10:"extraseurl";s:0:"";s:11:"firebuglite";b:0;s:8:"ga_token";s:0:"";s:16:"ga_api_responses";a:0:{}s:16:"gajslocalhosting";b:0;s:7:"gajsurl";s:0:"";s:16:"ignore_userlevel";s:2:"11";s:12:"internallink";s:0:"";s:17:"internallinklabel";s:0:"";s:16:"outboundpageview";b:0;s:17:"downloadspageview";b:0;s:17:"othercrossdomains";s:0:"";s:8:"position";s:6:"header";s:18:"primarycrossdomain";s:0:"";s:13:"theme_updated";b:0;s:16:"trackcommentform";b:1;s:16:"trackcrossdomain";b:0;s:12:"trackadsense";b:0;s:13:"trackoutbound";b:1;s:17:"trackregistration";b:0;s:14:"rsslinktagging";b:1;s:8:"uastring";s:13:"UA-45871625-6";s:7:"version";s:5:"4.3.5";s:3:"msg";s:0:"";s:14:"tracking_popup";s:4:"done";s:14:"yoast_tracking";b:0;s:15:"gfsubmiteventpv";s:0:"";s:11:"trackprefix";s:0:"";s:13:"admintracking";b:0;s:15:"manual_uastring";b:1;s:11:"taggfsubmit";b:0;s:13:"wpec_tracking";b:0;s:14:"shopp_tracking";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('141', 'acf_version', '4.3.8', 'yes'); 
INSERT INTO `wp_options` VALUES ('147', 'ewww_image_optimizer_disable_pngout', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('148', 'ewww_image_optimizer_optipng_level', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('149', 'ewww_image_optimizer_pngout_level', '2', 'yes'); 
INSERT INTO `wp_options` VALUES ('150', 'ewww_image_optimizer_version', '191', 'yes'); 
INSERT INTO `wp_options` VALUES ('151', 'ewww_image_optimizer_cloud_jpg', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('152', 'ewww_image_optimizer_cloud_png', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('153', 'ewww_image_optimizer_cloud_gif', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('162', 'wsblc_options', '{"max_execution_time":420,"check_threshold":72,"recheck_count":3,"recheck_threshold":1800,"run_in_dashboard":true,"run_via_cron":true,"mark_broken_links":true,"broken_link_css":".broken_link, a.broken_link {\n\ttext-decoration: line-through;\n}","nofollow_broken_links":false,"mark_removed_links":false,"removed_link_css":".removed_link, a.removed_link {\n\ttext-decoration: line-through;\n}","exclusion_list":[],"send_email_notifications":true,"send_authors_email_notifications":false,"notification_email_address":"","notification_schedule":"daily","last_notification_sent":1397334563,"suggestions_enabled":true,"server_load_limit":4,"enable_load_limit":false,"custom_fields":[],"enabled_post_statuses":["publish"],"autoexpand_widget":true,"dashboard_widget_capability":"edit_others_posts","show_link_count_bubble":true,"table_layout":"flexible","table_compact":true,"table_visible_columns":["new-url","status","used-in","new-link-text"],"table_links_per_page":30,"table_color_code_status":true,"need_resynch":false,"current_db_version":7,"timeout":30,"highlight_permanent_failures":false,"failure_duration_threshold":3,"logging_enabled":false,"log_file":"","custom_log_file_enabled":false,"installation_complete":true,"installation_flag_cleared_on":"2014-04-12T19:10:41+00:00 (1397329841.2321)","installation_flag_set_on":"2014-04-12T19:10:42+00:00 (1397329842.2148)","user_has_donated":false,"donation_flag_fixed":false,"first_installation_timestamp":1397329841,"active_modules":{"http":{"ModuleID":"http","ModuleCategory":"checker","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcHttpChecker","ModulePriority":-1,"ModuleCheckerUrlPattern":"","ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"Name":"Basic HTTP","PluginURI":"","Version":"1.0","Description":"Check all links that have the HTTP\/HTTPS protocol.","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"Basic HTTP","AuthorName":"Janis Elsts","file":"checkers\/http.php"},"link":{"ModuleID":"link","ModuleCategory":"parser","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcHTMLLink","ModulePriority":1000,"ModuleCheckerUrlPattern":"","ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"Name":"HTML links","PluginURI":"","Version":"1.0","Description":"Example : <code>&lt;a href=\"http:\/\/example.com\/\"&gt;link text&lt;\/a&gt;<\/code>","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"HTML links","AuthorName":"Janis Elsts","file":"parsers\/html_link.php"},"image":{"ModuleID":"image","ModuleCategory":"parser","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcHTMLImage","ModulePriority":900,"ModuleCheckerUrlPattern":"","ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"Name":"HTML images","PluginURI":"","Version":"1.0","Description":"e.g. <code>&lt;img src=\"http:\/\/example.com\/fluffy.jpg\"&gt;<\/code>","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"HTML images","AuthorName":"Janis Elsts","file":"parsers\/image.php"},"metadata":{"ModuleID":"metadata","ModuleCategory":"parser","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcMetadataParser","ModulePriority":0,"ModuleCheckerUrlPattern":"","ModuleHidden":true,"ModuleAlwaysActive":true,"ModuleRequiresPro":false,"Name":"Metadata","PluginURI":"","Version":"1.0","Description":"Parses metadata (AKA custom fields)","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"Metadata","AuthorName":"Janis Elsts","file":"parsers\/metadata.php"},"url_field":{"ModuleID":"url_field","ModuleCategory":"parser","ModuleContext":"on-demand","ModuleLazyInit":true,"ModuleClassName":"blcUrlField","ModulePriority":0,"ModuleCheckerUrlPattern":"","ModuleHidden":true,"ModuleAlwaysActive":true,"ModuleRequiresPro":false,"Name":"URL fields","PluginURI":"","Version":"1.0","Description":"Parses data fields that contain a single, plaintext URL.","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"URL fields","AuthorName":"Janis Elsts","file":"parsers\/url_field.php"},"comment":{"ModuleID":"comment","ModuleCategory":"container","ModuleContext":"all","ModuleLazyInit":false,"ModuleClassName":"blcCommentManager","ModulePriority":0,"ModuleCheckerUrlPattern":"","ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"Name":"Comments","PluginURI":"","Version":"1.0","Description":"","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"Comments","AuthorName":"Janis Elsts","file":"containers\/comment.php"},"post":{"Name":"Posts","ModuleCategory":"container","ModuleContext":"all","ModuleClassName":"blcAnyPostContainerManager","ModuleID":"post","file":"","ModuleLazyInit":false,"ModulePriority":0,"ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"TextDomain":"broken-link-checker","virtual":true},"page":{"Name":"P\u00e1ginas","ModuleCategory":"container","ModuleContext":"all","ModuleClassName":"blcAnyPostContainerManager","ModuleID":"page","file":"","ModuleLazyInit":false,"ModulePriority":0,"ModuleHidden":false,"ModuleAlwaysActive":false,"ModuleRequiresPro":false,"TextDomain":"broken-link-checker","virtual":true},"dummy":{"ModuleID":"dummy","ModuleCategory":"container","ModuleContext":"all","ModuleLazyInit":false,"ModuleClassName":"blcDummyManager","ModulePriority":0,"ModuleCheckerUrlPattern":"","ModuleHidden":true,"ModuleAlwaysActive":true,"ModuleRequiresPro":false,"Name":"Dummy","PluginURI":"","Version":"1.0","Description":"","Author":"Janis Elsts","AuthorURI":"","TextDomain":"broken-link-checker","DomainPath":"","Network":false,"Title":"Dummy","AuthorName":"Janis Elsts","file":"containers\/dummy.php"}},"module_deactivated_when":{"custom_field":1397329841},"last_email":{"subject":"[Asug | SAP NetWeaver Portal] Links quebrados encontrados","timestamp":1397334563,"success":false},"plugin_news":["Admin Menu Editor","http:\/\/wordpress.org\/extend\/plugins\/admin-menu-editor\/"]}', 'yes'); 
INSERT INTO `wp_options` VALUES ('168', '_transient_twentyfourteen_category_count', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('169', 'excerpt_everywhere_length', '500', 'yes'); 
INSERT INTO `wp_options` VALUES ('170', 'excerpt_everywhere_align', 'alignleft', 'yes'); 
INSERT INTO `wp_options` VALUES ('171', 'excerpt_everywhere_moretext', 'Detalhes [...]', 'yes'); 
INSERT INTO `wp_options` VALUES ('172', 'excerpt_everywhere_moreimg', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('173', 'excerpt_everywhere_rss', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES ('174', 'excerpt_everywhere_homepage', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('175', 'excerpt_everywhere_sticky', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('176', 'excerpt_everywhere_thumb', 'none', 'yes'); 
INSERT INTO `wp_options` VALUES ('185', 'gadash_options', '{"ga_dash_apikey":"","ga_dash_clientid":"","ga_dash_clientsecret":"","ga_dash_access_front":"manage_options","ga_dash_access_back":"manage_options","ga_dash_tableid_jail":"","ga_dash_pgd":0,"ga_dash_rd":0,"ga_dash_sd":0,"ga_dash_map":0,"ga_dash_traffic":0,"ga_dash_style":"#3366CC","ga_dash_jailadmins":1,"ga_dash_cachetime":3600,"ga_dash_tracking":1,"ga_dash_tracking_type":"classic","ga_dash_default_ua":"","ga_dash_anonim":0,"ga_dash_userapi":0,"ga_event_tracking":0,"ga_event_downloads":"zip|mp3|mpeg|pdf|doc*|ppt*|xls*|jpeg|png|gif|tiff","ga_track_exclude":"manage_options","ga_target_geomap":"","ga_target_number":10,"ga_realtime_pages":10,"ga_dash_token":"","ga_dash_refresh_token":"","ga_dash_profile_list":"","ga_dash_tableid":"","ga_dash_frontend_keywords":0,"ga_tracking_code":"","ga_enhanced_links":0,"ga_dash_default_metric":"visits","ga_dash_default_dimension":"30daysAgo","ga_dash_frontend_stats":0}', 'yes'); 
INSERT INTO `wp_options` VALUES ('186', 'seo_friendly_images_alt', '%name %title', 'yes'); 
INSERT INTO `wp_options` VALUES ('187', 'seo_friendly_images_title', '%title', 'yes'); 
INSERT INTO `wp_options` VALUES ('188', 'seo_friendly_images_override', 'on', 'yes'); 
INSERT INTO `wp_options` VALUES ('189', 'seo_friendly_images_override_title', 'off', 'yes'); 
INSERT INTO `wp_options` VALUES ('190', 'excerpt_everywhere_class', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('192', '_transient_random_seed', '95fb5774030de95e31e8e1a5693a726c', 'yes'); 
INSERT INTO `wp_options` VALUES ('198', 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1394900750;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('199', 'current_theme', 'ASUG', 'yes'); 
INSERT INTO `wp_options` VALUES ('200', 'theme_mods_twentytwelve', 'a:6:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:12:"header_image";s:64:"http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg";s:17:"header_image_data";a:5:{s:13:"attachment_id";i:61;s:3:"url";s:64:"http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg";s:13:"thumbnail_url";s:64:"http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg";s:5:"width";i:229;s:6:"height";i:76;}s:16:"header_textcolor";s:5:"blank";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1398209514;s:4:"data";a:6:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:1:{i:0;s:6:"text-2";}s:9:"sidebar-3";a:0:{}s:5:"wop-1";a:2:{i:0;s:7:"pages-2";i:1;s:6:"text-3";}s:5:"wop-2";a:4:{i:0;s:8:"search-3";i:1;s:17:"recent-comments-3";i:2;s:10:"calendar-2";i:3;s:13:"em_calendar-2";}}}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('201', 'theme_switched', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('202', 'sm_options', 'a:51:{s:18:"sm_b_prio_provider";s:41:"GoogleSitemapGeneratorPrioByCountProvider";s:9:"sm_b_ping";b:1;s:10:"sm_b_stats";b:0;s:12:"sm_b_pingmsn";b:1;s:12:"sm_b_autozip";b:1;s:11:"sm_b_memory";s:0:"";s:9:"sm_b_time";i:-1;s:18:"sm_b_style_default";b:1;s:10:"sm_b_style";s:0:"";s:12:"sm_b_baseurl";s:0:"";s:11:"sm_b_robots";b:1;s:9:"sm_b_html";b:1;s:12:"sm_b_exclude";a:0:{}s:17:"sm_b_exclude_cats";a:0:{}s:10:"sm_in_home";b:1;s:11:"sm_in_posts";b:1;s:15:"sm_in_posts_sub";b:0;s:11:"sm_in_pages";b:1;s:10:"sm_in_cats";b:0;s:10:"sm_in_arch";b:0;s:10:"sm_in_auth";b:0;s:10:"sm_in_tags";b:0;s:9:"sm_in_tax";a:0:{}s:17:"sm_in_customtypes";a:0:{}s:13:"sm_in_lastmod";b:1;s:10:"sm_cf_home";s:5:"daily";s:11:"sm_cf_posts";s:7:"monthly";s:11:"sm_cf_pages";s:6:"weekly";s:10:"sm_cf_cats";s:6:"weekly";s:10:"sm_cf_auth";s:6:"weekly";s:15:"sm_cf_arch_curr";s:5:"daily";s:14:"sm_cf_arch_old";s:6:"yearly";s:10:"sm_cf_tags";s:6:"weekly";s:10:"sm_pr_home";d:1;s:11:"sm_pr_posts";d:0.59999999999999997779553950749686919152736663818359375;s:15:"sm_pr_posts_min";d:0.200000000000000011102230246251565404236316680908203125;s:11:"sm_pr_pages";d:0.59999999999999997779553950749686919152736663818359375;s:10:"sm_pr_cats";d:0.299999999999999988897769753748434595763683319091796875;s:10:"sm_pr_arch";d:0.299999999999999988897769753748434595763683319091796875;s:10:"sm_pr_auth";d:0.299999999999999988897769753748434595763683319091796875;s:10:"sm_pr_tags";d:0.299999999999999988897769753748434595763683319091796875;s:12:"sm_i_donated";b:0;s:17:"sm_i_hide_donated";b:0;s:17:"sm_i_install_date";i:1394901253;s:14:"sm_i_hide_note";b:0;s:15:"sm_i_hide_works";b:0;s:16:"sm_i_hide_donors";b:0;s:9:"sm_i_hash";s:20:"0331706813ee67293627";s:13:"sm_i_lastping";i:1402077732;s:16:"sm_i_supportfeed";b:1;s:22:"sm_i_supportfeed_cache";i:1401917336;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('205', 'sm_status', 'O:28:"GoogleSitemapGeneratorStatus":4:{s:39:" GoogleSitemapGeneratorStatus startTime";d:1402077724.300448894500732421875;s:37:" GoogleSitemapGeneratorStatus endTime";d:1402077731.1113231182098388671875;s:41:" GoogleSitemapGeneratorStatus pingResults";a:2:{s:6:"google";a:5:{s:9:"startTime";d:1402077724.4073350429534912109375;s:7:"endTime";d:1402077730.4050109386444091796875;s:7:"success";b:0;s:3:"url";s:98:"http://www.google.com/webmasters/sitemaps/ping?sitemap=http%3A%2F%2F127.0.0.1%2Fasug%2Fsitemap.xml";s:4:"name";s:6:"Google";}s:4:"bing";a:5:{s:9:"startTime";d:1402077730.49425506591796875;s:7:"endTime";d:1402077730.9906330108642578125;s:7:"success";b:1;s:3:"url";s:91:"http://www.bing.com/webmaster/ping.aspx?siteMap=http%3A%2F%2F127.0.0.1%2Fasug%2Fsitemap.xml";s:4:"name";s:4:"Bing";}}s:38:" GoogleSitemapGeneratorStatus autoSave";b:1;}', 'no'); 
INSERT INTO `wp_options` VALUES ('222', 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('263', 'sam_pointers', 'a:4:{s:6:"places";b:0;s:3:"ads";b:0;s:5:"zones";b:0;s:6:"blocks";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('276', 'adrotate_db_timer', '1394949155', 'yes'); 
INSERT INTO `wp_options` VALUES ('301', 'dfads_transient_data_deleted_time', '1402082784', 'yes'); 
INSERT INTO `wp_options` VALUES ('302', 'nextend_error', 'a:1:{s:13:"missingfooter";a:1:{i:0;s:6:"/asug/";}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('303', 'dfads-settings', 'a:1:{s:28:"dfads_enable_count_for_admin";s:1:"1";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('718', 'tchpcs_displayimage', 'YES', 'yes'); 
INSERT INTO `wp_options` VALUES ('719', 'tchpcs_word_limit', '9', 'yes'); 
INSERT INTO `wp_options` VALUES ('720', 'tchpcs_query_posts_showposts', '3', 'yes'); 
INSERT INTO `wp_options` VALUES ('721', 'tchpcs_query_posts_orderby', 'date', 'yes'); 
INSERT INTO `wp_options` VALUES ('722', 'tchpcs_query_posts_order', 'DESC', 'yes'); 
INSERT INTO `wp_options` VALUES ('723', 'tchpcs_query_posts_category', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('957', 'shop_catalog_image_size', 'a:3:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";b:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('958', 'shop_single_image_size', 'a:3:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('959', 'shop_thumbnail_image_size', 'a:3:{s:5:"width";s:2:"90";s:6:"height";s:2:"90";s:4:"crop";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1020', '_transient_woocommerce_processing_order_count', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1031', '_transient_woocommerce_cache_excluded_uris', 'a:6:{i:0;s:4:"p=97";i:1;s:4:"p=98";i:2;s:4:"p=99";i:3;s:9:"/carrinho";i:4;s:17:"/finalizar-compra";i:5;s:12:"/minha-conta";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1036', 'user_role_editor', 'a:4:{s:17:"ure_caps_readable";i:0;s:24:"ure_show_deprecated_caps";i:0;s:19:"ure_hide_pro_banner";i:0;s:15:"show_admin_role";s:1:"1";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1037', 'wp_backup_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:138:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:57:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:14:"publish_events";b:1;s:20:"delete_others_events";b:1;s:18:"edit_others_events";b:1;s:22:"manage_others_bookings";b:1;s:24:"publish_recurring_events";b:1;s:30:"delete_others_recurring_events";b:1;s:28:"edit_others_recurring_events";b:1;s:17:"publish_locations";b:1;s:23:"delete_others_locations";b:1;s:16:"delete_locations";b:1;s:21:"edit_others_locations";b:1;s:23:"delete_event_categories";b:1;s:21:"edit_event_categories";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:20:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:15:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:12:{s:4:"read";b:1;s:7:"level_0";b:1;s:15:"manage_bookings";b:1;s:19:"upload_event_images";b:1;s:13:"delete_events";b:1;s:11:"edit_events";b:1;s:19:"read_private_events";b:1;s:23:"delete_recurring_events";b:1;s:21:"edit_recurring_events";b:1;s:14:"edit_locations";b:1;s:22:"read_private_locations";b:1;s:21:"read_others_locations";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:3:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"delete_posts";b:0;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:93:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'no'); 
INSERT INTO `wp_options` VALUES ('1160', 'M_Installed', '14', 'yes'); 
INSERT INTO `wp_options` VALUES ('1161', 'membership_options', 'a:13:{s:17:"registration_page";i:102;s:12:"account_page";i:103;s:14:"nocontent_page";i:104;s:25:"membershipadminshortcodes";a:1:{i:0;s:12:"contact-form";}s:24:"membershipdownloadgroups";a:1:{i:0;s:7:"default";}s:10:"masked_url";s:9:"downloads";s:13:"strangerlevel";i:2;s:15:"paymentcurrency";s:3:"BRL";s:13:"upgradeperiod";s:1:"0";s:13:"renewalperiod";s:3:"365";s:16:"registration_tos";s:0:"";s:20:"freeusersubscription";i:1;s:23:"enableincompletesignups";s:0:"";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1162', 'M_Newsstream_Installed', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('1165', 'membership_active', 'yes', 'yes'); 
INSERT INTO `wp_options` VALUES ('1166', 'membership_activated_gateways', 'a:1:{i:0;s:10:"paypalsolo";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1167', 'membership_wizard_visible', 'no', 'yes'); 
INSERT INTO `wp_options` VALUES ('1168', 'membership_simpleinvite_options', 'a:3:{s:11:"invitecodes";s:0:"";s:14:"inviterequired";s:0:"";s:12:"inviteremove";s:0:"";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1241', 'widget_pages', 'a:2:{i:2;a:3:{s:5:"title";s:9:"Veja mais";s:6:"sortby";s:10:"post_title";s:7:"exclude";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1274', 'wop_options_field', 'a:5:{s:10:"enable_css";s:1:"1";s:19:"num_of_wop_sidebars";s:1:"2";s:10:"wop_name_1";s:16:"Sidebar Esquerdo";s:10:"wop_name_2";s:15:"Sidebar Direito";s:10:"wop_name_3";s:21:"Sidebar Institucional";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1285', 'wpbu_schedule_settings', 'a:2:{s:16:"backup_frequency";s:5:"daily";s:11:"backup_type";s:8:"database";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1295', 'widget_calendar', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1296', 'widget_em_calendar', 'a:2:{i:2;a:3:{s:5:"title";s:11:"Calendário";s:8:"category";s:1:"0";s:11:"long_events";i:0;}s:12:"_multiwidget";i:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1315', 'wp_googlefontmgr_apikey', 'AIzaSyDL8M3sWzyTMRbpDXGctGJfWnUQihDIjuU', 'yes'); 
INSERT INTO `wp_options` VALUES ('1319', 'wp_googlefontmgr_styledefaults', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('1320', 'wp_googlefontmgr_styleopts', 'body{ font-family:\'Carrois Gothic SC\' !important; font-size: 16px !important; }', 'yes'); 
INSERT INTO `wp_options` VALUES ('1431', 'pie_register', 'a:130:{s:13:"paypal_option";s:1:"0";s:14:"paypal_butt_id";s:0:"";s:14:"paypal_sandbox";s:2:"no";s:10:"paypal_pdt";s:0:"";s:13:"loginredirect";s:0:"";s:8:"password";s:1:"1";s:14:"password_meter";s:1:"0";s:5:"short";s:9:"Too Short";s:3:"bad";s:12:"Bad Password";s:4:"good";s:13:"Good Password";s:6:"strong";s:15:"Strong Password";s:8:"mismatch";s:9:"Mis Match";s:4:"code";s:1:"1";s:8:"codename";s:10:"Invitation";s:8:"codepass";s:0:"";s:10:"codeexpiry";s:2:"15";s:13:"code_auto_del";s:1:"1";s:11:"Expcodepass";s:0:"";s:7:"captcha";s:1:"0";s:10:"disclaimer";s:1:"0";s:16:"disclaimer_title";s:10:"Disclaimer";s:18:"disclaimer_content";s:0:"";s:16:"disclaimer_agree";s:21:"Accept the Disclaimer";s:7:"license";s:1:"0";s:13:"license_title";s:17:"License Agreement";s:15:"license_content";s:0:"";s:13:"license_agree";s:28:"Accept the License Agreement";s:7:"privacy";s:1:"0";s:13:"privacy_title";s:14:"Privacy Policy";s:15:"privacy_content";s:0:"";s:13:"privacy_agree";s:25:"Accept the Privacy Policy";s:12:"email_exists";s:1:"0";s:9:"firstname";s:1:"1";s:8:"lastname";s:1:"1";s:7:"website";s:1:"1";s:3:"aim";s:1:"0";s:5:"yahoo";s:1:"0";s:6:"jabber";s:1:"0";s:5:"about";s:1:"0";s:11:"profile_req";a:1:{i:0;s:1:"0";}s:13:"require_style";s:50:"border:solid 1px #E6DB55;background-color:#FFFFE0;";s:11:"dash_widget";s:1:"1";s:12:"email_verify";s:1:"0";s:12:"admin_verify";s:1:"1";s:18:"email_delete_grace";i:7;s:4:"html";s:1:"1";s:13:"emailvmsghtml";s:1:"1";s:13:"adminvmsghtml";s:1:"1";s:9:"adminhtml";s:1:"1";s:4:"from";s:25:"contato@montarsite.com.br";s:8:"fromname";s:27:"Asug | SAP NetWeaver Portal";s:7:"subject";s:56:"[Asug | SAP NetWeaver Portal] Your username and password";s:10:"custom_msg";s:1:"1";s:19:"adminvmsguser_nl2br";s:1:"0";s:9:"adminvmsg";s:225:" %blogname% Registration 
 --------------------------- 

 Here are your credentials: 
 Username: %user_login% 
 Password: %user_pass% 
 Confirm Registration: %siteurl% 

 Thank you for registering with %blogname%!  
";s:19:"emailvmsguser_nl2br";s:1:"0";s:9:"emailvmsg";s:225:" %blogname% Registration 
 --------------------------- 

 Here are your credentials: 
 Username: %user_login% 
 Password: %user_pass% 
 Confirm Registration: %siteurl% 

 Thank you for registering with %blogname%!  
";s:10:"user_nl2br";s:1:"0";s:3:"msg";s:225:" %blogname% Registration 
 --------------------------- 

 Here are your credentials: 
 Username: %user_login% 
 Password: %user_pass% 
 Confirm Registration: %siteurl% 

 Thank you for registering with %blogname%!  
";s:13:"disable_admin";s:1:"0";s:9:"adminfrom";s:25:"contato@montarsite.com.br";s:13:"adminfromname";s:27:"Asug | SAP NetWeaver Portal";s:12:"adminsubject";s:47:"[Asug | SAP NetWeaver Portal] New User Register";s:15:"custom_adminmsg";s:1:"0";s:11:"admin_nl2br";s:1:"0";s:8:"adminmsg";s:114:" New %blogname% Registration 
 --------------------------- 

 Username: %user_login% 
 E-Mail: %user_email% 
";s:4:"logo";s:0:"";s:14:"login_redirect";s:0:"";s:12:"register_css";s:81:"body{height:auto;} #login{width: 370px;} .login #pass-strength-result{width:95%;}";s:9:"login_css";s:18:"body{height:auto;}";s:8:"firstday";s:1:"6";s:10:"dateformat";s:10:"mm/dd/yyyy";s:9:"startdate";s:10:"01/01/1901";s:7:"calyear";s:4:"1999";s:8:"calmonth";s:3:"cur";s:16:"_admin_message_1";s:54:"  Por favor, selecione um usu&aacute;rio para validar!";s:16:"_admin_message_2";s:27:"Usu&aacute;rios Verificados";s:16:"_admin_message_3";s:20:"Caro usu&aacute;rio,";s:16:"_admin_message_4";s:82:"Voc&ecirc; foi registrado com sucesso, mais h&aacute; pend&ecirc;ncias financeiras";s:16:"_admin_message_5";s:94:"Por favor, clique ou copie este link para o navegador para concluir a inscri&ccedil;&atilde;o.";s:16:"_admin_message_6";s:9:"Obrigado.";s:16:"_admin_message_7";s:18:"Pagamento pendente";s:16:"_admin_message_8";s:58:"Por favor, selecione um usu&aacute;rio para enviar o link!";s:16:"_admin_message_9";s:66:"Link de pagamento foi enviado para o e-mail dos usu&aacute;rio (s)";s:17:"_admin_message_10";s:51:"Por favor selecione o usu&aacute;rio a ser deletado";s:17:"_admin_message_12";s:24:"Usu&aacute;rio deleteado";s:17:"_admin_message_13";s:15:"Verificar URL: ";s:17:"_admin_message_14";s:15:"Verificar conta";s:17:"_admin_message_15";s:56:"Os e-mails de verifica&ccedil;&atilde;o foram reenviados";s:17:"_admin_message_16";s:58:"Por favor, selecione um usu&aacute;rio para enviar e-mail.";s:17:"_admin_message_17";s:53:"Sua conta j&aacute; foi ativada por um administrador.";s:17:"_admin_message_18";s:35:"Registro de Conta de Usu&aacute;rio";s:17:"_admin_message_19";s:24:"Digite seu primeiro nome";s:17:"_admin_message_20";s:20:"Digite seu sobrenome";s:17:"_admin_message_21";s:24:"Digite a URL do seu site";s:17:"_admin_message_22";s:29:"Digite seu usu&aacute;rio AIM";s:17:"_admin_message_23";s:31:"Digite seu usu&aacute;rio Yahoo";s:17:"_admin_message_24";s:40:"Digite seu usu&aacute;rio do Google Talk";s:17:"_admin_message_25";s:18:"Digite seu celular";s:17:"_admin_message_26";s:19:"Digite seu telefone";s:17:"_admin_message_27";s:66:"Por favor insira algumas informa&ccedil;&otilde;es sobre si mesmo.";s:17:"_admin_message_28";s:16:"Digite sua senha";s:17:"_admin_message_29";s:33:"Sua senha n&atilde;o corresponde.";s:17:"_admin_message_30";s:43:"Sua senha deve ter pelo menos 6 caracteres.";s:17:"_admin_message_31";s:57:"Valida&ccedil;&atilde;o de imagem n&atilde;o corresponde.";s:17:"_admin_message_32";s:49:"O reCAPTCHA n&atilde;o foi digitado corretamente.";s:17:"_admin_message_33";s:19:"Por favor, aceite o";s:17:"_admin_message_34";s:18:"Por favor insira o";s:17:"_admin_message_35";s:43:"C&oacute;digo expirou ou n&atilde;o aceito.";s:17:"_admin_message_36";s:24:"C&oacute;digo incorreto.";s:17:"_admin_message_37";s:126:"Por favor, verifique seu e-mail e clique no link de confirma&ccedil;&atilde;o para ativar sua conta e completar o seu registo.";s:17:"_admin_message_38";s:134:"Este site est&aacute; fechado para registros p&uacute;blicos. Voc&ecirc; vai precisar de um c&oacute;digo [prcodename] para registrar.";s:17:"_admin_message_39";s:94:"Ter um c&oacute;digo [prcodename]? Digite-o aqui. (Isto n&atilde;o &eacute; necess&aacute;rio)";s:17:"_admin_message_40";s:25:"Digite o texto da imagem.";s:17:"_admin_message_41";s:116:"Sua conta ser&aacute; revisado por um administrador e voc&ecirc; ser&aacute; notificado quando ele &eacute; ativado.";s:17:"_admin_message_42";s:113:"Por favor, ative sua conta usando o link de confirma&ccedil;&atilde;o enviado para seu endere&ccedil;o de e-mail.";s:17:"_admin_message_43";s:51:"Clique abaixo para continuar e concluir o registro.";s:17:"_admin_message_44";s:98:"N&atilde;o h&aacute; taxa de assinatura de um tempo. Clique para completar o seu registo de conta.";s:17:"_admin_message_45";s:142:"seu e-mail foi verificada. N&atilde;o h&aacute; taxa de assinatura de um tempo. Por favor Clique abaixo para completar o seu registo de conta.";s:17:"_admin_message_46";s:36:"para o registo, fa&ccedil;a o login.";s:17:"_admin_message_47";s:65:"seu pagamento foi recebido. Fa&ccedil;a login na sua conta agora!";s:17:"_admin_message_48";s:54:"Voc&ecirc; pagou com sucesso para a sua ades&atilde;o.";s:17:"_admin_message_49";s:47:"H&aacute; um erro ao verificar o seu pagamento.";s:17:"_admin_message_50";s:123:"Obrigado por seu pagamento, estamos verificando o seu pagamento! Por favor, atualize esta p&aacute;gina em poucos segundos.";s:15:"custom_logo_url";s:0:"";s:8:"code_req";N;s:5:"phone";N;s:17:"email_verify_date";N;s:16:"reCAP_public_key";s:0:"";s:17:"reCAP_private_key";s:0:"";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1432', 'pie_register_custom', 'a:1:{i:0;a:6:{s:5:"label";s:6:"Boleto";s:7:"profile";s:1:"1";s:3:"reg";s:1:"1";s:8:"required";N;s:9:"fieldtype";s:6:"select";s:12:"extraoptions";s:7:"a,b,c,d";}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1436', 'user_meta_history', 'a:1:{s:7:"version";a:2:{s:12:"last_version";s:5:"1.1.5";s:5:"1.1.5";a:1:{s:9:"timestamp";i:1395446767;}}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1439', 'user_meta_fields', 'a:1:{i:3;a:8:{s:11:"field_title";s:6:"boleto";s:10:"field_type";s:4:"text";s:14:"title_position";s:3:"top";s:11:"description";s:6:"Boleto";s:8:"meta_key";s:6:"boleto";s:10:"admin_only";s:2:"on";s:9:"read_only";s:2:"on";s:6:"unique";s:2:"on";}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1517', 'mail_from', 'felipe@montarsite.com.br', 'yes'); 
INSERT INTO `wp_options` VALUES ('1518', 'mail_from_name', 'Felipe', 'yes'); 
INSERT INTO `wp_options` VALUES ('1519', 'mailer', 'smtp', 'yes'); 
INSERT INTO `wp_options` VALUES ('1520', 'mail_set_return_path', 'false', 'yes'); 
INSERT INTO `wp_options` VALUES ('1521', 'smtp_host', 'mail.montarsite.com.br', 'yes'); 
INSERT INTO `wp_options` VALUES ('1522', 'smtp_port', '587', 'yes'); 
INSERT INTO `wp_options` VALUES ('1523', 'smtp_ssl', 'none', 'yes'); 
INSERT INTO `wp_options` VALUES ('1524', 'smtp_auth', 'true', 'yes'); 
INSERT INTO `wp_options` VALUES ('1525', 'smtp_user', 'felipe@montarsite.com.br', 'yes'); 
INSERT INTO `wp_options` VALUES ('1526', 'smtp_pass', 'felip538159$', 'yes'); 
INSERT INTO `wp_options` VALUES ('1797', 'wp_dashboard_setup', 'dashboard_representante_inativos', 'yes'); 
INSERT INTO `wp_options` VALUES ('1805', 'itsec_data', 'a:5:{s:5:"build";i:4002;s:20:"activation_timestamp";i:1395884059;s:17:"already_supported";b:0;s:15:"setup_completed";b:1;s:18:"tooltips_dismissed";b:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1806', 'itsec_global', 'a:19:{s:11:"write_files";b:1;s:18:"notification_email";a:1:{i:0;s:25:"contato@montarsite.com.br";}s:12:"backup_email";a:1:{i:0;s:25:"contato@montarsite.com.br";}s:15:"lockout_message";s:5:"error";s:20:"user_lockout_message";s:56:"You have been locked out due to too many login attempts.";s:9:"blacklist";b:1;s:15:"blacklist_count";i:3;s:16:"blacklist_period";i:7;s:14:"lockout_period";i:15;s:18:"lockout_white_list";a:0:{}s:19:"email_notifications";b:1;s:8:"log_type";i:0;s:12:"log_rotation";i:30;s:12:"log_location";s:61:"C:xampphtdocsasug/wp-content/uploads/ithemes-security/logs";s:11:"did_upgrade";b:1;s:14:"allow_tracking";b:0;s:10:"nginx_file";s:31:"C:xampphtdocsasug/nginx.conf";s:24:"infinitewp_compatibility";b:0;s:8:"log_info";s:30:"asug-sap-netweaver-p-pq1OBY9Ee";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1807', 'itsec_initials', 'a:3:{s:5:"login";b:0;s:5:"admin";b:0;s:11:"file_editor";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1808', 'itsec_four_oh_four', 'a:4:{s:12:"check_period";i:5;s:15:"error_threshold";i:20;s:10:"white_list";a:9:{i:0;s:12:"/favicon.ico";i:1;s:11:"/robots.txt";i:2;s:21:"/apple-touch-icon.png";i:3;s:33:"/apple-touch-icon-precomposed.png";i:4;s:17:"/wp-content/cache";i:5;s:18:"/browserconfig.xml";i:6;s:16:"/crossdomain.xml";i:7;s:11:"/labels.rdf";i:8;s:27:"/trafficbasedsspsitemap.xml";}s:7:"enabled";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1809', 'itsec_away_mode', 'a:4:{s:4:"type";i:2;s:7:"enabled";b:0;s:5:"start";i:1395964800;s:3:"end";i:1396072800;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1810', 'itsec_ban_users', 'a:5:{s:9:"host_list";a:0:{}s:10:"agent_list";a:1:{i:0;b:0;}s:10:"white_list";a:0:{}s:7:"enabled";b:0;s:7:"default";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1812', 'itsec_brute_force', 'a:4:{s:17:"max_attempts_host";i:5;s:17:"max_attempts_user";i:10;s:12:"check_period";i:5;s:7:"enabled";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1813', 'itsec_backup', 'a:8:{s:6:"method";i:1;s:8:"location";s:64:"C:xampphtdocsasug/wp-content/uploads/ithemes-security/backups";s:3:"zip";b:1;s:7:"exclude";a:3:{i:0;s:14:"itsec_lockouts";i:1;s:9:"itsec_log";i:2;s:10:"itsec_temp";}s:8:"interval";i:1;s:7:"enabled";b:0;s:9:"all_sites";b:0;s:8:"last_run";i:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1814', 'itsec_file_change', 'a:9:{s:6:"method";b:1;s:9:"file_list";a:1:{i:0;s:0:"";}s:5:"types";a:6:{i:0;s:4:".jpg";i:1;s:5:".jpeg";i:2;s:4:".png";i:3;s:4:".log";i:4;s:3:".mo";i:5;s:3:".po";}s:5:"email";b:1;s:12:"notify_admin";b:1;s:7:"enabled";b:0;s:5:"split";b:0;s:10:"last_chunk";b:0;s:8:"last_run";i:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1815', 'itsec_hide_backend', 'a:4:{s:4:"slug";s:0:"";s:8:"register";s:8:"register";s:7:"enabled";b:0;s:12:"show-tooltip";b:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1818', 'itsec_ssl', 'a:3:{s:8:"frontend";i:1;s:5:"login";b:0;s:5:"admin";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1819', 'itsec_strong_passwords', 'a:2:{s:4:"roll";s:13:"administrator";s:7:"enabled";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1820', 'itsec_tweaks', 'a:22:{s:13:"protect_files";b:0;s:18:"directory_browsing";b:0;s:15:"request_methods";b:0;s:24:"suspicious_query_strings";b:0;s:22:"non_english_characters";b:0;s:16:"long_url_strings";b:0;s:17:"write_permissions";b:0;s:13:"generator_tag";b:0;s:18:"wlwmanifest_header";b:0;s:14:"edituri_header";b:0;s:13:"theme_updates";b:0;s:14:"plugin_updates";b:0;s:12:"core_updates";b:0;s:12:"comment_spam";b:0;s:14:"random_version";b:0;s:11:"file_editor";b:0;s:14:"disable_xmlrpc";b:0;s:11:"uploads_php";b:0;s:11:"safe_jquery";b:0;s:12:"login_errors";b:0;s:21:"force_unique_nicename";b:0;s:27:"disable_unused_author_pages";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1830', '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1857', 'itsec_jquery_version', '1.10.2', 'yes'); 
INSERT INTO `wp_options` VALUES ('1924', 'ips_options', 'a:12:{s:13:"issuu_api_key";s:32:"soj0jol9sig4cuk6amondzxyq8wp0r5j";s:16:"issuu_secret_key";s:32:"0mao3y0a07huevqkn3x3eqyt4idn2v87";s:11:"auto_upload";s:1:"1";s:14:"add_ips_button";s:1:"1";s:6:"access";s:6:"public";s:6:"layout";s:1:"1";s:13:"custom_layout";s:7:"default";s:5:"width";s:3:"800";s:6:"height";s:3:"600";s:7:"bgcolor";s:6:"FFFFFF";s:17:"allow_full_screen";s:1:"1";s:13:"flip_timelaps";s:4:"6000";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1940', 'defaults', 'O:8:"stdClass":6:{s:2:"id";s:29:"Please enter your flipbook id";s:5:"width";i:600;s:6:"height";i:600;s:6:"layout";i:1;s:4:"link";s:15:"Got to Flipbook";s:10:"responsive";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('1941', 'flipbooks', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('1947', 'wp-booklet-pdf-limit-status', 'on', 'yes'); 
INSERT INTO `wp_options` VALUES ('1959', 'epaper_dir', 'C:xampphtdocsasug/wp-content/uploads/epaper', 'yes'); 
INSERT INTO `wp_options` VALUES ('1960', 'epaper_url', 'http://127.0.0.1/asug/wp-content/uploads/epaper', 'yes'); 
INSERT INTO `wp_options` VALUES ('2083', 'duplicate_post_copyexcerpt', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('2084', 'duplicate_post_copyattachments', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('2085', 'duplicate_post_copychildren', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('2086', 'duplicate_post_copystatus', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('2087', 'duplicate_post_taxonomies_blacklist', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('2088', 'duplicate_post_show_row', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('2089', 'duplicate_post_show_adminbar', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('2090', 'duplicate_post_show_submitbox', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('2091', 'duplicate_post_version', '2.6', 'yes'); 
INSERT INTO `wp_options` VALUES ('2314', 'sm_rewrite_done', '$Id: sitemap-loader.php 925789 2014-06-03 17:03:07Z arnee $', 'yes'); 
INSERT INTO `wp_options` VALUES ('2315', 'bup_db_version', '0.4.2', 'yes'); 
INSERT INTO `wp_options` VALUES ('2316', 'bup_db_installed', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('2317', 'wp-optimize-schedule', 'false', 'no'); 
INSERT INTO `wp_options` VALUES ('2318', 'wp-optimize-last-optimized', 'Never', 'no'); 
INSERT INTO `wp_options` VALUES ('2319', 'wp-optimize-schedule-type', 'wpo_weekly', 'no'); 
INSERT INTO `wp_options` VALUES ('2320', 'wp-optimize-retention-enabled', 'false', 'no'); 
INSERT INTO `wp_options` VALUES ('2321', 'wp-optimize-retention-period', '2', 'no'); 
INSERT INTO `wp_options` VALUES ('2322', 'wp-optimize-enable-admin-menu', 'false', 'no'); 
INSERT INTO `wp_options` VALUES ('2323', 'wp-optimize-total-cleaned', '0', 'no'); 
INSERT INTO `wp_options` VALUES ('2324', 'wp-optimize-auto', 'a:8:{s:9:"revisions";s:4:"true";s:6:"drafts";s:4:"true";s:5:"spams";s:4:"true";s:10:"unapproved";s:5:"false";s:9:"transient";s:5:"false";s:8:"postmeta";s:5:"false";s:4:"tags";s:5:"false";s:8:"optimize";s:4:"true";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('2385', 'blc_installation_log', 'a:50:{i:0;a:3:{i:0;i:1;i:1;s:40:"Plugin activated at 2014-04-12 19:10:41.";i:2;N;}i:1;a:3:{i:0;i:1;i:1;s:27:"Installation/update begins.";i:2;N;}i:2;a:3:{i:0;i:1;i:1;s:25:"Upgrading the database...";i:2;N;}i:3;a:3:{i:0;i:1;i:1;s:24:"Database schema updated.";i:2;N;}i:4;a:3:{i:0;i:1;i:1;s:31:"Database successfully upgraded.";i:2;N;}i:5;a:3:{i:0;i:1;i:1;s:27:"Cleaning up the database...";i:2;N;}i:6;a:3:{i:0;i:1;i:1;s:38:"... Deleting invalid container records";i:2;N;}i:7;a:3:{i:0;i:0;i:1;s:27:"... 0 synch records deleted";i:2;N;}i:8;a:3:{i:0;i:1;i:1;s:35:"... Deleting invalid link instances";i:2;N;}i:9;a:3:{i:0;i:0;i:1;s:23:"... 0 instances deleted";i:2;N;}i:10;a:3:{i:0;i:0;i:1;s:28:"... 0 more instances deleted";i:2;N;}i:11;a:3:{i:0;i:1;i:1;s:27:"... Deleting orphaned links";i:2;N;}i:12;a:3:{i:0;i:0;i:1;s:19:"... 0 links deleted";i:2;N;}i:13;a:3:{i:0;i:1;i:1;s:20:"Notifying modules...";i:2;N;}i:14;a:3:{i:0;i:0;i:1;s:25:"... Updating module cache";i:2;N;}i:15;a:3:{i:0;i:0;i:1;s:27:"... Notifying module "http"";i:2;N;}i:16;a:3:{i:0;i:0;i:1;s:27:"... Notifying module "link"";i:2;N;}i:17;a:3:{i:0;i:0;i:1;s:59:"...... Parser "link" is marking relevant items as unsynched";i:2;N;}i:18;a:3:{i:0;i:0;i:1;s:272:"...... Executing query: UPDATE wp_blc_synch SET synched = 0 WHERE (container_type = \'page\' AND last_synch >= \'1970-01-01 00:00:00\') OR (container_type = \'post\' AND last_synch >= \'1970-01-01 00:00:00\') OR (container_type = \'comment\' AND last_synch >= \'1970-01-01 00:00:00\')";i:2;N;}i:19;a:3:{i:0;i:0;i:1;s:38:"...... 46 rows affected, 0.033 seconds";i:2;N;}i:20;a:3:{i:0;i:0;i:1;s:28:"... Notifying module "image"";i:2;N;}i:21;a:3:{i:0;i:0;i:1;s:60:"...... Parser "image" is marking relevant items as unsynched";i:2;N;}i:22;a:3:{i:0;i:0;i:1;s:272:"...... Executing query: UPDATE wp_blc_synch SET synched = 0 WHERE (container_type = \'page\' AND last_synch >= \'1970-01-01 00:00:00\') OR (container_type = \'post\' AND last_synch >= \'1970-01-01 00:00:00\') OR (container_type = \'comment\' AND last_synch >= \'1970-01-01 00:00:00\')";i:2;N;}i:23;a:3:{i:0;i:0;i:1;s:37:"...... 0 rows affected, 0.012 seconds";i:2;N;}i:24;a:3:{i:0;i:0;i:1;s:31:"... Notifying module "metadata"";i:2;N;}i:25;a:3:{i:0;i:0;i:1;s:63:"...... Parser "metadata" is marking relevant items as unsynched";i:2;N;}i:26;a:3:{i:0;i:0;i:1;s:32:"... Notifying module "url_field"";i:2;N;}i:27;a:3:{i:0;i:0;i:1;s:64:"...... Parser "url_field" is marking relevant items as unsynched";i:2;N;}i:28;a:3:{i:0;i:0;i:1;s:134:"...... Executing query: UPDATE wp_blc_synch SET synched = 0 WHERE (container_type = \'comment\' AND last_synch >= \'1970-01-01 00:00:00\')";i:2;N;}i:29;a:3:{i:0;i:0;i:1;s:37:"...... 0 rows affected, 0.024 seconds";i:2;N;}i:30;a:3:{i:0;i:0;i:1;s:30:"... Notifying module "comment"";i:2;N;}i:31;a:3:{i:0;i:0;i:1;s:51:"...... Deleting synch. records for removed comments";i:2;N;}i:32;a:3:{i:0;i:0;i:1;s:22:"...... 0 rows affected";i:2;N;}i:33;a:3:{i:0;i:0;i:1;s:47:"...... Creating synch. records for new comments";i:2;N;}i:34;a:3:{i:0;i:0;i:1;s:22:"...... 0 rows affected";i:2;N;}i:35;a:3:{i:0;i:0;i:1;s:27:"... Notifying module "post"";i:2;N;}i:36;a:3:{i:0;i:0;i:1;s:47:"...... Deleting synch records for removed posts";i:2;N;}i:37;a:3:{i:0;i:0;i:1;s:21:"...... 0 rows deleted";i:2;N;}i:38;a:3:{i:0;i:0;i:1;s:41:"...... Marking changed posts as unsynched";i:2;N;}i:39;a:3:{i:0;i:0;i:1;s:21:"...... 0 rows updated";i:2;N;}i:40;a:3:{i:0;i:0;i:1;s:43:"...... Creating synch records for new posts";i:2;N;}i:41;a:3:{i:0;i:0;i:1;s:22:"...... 0 rows inserted";i:2;N;}i:42;a:3:{i:0;i:0;i:1;s:27:"... Notifying module "page"";i:2;N;}i:43;a:3:{i:0;i:0;i:1;s:74:"...... Skipping "page" resyncyh since all post types were already synched.";i:2;N;}i:44;a:3:{i:0;i:0;i:1;s:28:"... Notifying module "dummy"";i:2;N;}i:45;a:3:{i:0;i:1;i:1;s:38:"Updating server load limit settings...";i:2;N;}i:46;a:3:{i:0;i:1;i:1;s:26:"Optimizing the database...";i:2;N;}i:47;a:3:{i:0;i:1;i:1;s:26:"Completing installation...";i:2;N;}i:48;a:3:{i:0;i:1;i:1;s:20:"Configuration saved.";i:2;N;}i:49;a:3:{i:0;i:1;i:1;s:78:"Installation/update completed at 2014-04-12 19:10:42 with 30 queries executed.";i:2;N;}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('2657', 'db_upgraded', '', 'yes'); 
INSERT INTO `wp_options` VALUES ('2661', 'can_compress_scripts', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('2681', 'theme_mods_asug', 'a:4:{i:0;b:0;s:12:"header_image";s:69:"http://127.0.0.1/asug/wp-content/uploads/2014/03/copy-asug-brasil.jpg";s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:308;s:3:"url";s:69:"http://127.0.0.1/asug/wp-content/uploads/2014/03/copy-asug-brasil.jpg";s:13:"thumbnail_url";s:69:"http://127.0.0.1/asug/wp-content/uploads/2014/03/copy-asug-brasil.jpg";s:6:"height";i:76;s:5:"width";i:229;}s:18:"nav_menu_locations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('3681', 'event-categories_children', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('7231', '_site_transient_timeout_popular_importers_pt_BR', '1398800823', 'yes'); 
INSERT INTO `wp_options` VALUES ('7232', '_site_transient_popular_importers_pt_BR', 'a:2:{s:9:"importers";a:8:{s:7:"blogger";a:4:{s:4:"name";s:7:"Blogger";s:11:"description";s:86:"Install the Blogger importer to import posts, comments, and users from a Blogger blog.";s:11:"plugin-slug";s:16:"blogger-importer";s:11:"importer-id";s:7:"blogger";}s:9:"wpcat2tag";a:4:{s:4:"name";s:29:"Categories and Tags Converter";s:11:"description";s:109:"Install the category/tag converter to convert existing categories to tags or tags to categories, selectively.";s:11:"plugin-slug";s:18:"wpcat2tag-importer";s:11:"importer-id";s:9:"wpcat2tag";}s:11:"livejournal";a:4:{s:4:"name";s:11:"LiveJournal";s:11:"description";s:82:"Install the LiveJournal importer to import posts from LiveJournal using their API.";s:11:"plugin-slug";s:20:"livejournal-importer";s:11:"importer-id";s:11:"livejournal";}s:11:"movabletype";a:4:{s:4:"name";s:24:"Movable Type and TypePad";s:11:"description";s:99:"Install the Movable Type importer to import posts and comments from a Movable Type or TypePad blog.";s:11:"plugin-slug";s:20:"movabletype-importer";s:11:"importer-id";s:2:"mt";}s:4:"opml";a:4:{s:4:"name";s:8:"Blogroll";s:11:"description";s:61:"Install the blogroll importer to import links in OPML format.";s:11:"plugin-slug";s:13:"opml-importer";s:11:"importer-id";s:4:"opml";}s:3:"rss";a:4:{s:4:"name";s:3:"RSS";s:11:"description";s:58:"Install the RSS importer to import posts from an RSS feed.";s:11:"plugin-slug";s:12:"rss-importer";s:11:"importer-id";s:3:"rss";}s:6:"tumblr";a:4:{s:4:"name";s:6:"Tumblr";s:11:"description";s:84:"Install the Tumblr importer to import posts &amp; media from Tumblr using their API.";s:11:"plugin-slug";s:15:"tumblr-importer";s:11:"importer-id";s:6:"tumblr";}s:9:"wordpress";a:4:{s:4:"name";s:9:"WordPress";s:11:"description";s:130:"Install the WordPress importer to import posts, pages, comments, custom fields, categories, and tags from a WordPress export file.";s:11:"plugin-slug";s:18:"wordpress-importer";s:11:"importer-id";s:9:"wordpress";}}s:10:"translated";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('7262', 'cd_setting', 'a:7:{s:5:"cpost";s:15:"comment_post_ID";s:5:"cdate";s:12:"comment_date";s:4:"name";s:14:"comment_author";s:5:"email";s:20:"comment_author_email";s:7:"website";s:18:"comment_author_url";s:7:"content";s:15:"comment_content";s:10:"attachment";s:18:"comment_attachment";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('8412', 'category_children', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('10185', '_site_transient_timeout_browser_d88670820d154fdb975c9bc3be8d0cb6', '1399419857', 'yes'); 
INSERT INTO `wp_options` VALUES ('10186', '_site_transient_browser_d88670820d154fdb975c9bc3be8d0cb6', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"34.0.1847.116";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('12118', '_site_transient_timeout_browser_6350bd02ff99707793f8f7f5e331a1e5', '1399738698', 'yes'); 
INSERT INTO `wp_options` VALUES ('12119', '_site_transient_browser_6350bd02ff99707793f8f7f5e331a1e5', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"34.0.1847.131";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('13010', '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:2:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:65:"https://downloads.wordpress.org/release/pt_BR/wordpress-3.9.1.zip";s:6:"locale";s:5:"pt_BR";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:65:"https://downloads.wordpress.org/release/pt_BR/wordpress-3.9.1.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1402069903;s:15:"version_checked";s:5:"3.9.1";s:12:"translations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('13012', 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:25:"contato@montarsite.com.br";s:7:"version";s:5:"3.9.1";s:9:"timestamp";i:1401490828;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('13054', '_site_transient_timeout_browser_95d7e62a50bdc5562a7ae95f7f64d07c', '1402355562', 'yes'); 
INSERT INTO `wp_options` VALUES ('13055', '_site_transient_browser_95d7e62a50bdc5562a7ae95f7f64d07c', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"35.0.1916.114";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('14358', 'sap_servidor', 'https://performancemanager8.successfactors.com/', 'yes'); 
INSERT INTO `wp_options` VALUES ('14359', 'sap_chave_auth', 'aW50ZXJmYWNlMUBDMDAxMTE3ODg1OFQxOkFzdWcxMjM=', 'yes'); 
INSERT INTO `wp_options` VALUES ('14360', 'sap_login_valido', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('14361', 'sap_company', 'C0011178858T1', 'yes'); 
INSERT INTO `wp_options` VALUES ('14362', 'sap_username', 'interface1', 'yes'); 
INSERT INTO `wp_options` VALUES ('14363', 'sap_password', 'Asug123', 'yes'); 
INSERT INTO `wp_options` VALUES ('14364', 'sap_logar', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('14365', 'sap_ultima_sinc', '1401740981', 'yes'); 
INSERT INTO `wp_options` VALUES ('14366', 'sap_tklogin_key', 'novoportalasug', 'yes'); 
INSERT INTO `wp_options` VALUES ('14367', 'sap_sso_utilizavel', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('14368', 'sap_sso_valido', '1', 'yes'); 
INSERT INTO `wp_options` VALUES ('14369', 'sap_secret_key', 'asugkeysso1', 'yes'); 
INSERT INTO `wp_options` VALUES ('14470', 'dismissed_update_core', 'a:1:{s:11:"3.9.1|pt_BR";b:1;}', 'yes'); 
INSERT INTO `wp_options` VALUES ('14817', 'ewww_image_optimizer_bulk_attachments', 'a:13:{i:0;s:3:"123";i:1;s:3:"120";i:2;s:3:"119";i:3;s:2:"87";i:4;s:2:"86";i:5;s:2:"78";i:6;s:2:"77";i:7;s:2:"67";i:8;s:2:"66";i:9;s:2:"65";i:10;s:2:"64";i:11;s:2:"63";i:12;s:2:"61";}', 'no'); 
INSERT INTO `wp_options` VALUES ('14818', 'ewww_image_optimizer_flag_attachments', '', 'no'); 
INSERT INTO `wp_options` VALUES ('14819', 'ewww_image_optimizer_ngg_attachments', '', 'no'); 
INSERT INTO `wp_options` VALUES ('14820', 'ewww_image_optimizer_aux_attachments', '', 'no'); 
INSERT INTO `wp_options` VALUES ('15319', 'dfads_group_children', 'a:0:{}', 'yes'); 
INSERT INTO `wp_options` VALUES ('15656', 'flexipages_widget', 'a:1:{i:2;a:14:{s:5:"title";s:8:"Páginas";s:11:"sort_column";s:10:"menu_order";s:10:"sort_order";s:3:"ASC";s:9:"exinclude";s:7:"include";s:16:"exinclude_values";s:16:"6,39,37,35,41,43";s:19:"show_subpages_check";s:2:"on";s:13:"show_subpages";s:1:"0";s:9:"hierarchy";s:2:"on";s:5:"depth";s:1:"0";s:15:"show_home_check";s:0:"";s:9:"show_home";s:4:"Home";s:9:"show_date";s:0:"";s:11:"date_format";s:0:"";s:8:"dropdown";s:0:"";}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('16350', '_transient_timeout_feed_e14a1e5a5b311579a7d9f87467c39a91', '1402522136', 'no'); 
INSERT INTO `wp_options` VALUES ('16351', '_transient_feed_e14a1e5a5b311579a7d9f87467c39a91', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:23:"
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Google Sitemap Generator Support Topics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"Google Sitemap Generator Support Topics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://www.arnebrachhold.de/projects/wordpress-plugins/google-xml-sitemaps-generator/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Wed, 21 May 2014 5:23:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:3:{i:0;a:6:{s:4:"data";s:19:"
			
			
			
			
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"Common error messages in Google Webmaster Tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://www.arnebrachhold.de/redir/sitemap-feed-gwterrs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:20:"C2VZYxeTESzcCF2IhS13";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 28 Apr 2014 00:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:19:"
			
			
			
			
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"How to move your sitemap to the root of your domain";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://www.arnebrachhold.de/redir/sitemap-feed-movesm/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:20:"C2VZYxeTESzcCF2IhS12";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 27 Apr 2014 00:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:19:"
			
			
			
			
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Introducing a new format for your sitemap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://www.arnebrachhold.de/redir/sitemap-feed-newformat/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:20:"C2VZYxeTESzcCF2IhS1l";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 26 Apr 2014 00:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:16:"cloudflare-nginx";s:4:"date";s:29:"Wed, 04 Jun 2014 21:28:56 GMT";s:12:"content-type";s:23:"text/xml; charset=utf-8";s:10:"connection";s:5:"close";s:10:"set-cookie";s:138:"__cfduid=dcf564aa0ef8030d49893b95db10c35041401917336359; expires=Mon, 23-Dec-2019 23:50:00 GMT; path=/; domain=.arnebrachhold.de; HttpOnly";s:13:"cache-control";s:21:"public, max-age=86400";s:13:"last-modified";s:29:"Wed, 21 May 2014 17:23:30 GMT";s:4:"vary";s:15:"Accept-Encoding";s:6:"cf-ray";s:20:"135739183f9a0329-MIA";s:16:"content-encoding";s:4:"gzip";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('16352', '_transient_timeout_feed_mod_e14a1e5a5b311579a7d9f87467c39a91', '1402522136', 'no'); 
INSERT INTO `wp_options` VALUES ('16353', '_transient_feed_mod_e14a1e5a5b311579a7d9f87467c39a91', '1401917336', 'no'); 
INSERT INTO `wp_options` VALUES ('16716', '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1402101526', 'no'); 
INSERT INTO `wp_options` VALUES ('16717', '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:42:"http://wordpress.org/?v=4.0-alpha-20140605";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3077:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="http://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/imath">imath</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="http://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23291:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<embed src="//v0.wordpress.com/player.swf?v=1.03" type="application/x-shockwave-flash" width="640" height="360" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=sAiXhCfV&amp;isDynamicSeeking=true" title=""></embed>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'http://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; max-width: 100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3154-1" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=1" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lkwdwrd">lkwdwrd</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">ruud@joyo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2339:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.9 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 21:05:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3129";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"As teased earlier, the first release candidate for WordPress 3.9 is now available for testing! We hope to ship WordPress 3.9 next week, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.) To test WordPress 3.9 [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2967:"<p><a href="//wordpress.org/news/2014/04/wordpress-3-8-2/">As teased earlier</a>, the first release candidate for WordPress 3.9 is now available for testing!</p>
<p>We hope to ship WordPress 3.9 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>To test WordPress 3.9 RC1, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the work-in-progress About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="//wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="//core.trac.wordpress.org/report/5">find them here</a>.</p>
<p><strong>If you&#8217;re a plugin author</strong>, there are two important changes in particular to be aware of:</p>
<ul>
<li>TinyMCE received a major update, to version 4.0. Any editor plugins written for TinyMCE 3.x might require some updates. (If things broke, we&#8217;d like to hear about them so we can make adjustments.) For more, see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and <a href="http://www.tinymce.com/wiki.php/api4:index">API documentation</a>, and the notes on the <a href="//make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">core development blog</a>.</li>
<li>WordPress 3.9 now uses the MySQLi Improved extension for sites running PHP 5.5. Any plugins that made direct calls to <code>mysql_*</code> functions will experience some problems on these sites. For more information, see the notes on the <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">core development blog</a>.</li>
</ul>
<p>Be sure to follow along the core development blog, where we will be continuing to post <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example, read <a href="//make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">this</a> if you are using Masonry in your theme.) And please, please update your plugin&#8217;s <em>Tested up to</em> version in the readme to 3.9 before April 16.</p>
<p><em>Release candidate<br />
This haiku&#8217;s the easy one<br />
3.9 is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.8.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 19:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately. This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by Jon Cave of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by <a href="http://joncave.co.uk/">Jon Cave</a> of the WordPress security team.</p>
<p>It also contains a fix to prevent a user with the Contributor role from improperly publishing posts. Reported by <a href="http://edik.ch/">edik</a>.</p>
<p>This release also fixes nine bugs and contains three other security hardening changes:</p>
<ul>
<li>Pass along additional information when processing pingbacks to help hosts identify potentially abusive requests.</li>
<li>Fix a low-impact SQL injection by trusted users. Reported by <a href="http://www.dxw.com/">Tom Adams</a> of dxw.</li>
<li>Prevent possible cross-domain scripting through Plupload, the third-party library WordPress uses for uploading files. Reported by <a href="http://szgru.website.pl/">Szymon Gruszecki</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these security issues directly to our security team. For more information on all of the changes, see the <a href="http://codex.wordpress.org/Version_3.8.2">release notes</a> or consult <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=28057&amp;stop_rev=27024">the list of changes</a>.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.8.2 within 12 hours. If you are still on WordPress 3.7.1, you will be updated to 3.7.2, which contains the same security fixes as 3.8.2. We don&#8217;t support older versions, so please update to 3.8.2 for the latest and greatest.</p>
<p>Already testing WordPress 3.9? The first release candidate is <a href="https://wordpress.org/wordpress-3.9-RC1.zip">now available</a> (zip) and it contains these security fixes. Look for a full announcement later today; we expect to release 3.9 next week.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 29 Mar 2014 13:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3106";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"The third (and maybe last) beta of WordPress 3.9 is now available for download. Beta 3 includes more than 200 changes, including: New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out. UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2668:"<p>The third (and maybe last) beta of WordPress 3.9 is now available for download.</p>
<p>Beta 3 includes more than 200 <a href="https://core.trac.wordpress.org/log?rev=27850&amp;stop_rev=27639&amp;limit=300">changes</a>, including:</p>
<ul>
<li>New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out.</li>
<li>UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought back some of the advanced display settings for images.</li>
<li>If you want to test out audio and video playlists, the links will appear in the media manager once you&#8217;ve uploaded an audio or video file.</li>
<li>For theme developers, we&#8217;ve added HTML5 caption support (<a class="reopened ticket" title="task (blessed): HTML5 captions (reopened)" href="https://core.trac.wordpress.org/ticket/26642">#26642</a>) to match the new gallery support (<a class="closed ticket" title="enhancement: HTML5 Galleries (closed: fixed)" href="https://core.trac.wordpress.org/ticket/26697">#26697</a>).</li>
<li>The formatting function that turns straight quotes into smart quotes (among other things) underwent some changes to drastically speed it up, so let us know if you see anything weird.</li>
</ul>
<p><strong>We need your help</strong>. We&#8217;re still aiming for an April release, which means the next week will be critical for identifying and squashing bugs. If you&#8217;re just joining us, please see <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven&#8217;t tested WordPress 3.9 yet, now is the time — and be sure to update the &#8220;tested up to&#8221; version for your plugins so they&#8217;re listed as compatible with 3.9.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta3.zip">download the beta here</a> (zip).</p>
<p><em>WordPress 3.9<br />
Let&#8217;s make the date official<br />
It&#8217;s April 16</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:309:"WordPress 3.9 Beta 2 is now available for testing! We&#8217;ve made more than a hundred changes since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1901:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&amp;stop_rev=27500&amp;limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 13:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3083";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"I&#8217;m excited to announce that the first beta of WordPress 3.9 is now available for testing. WordPress 3.9 is due out next month &#8212; but in order to hit that goal, we need your help testing all of the goodies we&#8217;ve added: We updated TinyMCE, the software powering the visual editor, to the latest version. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6065:"<p>I&#8217;m excited to announce that the <strong>first beta of WordPress 3.9</strong> is now available for testing.</p>
<p>WordPress 3.9 is due out next month &#8212; but in order to hit that goal, <strong>we need your help</strong> testing all of the goodies we&#8217;ve added:</p>
<ul>
<li>We updated TinyMCE, the software powering the visual editor, to the latest version. Be on the lookout for cleaner markup. Also try the new paste handling &#8212; if you paste in a block of text from Microsoft Word, for example, it will no longer come out terrible. (The &#8220;Paste from Word&#8221; button you probably never noticed has been removed.) It&#8217;s possible some plugins that added stuff to the visual editor (like a new toolbar button) no longer work, so we&#8217;d like to hear about them (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>). (And be sure to <a href="http://wordpress.org/support/">open a support thread</a> for the plugin author.)</li>
<li>We&#8217;ve added <strong>widget management to live previews</strong> (the customizer). Please test editing, adding, and rearranging widgets! (<a href="https://core.trac.wordpress.org/ticket/27112">#27112</a>) We&#8217;ve also added the ability to upload, crop, and manage header images, without needing to leave the preview. (<a href="https://core.trac.wordpress.org/ticket/21785">#21785</a>)</li>
<li>We brought 3.8&#8242;s beautiful new theme browsing experience to the <strong>theme installer</strong>. Check it out! (<a title="View ticket" href="https://core.trac.wordpress.org/ticket/27055">#27055</a>)</li>
<li><strong>Galleries</strong> now receive a live preview in the editor. Upload some photos and insert a gallery to see this in action. (<a href="https://core.trac.wordpress.org/ticket/26959">#26959</a>)</li>
<li>You can now <strong>drag-and-drop</strong> images directly onto the editor to upload them. It can be a bit finicky, so try it and help us work out the kinks. (<a href="https://core.trac.wordpress.org/ticket/19845">#19845</a>)</li>
<li>Some things got improved around <strong>editing images</strong>. It&#8217;s a lot easier to make changes to an image after you insert it into a post (<a class="closed" title="View ticket" href="https://core.trac.wordpress.org/ticket/24409">#24409</a>) and you no longer get kicked to a new window when you need to crop or rotate an image (<a href="https://core.trac.wordpress.org/ticket/21811">#21811</a>).</li>
<li>New <strong>audio/video playlists</strong>. Upload a few audio or video files to test these. (<a href="https://core.trac.wordpress.org/ticket/26631">#26631</a>)</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We&#8217;d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip">download the beta here</a> (zip).</p>
<hr />
<p><strong>DEVELOPERS!</strong> Hello! There&#8217;s lots for you, too.</p>
<p><strong>Please test your plugins and themes!</strong> There&#8217;s a lot of great stuff under the hood in 3.9 and we hope to blog a bit about them in the coming days. If you haven&#8217;t been reading the awesome <a href="http://make.wordpress.org/core/tag/week-in-core/">weekly summaries</a> on the <a href="http://make.wordpress.org/core/">main core development blog</a>, that&#8217;s a great place to start. (You should definitely follow that blog.) For now, here are some things to watch out for when testing:</p>
<ul>
<li>The <strong>load process in multisite</strong> got rewritten. If you notice any issues with your network, see <a href="https://core.trac.wordpress.org/ticket/27003">#27003</a>.</li>
<li>We now use the <strong>MySQL Improved (mysqli) database extension</strong> if you&#8217;re running a recent version of PHP (<a href="https://core.trac.wordpress.org/ticket/21663">#21663</a>). Please test your plugins and see that everything works well, and please make sure you&#8217;re not calling <code>mysql_*</code> functions directly.</li>
<li><strong>Autosave</strong> was refactored, so if you see any issues related to autosaving, heartbeat, etc., let us know (<a href="https://core.trac.wordpress.org/ticket/25272">#25272</a>).</li>
<li>Library updates, in particular Backbone 1.1 and Underscore 1.6 (<a href="https://core.trac.wordpress.org/ticket/26799">#26799</a>). Also Masonry 3 (<a href="https://core.trac.wordpress.org/ticket/25351">#25351</a>), PHPMailer (<a href="https://core.trac.wordpress.org/ticket/25560">#25560</a>), Plupload (<a href="https://core.trac.wordpress.org/ticket/25663">#25663</a>), and TinyMCE (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>).</li>
<li>TinyMCE 4.0 is a <em>major</em> update. Please see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">upgrade guide</a> and our <a href="https://core.trac.wordpress.org/ticket/24067">implementation ticket</a> for more. If you have any questions or problems, please <a href="http://wordpress.org/support/forum/alphabeta">open a thread in the support forums</a>.</li>
</ul>
<p>Happy testing!</p>
<p><em><em>Lots of improvements<br />
Little things go a long way</em><br />
Please test beta one<br />
</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/01/wordpress-3-8-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/01/wordpress-3-8-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3063";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:358:"After six weeks and more than 9.3 million downloads of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3809:"<p>After six weeks and more than <a href="http://wordpress.org/download/counter/">9.3 million downloads</a> of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available.</p>
<p>Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query was resolved. And if you&#8217;ve been frustrated by submit buttons that won&#8217;t do anything when you click on them (or thought you were going crazy, like some of us), we&#8217;ve found and fixed this &#8220;dead zone&#8221; on submit buttons.</p>
<p>It also contains a fix for <strong>embedding tweets</strong> (by placing the URL to the tweet on its own line), which was broken due to a recent Twitter API change. (For more on Embeds, see <a href="http://codex.wordpress.org/Embeds">the Codex</a>.)</p>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.8.1">list of tickets</a> and <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=27018&amp;stop_rev=26862">the changelog</a>. There&#8217;s also a <a href="http://make.wordpress.org/core/2014/01/22/wordpress-3-8-1-release-candidate/">detailed summary</a> for developers on the development blog.</p>
<p>If you are one of the millions already running WordPress 3.8, we will start rolling out automatic background updates for WordPress 3.8.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.8.1:</p>
<p><a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="#">José Pino</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p><em>WordPress three eight one<br />
We heard you didn&#8217;t like bugs<br />
So we took them out</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/01/wordpress-3-8-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Fri, 06 Jun 2014 12:38:45 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 08 May 2014 18:40:58 GMT";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('16718', '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1402101526', 'no'); 
INSERT INTO `wp_options` VALUES ('16719', '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1402058326', 'no'); 
INSERT INTO `wp_options` VALUES ('16720', '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1402101528', 'no'); 
INSERT INTO `wp_options` VALUES ('16721', '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WordPress.tv: Francisco Javier Carazo Gil: WordPress como plataforma de desarrollo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25609";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://wordpress.tv/2014/06/06/francisco-javier-carazo-gil-wordpress-como-plataforma-de-desarrollo/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:719:"<div id="v-u20E7Fpe-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25609/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25609/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25609&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/06/francisco-javier-carazo-gil-wordpress-como-plataforma-de-desarrollo/"><img alt="Francisco Javier Carazo Gil: WordPress como plataforma de desarrollo" src="http://videos.videopress.com/u20E7Fpe/video-d6104776da_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Jun 2014 09:00:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WP Android: Version 2.9 of WordPress for Android";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"http://android.wordpress.org/?p=1065";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://android.wordpress.org/2014/06/06/version-2-9-of-wordpress-for-android/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4519:"<p>The WordPress for Android 2.9 release is now available in the Google Play Store. This release includes some exciting new features, enhancements, and bug fixes.</p>
<h2>Blog Discovery</h2>
<p>Blog discovery is a new feature in the Reader that lets you:</p>
<ul>
<li>Find new blogs (based on recommendations).</li>
<li>Preview a blog and read posts before following it.</li>
<li>Manage your tags and blog subscriptions.</li>
</ul>
<p><a href="http://wpandroid.files.wordpress.com/2014/06/blog-discovery-feature.gif"><img class="aligncenter size-full wp-image-1059" src="http://wpandroid.files.wordpress.com/2014/06/blog-discovery-feature.gif?w=840" alt="blog-discovery-feature" /></a></p>
<h2>Publish Icon Button</h2>
<p>We replaced the publish icon button with a contextual text button. Whether you&#8217;re saving a draft, publishing or scheduling a post, or updating one, this new button will display your action, depending on your current task.</p>

<a href="http://android.wordpress.org/?attachment_id=1063"><img width="90" height="150" src="http://wpandroid.files.wordpress.com/2014/06/screencap-2014-06-04t17-47-230800.png?w=90&h=150" class="attachment-thumbnail" alt="" /></a>
<a href="http://android.wordpress.org/?attachment_id=1060"><img width="90" height="150" src="http://wpandroid.files.wordpress.com/2014/06/screencap-2014-06-04t17-46-510800.png?w=90&h=150" class="attachment-thumbnail" alt="" /></a>
<a href="http://android.wordpress.org/?attachment_id=1061"><img width="90" height="150" src="http://wpandroid.files.wordpress.com/2014/06/screencap-2014-06-04t17-46-570800.png?w=90&h=150" class="attachment-thumbnail" alt="" /></a>
<a href="http://android.wordpress.org/?attachment_id=1062"><img width="90" height="150" src="http://wpandroid.files.wordpress.com/2014/06/screencap-2014-06-04t17-47-060800.png?w=90&h=150" class="attachment-thumbnail" alt="" /></a>
<a href="http://android.wordpress.org/?attachment_id=1064"><img width="90" height="150" src="http://wpandroid.files.wordpress.com/2014/06/screencap-2014-06-04t18-42-390800.png?w=90&h=150" class="attachment-thumbnail" alt="" /></a>

<h2>Faster Notifications and Stats Refresh</h2>
<p>We updated the Notifications feature to use <a href="https://simperium.com/">Simperium</a> technology, which will sync your notifications quickly and efficiently.</p>
<p>We also know you love viewing your Stats, so we improved them to refresh faster than ever before.</p>
<h2>Interface Improvements</h2>
<ul>
<li>Reintroduction of the refresh button in all refreshable views, along with the pull-to-refresh gesture.</li>
<li>Pull-to-refresh tip bar has been replaced by a less aggressive, self-hiding message.</li>
<li>Save dialog has been removed, and all posts are now auto-saved when you close the edit post view.</li>
<li>Reblogging interface redesign in the Reader.</li>
<li>Sharing image, video, text, or link via WordPress for Android now remembers the previous choice.</li>
</ul>
<h2>General Changes</h2>
<ul>
<li>Posts and pages auto-save feature has been improved.</li>
<li>Fixed bugs related to statistics (only affecting Jetpack users) and image handling.</li>
<li>Reader improvements to fill gaps in time between two syncs.</li>
<li>As <a href="http://android.wordpress.org/2014/05/16/wordpress-for-android-no-longer-paying-the-gingerbread-tax/">we announced earlier</a>, we dropped Android 2.3 support. Current (2.9) and later versions need Android 4.0 or later.</li>
<li>New translations: Hebrew and Basque.</li>
<li>SNI (Server Name Indication) support.</li>
<li>Minor bug fixes.</li>
</ul>
<h2>What’s Next?</h2>
<p>A big thanks to all of the contributors who worked on this release: <a href="https://github.com/beaucollins">@beaucollins</a>, <a href="https://github.com/daniloercoli">@daniloercoli</a>, <a href="https://github.com/maxme">@maxme</a>, <a href="https://github.com/nbradbury">@nbradbury</a>, <a href="https://github.com/roundhill">@roundhill</a>, and <a href="https://github.com/sendhil">@sendhil</a>! You can keep up with the development progress at <a href="http://make.wordpress.org/mobile">http://make.wordpress.org/mobile</a> and can also follow the app on Twitter <a href="http://twitter.com/wpandroid">@WPAndroid</a>. If you need support or want to send us suggestions, please visit <a href="http://android.forums.wordpress.org/">our forums</a>.</p><img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=android.wordpress.org&blog=9426921&post=1065&subd=wpandroid&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Jun 2014 08:34:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Maxime";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:124:"WordPress.tv: Fran Moreno: Themes premium desde la perspectiva del creador de contenidos, del diseñador y del desarrollador";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25604";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:139:"http://wordpress.tv/2014/06/06/fran-moreno-themes-premium-desde-la-perspectiva-del-creador-de-contenidos-del-disenador-y-del-desarrollador/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:701:"<div id="v-iRjlQwSY-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25604/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25604/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25604&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/06/fran-moreno-themes-premium-desde-la-perspectiva-del-creador-de-contenidos-del-disenador-y-del-desarrollador/"><img alt="themes.mp4" src="http://videos.videopress.com/iRjlQwSY/video-3bd011e887_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Jun 2014 08:00:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WordPress.tv: Rafael Poveda: Trabajando en Comunidad – WordPress desde dentro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25241";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wordpress.tv/2014/06/06/rafael-poveda-trabajando-en-comunidad-wordpress-desde-dentro/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:713:"<div id="v-U8CvZNdU-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25241/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25241/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25241&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/06/rafael-poveda-trabajando-en-comunidad-wordpress-desde-dentro/"><img alt="Rafael Poveda: Trabajando en Comunidad &#8211; WordPress desde dentro" src="http://videos.videopress.com/U8CvZNdU/video-735f74913e_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Jun 2014 07:00:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: Preview the “Press This” Bookmarklet Redesign, Alpha Plugin Now Ready for Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=24209";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:220:"http://wptavern.com/preview-the-press-this-bookmarklet-redesign-alpha-plugin-now-ready-for-testing?utm_source=rss&utm_medium=rss&utm_campaign=preview-the-press-this-bookmarklet-redesign-alpha-plugin-now-ready-for-testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3821:"<p>The &#8220;<a href="http://codex.wordpress.org/Press_This" target="_blank">Press This</a>&#8221; browser bookmarklet in WordPress is on its way to a <a href="http://make.wordpress.org/ui/2014/06/04/press-this/" target="_blank">complete redesign</a> via the <a href="http://make.wordpress.org/core/features-as-plugins/" target="_blank">features-as-plugins</a> development path. If you&#8217;ve never used it before, the feature allows you to make quick posts to your WordPress site from anywhere on the web. It&#8217;s actually a pretty smart tool for posting and can automatically detect media and grab the proper embed codes.</p>
<p>The redesign project, led by <a href="http://profiles.wordpress.org/michael-arestad" target="_blank">Michael Arestad</a>, is currently in the design stage, but an ultra alpha public release of the <a href="http://wordpress.org/plugins/press-this/" target="_blank">Press This</a> plugin is now available for testing. Here&#8217;s a sneak peak of the redesign progress thus far:</p>
<div id="attachment_24222" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/press-this.png" rel="prettyphoto[24209]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/press-this.png?resize=1025%2C653" alt="Press This redesign progress" class="size-full wp-image-24222" /></a><p class="wp-caption-text">Press This redesign progress</p></div>
<p>Parts of the design are still in flux (placement and behavior of WYSIWYG, modal pop-out, embeds, etc), as the bookmarklet is being completely rebuilt with a focus on automation and speed. Arestad posted a 30-second video demo that walks you through posting with the redesigned bookmarklet:<br />
<div class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<a href="http://wptavern.com/wp-content/uploads/2014/06/press-this-progress.mp4">http://wptavern.com/wp-content/uploads/2014/06/press-this-progress.mp4</a></div><div class="media-shortcode-extend"><div class="media-info video-info"><ul class="media-meta"><li><span class="prep">Run Time</span> <span class="data">0:29</span></li><li><span class="prep">Dimensions</span> <span class="data">1,280 &#215; 800</span></li><li><span class="prep">File Name</span> <span class="data"><a href="http://wptavern.com/wp-content/uploads/2014/06/press-this-progress.mp4">press-this-progress.mp4</a></span></li><li><span class="prep">File Size</span> <span class="data">4.63 MB</span></li><li><span class="prep">File Type</span> <span class="data">MP4</span></li><li><span class="prep">Mime Type</span> <span class="data">video/quicktime</span></li></ul></div><a class="media-info-toggle">Video Info</a></div></p>
<p>This iteration of Press This is currently powered by AJAX, but Arestad reports that it&#8217;s ready to be switched to use the <a href="http://wptavern.com/json-rest-api-slated-for-wordpress-4-1-release" target="_blank">WP-API</a> endpoints as they become available. It&#8217;s also backward compatible with the old bookmarklet but is built to override /wp-admin/press-this.php and the bookmarklet JS code in /wp-admin/tools.php with the new behavior.</p>
<p>The complete overhaul of the bookmarklet, with its speedy 2-step publishing capabilities, is bound to win the feature some new users. The contributors working on it are aiming for &#8220;lightning fast posting&#8221; and the progress so far looks promising.</p>
<p>When testing the <a href="http://wordpress.org/plugins/press-this/" target="_blank">alpha plugin</a>, be advised that it&#8217;s currently undergoing heavy development and will undoubtedly have some bugs. If you want to join in the discussion, feel free to jump in on the <a href="http://corepressthis.wordpress.com" target="_blank">Press This Working Group blog</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Jun 2014 02:35:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: Semicolon is Possibly the Cleanest Free Magazine Theme for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23953";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:200:"http://wptavern.com/semicolon-is-possibly-the-cleanest-free-magazine-theme-for-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=semicolon-is-possibly-the-cleanest-free-magazine-theme-for-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3105:"<p>WordPress magazine themes are notorious for being packed to the gills with content, widgets, post meta, and advertising. Many have a chaotic feel as a byproduct of trying to pack as much content as possible into the homepage.</p>
<p><a href="http://wordpress.org/themes/semicolon" target="_blank">Semicolon</a> is a shining exception among free WordPress magazine themes in that it features a super minimalist design with an emphasis on large, readable typography.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/06/semicolon.png" rel="prettyphoto[23953]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/06/semicolon.png?resize=880%2C660" alt="semicolon" class="aligncenter size-full wp-image-24147" /></a></p>
<p>Semicolon was created by <a href="http://kovshenin.com/" target="_blank">Konstantin Kovshenin</a>, a WordPress plugin and theme developer who is currently a code wrangler at Automattic.  It is based on the <a href="http://underscores.me/" target="_blank">Underscores</a> starter theme. The unique grid layout is 100% responsive and works beautifully on mobile devices.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/semicolon-mobile.png" rel="prettyphoto[23953]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/semicolon-mobile.png?resize=281%2C500" alt="semicolon-mobile" class="alignright size-large wp-image-24193" /></a>You can further personalize the theme by adding your own background image or setting the background color with the WordPress customizer. It also supports two menus: a primary navigation menu and a social menu than utilizes the <a href="http://genericons.com/" target="_blank">Genericons</a> vector icon webfont.</p>
<p>Check out a live demo of Semicolon in action at <a href="http://semicolon.kovshenin.com/" target="_blank">semicolon.kovshenin.com</a>.</p>
<p>Semicolon manages featured posts using Jetpack&#8217;s Featured Content module, so you&#8217;ll need to have that plugin installed in order to take advantage of this feature. You can then assign a unique tag for your featured posts via the customizer.</p>
<p>Single posts are followed by an author bio section that can be updated via Users → Your Profile in the admin. A list of related posts is also shown below the content. It&#8217;s generated by a simple algorithm that fetches recent posts in the same category.</p>
<p>The theme includes four widget areas. Unlike many other WordPress magazine themes, the widget areas are not used to determine the layout for the main content area. The primary, secondary and tertiary widgets are all located in the sidebar. The primary one is highlighted with a blue background and works best for a notice or information you want to feature. The fourth widget area is for the footer, where any widgets added will be stacked horizontally up to a maximum of three.</p>
<p>Want to test Semicolon on your site? <a href="http://wordpress.org/themes/semicolon" target="_blank">Download</a> it for free from WordPress.org or install it directly via the themes browser in the admin.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Jun 2014 20:29:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WordPress.tv: Brad Parbs: Writing Extensible Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35263";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.tv/2014/06/05/brad-parbs-writing-extensible-plugins/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:659:"<div id="v-hrL5ccBA-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35263/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35263/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35263&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/05/brad-parbs-writing-extensible-plugins/"><img alt="Brad Parbs: Writing Extensible Plugins" src="http://videos.videopress.com/hrL5ccBA/video-e797f9a98d_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Jun 2014 18:26:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:102:"WPTavern: WordPress.com to Implement SSL for All Subdomains, Joins the Fight Against Mass Surveillance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=24161";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:246:"http://wptavern.com/wordpress-com-to-implement-ssl-for-all-subdomains-joins-the-fight-against-mass-surveillance?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-com-to-implement-ssl-for-all-subdomains-joins-the-fight-against-mass-surveillance";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2381:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/reset-the-net.png" rel="prettyphoto[24161]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/reset-the-net.png?resize=1025%2C453" alt="reset-the-net" class="aligncenter size-full wp-image-24163" /></a></p>
<p>Today Automattic joins Google, Mozilla, Twitter, Reddit, and other companies across the web in announcing its support for <a href="https://www.resetthenet.org/" target="_blank">Reset the Net</a> campaign against mass surveillance, which takes place on the internet today.</p>
<p>Because the NSA continues to exploit weak links in internet security in order to spy on the world, the only way for companies to fight back is to build better security into their products. The campaign encourages citizens to commit to using apps that protect their devices from prying government eyes.</p>
<p>In an effort that goes far beyond simply displaying a banner, Automattic <a href="http://en.blog.wordpress.com/2014/06/05/reset-the-net/" target="_blank">announced</a> that it will be implementing SSL for all *.wordpress.com subdomains by the end of the year. Paul Sieminski, General Counsel for Automattic, reaffirmed the company&#8217;s commitment to secure the connection between users and WordPress.com websites:</p>
<blockquote><p>If we’ve learned anything over the past year, it’s that encryption, when done correctly, works. If we properly encrypt our sites and devices, we can make mass surveillance much more difficult.</p></blockquote>
<p>As of May this year, 409 million people view more than 14.5 billion pages each month on the WordPress.com network, which includes Jetpack-enabled self-hosted sites. By the end of the year, SSL will be in place for anyone viewing a site hosted on WordPress.com. It&#8217;s important to note that SSL is already forced for WordPress.com admin areas.</p>
<p>If you want to join in this historic push to secure the web, visit<a href="https://www.resetthenet.org/" target="_blank"> Reset the Net</a> to learn about specific ways that you can protect yourself and others to make mass government surveillance more difficult. Self-hosted WordPress sites can join in the campaign with the <a href="http://wordpress.org/plugins/reset-the-net-splash-screen/" target="_blank">Reset the Net splash screen</a> plugin, available for free on WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Jun 2014 17:26:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WordPress.tv: Scott Offord: Creating and Promoting Compelling Content Through Blogging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34789";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:103:"http://wordpress.tv/2014/06/05/scott-offord-creating-and-promoting-compelling-content-through-blogging/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:727:"<div id="v-mWiu88t0-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34789/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34789/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34789&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/05/scott-offord-creating-and-promoting-compelling-content-through-blogging/"><img alt="Scott Offord: Creating And Promoting Compelling Content Through Blogging" src="http://videos.videopress.com/mWiu88t0/video-066f69c912_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Jun 2014 08:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WordPress.tv: Adrian Zumbrunnen: On distraction-free reading experiences";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35490";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"http://wordpress.tv/2014/06/05/adrian-zumbrunnen-on-distraction-free-reading-experiences/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:701:"<div id="v-kthC8PH3-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35490/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35490/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35490&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/05/adrian-zumbrunnen-on-distraction-free-reading-experiences/"><img alt="Adrian Zumbrunnen: On distraction free reading experiences" src="http://videos.videopress.com/kthC8PH3/adrian-zumbrunnen-wcch14_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Jun 2014 07:00:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Matt: iOS 8 Embedded WebKit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43835";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:43:"http://ma.tt/2014/06/ios-8-embedded-webkit/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:606:"<p><a href="http://9to5mac.com/2014/06/03/ios-8-webkit-changes-finally-allow-all-apps-to-have-the-same-performance-as-safari/">iOS 8 WebKit changes finally allow all apps to have the same performance as Safari</a>. I was just asked about the future of the mobile web at last night&#8217;s WP talk in Singapore. (Which had about 300 people there, great turnout!) There are still a lot of issues for the open web in a closed mobile world, but things like this are a great step in the right direction. Another reason I can&#8217;t wait for iOS 8. Hat tip: <a href="http://bummyti.me/">Matt Bumgardner</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Jun 2014 06:01:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WPTavern: WordPress in Vietnamese: Now 100% Translated";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=24119";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:148:"http://wptavern.com/wordpress-in-vietnamese-now-100-translated?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-in-vietnamese-now-100-translated";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3909:"<div id="attachment_24140" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/06/vietnamese-flag.jpg" rel="prettyphoto[24119]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/06/vietnamese-flag.jpg?resize=1024%2C492" alt="photo credit: patrikmloeff - cc" class="size-full wp-image-24140" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/bupia/807902145/">patrikmloeff</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>This month marks a big milestone for WordPress in Vietnamese. It is now 100% translated, thanks in large part to the folks at <a href="http://foobla.com/" target="_blank">foobla</a> who volunteered a great deal of time and effort on the final push to finish translating the software into Vietnamese.</p>
<p>New WordPress translations don&#8217;t magically happen &#8211; they actually take quite a bit of manual work. It requires having a nuanced understanding of both languages in addition to a decent level of WordPress expertise for context. You forget how many words are in WordPress until you see pages and pages of strings in need of translation:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/translate-strings.jpg" rel="prettyphoto[24119]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/translate-strings.jpg?resize=984%2C525" alt="translate-strings" class="aligncenter size-full wp-image-24128" /></a></p>
<p>Back in December 2013, the <a href="http://wpvi.wordpress.com/2013/12/13/current-state-of-vietnamese-translations-for-wordpress-org/" target="_blank">progress of the Vietnamese translation</a> was slow and it was nowhere near finished. Coverage was sparse with /trunk/ strings at 69% complete, WordPress admin strings at 46% and network admin for multisite at just 6%. The three most recent default themes were all 0% translated.</p>
<p>Today&#8217;s <a href="http://wpvi.wordpress.com/2014/06/04/wordpress-now-100-translated-into-vietnamese/" target="_blank">announcement</a> of the fully complete translation is a huge victory for anyone wanting to use WordPress in Vietnamese. <a href="https://twitter.com/philip_arthur" target="_blank">Philip Arthur Moore</a>, who has been heavily involved in this effort, said that contributors will now change their focus to the Vietnamese WordPress.org site:</p>
<blockquote><p>Our next steps are to update <a href="http://vi.wordpress.org/" target="_blank">vi.wordpress.org</a> with the updated language packages, and make sure that when WordPress users in Vietnam to go vi.wordpress.org, they know how to begin using WordPress.</p></blockquote>
<p>Translations are an often overlooked area of WordPress contribution, but are a necessary part of expanding the software&#8217;s use to non-English speaking parts of the world. Internationalization stats on <a href="http://wpcentral.io/internationalization/" target="_blank">WP Central</a> show that only 41 locals are up to date on WordPress package translations and 22 locales are behind by two or more major versions. 60 locales do not yet have a package available.</p>
<p>More completed translations and better support for installing WordPress in any language may be the catalyst to pushing global WordPress usage stats over the 25% mark. Andrew Nacin recently set out an ambitious <a href="http://wptavern.com/major-internationalization-improvements-planned-for-wordpress-4-0" target="_blank">plan to improve internationalization</a> across the board for WordPress core and is aiming at getting these updates into the 4.0 release.</p>
<p>With the planned changes in place, WordPress core will have more elegant ways to get people on track to using the software in their own languages. 2014 is shaping up to be an important year for making WordPress friendlier for its users across the globe.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Jun 2014 21:05:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:104:"WPTavern: WordPress.com VIP Releases Presentation Documents and Resources Under Creative Commons License";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=24081";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:252:"http://wptavern.com/wordpress-com-vip-releases-presentation-documents-and-resources-under-creative-commons-license?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-com-vip-releases-presentation-documents-and-resources-under-creative-commons-license";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4319:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/documattic.jpg" rel="prettyphoto[24081]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/documattic.jpg?resize=992%2C453" alt="documattic" class="aligncenter size-full wp-image-24107" /></a></p>
<p><a href="http://vip.wordpress.com/" target="_blank">WordPress.com VIP</a> announced <a href="https://github.com/Automattic/Documattic" target="_blank">Documattic</a> today, a new GitHub repository to house presentations and resources shared with the community. The VIP team is regularly engaged in the task of educating new clients on the strengths and features of the WordPress platform. Sara Rosso explained in the <a href="http://vip.wordpress.com/2014/06/04/documattic-wordpress-com-vip-presentations-resources-on-github/" target="_blank">announcement</a> why they decided to share the relevant documents:</p>
<blockquote><p>We spend a lot of time explaining the great features of WordPress to client IT, security, and editorial teams, and work with partners and agencies to provide up-to-date information about WordPress software and its vast community of developers, designers, content creators, and site owners.</p></blockquote>
<p>The VIP team plans to share documents that will focus mainly on technical specifications, capabilities, features, and other information with a marketing, project or educational purpose.</p>
<p>Documattic currently contains three high quality resources. One is a recent presentation on <a href="https://github.com/Automattic/Documattic/tree/master/Presentations/Trends_in_Enterprise_WP_Content" target="_blank">Trends in Enterprise WordPress Content</a> by Sara Rosso. It&#8217;s available in both PDF and RevealJS slide formats.</p>
<p><a href="https://github.com/Automattic/Documattic/tree/master/Presentations/Trends_in_Enterprise_WP_Content"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/trends-in-enterprise-content.jpg?resize=1024%2C768" alt="trends-in-enterprise-content" class="aligncenter size-full wp-image-24090" /></a></p>
<p>The repository also includes a document highlighting FAQs regarding <a href="https://github.com/Automattic/Documattic/tree/master/Security" target="_blank">WordPress security</a>. It&#8217;s basically a Q&amp;A style document filled with questions that are commonly fielded by most WordPress development agencies when speaking with clients who are new to the platform.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/wp-security.jpg" rel="prettyphoto[24081]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/wp-security.jpg?resize=632%2C374" alt="wp-security" class="aligncenter size-full wp-image-24095" /></a></p>
<p>The third resource is a <a href="https://github.com/Automattic/Documattic/tree/master/WordPress_for_Government" target="_blank">WordPress in Government FAQ</a>, which answers questions such as:</p>
<ul>
<li>How is WordPress being used in government?</li>
<li>Who uses WordPress in government?</li>
<li>Why would a government agency use WordPress over other CMS / custom-built solutions?</li>
<li>How big is the WordPress developer ecosystem?</li>
</ul>
<p>These documents can be useful to any WordPress agency looking to attract more enterprise clients, as they provide an excellent starting point for articulating the strengths and capabilities of the platform.</p>
<p>The WordPress.com VIP team invites other agencies to contribute to the repository and they plan to continue curating it and building it up to be a collaborative resource open to the community.</p>
<p>Earlier this year Automattic added a <a href="https://github.com/Automattic/legalmattic" target="_blank">Legalmattic</a> repository to share its legal documents under a similar Creative Commons license. The repository contains legal documents used on WordPress.com including its Terms of Service. There&#8217;s no doubt some will find these documents useful, although the <a href="https://github.com/Automattic/Documattic" target="_blank">Documattic</a> repository is likely to have a broader appeal.</p>
<p>Anyone is welcome to reuse and edit these documents as necessary, provided you link back to the original source, as specified in the Creative Commons license applicable to the shared document.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Jun 2014 17:37:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WordPress.tv: José Antonio Maroto Fernández: Tu WordPress 100% legal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32517";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://wordpress.tv/2014/06/04/jose-antonio-maroto-fernandez-tu-wordpress-100-legal/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:694:"<div id="v-lSryyHXj-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32517/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32517/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32517&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/04/jose-antonio-maroto-fernandez-tu-wordpress-100-legal/"><img alt="José Antonio Maroto Fernández: Tu WordPress 100% legal" src="http://videos.videopress.com/lSryyHXj/video-9d0fc4cac3_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Jun 2014 09:15:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Enrique Rodríguez Vallejo: Ya éramos responsables";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32512";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://wordpress.tv/2014/06/04/enrique-rodriguez-vallejo-ya-eramos-responsables/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:684:"<div id="v-2IohVD3o-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32512/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32512/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32512&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/04/enrique-rodriguez-vallejo-ya-eramos-responsables/"><img alt="Enrique Rodríguez Vallejo: Ya éramos responsables" src="http://videos.videopress.com/2IohVD3o/video-eae210ae03_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Jun 2014 08:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:149:"WordPress.tv: Ricardo Prieto Antúnez, David Borrallo Rodríguez, Verónica Valenzuela Jiménez: WordPress y la personalización en el ecommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32507";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:107:"http://wordpress.tv/2014/06/04/jose-esteban-mucientes-manso-wordpress-y-la-personalizacion-en-el-ecommerce/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:794:"<div id="v-vhmWfYwU-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32507/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32507/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32507&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/04/jose-esteban-mucientes-manso-wordpress-y-la-personalizacion-en-el-ecommerce/"><img alt="Ricardo Prieto Antúnez, David Borrallo Rodríguez, Verónica Valenzuela Jiménez: WordPress y la personalización en el ecommerce" src="http://videos.videopress.com/vhmWfYwU/video-eff73e9174_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Jun 2014 07:00:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: New Plugin Batch Deletes WordPress Comment Spam Without Killing Your Server";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=24057";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:214:"http://wptavern.com/new-plugin-batch-deletes-wordpress-comment-spam-without-killing-your-server?utm_source=rss&utm_medium=rss&utm_campaign=new-plugin-batch-deletes-wordpress-comment-spam-without-killing-your-server";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2630:"<p>Once in awhile a WordPress site gets left to the wolves and becomes overrun by spam comments. Perhaps you set up an installation and forgot to install Akismet or some other spam-blocking plugin. If you neglected your site for a significant length of time, it&#8217;s likely that you&#8217;ll return to hundreds, if not thousands, of spam comments.</p>
<p>The problem is that servers tend to crap out on you when you attempt to batch delete that many WordPress comments at once. Pippin Williamson just released a new plugin that helps to tackle this problem.</p>
<p><a href="http://wordpress.org/plugins/batch-comment-spam-deletion/" target="_blank">Batch Comment Spam Deletion</a> works by modifying the the &#8220;Empty Spam&#8221; action in WordPress to process the spam deletion in batches instead of all at once.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/empty-spam.png" rel="prettyphoto[24057]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/empty-spam.png?resize=900%2C446" alt="empty-spam" class="aligncenter size-full wp-image-24071" /></a></p>
<p>With this plugin in place, you&#8217;ll be able to delete hundreds of thousands of spam comments at once without killing your server. The plugin keeps you in the loop with status updates as it processes batches of spam:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/06/processing-spam.png" rel="prettyphoto[24057]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/06/processing-spam.png?resize=1025%2C480" alt="processing-spam" class="aligncenter size-full wp-image-24072" /></a></p>
<p>I tested Batch Comment Spam Deletion and it breezed through deleting nearly 800 spam comments with no issues. Another user reports having deleted 18,500 spam comments on the first run. Although this is a relatively new plugin, you can bet that it&#8217;s rock solid. Its creator, Pippin Williamson, is also the author of the popular <a href="http://wordpress.org/plugins/easy-digital-downloads/" target="_blank">Easy Digital Downloads</a> plugin and <a href="http://profiles.wordpress.org/mordauk/" target="_blank">54 other free plugins</a> hosted on WordPress.org.</p>
<p>If you need to do some serious housekeeping in your comments, install <a href="http://wordpress.org/plugins/batch-comment-spam-deletion/" target="_blank">Batch Comment Spam Deletion</a> before eradicating your spam problem. Your server will thank you. You can set the clean-up process to run and come back later to zero spam comments. This beats spending hours trying to manually process thousands of batches of spam.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Jun 2014 03:56:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WPTavern: Press75 Acquired by Westwerk for Undisclosed Amount";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23994";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:166:"http://wptavern.com/press75-acquired-by-westwerk-for-undisclosed-amount?utm_source=rss&utm_medium=rss&utm_campaign=press75-acquired-by-westwerk-for-undisclosed-amount";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4797:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/press75-feature.png" rel="prettyphoto[23994]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/press75-feature.png?resize=907%2C436" alt="press75-feature" class="aligncenter size-full wp-image-24045" /></a></p>
<p><a href="http://press75.com/" target="_blank">Press75</a>, established by <a href="http://jason.sc/" target="_blank">Jason Schuller</a> in 2008, is one of the longest running successful WordPress theme shops. Schuller carved out his own niche creating video-centric WordPress themes and created a strong, well-respected brand. He gradually became more involved with creating <a href="http://dropplets.com/" target="_blank">Dropplets</a>, an alternative publishing platform, and experimenting with <a href="https://leeflets.com/" target="_blank">Leeflets</a>, and his <a href="https://cinemati.co/" target="_blank">Cinematico</a> project.</p>
<p>In April, Schuller decided to put Press75 up for auction on <a href="https://flippa.com/3056892-pr-6-site-with-13-621-uniques-mo-making-5-268-mo-selling-wordpress-themes" target="_blank">Flippa</a>, where the site pulled in bids as high as $45,000. He announced today that Press75 has been acquired by Westwerk, parent company of <a href="http://werkpress.com/" target="_blank">WerkPress</a>, a WordPress design and development agency.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/revenue-press75.png" rel="prettyphoto[23994]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/revenue-press75.png?resize=260%2C220" alt="revenue-press75" class="alignright size-full wp-image-24035" /></a>Although Westwerk is not at liberty to disclose the final sale price of Press75, the site&#8217;s revenue was public on Flippa. At one time, Press75 brought in more than $30,000 per month but had experienced a sharp decline over the past year.</p>
<p>I spoke with Amy Abt, account executive at WerkPress, who said that their team will be working to bring the site&#8217;s revenue back up from the current $5k/month where it plateaued:</p>
<blockquote><p>The site’s revenue had declined in recent months, as Jason began transitioning his focus to other projects. As of recent, average monthly revenue hovered around $5K. We are looking forward to bringing this up to historical averages and beyond!</p></blockquote>
<p>Abt said that they will not attempt to rebrand Press75 and noted that the site already sports a mint green color palette similar to its new parent company, <a href="http://westwerk.com/" target="_blank">Westwerk</a>.</p>
<h3>What&#8217;s Next for Press75?</h3>
<p>Press75 will continue supporting its current customers. The team, led by WerkPress director Travis Totz, is already busy creating new products.</p>
<p><strong>&#8220;We will be focusing on a couple themes that are in the WordPress.com pipeline, and then shifting gears to updating a few older themes, and releasing new themes (and plugins) as well,&#8221;</strong> Abt said. &#8220;We’re shooting to have an update available by next month.&#8221;</p>
<p>Press75 has a number of old, outdated themes among its collection, but Abt said the team hopes to revive them and create some more modern themes to add. &#8220;There are several that will remain archived,&#8221; she said. &#8220;However, we’d like to update and maintain as many relevant themes as possible, as well as release new themes, including several more responsive options.&#8221;</p>
<p>Current Press75 subscribers will be glad to know that WerkPress has transitioned a couple lead developers to help with the immediate theme updates. In the future, they plan to add a dedicated support team (in addition to implementing community-based forums).</p>
<p>It&#8217;s a bittersweet day in the history of commercial theme shops as Schuller officially makes his exit by handing over the keys to Press75&#8242;s new owners. Press75 came on the scene in the very early days around the same time as StudioPress, WooThemes and iThemes.  In a recent <a href="http://wptavern.com/interview-with-jason-schuller-founder-of-press75-com" target="_blank">interview</a> with the Tavern, Schuller shared with us his growing dissatisfaction with trying to make WordPress do what he wanted and needed.</p>
<p><strong>&#8220;WordPress was a great stepping stone for getting started as an entrepreneur,&#8221; he said. &#8220;But I just know in my gut that in order to move forward I need to go and experiment on my own.&#8221;</strong></p>
<p>Press75 is now in the hands of passionate people who will bring new energy to the site and its products. The folks at WestWerk believe strongly in the WordPress platform and plan to work diligently to make Press75 a successful product channel.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Jun 2014 20:25:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: Kirki: A Free Plugin to Style the WordPress Customizer and Add Advanced Controls";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23987";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:222:"http://wptavern.com/kirki-a-free-plugin-to-style-the-wordpress-customizer-and-add-advanced-controls?utm_source=rss&utm_medium=rss&utm_campaign=kirki-a-free-plugin-to-style-the-wordpress-customizer-and-add-advanced-controls";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3924:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/kirki.png" rel="prettyphoto[23987]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/kirki.png?resize=772%2C250" alt="kirki" class="aligncenter size-full wp-image-23991" /></a></p>
<p>The <a href="http://codex.wordpress.org/Theme_Customization_API" target="_blank">customizer</a> is a powerful tool that allows users to make changes to WordPress themes and preview them live. Because it is native to WordPress, many theme authors are starting to employ the customizer exclusively, instead of creating their own option panels.</p>
<p>Although the customizer is a frontend tool, it slides into view with a generic design that matches the backend of WordPress. Wouldn&#8217;t it be nice if you could style the customizer to be a more natural extension of your theme?</p>
<h3>Kirki Plugin Lets You Theme the WordPress Customizer and Add Advanced Controls</h3>
<p><a href="http://wordpress.org/plugins/kirki/" target="_blank">Kirki</a> is a new free plugin that adds advanced features to the WordPress customizer, including the ability to style it, add your own custom header, and include more advanced custom controls. It&#8217;s essentially a framework for the customizer.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/kirki-customizer.png" rel="prettyphoto[23987]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/kirki-customizer.png?resize=1025%2C627" alt="kirki-customizer" class="aligncenter size-full wp-image-23996" /></a></p>
<p>While many theme option frameworks add a new panel to the admin, Kirki was designed to do one thing: extend the customizer. If you&#8217;re using a theme powered by Kirki, you won&#8217;t even know it&#8217;s there, because it doesn&#8217;t brand itself or add anything additional to the WordPress admin.</p>
<p>Kirki packages more than a dozen different types of <a href="http://kirki.org/#fields" target="_blank">fields</a> that you can add to create advanced controls, such as multi-check checkboxes, sliders using the jQuery Slider UI, buttonsets, layout selection, and more.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/background-properties.png" rel="prettyphoto[23987]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/06/background-properties.png?resize=268%2C338" alt="background-properties" class="alignright size-full wp-image-24007" /></a>There are two ways to incorporate the Kirki framework into your creations: You can use it as a plugin or embed it within a WordPress theme you are building. Theming the customizer is easy with just a few lines of code, and the documentation offers a <a href="https://gist.github.com/aristath/f5bb04a81b3036d54f03#file-example-config-php" target="_blank">sample array</a>.</p>
<p>If you want to check out a demo of a bunch of Kirki-powered controls in action, you can install the <a href="https://github.com/wpmu/shoestrap" target="_blank">Shoestrap</a> theme, which doesn&#8217;t require the plugin. This will give you a feel of how the customizer can be themed and how various controls can be implemented. Full documentation for all of the fields is available on the <a href="http://kirki.org/" target="_blank">kirki.org</a> website.</p>
<p>Kirki was created by WordPress developer <a href="http://aristeides.com/" target="_blank">Aristeides Stathopoulos</a>, author of the <a href="http://shoestrap.org/" target="_blank">Shoestrap</a> theme. He built it to help theme developers reduce the time spent writing custom controls so they can focus on creating beautiful, user-friendly themes.</p>
<p>Kirki is free and open source. It&#8217;s available for <a href="http://wordpress.org/plugins/kirki/" target="_blank">download</a> from the WordPress Plugin Directory and can also be found on <a href="https://github.com/aristath/kirki" target="_blank">GitHub</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Jun 2014 17:54:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WordPress.tv: Javier Casares: Escalando WordPress hasta el infinito";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25602";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://wordpress.tv/2014/06/03/javier-casares-escalando-wordpress-hasta-el-infinito/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:689:"<div id="v-IDW2ZKUA-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25602/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25602/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25602&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/03/javier-casares-escalando-wordpress-hasta-el-infinito/"><img alt="Javier Casares: Escalando WordPress hasta el infinito" src="http://videos.videopress.com/IDW2ZKUA/video-5a6fa75e61_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Jun 2014 09:00:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WordPress.tv: Daniel Frías: Éxitos y fracasos en el desarrollo con WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25607";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://wordpress.tv/2014/06/03/daniel-frias-exitos-y-fracasos-en-el-desarrollo-con-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:709:"<div id="v-62spXAXw-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25607/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25607/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25607&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/03/daniel-frias-exitos-y-fracasos-en-el-desarrollo-con-wordpress/"><img alt="Daniel Frías: Éxitos y fracasos en el desarrollo con WordPress" src="http://videos.videopress.com/62spXAXw/video-644eb41302_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Jun 2014 08:00:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:92:"WordPress.tv: Javier Santos: Hacer de WordPress un CMS más sencillo: consejos y WP Wizard 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25612";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:107:"http://wordpress.tv/2014/06/03/javier-santos-hacer-de-wordpress-un-cms-mas-sencillo-consejos-y-wp-wizard-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:737:"<div id="v-HtlXmkj7-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25612/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25612/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25612&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/03/javier-santos-hacer-de-wordpress-un-cms-mas-sencillo-consejos-y-wp-wizard-2/"><img alt="Javier Santos: Hacer de WordPress un CMS más sencillo: consejos y WP Wizard 2" src="http://videos.videopress.com/HtlXmkj7/video-c622c4081c_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Jun 2014 07:00:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WPTavern: Major Internationalization Improvements Planned for WordPress 4.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23951";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:194:"http://wptavern.com/major-internationalization-improvements-planned-for-wordpress-4-0?utm_source=rss&utm_medium=rss&utm_campaign=major-internationalization-improvements-planned-for-wordpress-4-0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4532:"<div id="attachment_23969" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/globe.jpg" rel="prettyphoto[23951]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/globe.jpg?resize=800%2C368" alt="photo credit: Sarah Elizabeth Altendorf - cc" class="size-full wp-image-23969" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/sarah_elizabeth_simpson/6263928301/">Sarah Elizabeth Altendorf</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc/2.0/">cc</a></p></div>
<p>Many native English speakers take WordPress&#8217; <a href="http://codex.wordpress.org/Installing_WordPress#Famous_5-Minute_Install" target="_blank">famous 5-minute installation</a> process for granted. Have you every wondered how much of a hurdle it might be to try to install the software when English is not your first language?</p>
<p>Andrew Nacin recently published an extensive <a href="http://make.wordpress.org/core/2014/05/21/internationalization-goals-for-4-0/" target="_blank">plan</a> to tackle this problem and a host of others with internationalization improvements for WordPress 4.0. He outlined five major goals for the next release. The first, and perhaps one of the most important, is that you should be able to choose a language before embarking on installation.</p>
<h3>Choosing a Langue Before Installing WordPress</h3>
<p>Given that many applications allow you to select the language before installing, this improvement to WordPress seems like it might be a trivial thing to accomplish. However, Nacin identified some unique technical challenges, depending on how the user is attempting to install WordPress:</p>
<blockquote><p>If the user’s first step is setup-config.php, we don’t actually have WordPress fully loaded at this point, which makes actually installing a language pack more difficult. The install step has WordPress loaded in full, just without database tables. We should look into making setup-config.php load “all” of WordPress to make these environments easier to code.</p></blockquote>
<p>He proposed two solutions, which include downloading the language files as soon as the user selects a language or bundling barebones language files for use on the installation screen. Both create their own set of new problems to solve, especially given that users install WordPress using several different methods.</p>
<p>The next step after accomplishing this goal would be to make it possible for users to choose/switch a language from the general settings screen. This involves fetching the available languages from WordPress.org so that a new pack can be downloaded after it is selected.</p>
<h3>Searching the Admin for Plugins and Themes Available in Your Language</h3>
<p>Another one of the major goals Nacin identified is to allow users to search via the admin for extensions available in their selected language. Of course, this would also include the ability to expand the search to include extensions from any available language. All of this would require having &#8220;localized&#8221; plugin and theme directories on the translated WordPress.org sites.</p>
<p>The ability to search extensions by language will also rely on the final two goals, which are interdependent:</p>
<ul>
<li>All localized packages should be able to be automatically generated and made available immediately as part of the core release process.</li>
<li>Localized packages should only be used for initial downloads from WordPress.org. Instead, language packs should be transparently used for updates.</li>
</ul>
<p>Nacin outlined a list of WordPress.org/API work and core work that will need to be done in order to accomplish these goals. It&#8217;s a major undertaking and will require a group of highly motivated contributors to make this happen for 4.0.</p>
<p>Hopefully these changes will serve to reduce the burden of trying to install and use WordPress in different languages. The software already powers a fairly large chunk of the web (22%), but if its rapid growth is to continue, contributors will need to keep internationalization as a top priority. Andrew Nacin&#8217;s outline is right on track for improving the experience of using WordPress in your own language. If you want to contribute, make sure to read the full outline for more in-depth details on WordPress&#8217; <a href="http://make.wordpress.org/core/2014/05/21/internationalization-goals-for-4-0/" target="_blank">internationalization goals for 4.0</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Jun 2014 02:45:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Matt: Internet With A Human Face";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43831";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://ma.tt/2014/06/internet-with-a-human-face/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:384:"<blockquote><p>&#8220;These big collections of personal data are like radioactive waste. [...] Surveillance limits our ability to be creative with technology. It&#8217;s like a tax we all have to pay on innovation.&#8221;</p></blockquote>
<p>Maciej Ceg&#0322;owski gave a great talk he later wrote out in <a href="http://idlewords.com/bt14.htm">The Internet With A Human Face</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 20:39:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: New Plugin Syncs WordPress Content With a GitHub Repository";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23921";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/new-plugin-syncs-wordpress-content-with-a-github-repository?utm_source=rss&utm_medium=rss&utm_campaign=new-plugin-syncs-wordpress-content-with-a-github-repository";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4498:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/01/wpvsgithub.jpg" rel="prettyphoto[23921]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/01/wpvsgithub.jpg?resize=1025%2C381" alt="WordPress Versus Github" class="aligncenter size-full wp-image-15216" /></a></p>
<p>WordPress is excellent for writing posts privately by yourself and can be extended to allow collaborative writing with other registered authors. But what if you could open up your posts and revisions to even more contributors without requiring them to register to your site or even use WordPress?</p>
<p><a href="https://github.com/benbalter/wordpress-github-sync" target="_blank">WordPress <--> GitHub Sync</a> is a new plugin that enables collaborative writing. It was created by <a href="https://twitter.com/BenBalter" target="_blank">Ben Balter</a>, who has fully embraced this practice and hosts his <a href="http://ben.balter.com/" target="_blank">blog</a> on GitHub pages where you can view all of his drafts and revisions. Balter is also the creator of the first working prototype of what later became version 0.1 of the <a href="http://wptavern.com/introducing-wordpress-post-forking-version-control-for-writers" target="_blank">Post Forking</a> plugin, which offers version control for writers working in WordPress.</p>
<h3>Collaborative Writing with WordPress and GitHub</h3>
<p><a href="https://github.com/benbalter/wordpress-github-sync" target="_blank">WordPress <--> GitHub Sync</a> makes it possible for you to accept pull requests to your WordPress posts. Additionally, if you are blogging with <a href="http://jekyllrb.com/" target="_blank">Jekyll</a>, the plugin enables you to author your Jekyll site with WordPress&#8217; user-friendly web interface.</p>
<p>Balter outlines the three major benefits of WordPress <--> GitHub Sync:</p>
<ul>
<li>Allows content publishers to version their content in GitHub, exposing &#8220;who made what change when&#8221; to readers</li>
<li>Allows readers to submit proposed improvements to WordPress-served content via GitHub&#8217;s Pull Request model</li>
<li>Allows non-technical writers to draft and edit a Jekyll site in WordPress&#8217;s best-of-breed editing interface</li>
</ul>
<p>Whenever WordPress&#8217; save_post hook is called, the plugin will fire a sync in response and will push the content to GitHub. In turn, GitHub&#8217;s push webhook will trigger a sync of all changed files back to WordPress.</p>
<p>When you install the plugin, you&#8217;ll need to enter your GitHub hostname and specify a repository to commit to. You&#8217;ll also need to enter your Oauth Token and Webhook Secret.  At the bottom of the settings page, you&#8217;ll find bulk actions for exporting to GitHub and importing from GitHub, so it doesn&#8217;t necessarily have to be started on a brand new blog.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/wp-github-sync-settings.jpg" rel="prettyphoto[23921]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/wp-github-sync-settings.jpg?resize=867%2C657" alt="wp-github-sync-settings" class="aligncenter size-full wp-image-23927" /></a></p>
<p>In the future, Balter says the plugin may allow you to do even more, such as sync the content of two different WordPress installations via GitHub. It could also be adapted to allow you to stage and preview content before &#8220;deploying&#8221; to your production server.</p>
<p>For many writers the <a href="https://konklone.com/post/writing-in-public-syncing-with-github" target="_blank">idea of writing</a> in public may seem a bit daunting, but the practice and benefits are very much akin to writing open source code. Public revisions and incorporation of improvements bring a new transparency to the writer&#8217;s process and transforms the work into a shared community document. Publications that embrace collaborative writing have the potential to bring a whole new level of community participation to online journalism.</p>
<p>If you&#8217;re interested in experimenting with collaborative writing, Balter&#8217;s <a href="https://github.com/benbalter/wordpress-github-sync" target="_blank">WordPress <--> GitHub Sync</a> is a good starting point. Be advised that it&#8217;s still a work in progress. If you&#8217;d like to help make it better, please refer to the <a href="https://github.com/benbalter/wordpress-github-sync/blob/master/CONTRIBUTING.md" target="_blank">contributing documentation</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 17:52:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WordPress.tv: Benjamin Caubère: Crear un plugin con el modelo Freemium en WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32798";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"http://wordpress.tv/2014/06/02/benjamin-caubere-crear-un-plugin-con-el-modelo-freemium-en-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:723:"<div id="v-oVd0Ul78-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32798/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32798/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32798&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/02/benjamin-caubere-crear-un-plugin-con-el-modelo-freemium-en-wordpress/"><img alt="Benjamin Caubère: Crear un plugin con el modelo Freemium en WordPress" src="http://videos.videopress.com/oVd0Ul78/video-8036b88a1d_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 09:00:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WPTavern: 10 New Free WordPress Themes From May 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23866";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:148:"http://wptavern.com/10-new-free-wordpress-themes-from-may-2014?utm_source=rss&utm_medium=rss&utm_campaign=10-new-free-wordpress-themes-from-may-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8191:"<p>May was an excellent month for free WordPress themes landing in the official Themes Directory. Several dozen were approved and added to the directory last week in one sweep. We&#8217;ve hand-picked some of the best themes released in the month of May, all of which have undergone the rigorous review process conducted by the Theme Review Team. Grab a coffee or tea and start bookmarking your favorites.</p>
<h3>Themify Base</h3>
<p><a href="http://wordpress.org/themes/themify-base"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/themify.png?resize=1025%2C769" alt="themify" class="aligncenter size-full wp-image-23868" /></a></p>
<p>Themify Base is a minimalist style blog theme from the folks at <a href="http://themify.me/" target="_blank">Themify</a>. It&#8217;s translation ready, includes one custom menu, a sidebar, and three footer widget areas. The theme options contain six different skins and multiple layouts for the index, archives, pages, and posts.</p>
<p><strong><a href="http://themify.me/demo/themes/base/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/themify-base" target="_blank">Download</a></strong></p>
<h3>Tracks</h3>
<p><a href="http://wordpress.org/themes/tracks"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks.jpg?resize=1000%2C600" alt="tracks" class="aligncenter size-full wp-image-23832" /></a></p>
<p>Tracks is a bold, beautiful theme designed for use on personal blogs. Making your site look just like the demo takes no time, as it features just a handful of options in the WordPress customizer. The theme looks its best with large, panoramic featured images in place for each post. It also includes a customized author section that will display social links and a bio for each author at the bottom of posts.</p>
<p><strong><a href="http://www.competethemes.com/tracks-live-demo" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/tracks" target="_blank">Download</a></strong></p>
<h3>Link</h3>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/link.png" rel="prettyphoto[23866]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/link.png?resize=880%2C660" alt="link" class="aligncenter size-full wp-image-23874" /></a></p>
<p>Link based on Bootstrap and is an adaptation of the &#8220;Link&#8221; theme by Blacktie.co. It features big full-width images and full-width colored sections. The theme is actually a child theme of the <a href="http://wordpress.org/themes/flat-bootstrap" target="_blank">Flat Bootstrap</a> theme created by Tim Nicholson. Link includes support for customer header images, multiple widget areas, and Font Awesome icons.</p>
<p><strong><a href="http://wordpress.org/themes/link" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/link" target="_blank">Download</a></strong></p>
<h3>tdPersona</h3>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/tdpersona.png" rel="prettyphoto[23866]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/tdpersona.png?resize=880%2C660" alt="tdpersona" class="aligncenter size-full wp-image-23875" /></a></p>
<p>tdPersona is a beautiful theme with a clean, simple design. This minimal style theme has support for all of the standard post formats and includes a unique header menu for navigating them. A hidden sidebar widget area slides out when activated by an unobtrusive icon in the top menu.</p>
<p><strong><a href="http://demo.tdwp.us/tdpersona/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/tdpersona" target="_blank">Download</a></strong></p>
<h3>Forceful Lite</h3>
<p><a href="http://wordpress.org/themes/forceful-lite"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/forceful-lite.png?resize=600%2C450" alt="forceful-lite" class="aligncenter size-full wp-image-23876" /></a></p>
<p>Forceful Lite is a free theme suited to magazines, blogs and news sites. It includes multiple widget areas as well as the ability to create your own unique sidebars and assign them to individual posts/pages. The theme is packaged with 14 custom widgets for customizing the display of recent content, advertising, social links, and more.</p>
<p><strong><a href="http://kopatheme.com/demo/forceful-magazine-wordpress-theme-light-version/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/forceful-lite" target="_blank">Download</a></strong></p>
<h3>Carrot Lite</h3>
<p><a href="http://wordpress.org/themes/carrot-lite"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/carrot-lite.png?resize=880%2C660" alt="carrot-lite" class="aligncenter size-full wp-image-23877" /></a></p>
<p>The Carrot Lite homepage sports a magazine-style design with a large welcome message that can be easily edited in the customizer. The theme includes footer and sidebar widget areas and support for Font Awesome icons.</p>
<p><strong><a href="http://wordpress.org/themes/carrot-lite" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/carrot-lite" target="_blank">Download</a></strong></p>
<h3>Fictive</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/fictive.png" rel="prettyphoto[23866]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/fictive.png?resize=880%2C660" alt="fictive" class="aligncenter size-full wp-image-23878" /></a></p>
<p>Fictive is a beautiful free theme from Automattic, designed for bloggers. It can be customized with your own header, Gravatar and social links in the sidebar, which can be set to fixed or scroll. Fictive features post formats with different colors and icons for each.</p>
<p><strong><a href="http://fictivedemo.wordpress.com/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/fictive" target="_blank">Download</a></strong></p>
<h3>Make</h3>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/make.png" rel="prettyphoto[23866]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/make.png?resize=880%2C660" alt="make" class="aligncenter size-full wp-image-23250" /></a></p>
<p>Make is Theme Foundry&#8217;s first free WordPress theme. It includes a unique drag and drop page builder that makes it easy for anyone to customize the layout. The design can be further customized with your own background, fonts, colors, and logo. Make can be used as a base for nearly any kind of website, including portfolios, blogs, businesses, e-commerce, or magazine sites.</p>
<p><strong><a href="https://thethemefoundry.com/wordpress-themes/make/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/make" target="_blank">Download</a></strong></p>
<h3>Pictorico</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/pictorico.png" rel="prettyphoto[23866]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/pictorico.png?resize=880%2C660" alt="pictorico" class="aligncenter size-full wp-image-22830" /></a></p>
<p>Pictorico is a single-column, grid-based portfolio theme created by the folks at Automattic. It&#8217;s well-suited to photoblogging or portfolio sites that feature large images. The theme can be customized with your own background and header. Pictorico also includes a post slider and support for post formats and sticky posts.</p>
<p><strong><a href="http://pictoricodemo.wordpress.com/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/pictorico" target="_blank">Download</a></strong></p>
<h3>Quality</h3>
<p><a href="http://wordpress.org/themes/quality "><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/quality.png?resize=880%2C660" alt="quality" class="aligncenter size-full wp-image-23870" /></a></p>
<p>Quality is a business theme with a custom blog and homepage template. The options include the ability to upload your own logo and header image. Quality supports Font Awesome icons which are featured in the homepage services section and can be easily edited in the theme&#8217;s options.</p>
<p><strong><a href="http://wordpress.org/themes/quality" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/quality" target="_blank">Download</a></strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 08:11:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:101:"WordPress.tv: Mercedes Romero: AlbertoContador.org – WordPress multisitio, multiidioma y red social";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32795";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:113:"http://wordpress.tv/2014/06/02/mercedes-romero-albertocontador-org-wordpress-multisitio-multiidioma-y-red-social/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:752:"<div id="v-07Liu1Wd-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32795/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32795/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32795&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/02/mercedes-romero-albertocontador-org-wordpress-multisitio-multiidioma-y-red-social/"><img alt="Mercedes Romero: AlbertoContador.org – WordPress multisitio, multiidioma y red social" src="http://videos.videopress.com/07Liu1Wd/video-91f834ca2a_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 08:00:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:111:"WordPress.tv: Rafael Poveda: 30 cosas que no sabías que se podían hacer con un WordPress recién instalado";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:122:"http://wordpress.tv/2014/06/02/rafael-poveda-30-cosas-que-no-sabias-que-se-podian-hacer-con-un-wordpress-recien-instalado/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:771:"<div id="v-Y3vXBBC9-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32500/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32500/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32500&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/02/rafael-poveda-30-cosas-que-no-sabias-que-se-podian-hacer-con-un-wordpress-recien-instalado/"><img alt="Rafael Poveda: 30 cosas que no sabías que se podían hacer con un WordPress recién instalado" src="http://videos.videopress.com/Y3vXBBC9/video-f935c26916_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 07:00:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WordPress.tv: Syed Balkhi: KidsCamp Atlanta – Fundamental Decisions regarding your WordPress setup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35275";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:113:"http://wordpress.tv/2014/06/02/syed-balkhi-kidscamp-atlanta-fundamental-decisions-regarding-your-wordpress-setup/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:755:"<div id="v-Zw4VDHcJ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35275/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35275/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35275&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/02/syed-balkhi-kidscamp-atlanta-fundamental-decisions-regarding-your-wordpress-setup/"><img alt="Syed Balkhi: KidsCamp Atlanta &#8211; Fundamental Decisions regarding your WordPress setup" src="http://videos.videopress.com/Zw4VDHcJ/video-9637bcec11_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 07:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: Laundry-App Race";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43829";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2014/06/laundry-app-race/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:188:"<p>Jessica Pressler in New York Magazine has an unintentionally funny look at <a href="http://nymag.com/news/features/laundry-apps-2014-5/">Silicon Valley&#8217;s Laundry-App Race</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 20:22:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WordPress.tv: Cliff Seal: Get Started in Professional WordPress Design and Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35255";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:103:"http://wordpress.tv/2014/06/01/cliff-seal-get-started-in-professional-wordpress-design-and-development/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:721:"<div id="v-Gb3K8ynt-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35255/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35255/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35255&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/01/cliff-seal-get-started-in-professional-wordpress-design-and-development/"><img alt="Cliff Seal: Get Started in Professional WordPress Design and Development" src="http://videos.videopress.com/Gb3K8ynt/video-d7ccd33426_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 18:37:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress.tv: Bryan Petty: Finding the Perfect Themes and Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35243";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2014/06/01/bryan-petty-finding-the-perfect-themes-and-plugins/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:679:"<div id="v-233NQZiw-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35243/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35243/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35243&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/01/bryan-petty-finding-the-perfect-themes-and-plugins/"><img alt="Bryan Petty: Finding the Perfect Themes and Plugins" src="http://videos.videopress.com/233NQZiw/video-67347b08b9_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 18:34:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WordPress.tv: David Laietta: Web Development Trends For 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35241";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.tv/2014/06/01/david-laietta-web-development-trends-for-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:669:"<div id="v-F5Ynj9Ql-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35241/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35241/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35241&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/01/david-laietta-web-development-trends-for-2014/"><img alt="David Laietta: Web Development Trends For 2014" src="http://videos.videopress.com/F5Ynj9Ql/video-ccdb65be9b_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 18:31:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Akismet: May Stats Roundup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1505";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://blog.akismet.com/2014/06/01/may-stats-roundup/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4480:"<p>Welcome to the second post in a series of monthly articles summarizing some stats and figures from the Akismet universe. You can find April&#8217;s post <a href="http://blog.akismet.com/2014/05/01/april-stats-roundup/">here</a>.</p>
<div id="attachment_1507" class="wp-caption alignright"><a href="http://akismet.files.wordpress.com/2014/06/8116030061_cd2098f723_o.jpg"><img class="wp-image-1507 size-medium" src="http://akismet.files.wordpress.com/2014/06/8116030061_cd2098f723_o.jpg?w=300&h=200" alt="Atos Olympic Games male swimmers diving two London 2012 by Atos on Flickr" width="300" height="200" /></a><p class="wp-caption-text">This image is a derivative of &#8216;<a href="https://www.flickr.com/photos/atosorigin/8116030061/">Atos Olympic Games male swimmers diving two London 2012</a>&#8216; by Atos. Used under <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC BY-SA</a></p></div>
<p>In May, Akismet caught a total of <strong>6,562,229,410</strong> pieces of spam &#8211; including comments, forum posts, contact form submissions, etc. To visualize this number, <strong>picture each piece of spam as a sugar cube</strong> &#8211; that&#8217;d be enough sugar cubes to fill about 6 and a fifth Olympic swimming pools.</p>
<p>The amount of spam we caught in May is up 4% from last month, and up 269% from May 2012. Here&#8217;s a breakdown of the spam and ham we detected each day:</p>
<p><a href="https://akismet.files.wordpress.com/2014/06/akismet-ham-stats-may-20141.png"><img src="http://akismet.files.wordpress.com/2014/06/akismet-ham-stats-may-20141.png?w=640&h=400" alt="Akismet Spam and Ham Stats, May 2014" width="640" height="400" class="alignnone size-large wp-image-1529" /></a></p>
<p>There weren&#8217;t any big dips or highs during the month of May. The busiest day of the month was May 8, with just over <strong>230 million</strong> spam messages detected. The slowest day was May 25, with &#8216;only&#8217; about 178 million pieces of spam caught. You may have seen similar ups and downs in the spam activity on your own site.</p>
<p>We had no service interruptions this month, so any fluctuations in spam numbers we attribute to the natural way spam is posted. If you want to hear about any service interruptions you can subscribe to this blog, or follow <a href="https://twitter.com/akismet">us on Twitter</a>.</p>
<p>As usual, there&#8217;s much more spam going around than real comments (which we call ham). You can see this by looking at the purple bars in the graph.</p>
<p>Akismet detected a total of 294,312,590 real messages in May. If each real comment were a sugar cube, they&#8217;d only enough be enough to fill about 10% of one Olympic swimming pool.</p>
<p>In May, we missed only about 1 in every 7,404 spam messages. If you&#8217;ve seeing lots of missed spam comments on your own site, we are happy to help with that, so feel free to <a href="http://akismet.com/contact/">contact us</a> about it, and please include your website &amp; your API key in your message.</p>
<p>
<strong>Some reads from the month that we recommend:</strong><br />
This month, we rather enjoyed reading <a href="http://www.theatlantic.com/technology/archive/2014/05/spam-always-finds-a-way/371194/">this piece</a> by Adrienne LaFrance about the history of spam (going back to snail mail!), and how it affects us nowadays. We also liked Seth Godin&#8217;s <a href="http://sethgodin.typepad.com/seths_blog/2014/04/what-is-spam.html">sage advice</a> (as always) on how not to spam people as a business, but still get business. In fact, in July <a href="http://blogs.windsorstar.com/2014/05/26/new-anti-spam-regulations-feature-tight-restrictions-hefty-fines/">Canada&#8217;s Anti-Spam legislation will come into effect</a> (<a href="http://www.techvibes.com/blog/a-guide-to-canadas-anti-spam-law-2014-05-20">similar to CAN-SPAM</a>), making the suggestions Seth Godin recommends, and even stricter rules around emailing, into law, which should make Canadians much happier with their inboxes <span class="wp-smiley emoji emoji-smile" title=":)">:)</span>. We like where this is going!</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1505/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1505/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1505&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 06:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Valerie";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: WordPress Plugin All In One SEO Releases Important Security Update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23880";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:196:"http://wptavern.com/wordpress-plugin-all-in-one-seo-releases-important-security-update?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-plugin-all-in-one-seo-releases-important-security-update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2024:"<p>The popular <a title="http://wordpress.org/plugins/all-in-one-seo-pack/" href="http://wordpress.org/plugins/all-in-one-seo-pack/">All In One SEO Plugin</a> for WordPress has <a title="http://semperfiwebdesign.com/blog/all-in-one-seo-pack/all-in-one-seo-pack-release-history/" href="http://semperfiwebdesign.com/blog/all-in-one-seo-pack/all-in-one-seo-pack-release-history/">released an update</a> addressing two security issues <a title="http://blog.sucuri.net/2014/05/vulnerability-found-in-the-all-in-one-seo-pack-wordpress-plugin.html" href="http://blog.sucuri.net/2014/05/vulnerability-found-in-the-all-in-one-seo-pack-wordpress-plugin.html">discovered by Sucuri </a>during a security audit. According to Sucuri, one of the vulnerabilities can be used to escalate privileges while the other deals with Cross Site Scripting attacks.</p>
<div id="attachment_23882" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/AllInOneSEOFeaturedImage.png" rel="prettyphoto[23880]"><img class="size-full wp-image-23882" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/AllInOneSEOFeaturedImage.png?resize=730%2C269" alt="All In One SEO Plugin Header Image" /></a><p class="wp-caption-text">All In One SEO Plugin Header Image</p></div>
<p>A logged-in user who doesn&#8217;t have administrative capabilities is able to modify certain parameters of the plugin such as the <strong>post&#8217;s SEO title, description, and meta tags</strong>. These changes could cause long-term negative effects to search engine rankings.</p>
<p>Unfortunately, this bug can also be used to execute malicious code on an administrator&#8217;s control panel. Sucuri says &#8220;this means that an attacker could potentially inject any JavaScript code and do things like change the admin’s account password to leaving some backdoor in your website’s files in order to conduct even more “evil” activities later.&#8221;</p>
<p>Sucuri recommends upgrading the plugin as soon as possible.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 02:34:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WordPress.tv: Ignacio de Miguel: La unión hace la fuerza: PHP, WordPress y creatividad";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25348";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://wordpress.tv/2014/05/31/ignacio-de-miguel-la-union-hace-la-fuerza-php-wordpress-y-creatividad/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:720:"<div id="v-ahcdnnUU-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25348/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25348/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25348&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/31/ignacio-de-miguel-la-union-hace-la-fuerza-php-wordpress-y-creatividad/"><img alt="Ignacio de Miguel: La unión hace la fuerza: PHP, WordPress y creatividad" src="http://videos.videopress.com/ahcdnnUU/video-86eea2dfe6_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 31 May 2014 09:00:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress.tv: Andy García: WordPress vs Drupal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25195";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.tv/2014/05/31/andy-garcia-wordpress-vs-drupal/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:648:"<div id="v-tNhCssxb-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25195/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25195/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25195&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/31/andy-garcia-wordpress-vs-drupal/"><img alt="Andy García: WordPress vs Drupal" src="http://videos.videopress.com/tNhCssxb/video-1efcaf2516_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 31 May 2014 08:00:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WordPress.tv: Jorge Coronado: Hardening en WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25250";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.tv/2014/05/31/jorge-coronado-hardening-en-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:659:"<div id="v-79g7dalR-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25250/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25250/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25250&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/31/jorge-coronado-hardening-en-wordpress/"><img alt="Jorge Coronado: Hardening en WordPress" src="http://videos.videopress.com/79g7dalR/video-1b851666f8_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 31 May 2014 07:00:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: WPWeekly Episode 150 – Interview With Ryan Vaughn, CEO Of Varsity News Network";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=23857&preview_id=23857";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:214:"http://wptavern.com/wpweekly-episode-150-interview-with-ryan-vaughn-ceo-of-varsity-news-network?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-150-interview-with-ryan-vaughn-ceo-of-varsity-news-network";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2683:"<p>We started the show off with Andrew Nacin where he clarified a number of points dealing with the <a href="http://arstechnica.com/security/2014/05/unsafe-cookies-leave-wordpress-accounts-open-to-hijacking-2-factor-bypass/" title="http://arstechnica.com/security/2014/05/unsafe-cookies-leave-wordpress-accounts-open-to-hijacking-2-factor-bypass/">WordPress.com Cookie problem</a>. He also published a <a href="http://nacin.com/2014/05/30/security-is-nuanced/" title="http://nacin.com/2014/05/30/security-is-nuanced/">great post</a> explaining why security is nuanced.</p>
<p>The second part of the show featured an interview with <a href="http://varsitynewsnetwork.com/home" title="http://varsitynewsnetwork.com/home">Varsity News Network</a> CEO, Ryan Vaughn, to discuss how the company is utilizing WordPress to become the ESPN of high school sports. Using a custom designed theme, VNN provides more than 350 high schools across the country a website to publish informational events, schedules, and scores.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/wordpress-com-security-vulnerability-stirs-debate-over-responsible-disclosure" title="http://wptavern.com/wordpress-com-security-vulnerability-stirs-debate-over-responsible-disclosure">WordPress.com Security Vulnerability Stirs Debate Over Responsible Disclosure</a><br />
<a href="http://wptavern.com/json-rest-api-slated-for-wordpress-4-1-release" title="http://wptavern.com/json-rest-api-slated-for-wordpress-4-1-release">JSON REST API Slated For WordPress 4.1 Release</a><br />
<a href="http://wptavern.com/alex-shiels-proposal-for-improving-the-wordpress-plugin-management-page" title="http://wptavern.com/alex-shiels-proposal-for-improving-the-wordpress-plugin-management-page">Alex Shiels Proposal For Improving The WordPress Plugin Management Page</a><br />
<a href="http://wptavern.com/wordpress-celebrates-its-11th-birthday" title="http://wptavern.com/wordpress-celebrates-its-11th-birthday">WordPress Celebrates Its 11th Birthday</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, June 13th 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #150:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 31 May 2014 03:01:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: Tracks: A Free Bold WordPress Theme for Personal Blogs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23829";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:170:"http://wptavern.com/tracks-a-free-bold-wordpress-theme-for-personal-blogs?utm_source=rss&utm_medium=rss&utm_campaign=tracks-a-free-bold-wordpress-theme-for-personal-blogs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3227:"<p><a href="http://wordpress.org/themes/tracks" target="_blank">Tracks</a> is a new free theme in the WordPress Themes Directory with a unique design that utilizes panoramic featured images. The homepage displays recent posts and a short excerpt for each, with big, bold images alternating down the page.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks.jpg" rel="prettyphoto[23829]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks.jpg?resize=1000%2C600" alt="tracks" class="aligncenter size-full wp-image-23832" /></a></p>
<p>If you&#8217;re looking for a simple theme with very few options to configure, then Tracks is a good pick. It has just a handful of customization options built into the WordPress customizer, which means it will take less than a minute to make your site look like the demo.</p>
<p>You can upload a logo image, set the navigation menu, add site title and tagline, and elect to use a static front page. Apart from those options, the design is set for you.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks-customizer.jpg" rel="prettyphoto[23829]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks-customizer.jpg?resize=1025%2C587" alt="tracks-customizer" class="aligncenter size-full wp-image-23841" /></a></p>
<p>The only caveat with using this theme is that you&#8217;ll need to make sure you upload a large featured image for each post in order to keep the homepage looking colorful. The single posts page also uses that image for a panoramic display at the top of the content.</p>
<p>The author bio section allows each author on the site to display links to social profiles after each post. This is configured in the &#8220;Edit Profile&#8221; page in the admin.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/author-profile.jpg" rel="prettyphoto[23829]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/author-profile.jpg?resize=730%2C175" alt="author-profile" class="aligncenter size-full wp-image-23850" /></a></p>
<p>Tracks is 100% responsive. If you resize the <a href="http://www.competethemes.com/tracks-live-demo" target="_blank">live demo</a> page, you&#8217;ll see that the content responds nicely to various screen sizes. It was designed to work well on well on desktops, tablets and phones. It uses fitvids.js to make sure that videos in your posts are also responsive to devices.</p>
<p>The theme does not include any widget areas. As you can tell from the short list of options, Tracks is a design-specific theme focused on blog content and images. What you cannot see from the demo is that the theme is SEO-friendly with semantic link anchors and optimized title tags. It also incorporates ARIA-roles and follows basic accessibility guidelines.</p>
<p>Tracks was created by <a href="http://profiles.wordpress.org/BenSibley/" target="_blank">Ben Sibley</a> and is available for free from WordPress.org. <a href="http://www.competethemes.com/documentation/tracks-knowledgebase/" target="_blank">Documentation</a> can be found on the author&#8217;s website and includes instructions for customizing the theme with a child theme.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 23:13:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:103:"WPTavern: Feuilles App Aims to Replace Editorially, Offers Publishing to Github, WordPress, and Dropbox";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23791";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:244:"http://wptavern.com/feuilles-app-aims-to-replace-editorially-offers-publishing-to-github-wordpress-and-dropbox?utm_source=rss&utm_medium=rss&utm_campaign=feuilles-app-aims-to-replace-editorially-offers-publishing-to-github-wordpress-and-dropbox";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5076:"<p>Editorially closed its doors for good today, and with it goes all of the writing collaboration tools its users came to love. Unfortunately, some <a href="https://twitter.com/aworkinglibrary/status/465949423944884226" target="_blank">legal issues</a> are currently preventing them from open sourcing the code for the application, but it&#8217;s under consideration.</p>
<p>In the meantime, a newcomer has stepped in to provide some of the features that users loved best about Editorially. <a href="https://feuill.es/" target="_blank">Feuilles</a>, which means &#8220;paper sheets&#8221; in French, is a new app for helping people write together. It provides a markdown editor and a platform for discussing your texts with other people. If you have an Editorially export, you can import all of your documents into Feuilles and carry on writing.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/Feuilles.jpg" rel="prettyphoto[23791]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/Feuilles.jpg?resize=962%2C509" alt="Feuilles" class="aligncenter size-full wp-image-23799" /></a></p>
<p>Feuilles allows you to publish to Github, WordPress.com, and Dropbox, although the connections are still in the early/buggy stages, since the app is currently open to those interested in beta testing. It also works with Jetpack-enabled self-hosted WordPress sites.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/publish-Feuilles.jpg" rel="prettyphoto[23791]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/publish-Feuilles.jpg?resize=727%2C377" alt="publish-Feuilles" class="aligncenter size-full wp-image-23800" /></a></p>
<p><a href="https://twitter.com/alexduloz" target="_blank">Alex Duloz</a> and his partner <a href="https://twitter.com/_KatyWatkins" target="_blank">Katy Watkins</a> used Editorially extensively in their work with <a href="https://the-pastry-box-project.net/" target="_blank">The Pastry Box Project</a> while discussing texts and polishing their publishing skills. When Editorially announced that it was disappearing, they decided to create their own app but with a new twist: an emphasis on empowering people with a versatile API. Duloz explained the app&#8217;s purpose:</p>
<blockquote><p>Feuilles is not Editorially. It&#8217;s a new project that sits on the shoulders of giants. My fanboy-ism took the latter form, the one of a homage. If you were used to working in Editorially, the previous sentence will immediately make sense when you start using Feuilles. There is a certain “feeling” that characterized Editorially which has been preserved in Feuilles (the way conversations work, how the dashboard allows you to interact with documents), but you will find that using our website to write is in fact not the real purpose of our website.</p></blockquote>
<p>The power of Feuilles is in its <a href="https://feuill.es/documentation/api" target="_blank">API</a>; Duloz built the app for you to use with your own website. &#8220;Feuilles is here to provide publishers with <a href="https://feuill.es/documentation/api" target="_blank">a versatile API</a> (the same that we actually consume to operate) that they can use in their projects,&#8221; he said. <strong>&#8220;In fact, Feuilles is here so that you can launch collaborative blogs without even having to visit Feuilles. Our platform should just a be a means. Not an end.&#8221;</strong></p>
<p>The API allows you to work through HTTP requests, so there&#8217;s no need to use the Feuilles app in order to work. They&#8217;ve opened a few of their endpoints for developers to experiment with to use Feuilles from remote HTTP locations. The &#8220;<a href="https://feuill.es/documentation/in-house-publishing" target="_blank">In-House Publishing</a>&#8221; feature makes it possible for you to post data from Feuilles to your own website by <a href="https://feuill.es/console/applications" target="_blank">registering an application</a>. Requests received to your website are POST requests and right now there isn&#8217;t a WordPress plugin to automate the In-House Publishing feature, so you&#8217;d have to dive into the technical details if you want to try it out.</p>
<p>Duloz is aiming to make Feuilles a language/device agnostic CMS with In-House Publishing. As WordPress currently powers 22% of the web, it will be interesting to see how this app evolves to support people with self-hosted WordPress sites.</p>
<p>Those who participate in collaborative writing are a rather small segment of overall WordPress users. However, if the popularity of Editorially is any indication, Feuilles may have the chance to become the web&#8217;s go-to application for writing collaboratively. Since its creators intend for it to be a means, not an end, its likely to enjoy a different trajectory than Editorially. Coming out of the gate with a strong focus on its API is a shrewd move that will enable the <a href="https://feuill.es/" target="_blank">Feuilles</a> app to be used in a multitude of different ways.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 19:10:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Andrew Nacin: Security is nuanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:24:"http://nacin.com/?p=4235";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://nacin.com/2014/05/30/security-is-nuanced/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8171:"<p>As a software vendor, there are many reasons to prefer responsible disclosure of security issues. But the most important reason is also less obvious: vulnerability reports need to be <em>correct</em>.</p>
<p>I&#8217;ve seen countless &#8220;full disclosure&#8221; reports that are wrong and invalid. Most of these could have been prevented by privately disclosing it to the vendor and allowing them the opportunity to respond.</p>
<p>Everyone sees WordPress in the headlines, over and over again, but no one ever notices the &#8220;this report is invalid&#8221; response. We&#8217;ve prevented countless invalid reports from being published simply because they were disclosed to us first. This is better for the software&#8217;s users, who are otherwise left to scramble every time they see a report. They are not an expert, and often, neither is the reporter.</p>
<p>There&#8217;s another angle here, though: sometimes, the vulnerability report is correct, but <em>incomplete</em>. This too can send everyone scrambling, starting with the vendor who was not given the opportunity to straighten things out.</p>
<p>When responsible disclosure works, it works really well. I offer <a href="http://jetpack.me/2014/04/10/jetpack-security-update/">Jetpack&#8217;s recent vulnerability</a> as a recent case study. While this was discovered internally at Automattic, the effect is the same: they were able to quickly and thoroughly investigate the issues and follow through with a plan of action. During their investigation they learned the problem was far more severe than they originally identified, and that their initial proposed fix was incomplete.</p>
<p>There will always be individuals who want everything to be fully disclosed, and there are some great arguments for that. I&#8217;m not trying to sway you one way or the other. But if you&#8217;re trying to do the right thing — you&#8217;re doing full disclosure in the interest of users, possibly even providing a patch or steps to mitigate — working with the vendor is a good way to ensure you haven&#8217;t missed anything.</p>
<p>I&#8217;m not sure how many times now I&#8217;ve responded to a mailing list saying, &#8220;well, this isn&#8217;t a vulnerability,&#8221; or &#8220;your proposed patch is incomplete,&#8221; or &#8220;your patch makes it worse.&#8221; Or when I don&#8217;t respond to the mailing list because my thought is <em>T</em><em>his is worse than the reporter realizes.</em></p>
<p>Security is nuanced.</p>
<p>Last week, a security researcher disclosed some issues with WordPress. They stated that WordPress issues a cookie in plain HTTP that identifies the user. Correct. They also stated that this cookie does not expire when the user logs out. Also correct.</p>
<p>She went on to state that the cookie has a lifetime of 3 years, that it can be used to mess with the account&#8217;s two-factor authentication settings, and change their email and other settings. She followed that up with &#8220;have notified them and waited 24hrs for response, none yet. guessing it&#8217;s a wontfix for now, since their SSL support is patchy.&#8221;</p>
<p>Yes, absolutely, SSL support in WordPress is patchy. (Coincidentally, fixing all of this was already slated for the next major release.) While you can force SSL for the dashboard, we don&#8217;t have the concept of forcing SSL for the front-end of the site. So, that &#8220;logged in&#8221; cookie is issued over plain HTTP. It&#8217;s trivial in a plugin to force that cookie to be secure, but of course most users aren&#8217;t going to do that. Of course, most users also aren&#8217;t using SSL (sadly).</p>
<p>WordPress also doesn&#8217;t have any concept of session management. The user is authenticated and a cookie is issued, but there&#8217;s no way for it to be automatically invalidated upon logout (without you changing your password). Changing this is a major architectural change we&#8217;ve been planning for some time. But this is also why cookies are designed with a limited expiration: just 48 hours, or 14 days if you click &#8220;Remember me.&#8221;</p>
<p>But the report was that it didn&#8217;t expire for three years, right? This is where it gets a bit weird. I&#8217;d love it if &#8220;Remember me&#8221; remembered you for 30, 90, or even 365 days, but WordPress will wait to make any changes until cookies can be invalidated. Some time ago, though, WordPress.com configured this cookie to last for three years.</p>
<p>Normally, this wouldn&#8217;t be that bad. You see, the &#8220;logged in&#8221; cookie is <em>relatively</em> harmless. It allows presentational things like the toolbar, edit links in your theme, and such. But you can&#8217;t use it to manage your account, change your email, or do anything particularly crazy. In fact, WordPress issues a separate, secure &#8220;auth&#8221; cookie used for the &#8220;wp-admin&#8221; dashboard. It’s like Amazon knowing who you are after six months of not being on the site, but asking you to log in when you start to check out.</p>
<p>On WordPress.com, however, a lot of settings can be managed outside of the dashboard, on their &#8220;new dashboard,&#8221; at wordpress.com/settings/. As you might have guessed by now, they were not requiring the &#8220;auth&#8221; cookie on this page, only the &#8220;logged in&#8221; cookie. That is the true critical vulnerability here. A number of decisions came together to make a latent issue a very real one. The issue wasn&#8217;t reported like this because the reporter isn&#8217;t familiar with the intricacies of user authentication internals in WordPress, nor should anyone expect them to. Rather, an assumption was made it was a design decision that would probably just be a &#8220;wontfix&#8221; due to &#8220;patchy&#8221; SSL support.</p>
<p>The disclosure was well-intentioned, but because it happened within just 24 hours, Automattic wasn&#8217;t able to react quickly enough to identify the actual issue and request that it not be disclosed until they got a fix in place.</p>
<p>I&#8217;m just trying to set the record straight on what happened, since I keep seeing confused tweets, blog posts, comments, and Facebook chatter. (Favorite Facebook comment, after I posted a brief explanation: &#8220;Did we just open all those nesting doll layers to discover the belly was empty?&#8221;) This situation probably could have been handled better by everyone involved, but that&#8217;s not really the point. The primary issue is now handled, and other issues are also being addressed. I don&#8217;t think this requires post-mortem blog posts with a side of FUD. I&#8217;m not looking for a debate on full disclosure versus responsible disclosure. And I certainly don&#8217;t think anyone should be questioning the researcher, who has spent years dedicating herself to making the Internet more secure.</p>
<p>In this case, WordPress.com the service was able to react quickly to mitigate this issue for all of its users. Of course, with software, holes can&#8217;t be closed so easily, and in this case, the situation was probably exacerbated by confusing WordPress.com the service with WordPress the software. That confusion is easy to understand, especially since some of these issues have roots in the core software.</p>
<address>Security is nuanced.</address>
<p><em>I&#8217;ve not linked to any previous posts because I don&#8217;t want this to be a criticism of any researcher or writer, but if you&#8217;re looking for background: <a href="https://zyan.scripts.mit.edu/blog/wordpress-fail/">1</a> <a href="http://arstechnica.com/security/2014/05/unsafe-cookies-leave-wordpress-accounts-open-to-hijacking-2-factor-bypass/">2</a> <a href="http://wptavern.com/wordpress-com-security-vulnerability-stirs-debate-over-responsible-disclosure">3</a>. Also, related work for WordPress 4.0 is happening <a href="https://core.trac.wordpress.org/query?milestone=4.0&component=Security">here</a>.</em></p>
<p class="share-sfc-stc"><a href="http://twitter.com/share?url=http%3A%2F%2Fwp.me%2FpQEdq-16j&count=horizontal&related=nacin&text=Security is nuanced" class="twitter-share-button"></a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 18:44:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: WordPress Think Tank 2 Now Available To Watch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23796";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:154:"http://wptavern.com/wordpress-think-tank-2-now-available-to-watch?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-think-tank-2-now-available-to-watch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1430:"<p>The second ever <a title="http://wpthinktank.com/" href="http://wpthinktank.com/">WP Think Tank </a>hosted by Troy Dean is now available to watch. WP Think Tank is a by-product of the <a title="http://www.wpelevation.com/category/podcast/" href="http://www.wpelevation.com/category/podcast/">WP Elevation podcast</a>. The two hour-long show is filled with great information from some of the brightest minds working with large WordPress clients every day.</p>
<ul>
<li>Matt Medeiros &#8211; Founder of the MattReport</li>
<li>Alex King &#8211; CTO of Crowd Favorite</li>
<li>Lisa Sabin-Wilson &#8211; Partner at WebDevStudios and AppPresser</li>
<li>Brian Clark &#8211; CEO of Copyblogger</li>
<li>Tim Willmot &#8211; CEO of Human Made, Happy Tables, WP Remote</li>
<li>Miriam Schwab &#8211; Co-CEO and Founder of Illuminea</li>
<li>Cory Miller &#8211; CEO of iThemes.</li>
</ul>
<p>The first hour of the show centered around the topic of enterprise and whether WordPress is a suitable solution for both enterprise clients and eCommerce websites. The second hour of the show covered things from a user point of view. For instance, does WordPress deliver on the expectations of the average user or has it become too difficult to use? Are there too many options and navigation headaches in the backend causing user frustration?</p>
<p>Give it a listen and let us know what you think.</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 18:24:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WordPress.tv: Matteo Cavucci: Io odio i temi di WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17315";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.tv/2014/05/30/matteo-cavucci-io-odio-i-temi-di-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:641:"<div id="v-Ivmk1LCc-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17315/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17315/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17315&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/30/matteo-cavucci-io-odio-i-temi-di-wordpress/"><img alt="01 Matteo Cavucci.mp4" src="http://videos.videopress.com/Ivmk1LCc/video-f40fad27f1_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 09:00:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:113:"WordPress.tv: Andrea Cardinali: 5 Regole SEO per sviluppo temi e plugin + 50 tips su Web Performance Optimization";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17367";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:128:"http://wordpress.tv/2014/05/30/andrea-cardinali-5-regole-seo-per-sviluppo-temi-e-plugin-50-tips-su-web-performance-optimization/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:773:"<div id="v-KB03gyQb-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17367/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17367/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17367&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/30/andrea-cardinali-5-regole-seo-per-sviluppo-temi-e-plugin-50-tips-su-web-performance-optimization/"><img alt="Andrea Cardinali: 5 Regole SEO per sviluppo temi e plugin + 50 tips su Web Performance Optimization" src="http://videos.videopress.com/KB03gyQb/video-fa5ff5b75c_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 08:00:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WordPress.tv: Mattia Compagnucci: L’uso efficace di una Tipografia corretta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17357";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wordpress.tv/2014/05/30/mattia-compagnucci-luso-efficace-di-una-tipografia-corretta/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:700:"<div id="v-FnT6vRQs-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17357/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17357/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17357&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/30/mattia-compagnucci-luso-efficace-di-una-tipografia-corretta/"><img alt="Mattia Compagnucci: L’uso efficace di una Tipografia corretta" src="http://videos.videopress.com/FnT6vRQs/video-d6e3e5a252_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 07:00:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: WordPress Query Recorder Plugin: Record and Save Queries to a SQL File for Deployment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23767";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:232:"http://wptavern.com/wordpress-query-recorder-plugin-record-and-save-queries-to-a-sql-file-for-deployment?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-query-recorder-plugin-record-and-save-queries-to-a-sql-file-for-deployment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2934:"<p><a href="https://wordpress.org/plugins/query-recorder/" target="_blank">Query Recorder</a> is a new tool that allows developers to record queries while working in the WordPress admin. The plugin was created by Brad Touesnard, author of the popular <a href="http://wptavern.com/wordpress-plugin-review-wp-db-migrate" target="_blank">WP Migrate DB</a> plugin. Touesnard introduced Query Recorder earlier this month at WordCamp Miami during his presentation on database deployment strategy.</p>
<p>Once installed, the plugin allows you to create recordings that save queries run by your theme or plugins. The recordings are sent to a sql file located in your /uploads/ directory.</p>
<p>The settings page gives you the option to set exclusions for certain types of queries and elect to omit or record queries that begin with insert, update, delete, drop, and create.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/query-recorder-settings.png" rel="prettyphoto[23767]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/query-recorder-settings.png?resize=1025%2C904" alt="query-recorder-settings" class="aligncenter size-full wp-image-23773" /></a></p>
<p>Clicking the button in the admin bar will start or stop the recording:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/start-stop-recording.png" rel="prettyphoto[23767]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/start-stop-recording.png?resize=1025%2C736" alt="start-stop-recording" class="aligncenter size-full wp-image-23774" /></a></p>
<p>Once you&#8217;ve made a recording, open up the SQL file in your uploads folder and you&#8217;ll find your saved queries. In the example below you can see that I&#8217;ve enabled and disabled some plugins and themes.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/query-recorder.png" rel="prettyphoto[23767]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/query-recorder.png?resize=1025%2C447" alt="query-recorder" class="aligncenter size-full wp-image-23771" /></a></p>
<p>Query Recorder can be particularly useful when working on a local installation of WordPress. You can record queries as you&#8217;re setting up a theme or plugin and create a SQL script that can be run later when deploying to another site. You can quickly test plugins and themes and then import the sql file when setting them up on a staging or live site. This is much easier than having to repeat those exact steps again in another environment.</p>
<p>I tested the plugin and it works exactly as advertised. Download <a href="https://wordpress.org/plugins/query-recorder/" target="_blank">Query Recorder</a> for free from the WordPress plugin directory. If you&#8217;d like to contribute to the project, it&#8217;s also hosted on <a href="https://github.com/deliciousbrains/wp-query-recorder" target="_blank">Github</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 03:42:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: Alex Shiels Proposal For Improving The WordPress Plugin Management Page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23671";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:206:"http://wptavern.com/alex-shiels-proposal-for-improving-the-wordpress-plugin-management-page?utm_source=rss&utm_medium=rss&utm_campaign=alex-shiels-proposal-for-improving-the-wordpress-plugin-management-page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5312:"<p>While WordPress <a title="http://wptavern.com/wordpress-3-8-parker-released" href="http://wptavern.com/wordpress-3-8-parker-released">3.8</a> and <a title="http://wptavern.com/wordpress-3-9-smith-released" href="http://wptavern.com/wordpress-3-9-smith-released">3.9</a> substantially improved the theme experience within WordPress, the plugins page hasn&#8217;t had the same treatment. In fact, the page hasn&#8217;t changed much since 2.7.</p>
<div id="attachment_23752" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WordPress27PluginsPage.png" rel="prettyphoto[23671]"><img class="size-full wp-image-23752" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WordPress27PluginsPage.png?resize=831%2C537" alt="WordPress 2.7 Plugins Page" /></a><p class="wp-caption-text">WordPress 2.7 Plugins Page</p></div>
<p>However, that may change as Alex Shiels has proposed a <a title="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/" href="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/">detailed outline</a> explaining the improvements and changes he&#8217;d like to see. According to Shiels, the goal is to improve the experience for both new and experienced users.</p>
<p>One of the suggested improvements is to have the plugin-install.php be the default page when selecting the Plugins menu in the backend of WordPress. I generally use the plugins page to activate or deactivate plugins for troubleshooting purposes. By making plugin-install.php the default page, it would require an extra step to browse to the installed plugins page.</p>
<p>Instead, I&#8217;d rather the default page be left alone and enable the search box to find plugins within the directory. Other users <a title="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/#comment-15346" href="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/#comment-15346">have chimed in</a> with similar feedback. As Shiels mentioned, &#8220;the Search Installed Plugins box on plugins.php is easily mistaken for a plugin directory search.&#8221;</p>
<div id="attachment_23753" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/PluginSearchBox.png" rel="prettyphoto[23671]"><img class="size-full wp-image-23753" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/PluginSearchBox.png?resize=807%2C455" alt="Users Mistakenly Use The Search Box To Search The Plugin Directory" /></a><p class="wp-caption-text">Users Mistakenly Use The Search Box To Search The Plugin Directory</p></div>
<p>I want the search engine for plugins to be improved. I&#8217;d also like to be able to organize search results by ratings, reviews, download count, etc. I&#8217;m happy to see the tag cloud may potentially be removed in favor of specific categories.</p>
<p>Something I&#8217;d love to see is the ability to rate and review plugins from the backend of WordPress. This way, I wouldn&#8217;t have to visit each plugin&#8217;s page on the directory to give feedback. I&#8217;d also like to be able to access that information somehow on the Installed Plugins page.</p>
<p>I think the Visit Plugin Site URL should link to the WordPress.org page listing for the plugin, not the author&#8217;s website. It would make it a lot easier to find the appropriate location to get support or view other data about the plugin on WordPress.org.</p>
<h3>User Submitted Ideas</h3>
<p>There are a lot of great ideas in the comments of the post. For instance, <a title="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/#comment-15350" href="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/#comment-15350">Brad Tousnard suggested</a> a Plugin installation that uses AJAX to install plugins in-place instead of having to go through a series of steps or have separate browser tabs open to install multiple plugins.</p>
<p>The plugin page doesn&#8217;t show whether or a not a plugin is dependent on another to work properly. Although there is a <a title="https://core.trac.wordpress.org/ticket/11308" href="https://core.trac.wordpress.org/ticket/11308">four-year old trac ticket</a> that has a lengthy discussion about the topic, nothing concrete has been established. Once it&#8217;s out, the next step would be to create an easy way to see those dependencies when searching for plugins.</p>
<h3>How to Get Involved</h3>
<p>Since nearly everyone has experience managing plugins in WordPress, it&#8217;s no wonder the post is generating so much feedback. If you want to get involved with helping Shiels make improvements to the page, keep an eye on the <a title="https://core.trac.wordpress.org/component/Plugins" href="https://core.trac.wordpress.org/component/Plugins">Plugins Component</a> on Trac. This is where tickets specifically for that part of WordPress will be located. You can also <a title="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/" href="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/">leave feedback on the post</a> with suggestions you have.</p>
<p>What changes would you like to see that would improve searching, adding, and managing plugins in WordPress for new and advanced users?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2014 21:32:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WPTavern: WP-CFM: A Free Plugin for Storing and Deploying WordPress Database Configurations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23708";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:224:"http://wptavern.com/wp-cfm-a-free-plugin-for-storing-and-deploying-wordpress-database-configurations?utm_source=rss&utm_medium=rss&utm_campaign=wp-cfm-a-free-plugin-for-storing-and-deploying-wordpress-database-configurations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4903:"<p><a href="http://forumone.github.io/wp-cfm/" target="_blank">WP-CFM</a> is a new free tool for WordPress created by <a href="https://twitter.com/mgibbs189" target="_blank">Matt Gibbs</a>, author of the popular <a href="http://wordpress.org/plugins/custom-field-suite/" target="_blank">Custom Field Suite</a> plugin. It provides configuration management for WordPress database changes, similar to Drupal&#8217;s <a href="https://drupal.org/project/features" target="_blank">Features</a> module.</p>
<p>WP-CFM lets you create and store bundles, which are essentially a group of one or more configuration options. The first step after installing the plugin is to create a /wp-content/config/ directory and grant write access.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/add-bundle.jpg" rel="prettyphoto[23708]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/add-bundle.jpg?resize=967%2C339" alt="add-bundle" class="aligncenter size-full wp-image-23730" /></a></p>
<p>WP-CFM provides a friendly interface for viewing the contents of the wp_options table so that you can select the options you want to be stored in a specific bundle. For example, let&#8217;s say that you want to grab all of your Jetpack options for deploying somewhere else. Create a Jetpack bundle:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/jetpack-bundle.jpg" rel="prettyphoto[23708]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/jetpack-bundle.jpg?resize=892%2C530" alt="jetpack-bundle" class="aligncenter size-full wp-image-23733" /></a></p>
<p>Each bundle has options for diff, push and pull:</p>
<ul>
<li><strong>diff</strong> &#8211; comparison of database version vs the file version</li>
<li><strong>push</strong> &#8211; write database changes to the file system</li>
<li><strong>pull</strong> &#8211; import file changes in the database</li>
</ul>
<p>Selecting &#8216;push&#8217; will store the database configuration in the file system (wp-content/config) as a .json file that you can then pull into your database at a later time or pull into another server.</p>
<p>One very common example where WP-CFM would be helpful is in the case of widgets options. Step one is to create a widgets bundle:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/widget-options.jpg" rel="prettyphoto[23708]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/widget-options.jpg?resize=818%2C380" alt="widget-options" class="aligncenter size-full wp-image-23737" /></a></p>
<p>Next you would create a widgets diff:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/widgets-diff.jpg" rel="prettyphoto[23708]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/widgets-diff.jpg?resize=966%2C390" alt="widgets-diff" class="aligncenter size-full wp-image-23738" /></a></p>
<p>From here you can push those changes to the filesystem so they&#8217;re ready to deploy at another time. Most of the time when using WP-CFM, you&#8217;ll follow this basic workflow for storing and deploying configurations:</p>
<ol>
<li>Make database changes</li>
<li>Store them in configuration management</li>
<li>Push the file to another server</li>
</ol>
<p>The &#8216;push&#8217; option on the All Bundles item writes all of your bundles to the file system at once, which is fairly handy. WP-CFM also includes developer hooks for registering custom configuration items, including a callback parameter for configuration data that is not stored within wp_options.</p>
<p>Deploying bundles is really easy with WP-CFM&#8217;s support for WP-CLI, which enables you to pull or push bundles from the command line. Setting the bundle_name to &#8220;all&#8221; will push/pull all at once:</p>
<pre class="brush: php; light: true; title: ; notranslate">wp config pull &lt;bundle_name&gt;
wp config push &lt;bundle_name&gt;</pre>
<h3>Benefits of using WP-CFM</h3>
<p>WP-CFM can save you quite a bit of time when working alone but it really shines when working with team of multiple developers. In the docs, Gibbs identifies the benefits of including it in your workflow:</p>
<ul>
<li>Less need to copy the database. If you make changes, Push your bundle to the filesystem. To load changes, Pull the bundle into your database.</li>
<li>No need to manually apply database settings changes. No more &#8220;fire drills&#8221; where you&#8217;re rushing to figure out which settings you forgot to change.</li>
<li>Track and migrate configuration files using git, subversion, etc.</li>
</ul>
<p>WP-CFM is an excellent new tool for simplifying deployments and the best part is that it&#8217;s totally free. You can download it from <a href="https://github.com/forumone/wp-cfm" target="_blank">Github</a> or via the plugin&#8217;s <a href="http://forumone.github.io/wp-cfm/" target="_blank">homepage</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2014 19:05:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Fri, 06 Jun 2014 12:38:47 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"152987";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Fri, 06 Jun 2014 12:30:15 GMT";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('16722', '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1402101528', 'no'); 
INSERT INTO `wp_options` VALUES ('16723', '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1402058328', 'no'); 
INSERT INTO `wp_options` VALUES ('16724', '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1402101528', 'no'); 
INSERT INTO `wp_options` VALUES ('16725', '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Jun 2014 12:27:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 10 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"50539@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Displays Google Analytics Reports and Real-Time Statistics in your Dashboard. Automatically inserts the tracking code in every page of your website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Fri, 06 Jun 2014 12:38:49 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 01 Jan 2009 20:34:44 GMT";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20130911070210";}', 'no'); 
INSERT INTO `wp_options` VALUES ('16726', '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1402101528', 'no'); 
INSERT INTO `wp_options` VALUES ('16727', '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1402058328', 'no'); 
INSERT INTO `wp_options` VALUES ('16728', '_transient_timeout_plugin_slugs', '1402146781', 'no'); 
INSERT INTO `wp_options` VALUES ('16729', '_transient_plugin_slugs', 'a:41:{i:0;s:29:"ads-by-datafeedrcom/dfads.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:63:"advanced-custom-fields-location-field-add-on/location-field.php";i:3;s:51:"acf-field-date-time-picker/acf-date_time_picker.php";i:4;s:36:"acf-repeater-master/acf-repeater.php";i:5;s:45:"acf-role-selector-field/acf-role_selector.php";i:6;s:19:"akismet/akismet.php";i:7;s:51:"auto-excerpt-everywhere/auto-excerpt-everywhere.php";i:8;s:43:"broken-link-checker/broken-link-checker.php";i:9;s:85:"carousel-horizontal-posts-content-slider/carousel-horizontal-posts-content-slider.php";i:10;s:25:"cloudflare/cloudflare.php";i:11;s:36:"contact-form-7/wp-contact-form-7.php";i:12;s:39:"admin-customizado/admin-customizado.php";i:13;s:38:"dashboard_usuario/dashbord_usuario.php";i:14;s:33:"duplicate-post/duplicate-post.php";i:15;s:39:"webriti-smtp-mail/webriti-smtp-mail.php";i:16;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:17;s:37:"export-user-data/export-user-data.php";i:18;s:41:"flexi-pages-widget/flexi-pages-widget.php";i:19;s:43:"google-analytics-dashboard-for-wp/gadwp.php";i:20;s:50:"google-analytics-for-wordpress/googleanalytics.php";i:21;s:43:"google-font-manager/google-font-manager.php";i:22;s:36:"google-sitemap-generator/sitemap.php";i:23;s:45:"inscricao-de-eventos/inscricao-de-eventos.php";i:24;s:24:"wp-issuu/issuu-embed.php";i:25;s:27:"issuu-embed/issue-embed.php";i:26;s:41:"better-wp-security/better-wp-security.php";i:27;s:24:"log-user-stats/index.php";i:28;s:32:"boleto-usuario/modulo_boleto.php";i:29;s:29:"ready-backup/backup-ready.php";i:30;s:33:"seo-image/seo-friendly-images.php";i:31;s:45:"simple-local-avatars/simple-local-avatars.php";i:32;s:11:"sap/sap.php";i:33;s:33:"smart-slider-2/smart-slider-2.php";i:34;s:56:"New-Media-Image-Uploader-master/tgm-new-media-plugin.php";i:35;s:37:"user-role-editor/user-role-editor.php";i:36;s:29:"user-status-manager/start.php";i:37;s:33:"w3-total-cache/w3-total-cache.php";i:38;s:37:"widgets-on-pages/widgets_on_pages.php";i:39;s:27:"wp-optimize/wp-optimize.php";i:40;s:31:"wp-backupware/wp-backupware.php";}', 'no'); 
INSERT INTO `wp_options` VALUES ('16730', '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1402101530', 'no'); 
INSERT INTO `wp_options` VALUES ('16731', '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/05/wordpress-3-9-1/\'>WordPress 3.9.1 Maintenance Release</a> <span class="rss-date">8 08UTC maio 08UTC 2014</span><div class="rssSummary">After three weeks and more than 9 million downloads of WordPress 3.9, we’re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We’ve also made some improvements to the new audio/vi</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/06/06/francisco-javier-carazo-gil-wordpress-como-plataforma-de-desarrollo/\' title=\'\'>WordPress.tv: Francisco Javier Carazo Gil: WordPress como plataforma de desarrollo</a></li><li><a class=\'rsswidget\' href=\'http://android.wordpress.org/2014/06/06/version-2-9-of-wordpress-for-android/\' title=\'The WordPress for Android 2.9 release is now available in the Google Play Store. This release includes some exciting new features, enhancements, and bug fixes. Blog Discovery Blog discovery is a new feature in the Reader that lets you: Find new blogs (based on recommendations). Preview a blog and read posts before following it. Manage your tags and blog subs\'>WP Android: Version 2.9 of WordPress for Android</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/06/06/fran-moreno-themes-premium-desde-la-perspectiva-del-creador-de-contenidos-del-disenador-y-del-desarrollador/\' title=\'\'>WordPress.tv: Fran Moreno: Themes premium desde la perspectiva del creador de contenidos, del diseñador y del desarrollador</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Plugins populares:</span> <a href=\'http://wordpress.org/plugins/jetpack/\' class=\'dashboard-news-plugin-link\'>Jetpack by WordPress.com</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=jetpack&amp;_wpnonce=f881014875&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Jetpack by WordPress.com\'>Instalar</a>)</span></li></ul></div>', 'no'); 
INSERT INTO `wp_options` VALUES ('16817', '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1402070958', 'yes'); 
INSERT INTO `wp_options` VALUES ('16818', '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4463";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2778";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2683";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2196";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2110";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1756";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1553";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1513";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1465";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1449";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1401";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1340";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1308";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1157";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1116";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1096";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"999";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"955";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"955";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"789";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"782";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"781";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"769";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"766";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"703";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"678";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"662";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"651";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"619";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"610";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"592";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"583";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"579";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"579";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"568";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"532";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"525";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"524";}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";s:3:"510";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"507";}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('16829', '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1402069910;s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'); 
INSERT INTO `wp_options` VALUES ('17698', '_site_transient_timeout_theme_roots', '1402071706', 'yes'); 
INSERT INTO `wp_options` VALUES ('17699', '_site_transient_theme_roots', 'a:2:{s:4:"asug";s:7:"/themes";s:27:"twentytwelve/page-templates";s:7:"/themes";}', 'yes'); 
INSERT INTO `wp_options` VALUES ('18243', '_transient_timeout_dfad_', '1402076510', 'no'); 
INSERT INTO `wp_options` VALUES ('18244', '_transient_dfad_', '1', 'no'); 
INSERT INTO `wp_options` VALUES ('18392', '_transient_is_multi_author', '0', 'yes'); 
INSERT INTO `wp_options` VALUES ('18505', '_transient_doing_cron', '1402082782.9342739582061767578125', 'yes'); 
INSERT INTO `wp_options` VALUES ('18507', 'rewrite_rules', 'a:96:{s:34:"sitemap(-+([a-zA-Z0-9_-]+))?\.xml$";s:40:"index.php?xml_sitemap=params=$matches[2]";s:38:"sitemap(-+([a-zA-Z0-9_-]+))?\.xml\.gz$";s:49:"index.php?xml_sitemap=params=$matches[2];zip=true";s:35:"sitemap(-+([a-zA-Z0-9_-]+))?\.html$";s:50:"index.php?xml_sitemap=params=$matches[2];html=true";s:38:"sitemap(-+([a-zA-Z0-9_-]+))?\.html.gz$";s:59:"index.php?xml_sitemap=params=$matches[2];html=true;zip=true";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:52:"dfads_group/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?dfads_group=$matches[1]&feed=$matches[2]";s:47:"dfads_group/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?dfads_group=$matches[1]&feed=$matches[2]";s:40:"dfads_group/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?dfads_group=$matches[1]&paged=$matches[2]";s:22:"dfads_group/([^/]+)/?$";s:33:"index.php?dfads_group=$matches[1]";s:40:"wpbu_backups/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:50:"wpbu_backups/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:70:"wpbu_backups/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"wpbu_backups/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:65:"wpbu_backups/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"wpbu_backups/([^/]+)/trackback/?$";s:54:"index.php?post_type=wpbu_backups&name=$matches[1]&tb=1";s:41:"wpbu_backups/([^/]+)/page/?([0-9]{1,})/?$";s:67:"index.php?post_type=wpbu_backups&name=$matches[1]&paged=$matches[2]";s:48:"wpbu_backups/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?post_type=wpbu_backups&name=$matches[1]&cpage=$matches[2]";s:36:"wpbu_backups/([^/]+)/ajax(/(.*))?/?$";s:66:"index.php?post_type=wpbu_backups&name=$matches[1]&ajax=$matches[3]";s:41:"wpbu_backups/([^/]+)/confirmar(/(.*))?/?$";s:71:"index.php?post_type=wpbu_backups&name=$matches[1]&confirmar=$matches[3]";s:33:"wpbu_backups/([^/]+)(/[0-9]+)?/?$";s:66:"index.php?post_type=wpbu_backups&name=$matches[1]&page=$matches[2]";s:29:"wpbu_backups/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:39:"wpbu_backups/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:59:"wpbu_backups/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"wpbu_backups/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:54:"wpbu_backups/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=2&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:23:"(.?.+?)/ajax(/(.*))?/?$";s:47:"index.php?pagename=$matches[1]&ajax=$matches[3]";s:28:"(.?.+?)/confirmar(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&confirmar=$matches[3]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:23:"([^/]+)/ajax(/(.*))?/?$";s:43:"index.php?name=$matches[1]&ajax=$matches[3]";s:28:"([^/]+)/confirmar(/(.*))?/?$";s:48:"index.php?name=$matches[1]&confirmar=$matches[3]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_postmeta`
--
DROP TABLE IF EXISTS `wp_postmeta`;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2122 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_postmeta`
--
LOCK TABLES `wp_postmeta` WRITE;
INSERT INTO `wp_postmeta` VALUES ('1', '2', '_wp_page_template', 'page-templates/front-page.php'); 
INSERT INTO `wp_postmeta` VALUES ('2', '4', '_form', '<p>Assunto (obrigatório)<br />
   [select* assunto include_blank "Grupo de pesquisas" "Portal ASUG" "Como se associar" "Assuntos gerais"]</p>

<p>[text* nome placeholder "Nome"] </p>

<p>[text* empresa placeholder "Empresa"] </p>

<p>[email* email placeholder "E-mail"] </p>

<p>[tel* telefone placeholder "Telefone "] </p>

<p>Sua mensagem<br />
    [textarea* your-message] </p>

<p>[submit "Enviar"]</p>'); 
INSERT INTO `wp_postmeta` VALUES ('3', '4', '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:201:"De: [your-name] <[your-email]>
Assunto: [your-subject]

Corpo da mensagem:
[your-message]

--
Este e-mail foi enviado de um formulário de contato em Asug | SAP NetWeaver Portal (http://127.0.0.1/asug)";s:9:"recipient";s:24:"felipe@montarsite.com.br";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('4', '4', '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:145:"Corpo da mensagem:
[your-message]

--
Este e-mail foi enviado de um formulário de contato em Asug | SAP NetWeaver Portal (http://127.0.0.1/asug)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('5', '4', '_messages', 'a:21:{s:12:"mail_sent_ok";s:47:"Sua mensagem foi enviada com sucesso. Obrigado.";s:12:"mail_sent_ng";s:115:"Não foi possível enviar a sua mensagem. Por favor, tente mais tarde ou contate o administrador por outro método.";s:16:"validation_error";s:77:"Ocorreram erros de validação. Por favor confira os dados e envie novamente.";s:4:"spam";s:115:"Não foi possível enviar a sua mensagem. Por favor, tente mais tarde ou contate o administrador por outro método.";s:12:"accept_terms";s:43:"Por favor aceite os termos para prosseguir.";s:16:"invalid_required";s:43:"Por favor preencha este campo obrigatório.";s:17:"captcha_not_match";s:35:"O código digitado está incorreto.";s:14:"invalid_number";s:36:"Formato de número parece inválido.";s:16:"number_too_small";s:30:"Este número é muito pequeno.";s:16:"number_too_large";s:29:"Este número é muito grande.";s:13:"invalid_email";s:39:"O endereço de e-mail parece inválido.";s:11:"invalid_url";s:21:"URL parece inválido.";s:11:"invalid_tel";s:26:"Telefone parece inválido.";s:23:"quiz_answer_not_correct";s:29:"Sua resposta está incorreta.";s:12:"invalid_date";s:33:"Formato da data parece inválido.";s:14:"date_too_early";s:32:"Esta data é demasiado primeira.";s:13:"date_too_late";s:29:"Esta data é demasiado tarde.";s:13:"upload_failed";s:27:"Falha no upload do arquivo.";s:24:"upload_file_type_invalid";s:39:"Este tipo de arquivo não é permitido.";s:21:"upload_file_too_large";s:30:"Este arquivo é grande demais.";s:23:"upload_failed_php_error";s:27:"Falha no upload do arquivo.";}'); 
INSERT INTO `wp_postmeta` VALUES ('6', '4', '_additional_settings', ''); 
INSERT INTO `wp_postmeta` VALUES ('7', '4', '_locale', 'pt_BR'); 
INSERT INTO `wp_postmeta` VALUES ('8', '2', '_edit_lock', '1398214009:1'); 
INSERT INTO `wp_postmeta` VALUES ('9', '2', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('11', '6', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('12', '6', '_edit_lock', '1401919370:1'); 
INSERT INTO `wp_postmeta` VALUES ('13', '6', '_wp_page_template', 'page-templates/sidebar-esquerda.php'); 
INSERT INTO `wp_postmeta` VALUES ('14', '6', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('15', '8', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('16', '8', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('18', '8', '_edit_lock', '1394901197:1'); 
INSERT INTO `wp_postmeta` VALUES ('31', '16', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('32', '16', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('33', '16', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('34', '16', '_edit_lock', '1394901293:1'); 
INSERT INTO `wp_postmeta` VALUES ('35', '18', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('36', '18', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('37', '18', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('38', '18', '_edit_lock', '1394901318:1'); 
INSERT INTO `wp_postmeta` VALUES ('39', '20', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('40', '20', '_wp_page_template', 'page-templates/sidebar-direita.php'); 
INSERT INTO `wp_postmeta` VALUES ('41', '20', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('42', '20', '_edit_lock', '1397330428:1'); 
INSERT INTO `wp_postmeta` VALUES ('43', '22', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('44', '22', '_wp_page_template', 'page-templates/asug-news.php'); 
INSERT INTO `wp_postmeta` VALUES ('45', '22', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('46', '22', '_edit_lock', '1397330425:1'); 
INSERT INTO `wp_postmeta` VALUES ('146', '35', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('147', '35', '_edit_lock', '1394901437:1'); 
INSERT INTO `wp_postmeta` VALUES ('148', '35', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('149', '35', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('150', '37', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('151', '37', '_edit_lock', '1395346601:1'); 
INSERT INTO `wp_postmeta` VALUES ('152', '37', '_wp_page_template', 'page-templates/sidebar-esquerda.php'); 
INSERT INTO `wp_postmeta` VALUES ('153', '37', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('154', '39', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('155', '39', '_wp_page_template', 'page-templates/sidebar-esquerda.php'); 
INSERT INTO `wp_postmeta` VALUES ('157', '39', '_edit_lock', '1401900828:1'); 
INSERT INTO `wp_postmeta` VALUES ('158', '41', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('159', '41', '_edit_lock', '1395343282:1'); 
INSERT INTO `wp_postmeta` VALUES ('160', '41', '_wp_page_template', 'page-templates/sidebar-direita.php'); 
INSERT INTO `wp_postmeta` VALUES ('161', '41', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('162', '43', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('163', '43', '_edit_lock', '1395343283:1'); 
INSERT INTO `wp_postmeta` VALUES ('164', '43', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('165', '43', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('166', '45', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('167', '45', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('168', '45', '_menu_item_object_id', '2'); 
INSERT INTO `wp_postmeta` VALUES ('169', '45', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('170', '45', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('171', '45', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('172', '45', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('173', '45', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('184', '47', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('185', '47', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('186', '47', '_menu_item_object_id', '8'); 
INSERT INTO `wp_postmeta` VALUES ('187', '47', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('188', '47', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('189', '47', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('190', '47', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('191', '47', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('193', '48', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('194', '48', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('195', '48', '_menu_item_object_id', '20'); 
INSERT INTO `wp_postmeta` VALUES ('196', '48', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('197', '48', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('198', '48', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('199', '48', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('200', '48', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('202', '49', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('203', '49', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('204', '49', '_menu_item_object_id', '22'); 
INSERT INTO `wp_postmeta` VALUES ('205', '49', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('206', '49', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('207', '49', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('208', '49', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('209', '49', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('211', '50', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('212', '50', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('213', '50', '_menu_item_object_id', '16'); 
INSERT INTO `wp_postmeta` VALUES ('214', '50', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('215', '50', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('216', '50', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('217', '50', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('218', '50', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('247', '54', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('248', '54', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('249', '54', '_menu_item_object_id', '18'); 
INSERT INTO `wp_postmeta` VALUES ('250', '54', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('251', '54', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('252', '54', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('253', '54', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('254', '54', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('265', '56', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('266', '56', '_menu_item_menu_item_parent', '444'); 
INSERT INTO `wp_postmeta` VALUES ('267', '56', '_menu_item_object_id', '39'); 
INSERT INTO `wp_postmeta` VALUES ('268', '56', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('269', '56', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('270', '56', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('271', '56', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('272', '56', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('274', '57', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('275', '57', '_menu_item_menu_item_parent', '444'); 
INSERT INTO `wp_postmeta` VALUES ('276', '57', '_menu_item_object_id', '37'); 
INSERT INTO `wp_postmeta` VALUES ('277', '57', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('278', '57', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('279', '57', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('280', '57', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('281', '57', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('283', '58', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('284', '58', '_menu_item_menu_item_parent', '444'); 
INSERT INTO `wp_postmeta` VALUES ('285', '58', '_menu_item_object_id', '35'); 
INSERT INTO `wp_postmeta` VALUES ('286', '58', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('287', '58', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('288', '58', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('289', '58', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('290', '58', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('292', '59', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('293', '59', '_menu_item_menu_item_parent', '444'); 
INSERT INTO `wp_postmeta` VALUES ('294', '59', '_menu_item_object_id', '41'); 
INSERT INTO `wp_postmeta` VALUES ('295', '59', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('296', '59', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('297', '59', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('298', '59', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('299', '59', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('301', '60', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('302', '60', '_menu_item_menu_item_parent', '444'); 
INSERT INTO `wp_postmeta` VALUES ('303', '60', '_menu_item_object_id', '43'); 
INSERT INTO `wp_postmeta` VALUES ('304', '60', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('305', '60', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('306', '60', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('307', '60', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('308', '60', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('310', '61', '_wp_attached_file', '2014/03/asug-brasil.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('311', '61', '_wp_attachment_context', 'custom-header'); 
INSERT INTO `wp_postmeta` VALUES ('312', '61', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:229;s:6:"height";i:76;s:4:"file";s:23:"2014/03/asug-brasil.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:22:"asug-brasil-150x76.jpg";s:5:"width";i:150;s:6:"height";i:76;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('313', '61', '_wp_attachment_is_custom_header', 'twentytwelve'); 
INSERT INTO `wp_postmeta` VALUES ('314', '63', '_wp_attached_file', '2014/03/slider.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('315', '63', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:542;s:6:"height";i:250;s:4:"file";s:18:"2014/03/slider.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"slider-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:18:"slider-300x138.jpg";s:5:"width";i:300;s:6:"height";i:138;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('316', '64', '_wp_attached_file', '2014/03/banner03.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('317', '64', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:235;s:6:"height";i:121;s:4:"file";s:20:"2014/03/banner03.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"banner03-150x121.jpg";s:5:"width";i:150;s:6:"height";i:121;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('318', '65', '_wp_attached_file', '2014/03/banner04.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('319', '65', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:235;s:6:"height";i:121;s:4:"file";s:20:"2014/03/banner04.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"banner04-150x121.jpg";s:5:"width";i:150;s:6:"height";i:121;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('320', '66', '_wp_attached_file', '2014/03/banner01.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('321', '66', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:235;s:6:"height";i:122;s:4:"file";s:20:"2014/03/banner01.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"banner01-150x122.jpg";s:5:"width";i:150;s:6:"height";i:122;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('322', '67', '_wp_attached_file', '2014/03/banner02.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('323', '67', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:234;s:6:"height";i:122;s:4:"file";s:20:"2014/03/banner02.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"banner02-150x122.jpg";s:5:"width";i:150;s:6:"height";i:122;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('324', '68', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('325', '68', '_edit_lock', '1394950263:1'); 
INSERT INTO `wp_postmeta` VALUES ('326', '68', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('327', '68', '_dfads_start_date', '1394928000'); 
INSERT INTO `wp_postmeta` VALUES ('328', '68', '_dfads_end_date', '1430352000'); 
INSERT INTO `wp_postmeta` VALUES ('329', '68', '_dfads_impression_limit', '90000'); 
INSERT INTO `wp_postmeta` VALUES ('330', '68', '_dfads_impression_count', '524'); 
INSERT INTO `wp_postmeta` VALUES ('331', '70', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('332', '70', '_edit_lock', '1394950319:1'); 
INSERT INTO `wp_postmeta` VALUES ('333', '70', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('334', '70', '_dfads_impression_limit', '0'); 
INSERT INTO `wp_postmeta` VALUES ('335', '70', '_dfads_impression_count', '526'); 
INSERT INTO `wp_postmeta` VALUES ('336', '72', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('337', '72', '_edit_lock', '1394950356:1'); 
INSERT INTO `wp_postmeta` VALUES ('338', '72', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('339', '72', '_dfads_impression_limit', '0'); 
INSERT INTO `wp_postmeta` VALUES ('340', '74', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('341', '74', '_edit_lock', '1395233203:1'); 
INSERT INTO `wp_postmeta` VALUES ('342', '74', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('343', '74', '_dfads_impression_limit', '0'); 
INSERT INTO `wp_postmeta` VALUES ('344', '72', '_dfads_impression_count', '518'); 
INSERT INTO `wp_postmeta` VALUES ('345', '74', '_dfads_impression_count', '520'); 
INSERT INTO `wp_postmeta` VALUES ('346', '76', '_menu_item_type', 'custom'); 
INSERT INTO `wp_postmeta` VALUES ('347', '76', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('348', '76', '_menu_item_object_id', '76'); 
INSERT INTO `wp_postmeta` VALUES ('349', '76', '_menu_item_object', 'custom'); 
INSERT INTO `wp_postmeta` VALUES ('350', '76', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('351', '76', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('352', '76', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('353', '76', '_menu_item_url', '#'); 
INSERT INTO `wp_postmeta` VALUES ('355', '77', '_wp_attached_file', '2014/03/eventos01.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('356', '77', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:149;s:6:"height";i:90;s:4:"file";s:21:"2014/03/eventos01.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('357', '78', '_wp_attached_file', '2014/03/eventos02.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('358', '78', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:149;s:6:"height";i:90;s:4:"file";s:21:"2014/03/eventos02.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('359', '1', '_edit_lock', '1398627826:1'); 
INSERT INTO `wp_postmeta` VALUES ('360', '86', '_wp_attached_file', '2014/03/eventos011.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('361', '86', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:149;s:6:"height";i:90;s:4:"file";s:22:"2014/03/eventos011.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('362', '87', '_wp_attached_file', '2014/03/eventos021.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('363', '87', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:149;s:6:"height";i:90;s:4:"file";s:22:"2014/03/eventos021.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('364', '1', '_thumbnail_id', '87'); 
INSERT INTO `wp_postmeta` VALUES ('365', '1', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('368', '1', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('369', '1', '_wp_old_slug', 'ola-mundo'); 
INSERT INTO `wp_postmeta` VALUES ('370', '90', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('371', '90', '_edit_lock', '1395013464:1'); 
INSERT INTO `wp_postmeta` VALUES ('372', '90', '_thumbnail_id', '86'); 
INSERT INTO `wp_postmeta` VALUES ('375', '90', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('376', '92', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('377', '92', '_edit_lock', '1395013492:1'); 
INSERT INTO `wp_postmeta` VALUES ('378', '92', '_thumbnail_id', '77'); 
INSERT INTO `wp_postmeta` VALUES ('381', '92', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('382', '94', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('383', '94', '_edit_lock', '1395608972:1'); 
INSERT INTO `wp_postmeta` VALUES ('384', '94', '_thumbnail_id', '78'); 
INSERT INTO `wp_postmeta` VALUES ('387', '94', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('393', '117', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1395343555.zip'); 
INSERT INTO `wp_postmeta` VALUES ('394', '117', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('395', '117', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('396', '117', 'backup_size', '0.17 MB'); 
INSERT INTO `wp_postmeta` VALUES ('397', '118', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1395343586.zip'); 
INSERT INTO `wp_postmeta` VALUES ('398', '118', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('399', '118', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('400', '118', 'backup_size', '0.17 MB'); 
INSERT INTO `wp_postmeta` VALUES ('401', '119', '_wp_attached_file', '2014/03/banner.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('402', '119', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1019;s:6:"height";i:248;s:4:"file";s:18:"2014/03/banner.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"banner-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:17:"banner-300x73.jpg";s:5:"width";i:300;s:6:"height";i:73;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"shop_thumbnail";a:5:{s:4:"file";s:16:"banner-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:12:"shop_catalog";a:5:{s:4:"file";s:18:"banner-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:10:"No savings";}s:11:"shop_single";a:5:{s:4:"file";s:18:"banner-300x248.jpg";s:5:"width";i:300;s:6:"height";i:248;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:18:"banner-624x151.jpg";s:5:"width";i:624;s:6:"height";i:151;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('404', '39', '_thumbnail_id', '119'); 
INSERT INTO `wp_postmeta` VALUES ('405', '120', '_wp_attached_file', '2014/03/banner_comite.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('406', '120', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1019;s:6:"height";i:248;s:4:"file";s:25:"2014/03/banner_comite.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:5:{s:4:"file";s:25:"banner_comite-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:24:"banner_comite-300x73.jpg";s:5:"width";i:300;s:6:"height";i:73;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"shop_thumbnail";a:5:{s:4:"file";s:23:"banner_comite-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:12:"shop_catalog";a:5:{s:4:"file";s:25:"banner_comite-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:10:"No savings";}s:11:"shop_single";a:5:{s:4:"file";s:25:"banner_comite-300x248.jpg";s:5:"width";i:300;s:6:"height";i:248;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:25:"banner_comite-624x151.jpg";s:5:"width";i:624;s:6:"height";i:151;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('408', '123', '_wp_attached_file', '2014/03/banner1.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('409', '123', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1019;s:6:"height";i:248;s:4:"file";s:19:"2014/03/banner1.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:5:{s:4:"file";s:19:"banner1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:18:"banner1-300x73.jpg";s:5:"width";i:300;s:6:"height";i:73;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"shop_thumbnail";a:5:{s:4:"file";s:17:"banner1-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:12:"shop_catalog";a:5:{s:4:"file";s:19:"banner1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:10:"No savings";}s:11:"shop_single";a:5:{s:4:"file";s:19:"banner1-300x248.jpg";s:5:"width";i:300;s:6:"height";i:248;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:19:"banner1-624x151.jpg";s:5:"width";i:624;s:6:"height";i:151;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('410', '124', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1395431624.zip'); 
INSERT INTO `wp_postmeta` VALUES ('411', '124', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('412', '124', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('413', '124', 'backup_size', '0.21 MB'); 
INSERT INTO `wp_postmeta` VALUES ('414', '126', '_wp_attached_file', '2014/03/sua_fatura_de_energia_mesref_2014031.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('415', '126', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('416', '127', '_wp_attached_file', '2014/03/sua_fatura_de_energia_mesref_2014032.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('417', '127', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('418', '128', '_wp_attached_file', '2014/03/sua_fatura_de_energia_mesref_2014033.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('419', '128', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('420', '129', '_wp_attached_file', '2014/03/sua_fatura_de_energia_mesref_2014034.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('421', '129', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('422', '130', '_wp_attached_file', '2014/03/sua_fatura_de_energia_mesref_2014035.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('423', '130', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('424', '131', '_wp_attached_file', '2014/03/sua_fatura_de_energia_mesref_2014036.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('425', '131', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('426', '132', '_wp_attached_file', '2014/03/sua_fatura_de_energia_mesref_2014037.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('427', '132', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('428', '133', '_wp_attached_file', '2014/03/sua_fatura_de_energia_mesref_2014038.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('429', '133', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('430', '134', '_wp_attached_file', '2014/03/wireframe-interna-ASUG.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('431', '134', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('432', '135', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1395596264.zip'); 
INSERT INTO `wp_postmeta` VALUES ('433', '135', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('434', '135', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('435', '135', 'backup_size', '0.21 MB'); 
INSERT INTO `wp_postmeta` VALUES ('436', '136', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1395602764.zip'); 
INSERT INTO `wp_postmeta` VALUES ('437', '136', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('438', '136', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('439', '136', 'backup_size', '0.22 MB'); 
INSERT INTO `wp_postmeta` VALUES ('440', '137', '_edit_lock', '1397591990:1'); 
INSERT INTO `wp_postmeta` VALUES ('441', '137', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('442', '137', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('443', '137', 'bwps_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('444', '150', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1395700838.zip'); 
INSERT INTO `wp_postmeta` VALUES ('445', '150', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('446', '150', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('447', '150', 'backup_size', '0.22 MB'); 
INSERT INTO `wp_postmeta` VALUES ('525', '158', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1395788465.zip'); 
INSERT INTO `wp_postmeta` VALUES ('526', '158', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('527', '158', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('528', '158', 'backup_size', '0.21 MB'); 
INSERT INTO `wp_postmeta` VALUES ('529', '159', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1395870668.zip'); 
INSERT INTO `wp_postmeta` VALUES ('530', '159', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('531', '159', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('532', '159', 'backup_size', '0.21 MB'); 
INSERT INTO `wp_postmeta` VALUES ('533', '160', '_edit_lock', '1395889098:1'); 
INSERT INTO `wp_postmeta` VALUES ('534', '160', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('535', '160', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('536', '160', 'itsec_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('537', '2', 'itsec_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('538', '165', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1395953779.zip'); 
INSERT INTO `wp_postmeta` VALUES ('539', '165', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('540', '165', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('541', '165', 'backup_size', '0.22 MB'); 
INSERT INTO `wp_postmeta` VALUES ('542', '8', 'itsec_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('543', '39', 'itsec_enable_ssl', ''); 
INSERT INTO `wp_postmeta` VALUES ('545', '167', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1396115234.zip'); 
INSERT INTO `wp_postmeta` VALUES ('546', '167', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('547', '167', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('548', '167', 'backup_size', '0.21 MB'); 
INSERT INTO `wp_postmeta` VALUES ('552', '134', 'issuu_pdf_id', '140329182930-60a7a3782bd04be4987cb898e71b0cb2'); 
INSERT INTO `wp_postmeta` VALUES ('553', '134', 'issuu_pdf_username', 'felipeaugustopita'); 
INSERT INTO `wp_postmeta` VALUES ('554', '134', 'issuu_pdf_name', 'wireframe-interna-asug'); 
INSERT INTO `wp_postmeta` VALUES ('555', '133', 'issuu_pdf_id', '140329182930-5580d2df2ee443ce830e8fd4d0b684db'); 
INSERT INTO `wp_postmeta` VALUES ('556', '133', 'issuu_pdf_username', 'felipeaugustopita'); 
INSERT INTO `wp_postmeta` VALUES ('557', '133', 'issuu_pdf_name', 'sua_fatura_de_energia_mesref_201403-8'); 
INSERT INTO `wp_postmeta` VALUES ('558', '130', 'issuu_pdf_id', '140329182932-71deedcf1c65431eb83c022ec792d87b'); 
INSERT INTO `wp_postmeta` VALUES ('559', '130', 'issuu_pdf_username', 'felipeaugustopita'); 
INSERT INTO `wp_postmeta` VALUES ('560', '130', 'issuu_pdf_name', 'sua_fatura_de_energia_mesref_201403-5'); 
INSERT INTO `wp_postmeta` VALUES ('561', '129', 'issuu_pdf_id', '140329182932-b9b41240b5584226b5020b42823c2a2e'); 
INSERT INTO `wp_postmeta` VALUES ('562', '129', 'issuu_pdf_username', 'felipeaugustopita'); 
INSERT INTO `wp_postmeta` VALUES ('563', '129', 'issuu_pdf_name', 'sua_fatura_de_energia_mesref_201403-4'); 
INSERT INTO `wp_postmeta` VALUES ('572', '132', 'issuu_pdf_id', '140329184352-c2ef9e1b38b44ae79d02eaae2bec44a3'); 
INSERT INTO `wp_postmeta` VALUES ('573', '132', 'issuu_pdf_username', 'felipeaugustopita'); 
INSERT INTO `wp_postmeta` VALUES ('574', '132', 'issuu_pdf_name', 'sua_fatura_de_energia_mesref_201403-7'); 
INSERT INTO `wp_postmeta` VALUES ('575', '131', 'issuu_pdf_id', '140329184352-deb970e030f540988ab9de0fb6f2324b'); 
INSERT INTO `wp_postmeta` VALUES ('576', '131', 'issuu_pdf_username', 'felipeaugustopita'); 
INSERT INTO `wp_postmeta` VALUES ('577', '131', 'issuu_pdf_name', 'sua_fatura_de_energia_mesref_201403-6'); 
INSERT INTO `wp_postmeta` VALUES ('578', '128', 'issuu_pdf_id', '140329184353-f4610385d1dd4ee48f2a57cea537d97d'); 
INSERT INTO `wp_postmeta` VALUES ('579', '128', 'issuu_pdf_username', 'felipeaugustopita'); 
INSERT INTO `wp_postmeta` VALUES ('580', '128', 'issuu_pdf_name', 'sua_fatura_de_energia_mesref_201403-3'); 
INSERT INTO `wp_postmeta` VALUES ('581', '127', 'issuu_pdf_id', '140329184354-1aaffe4a132c4f69b027086e13d8167a'); 
INSERT INTO `wp_postmeta` VALUES ('582', '127', 'issuu_pdf_username', 'felipeaugustopita'); 
INSERT INTO `wp_postmeta` VALUES ('583', '127', 'issuu_pdf_name', 'sua_fatura_de_energia_mesref_201403-2'); 
INSERT INTO `wp_postmeta` VALUES ('584', '126', 'issuu_pdf_id', '140329184354-014ffdace3ef4d3a9bcf7bd60e3d3d0d'); 
INSERT INTO `wp_postmeta` VALUES ('585', '126', 'issuu_pdf_username', 'felipeaugustopita'); 
INSERT INTO `wp_postmeta` VALUES ('586', '126', 'issuu_pdf_name', 'sua_fatura_de_energia_mesref_201403'); 
INSERT INTO `wp_postmeta` VALUES ('587', '134', '_edit_lock', '1396118769:1'); 
INSERT INTO `wp_postmeta` VALUES ('588', '134', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('604', '187', '_wp_attached_file', '2014/03/cartao-sms.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('605', '187', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('607', '189', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1396121168.zip'); 
INSERT INTO `wp_postmeta` VALUES ('608', '189', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('609', '189', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('610', '189', 'backup_size', '0.22 MB'); 
INSERT INTO `wp_postmeta` VALUES ('611', '190', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('612', '190', '_edit_lock', '1396122743:1'); 
INSERT INTO `wp_postmeta` VALUES ('613', '190', 'epaper_meta_realepaper', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/cartao-sms.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('614', '190', 'epaper_meta_pdf', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/cartao-sms.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('615', '190', 'epaper_meta_pages', 'a:1:{i:0;s:27:"aaaaaaaaaaaaaaaaaaaaaaaaaaa";}'); 
INSERT INTO `wp_postmeta` VALUES ('622', '202', '_edit_lock', '1402072285:1'); 
INSERT INTO `wp_postmeta` VALUES ('623', '202', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('624', '202', 'field_53373670701de', 'a:10:{s:3:"key";s:19:"field_53373670701de";s:5:"label";s:17:"Upload da revista";s:4:"name";s:17:"upload_da_revista";s:4:"type";s:4:"file";s:12:"instructions";s:37:"Faça o upload do PDF da revista aqui";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('627', '202', 'position', 'normal'); 
INSERT INTO `wp_postmeta` VALUES ('628', '202', 'layout', 'no_box'); 
INSERT INTO `wp_postmeta` VALUES ('629', '202', 'hide_on_screen', ''); 
INSERT INTO `wp_postmeta` VALUES ('678', '213', '_edit_lock', '1396398181:1'); 
INSERT INTO `wp_postmeta` VALUES ('681', '214', '_wp_attached_file', '2014/03/capa-revista-hsm-management-01.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('682', '214', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:378;s:6:"height";i:500;s:4:"file";s:42:"2014/03/capa-revista-hsm-management-01.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:42:"capa-revista-hsm-management-01-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:42:"capa-revista-hsm-management-01-226x300.jpg";s:5:"width";i:226;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('684', '213', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('687', '215', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('688', '215', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('689', '215', '_', ''); 
INSERT INTO `wp_postmeta` VALUES ('690', '213', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('691', '213', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('692', '213', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('695', '202', 'field_533745765a5ee', 'a:11:{s:3:"key";s:19:"field_533745765a5ee";s:5:"label";s:15:"Capa da revista";s:4:"name";s:15:"capa_da_revista";s:4:"type";s:5:"image";s:12:"instructions";s:35:"Faça o upload da capada da revista";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'); 
INSERT INTO `wp_postmeta` VALUES ('696', '202', 'field_5337459f5a5ef', 'a:14:{s:3:"key";s:19:"field_5337459f5a5ef";s:5:"label";s:0:"";s:4:"name";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'); 
INSERT INTO `wp_postmeta` VALUES ('699', '202', 'rule', 'a:5:{s:5:"param";s:9:"user_type";s:8:"operator";s:2:"==";s:5:"value";s:13:"administrator";s:8:"order_no";i:0;s:8:"group_no";i:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('700', '202', 'rule', 'a:5:{s:5:"param";s:13:"post_category";s:8:"operator";s:2:"==";s:5:"value";s:2:"19";s:8:"order_no";i:1;s:8:"group_no";i:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('703', '217', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('704', '217', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('705', '217', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('706', '217', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('707', '217', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('708', '213', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('709', '213', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('721', '213', '_thumbnail_id', '123'); 
INSERT INTO `wp_postmeta` VALUES ('728', '218', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('729', '218', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('730', '218', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('731', '218', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('732', '218', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('733', '219', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1396392617.zip'); 
INSERT INTO `wp_postmeta` VALUES ('734', '219', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('735', '219', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('736', '219', 'backup_size', '0.22 MB'); 
INSERT INTO `wp_postmeta` VALUES ('737', '222', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('738', '222', '_edit_lock', '1396393500:1'); 
INSERT INTO `wp_postmeta` VALUES ('739', '223', '_wp_attached_file', '2014/04/capa-revista-gloss.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('740', '223', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:377;s:6:"height";i:492;s:4:"file";s:30:"2014/04/capa-revista-gloss.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:30:"capa-revista-gloss-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:30:"capa-revista-gloss-229x300.jpg";s:5:"width";i:229;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('743', '224', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('744', '224', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('745', '224', 'capa_da_revista', '223'); 
INSERT INTO `wp_postmeta` VALUES ('746', '224', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('747', '224', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('748', '222', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('749', '222', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('750', '222', 'capa_da_revista', '223'); 
INSERT INTO `wp_postmeta` VALUES ('751', '222', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('752', '222', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('753', '226', '_edit_lock', '1402072287:1'); 
INSERT INTO `wp_postmeta` VALUES ('754', '226', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('755', '226', 'upload_da_revista', '298'); 
INSERT INTO `wp_postmeta` VALUES ('756', '226', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('757', '226', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('758', '226', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('759', '226', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('760', '226', '_thumbnail_id', '123'); 
INSERT INTO `wp_postmeta` VALUES ('761', '226', '_dp_original', '213'); 
INSERT INTO `wp_postmeta` VALUES ('762', '227', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('763', '227', '_edit_lock', '1396393500:1'); 
INSERT INTO `wp_postmeta` VALUES ('764', '227', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('765', '227', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('766', '227', 'capa_da_revista', '223'); 
INSERT INTO `wp_postmeta` VALUES ('767', '227', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('768', '227', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('769', '227', '_dp_original', '222'); 
INSERT INTO `wp_postmeta` VALUES ('770', '228', '_edit_lock', '1396398181:1'); 
INSERT INTO `wp_postmeta` VALUES ('771', '228', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('772', '228', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('773', '228', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('774', '228', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('775', '228', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('776', '228', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('777', '228', '_thumbnail_id', '123'); 
INSERT INTO `wp_postmeta` VALUES ('778', '228', '_dp_original', '213'); 
INSERT INTO `wp_postmeta` VALUES ('779', '229', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('780', '229', '_edit_lock', '1396393500:1'); 
INSERT INTO `wp_postmeta` VALUES ('781', '229', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('782', '229', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('783', '229', 'capa_da_revista', '223'); 
INSERT INTO `wp_postmeta` VALUES ('784', '229', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('785', '229', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('786', '229', '_dp_original', '222'); 
INSERT INTO `wp_postmeta` VALUES ('787', '230', '_edit_lock', '1396398181:1'); 
INSERT INTO `wp_postmeta` VALUES ('788', '230', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('789', '230', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('790', '230', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('791', '230', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('792', '230', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('793', '230', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('794', '230', '_thumbnail_id', '123'); 
INSERT INTO `wp_postmeta` VALUES ('795', '230', '_dp_original', '213'); 
INSERT INTO `wp_postmeta` VALUES ('796', '231', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('797', '231', '_edit_lock', '1396393500:1'); 
INSERT INTO `wp_postmeta` VALUES ('798', '231', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('799', '231', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('800', '231', 'capa_da_revista', '223'); 
INSERT INTO `wp_postmeta` VALUES ('801', '231', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('802', '231', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('803', '231', '_dp_original', '222'); 
INSERT INTO `wp_postmeta` VALUES ('804', '232', '_edit_lock', '1396398181:1'); 
INSERT INTO `wp_postmeta` VALUES ('805', '232', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('806', '232', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('807', '232', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('808', '232', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('809', '232', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('810', '232', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('811', '232', '_thumbnail_id', '123'); 
INSERT INTO `wp_postmeta` VALUES ('812', '232', '_dp_original', '213'); 
INSERT INTO `wp_postmeta` VALUES ('813', '233', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('814', '233', '_edit_lock', '1396393500:1'); 
INSERT INTO `wp_postmeta` VALUES ('815', '233', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('816', '233', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('817', '233', 'capa_da_revista', '223'); 
INSERT INTO `wp_postmeta` VALUES ('818', '233', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('819', '233', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('820', '233', '_dp_original', '222'); 
INSERT INTO `wp_postmeta` VALUES ('821', '234', '_edit_lock', '1396398181:1'); 
INSERT INTO `wp_postmeta` VALUES ('822', '234', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('823', '234', 'upload_da_revista', '187'); 
INSERT INTO `wp_postmeta` VALUES ('824', '234', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('825', '234', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('826', '234', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('827', '234', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('828', '234', '_thumbnail_id', '123'); 
INSERT INTO `wp_postmeta` VALUES ('829', '234', '_dp_original', '213'); 
INSERT INTO `wp_postmeta` VALUES ('848', '120', '_edit_lock', '1397489845:1'); 
INSERT INTO `wp_postmeta` VALUES ('849', '244', '_wp_attached_file', '2014/03/revista.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('850', '244', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1019;s:6:"height";i:248;s:4:"file";s:19:"2014/03/revista.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:19:"revista-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:18:"revista-300x73.jpg";s:5:"width";i:300;s:6:"height";i:73;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:19:"revista-624x151.jpg";s:5:"width";i:624;s:6:"height";i:151;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('851', '20', '_thumbnail_id', '244'); 
INSERT INTO `wp_postmeta` VALUES ('852', '245', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1396474863.zip'); 
INSERT INTO `wp_postmeta` VALUES ('853', '245', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('854', '245', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('855', '245', 'backup_size', '0.18 MB'); 
INSERT INTO `wp_postmeta` VALUES ('857', '247', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1396562592.zip'); 
INSERT INTO `wp_postmeta` VALUES ('858', '247', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('859', '247', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('860', '247', 'backup_size', '0.23 MB'); 
INSERT INTO `wp_postmeta` VALUES ('869', '250', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1396639554.zip'); 
INSERT INTO `wp_postmeta` VALUES ('870', '250', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('871', '250', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('872', '250', 'backup_size', '0.23 MB'); 
INSERT INTO `wp_postmeta` VALUES ('873', '251', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1396726024.zip'); 
INSERT INTO `wp_postmeta` VALUES ('874', '251', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('875', '251', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('876', '251', 'backup_size', '0.23 MB'); 
INSERT INTO `wp_postmeta` VALUES ('877', '253', '_edit_lock', '1396727906:1'); 
INSERT INTO `wp_postmeta` VALUES ('878', '253', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('879', '254', '_wp_attached_file', '2014/04/asug_recibo_cabecalho.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('880', '254', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1020;s:6:"height";i:71;s:4:"file";s:33:"2014/04/asug_recibo_cabecalho.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:32:"asug_recibo_cabecalho-150x71.jpg";s:5:"width";i:150;s:6:"height";i:71;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:32:"asug_recibo_cabecalho-300x20.jpg";s:5:"width";i:300;s:6:"height";i:20;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:32:"asug_recibo_cabecalho-624x43.jpg";s:5:"width";i:624;s:6:"height";i:43;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('881', '255', '_wp_attached_file', '2014/04/asug_recibo_rodape.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('882', '255', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1020;s:6:"height";i:38;s:4:"file";s:30:"2014/04/asug_recibo_rodape.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:29:"asug_recibo_rodape-150x38.jpg";s:5:"width";i:150;s:6:"height";i:38;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:29:"asug_recibo_rodape-300x11.jpg";s:5:"width";i:300;s:6:"height";i:11;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:29:"asug_recibo_rodape-624x23.jpg";s:5:"width";i:624;s:6:"height";i:23;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('914', '285', '_edit_lock', '1396760978:1'); 
INSERT INTO `wp_postmeta` VALUES ('915', '285', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('916', '285', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('917', '287', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1397329543.zip'); 
INSERT INTO `wp_postmeta` VALUES ('918', '287', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('919', '287', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('920', '287', 'backup_size', '0.22 MB'); 
INSERT INTO `wp_postmeta` VALUES ('933', '291', '_edit_lock', '1401916588:1'); 
INSERT INTO `wp_postmeta` VALUES ('934', '291', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('935', '291', '_wp_page_template', 'page-templates/sidebar-esquerda.php'); 
INSERT INTO `wp_postmeta` VALUES ('936', '293', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('937', '293', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('938', '293', '_menu_item_object_id', '291'); 
INSERT INTO `wp_postmeta` VALUES ('939', '293', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('940', '293', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('941', '293', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('942', '293', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('943', '293', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('945', '294', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('946', '294', '_edit_lock', '1397330444:1'); 
INSERT INTO `wp_postmeta` VALUES ('947', '294', '_wp_page_template', 'page-templates/full-width.php'); 
INSERT INTO `wp_postmeta` VALUES ('948', '296', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('949', '296', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('950', '296', '_menu_item_object_id', '294'); 
INSERT INTO `wp_postmeta` VALUES ('951', '296', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('952', '296', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('953', '296', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('954', '296', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('955', '296', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('957', '22', '_thumbnail_id', '123'); 
INSERT INTO `wp_postmeta` VALUES ('958', '297', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1397330827.zip'); 
INSERT INTO `wp_postmeta` VALUES ('959', '297', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('960', '297', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('961', '297', 'backup_size', '0.23 MB'); 
INSERT INTO `wp_postmeta` VALUES ('962', '298', '_wp_attached_file', '2014/04/PASSEI_online_menor_1.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('963', '298', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('966', '299', 'upload_da_revista', '298'); 
INSERT INTO `wp_postmeta` VALUES ('967', '299', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('968', '299', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('969', '299', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('970', '299', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('971', '300', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1397417427.zip'); 
INSERT INTO `wp_postmeta` VALUES ('972', '300', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('973', '300', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('974', '300', 'backup_size', '0.23 MB'); 
INSERT INTO `wp_postmeta` VALUES ('975', '244', '_edit_lock', '1397489847:1'); 
INSERT INTO `wp_postmeta` VALUES ('976', '119', '_edit_lock', '1397489834:1'); 
INSERT INTO `wp_postmeta` VALUES ('977', '302', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1397505353.zip'); 
INSERT INTO `wp_postmeta` VALUES ('978', '302', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('979', '302', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('980', '302', 'backup_size', '0.24 MB'); 
INSERT INTO `wp_postmeta` VALUES ('982', '304', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1397590261.zip'); 
INSERT INTO `wp_postmeta` VALUES ('983', '304', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('984', '304', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('985', '304', 'backup_size', '0.24 MB'); 
INSERT INTO `wp_postmeta` VALUES ('986', '305', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398202522.zip'); 
INSERT INTO `wp_postmeta` VALUES ('987', '305', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('988', '305', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('989', '305', 'backup_size', '0.23 MB'); 
INSERT INTO `wp_postmeta` VALUES ('991', '308', '_wp_attached_file', '2014/03/copy-asug-brasil.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('992', '308', '_wp_attachment_context', 'custom-header'); 
INSERT INTO `wp_postmeta` VALUES ('993', '308', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:229;s:6:"height";i:76;s:4:"file";s:28:"2014/03/copy-asug-brasil.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:27:"copy-asug-brasil-150x76.jpg";s:5:"width";i:150;s:6:"height";i:76;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('994', '308', '_wp_attachment_is_custom_header', 'asug'); 
INSERT INTO `wp_postmeta` VALUES ('995', '309', '_edit_lock', '1398211963:1'); 
INSERT INTO `wp_postmeta` VALUES ('996', '309', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('997', '310', '_wp_attached_file', '2014/04/Technology-news1.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('998', '310', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1000;s:6:"height";i:842;s:4:"file";s:28:"2014/04/Technology-news1.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:28:"Technology-news1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:28:"Technology-news1-300x252.jpg";s:5:"width";i:300;s:6:"height";i:252;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:28:"Technology-news1-624x525.jpg";s:5:"width";i:624;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('999', '309', '_thumbnail_id', '310'); 
INSERT INTO `wp_postmeta` VALUES ('1002', '312', '_edit_lock', '1398212123:1'); 
INSERT INTO `wp_postmeta` VALUES ('1003', '312', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1005', '312', '_dp_original', '309'); 
INSERT INTO `wp_postmeta` VALUES ('1006', '313', '_edit_lock', '1398212117:1'); 
INSERT INTO `wp_postmeta` VALUES ('1007', '313', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1009', '313', '_dp_original', '309'); 
INSERT INTO `wp_postmeta` VALUES ('1010', '314', '_edit_lock', '1398549600:1'); 
INSERT INTO `wp_postmeta` VALUES ('1011', '314', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1013', '314', '_dp_original', '309'); 
INSERT INTO `wp_postmeta` VALUES ('1028', '320', '_wp_attached_file', '2014/04/circuit-Sqr1.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('1029', '320', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1698;s:6:"height";i:1131;s:4:"file";s:24:"2014/04/circuit-Sqr1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:24:"circuit-Sqr1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:24:"circuit-Sqr1-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:5:"large";a:5:{s:4:"file";s:25:"circuit-Sqr1-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:24:"circuit-Sqr1-624x415.jpg";s:5:"width";i:624;s:6:"height";i:415;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";d:4;s:6:"credit";s:0:"";s:6:"camera";s:13:"Canon EOS 10D";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1170176907;s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"50";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:16:"0.16666666666667";s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('1030', '312', '_thumbnail_id', '320'); 
INSERT INTO `wp_postmeta` VALUES ('1033', '322', '_wp_attached_file', '2014/04/technology-hand1.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('1034', '322', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1400;s:6:"height";i:933;s:4:"file";s:28:"2014/04/technology-hand1.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:28:"technology-hand1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:28:"technology-hand1-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:5:"large";a:5:{s:4:"file";s:29:"technology-hand1-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:28:"technology-hand1-624x415.jpg";s:5:"width";i:624;s:6:"height";i:415;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('1035', '313', '_thumbnail_id', '322'); 
INSERT INTO `wp_postmeta` VALUES ('1038', '324', '_wp_attached_file', '2014/04/cpuaroundworld_alpha1.png'); 
INSERT INTO `wp_postmeta` VALUES ('1039', '324', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1633;s:6:"height";i:1225;s:4:"file";s:33:"2014/04/cpuaroundworld_alpha1.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:33:"cpuaroundworld_alpha1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:33:"cpuaroundworld_alpha1-300x225.png";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:9:"image/png";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:5:"large";a:5:{s:4:"file";s:34:"cpuaroundworld_alpha1-1024x768.png";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:33:"cpuaroundworld_alpha1-624x468.png";s:5:"width";i:624;s:6:"height";i:468;s:9:"mime-type";s:9:"image/png";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('1040', '314', '_thumbnail_id', '324'); 
INSERT INTO `wp_postmeta` VALUES ('1041', '327', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398302411.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1042', '327', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1043', '327', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1044', '327', 'backup_size', '0.15 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1045', '328', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398384395.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1046', '328', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1047', '328', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1048', '328', 'backup_size', '0.15 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1049', '329', '_edit_lock', '1398391122:1'); 
INSERT INTO `wp_postmeta` VALUES ('1050', '329', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1051', '329', '_wp_page_template', 'page-templates/lista-detaques.php'); 
INSERT INTO `wp_postmeta` VALUES ('1052', '331', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398463094.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1053', '331', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1054', '331', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1055', '331', 'backup_size', '0.14 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1056', '332', '_edit_lock', '1402079088:1'); 
INSERT INTO `wp_postmeta` VALUES ('1057', '332', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1060', '332', 'field_535aff2f5871d', 'a:11:{s:3:"key";s:19:"field_535aff2f5871d";s:5:"label";s:14:"Data do evento";s:4:"name";s:14:"data_do_evento";s:4:"type";s:11:"date_picker";s:12:"instructions";s:30:"Data em que ocorrerá o evento";s:8:"required";s:1:"1";s:11:"date_format";s:8:"dd/mm/yy";s:14:"display_format";s:8:"dd/mm/yy";s:9:"first_day";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('1061', '332', 'field_535affcf5871e', 'a:12:{s:3:"key";s:19:"field_535affcf5871e";s:5:"label";s:15:"Local do evento";s:4:"name";s:15:"local_do_evento";s:4:"type";s:10:"google_map";s:12:"instructions";s:72:"Latitude e longitude, esse campo será adicionado uma API do Google Maps";s:8:"required";s:1:"0";s:10:"center_lat";s:0:"";s:10:"center_lng";s:0:"";s:4:"zoom";s:0:"";s:6:"height";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'); 
INSERT INTO `wp_postmeta` VALUES ('1062', '332', 'field_535b00015871f', 'a:11:{s:3:"key";s:19:"field_535b00015871f";s:5:"label";s:18:"Botão de cadastro";s:4:"name";s:17:"botao_de_cadastro";s:4:"type";s:5:"image";s:12:"instructions";s:69:"Upload do botão "Inscreva-se" dimensões recomendada: 300px por 80px";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'); 
INSERT INTO `wp_postmeta` VALUES ('1063', '332', 'field_535b004658720', 'a:15:{s:3:"key";s:19:"field_535b004658720";s:5:"label";s:19:"Usuário registrado";s:4:"name";s:18:"usuario_registrado";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:5:"00,00";s:7:"prepend";s:2:"R$";s:6:"append";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:4:"step";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'); 
INSERT INTO `wp_postmeta` VALUES ('1064', '332', 'field_535b008b58721', 'a:15:{s:3:"key";s:19:"field_535b008b58721";s:5:"label";s:16:"Empresa parceira";s:4:"name";s:16:"empresa_parceira";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:5:"00,00";s:7:"prepend";s:2:"R$";s:6:"append";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:4:"step";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'); 
INSERT INTO `wp_postmeta` VALUES ('1065', '332', 'field_535b00a958722', 'a:15:{s:3:"key";s:19:"field_535b00a958722";s:5:"label";s:15:"Empresa cliente";s:4:"name";s:15:"empresa_cliente";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:5:"00,00";s:7:"prepend";s:2:"R$";s:6:"append";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:4:"step";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'); 
INSERT INTO `wp_postmeta` VALUES ('1066', '332', 'field_535b00bf58723', 'a:15:{s:3:"key";s:19:"field_535b00bf58723";s:5:"label";s:14:"Não associado";s:4:"name";s:13:"nao_associado";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:5:"00,00";s:7:"prepend";s:2:"R$";s:6:"append";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:4:"step";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:6;}'); 
INSERT INTO `wp_postmeta` VALUES ('1075', '332', 'position', 'normal'); 
INSERT INTO `wp_postmeta` VALUES ('1076', '332', 'layout', 'no_box'); 
INSERT INTO `wp_postmeta` VALUES ('1077', '332', 'hide_on_screen', 'a:6:{i:0;s:7:"excerpt";i:1;s:10:"discussion";i:2;s:8:"comments";i:3;s:6:"format";i:4;s:4:"tags";i:5;s:15:"send-trackbacks";}'); 
INSERT INTO `wp_postmeta` VALUES ('1080', '332', 'field_535b04522d931', 'a:13:{s:3:"key";s:19:"field_535b04522d931";s:5:"label";s:5:"Grade";s:4:"name";s:5:"grade";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"sub_fields";a:7:{i:0;a:14:{s:3:"key";s:19:"field_535b045d2d932";s:5:"label";s:8:"Horário";s:4:"name";s:7:"horario";s:4:"type";s:16:"date_time_picker";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:9:"show_date";s:5:"false";s:11:"date_format";s:5:"m/d/y";s:11:"time_format";s:5:"hh:mm";s:16:"show_week_number";s:5:"false";s:6:"picker";s:6:"slider";s:17:"save_as_timestamp";s:4:"true";s:16:"get_as_timestamp";s:5:"false";s:8:"order_no";i:0;}i:1;a:13:{s:3:"key";s:19:"field_535b0b502d933";s:5:"label";s:19:"Título da palestra";s:4:"name";s:18:"titulo_da_palestra";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:19:"Título da palestra";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:8:"order_no";i:1;}i:2;a:10:{s:3:"key";s:19:"field_535b0b6a2d934";s:5:"label";s:20:"Detalhes da palestra";s:4:"name";s:20:"detalhes_da_palestra";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:7:"toolbar";s:5:"basic";s:12:"media_upload";s:2:"no";s:8:"order_no";i:2;}i:3;a:13:{s:3:"key";s:19:"field_535b0b7f2d935";s:5:"label";s:11:"Palestrante";s:4:"name";s:11:"palestrante";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:11:"Palestrante";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:8:"order_no";i:3;}i:4;a:13:{s:3:"key";s:19:"field_535b0b942d936";s:5:"label";s:4:"Sala";s:4:"name";s:4:"sala";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:4:"Sala";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:8:"order_no";i:4;}i:5;a:14:{s:3:"key";s:19:"field_535b0ba32d937";s:5:"label";s:18:"Capacidade da sala";s:4:"name";s:18:"capacidade_da_sala";s:4:"type";s:6:"number";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:4:"step";s:0:"";s:8:"order_no";i:5;}i:6;a:9:{s:3:"key";s:19:"field_535b0bb72d938";s:5:"label";s:18:"Upload do material";s:4:"name";s:18:"upload_do_material";s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:11:"save_format";s:3:"url";s:7:"library";s:3:"all";s:8:"order_no";i:6;}}s:7:"row_min";s:1:"1";s:9:"row_limit";s:2:"30";s:6:"layout";s:3:"row";s:12:"button_label";s:9:"Adicionar";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:10;}'); 
INSERT INTO `wp_postmeta` VALUES ('1121', '361', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398549688.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1122', '361', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1123', '361', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1124', '361', 'backup_size', '0.14 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1131', '332', 'field_535c2f77bb095', 'a:8:{s:3:"key";s:19:"field_535c2f77bb095";s:5:"label";s:22:"Grade de programação";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:9;}'); 
INSERT INTO `wp_postmeta` VALUES ('1132', '332', 'field_535c3015bb096', 'a:8:{s:3:"key";s:19:"field_535c3015bb096";s:5:"label";s:6:"Álbum";s:4:"name";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:11;}'); 
INSERT INTO `wp_postmeta` VALUES ('1133', '332', 'field_535c3023bb097', 'a:13:{s:3:"key";s:19:"field_535c3023bb097";s:5:"label";s:5:"Fotos";s:4:"name";s:5:"fotos";s:4:"type";s:8:"repeater";s:12:"instructions";s:15:"Fotos do evento";s:8:"required";s:1:"0";s:10:"sub_fields";a:1:{i:0;a:10:{s:3:"key";s:19:"field_535c303abb098";s:5:"label";s:14:"Foto do evento";s:4:"name";s:14:"foto_do_evento";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:11:"save_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:8:"order_no";i:0;}}s:7:"row_min";s:1:"0";s:9:"row_limit";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:12:"Incluir foto";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:12;}'); 
INSERT INTO `wp_postmeta` VALUES ('1135', '364', '_edit_lock', '1402079098:1'); 
INSERT INTO `wp_postmeta` VALUES ('1136', '364', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1139', '365', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1140', '365', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1141', '365', 'data_do_evento', '230520142014'); 
INSERT INTO `wp_postmeta` VALUES ('1142', '365', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1143', '365', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1144', '365', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1145', '365', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1146', '365', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1147', '365', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1148', '365', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1149', '365', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1150', '365', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1151', '365', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1152', '365', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1153', '365', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1154', '365', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1155', '365', 'grade_0_horario', '1398513600'); 
INSERT INTO `wp_postmeta` VALUES ('1156', '365', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1157', '365', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1158', '365', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1159', '365', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1160', '365', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1161', '365', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1162', '365', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1163', '365', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1164', '365', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1165', '365', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1166', '365', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1167', '365', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1168', '365', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1169', '365', 'grade_1_horario', '1398474000'); 
INSERT INTO `wp_postmeta` VALUES ('1170', '365', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1171', '365', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1172', '365', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1173', '365', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1174', '365', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1175', '365', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1176', '365', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1177', '365', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1178', '365', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1179', '365', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1180', '365', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1181', '365', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1182', '365', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1183', '365', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1184', '365', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1185', '365', 'fotos_0_foto_do_evento', ''); 
INSERT INTO `wp_postmeta` VALUES ('1186', '365', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1187', '365', 'fotos', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1188', '365', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1189', '364', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1190', '364', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1191', '364', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1192', '364', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1193', '364', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1194', '364', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1195', '364', 'botao_de_cadastro', '464'); 
INSERT INTO `wp_postmeta` VALUES ('1196', '364', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1197', '364', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1198', '364', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1199', '364', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1200', '364', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1201', '364', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1202', '364', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1203', '364', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1204', '364', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1205', '364', 'grade_0_horario', '1402056000'); 
INSERT INTO `wp_postmeta` VALUES ('1206', '364', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1207', '364', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1208', '364', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1209', '364', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1210', '364', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1211', '364', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1212', '364', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1213', '364', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1214', '364', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1215', '364', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1216', '364', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1217', '364', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1218', '364', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1219', '364', 'grade_1_horario', '1402016400'); 
INSERT INTO `wp_postmeta` VALUES ('1220', '364', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1221', '364', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1222', '364', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1223', '364', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1224', '364', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1225', '364', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1226', '364', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1227', '364', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1228', '364', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1229', '364', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1230', '364', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1231', '364', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1232', '364', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1233', '364', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1234', '364', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1235', '364', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('1236', '364', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1237', '364', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('1238', '364', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1242', '366', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1243', '366', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1244', '366', 'data_do_evento', '230520142014'); 
INSERT INTO `wp_postmeta` VALUES ('1245', '366', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1246', '366', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1247', '366', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1248', '366', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1249', '366', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1250', '366', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1251', '366', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1252', '366', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1253', '366', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1254', '366', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1255', '366', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1256', '366', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1257', '366', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1258', '366', 'grade_0_horario', '1398513600'); 
INSERT INTO `wp_postmeta` VALUES ('1259', '366', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1260', '366', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1261', '366', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1262', '366', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1263', '366', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1264', '366', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1265', '366', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1266', '366', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1267', '366', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1268', '366', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1269', '366', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1270', '366', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1271', '366', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1272', '366', 'grade_1_horario', '1398474000'); 
INSERT INTO `wp_postmeta` VALUES ('1273', '366', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1274', '366', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1275', '366', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1276', '366', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1277', '366', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1278', '366', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1279', '366', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1280', '366', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1281', '366', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1282', '366', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1283', '366', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1284', '366', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1285', '366', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1286', '366', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1287', '366', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1288', '366', 'fotos_0_foto_do_evento', ''); 
INSERT INTO `wp_postmeta` VALUES ('1289', '366', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1290', '366', 'fotos', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1291', '366', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1294', '367', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1295', '367', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1296', '367', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1297', '367', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1298', '367', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1299', '367', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1300', '367', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1301', '367', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1302', '367', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1303', '367', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1304', '367', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1305', '367', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1306', '367', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1307', '367', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1308', '367', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1309', '367', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1310', '367', 'grade_0_horario', '1398513600'); 
INSERT INTO `wp_postmeta` VALUES ('1311', '367', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1312', '367', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1313', '367', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1314', '367', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1315', '367', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1316', '367', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1317', '367', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1318', '367', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1319', '367', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1320', '367', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1321', '367', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1322', '367', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1323', '367', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1324', '367', 'grade_1_horario', '1398474000'); 
INSERT INTO `wp_postmeta` VALUES ('1325', '367', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1326', '367', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1327', '367', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1328', '367', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1329', '367', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1330', '367', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1331', '367', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1332', '367', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1333', '367', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1334', '367', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1335', '367', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1336', '367', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1337', '367', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1338', '367', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1339', '367', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1340', '367', 'fotos_0_foto_do_evento', ''); 
INSERT INTO `wp_postmeta` VALUES ('1341', '367', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1342', '367', 'fotos', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1343', '367', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1346', '368', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1347', '368', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1348', '368', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1349', '368', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1350', '368', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1351', '368', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1352', '368', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1353', '368', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1354', '368', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1355', '368', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1356', '368', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1357', '368', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1358', '368', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1359', '368', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1360', '368', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1361', '368', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1362', '368', 'grade_0_horario', '1398600000'); 
INSERT INTO `wp_postmeta` VALUES ('1363', '368', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1364', '368', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1365', '368', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1366', '368', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1367', '368', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1368', '368', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1369', '368', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1370', '368', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1371', '368', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1372', '368', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1373', '368', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1374', '368', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1375', '368', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1376', '368', 'grade_1_horario', '1398560400'); 
INSERT INTO `wp_postmeta` VALUES ('1377', '368', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1378', '368', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1379', '368', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1380', '368', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1381', '368', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1382', '368', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1383', '368', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1384', '368', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1385', '368', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1386', '368', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1387', '368', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1388', '368', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1389', '368', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1390', '368', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1391', '368', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1392', '368', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('1393', '368', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1394', '368', 'fotos', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1395', '368', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1398', '369', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1399', '369', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1400', '369', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1401', '369', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1402', '369', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1403', '369', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1404', '369', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1405', '369', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1406', '369', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1407', '369', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1408', '369', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1409', '369', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1410', '369', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1411', '369', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1412', '369', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1413', '369', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1414', '369', 'grade_0_horario', '1398600000'); 
INSERT INTO `wp_postmeta` VALUES ('1415', '369', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1416', '369', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1417', '369', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1418', '369', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1419', '369', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1420', '369', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1421', '369', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1422', '369', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1423', '369', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1424', '369', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1425', '369', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1426', '369', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1427', '369', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1428', '369', 'grade_1_horario', '1398560400'); 
INSERT INTO `wp_postmeta` VALUES ('1429', '369', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1430', '369', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1431', '369', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1432', '369', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1433', '369', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1434', '369', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1435', '369', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1436', '369', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1437', '369', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1438', '369', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1439', '369', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1440', '369', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1441', '369', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1442', '369', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1443', '369', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1444', '369', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('1445', '369', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1446', '369', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('1447', '369', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1448', '369', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('1449', '369', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1450', '369', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('1451', '369', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1452', '364', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('1453', '364', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1454', '364', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('1455', '364', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1456', '332', 'field_535c54f61960d', 'a:13:{s:3:"key";s:19:"field_535c54f61960d";s:5:"label";s:14:"Patrocinadores";s:4:"name";s:14:"patrocinadores";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"sub_fields";a:1:{i:0;a:10:{s:3:"key";s:19:"field_535c55031960e";s:5:"label";s:4:"logo";s:4:"name";s:4:"logo";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:12:"column_width";s:0:"";s:11:"save_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:8:"order_no";i:0;}}s:7:"row_min";s:1:"0";s:9:"row_limit";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:20:"Incluir patrocinador";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:8;}'); 
INSERT INTO `wp_postmeta` VALUES ('1461', '371', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1462', '371', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1463', '371', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1464', '371', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1465', '371', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1466', '371', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1467', '371', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1468', '371', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1469', '371', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1470', '371', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1471', '371', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1472', '371', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1473', '371', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1474', '371', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1475', '371', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1476', '371', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1477', '371', 'patrocinadores', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1478', '371', '_patrocinadores', 'field_535c54f61960d'); 
INSERT INTO `wp_postmeta` VALUES ('1479', '371', 'grade_0_horario', '1398600000'); 
INSERT INTO `wp_postmeta` VALUES ('1480', '371', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1481', '371', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1482', '371', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1483', '371', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1484', '371', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1485', '371', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1486', '371', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1487', '371', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1488', '371', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1489', '371', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1490', '371', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1491', '371', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1492', '371', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1493', '371', 'grade_1_horario', '1398560400'); 
INSERT INTO `wp_postmeta` VALUES ('1494', '371', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1495', '371', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1496', '371', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1497', '371', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1498', '371', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1499', '371', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1500', '371', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1501', '371', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1502', '371', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1503', '371', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1504', '371', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1505', '371', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1506', '371', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1507', '371', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1508', '371', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1509', '371', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('1510', '371', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1511', '371', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('1512', '371', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1513', '371', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('1514', '371', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1515', '371', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('1516', '371', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1517', '364', 'patrocinadores', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1518', '364', '_patrocinadores', 'field_535c54f61960d'); 
INSERT INTO `wp_postmeta` VALUES ('1519', '372', '_edit_lock', '1398560512:1'); 
INSERT INTO `wp_postmeta` VALUES ('1520', '372', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1521', '372', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1522', '372', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1523', '372', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1524', '372', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1525', '372', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1526', '372', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1527', '372', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1528', '372', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1529', '372', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1530', '372', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1531', '372', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1532', '372', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1533', '372', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1534', '372', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1535', '372', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1536', '372', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1537', '372', 'grade_0_horario', '1398600000'); 
INSERT INTO `wp_postmeta` VALUES ('1538', '372', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1539', '372', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1540', '372', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1541', '372', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1542', '372', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1543', '372', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1544', '372', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1545', '372', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1546', '372', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1547', '372', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1548', '372', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1549', '372', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1550', '372', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1551', '372', 'grade_1_horario', '1398560400'); 
INSERT INTO `wp_postmeta` VALUES ('1552', '372', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1553', '372', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1554', '372', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1555', '372', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1556', '372', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1557', '372', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1558', '372', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1559', '372', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1560', '372', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1561', '372', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1562', '372', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1563', '372', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1564', '372', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1565', '372', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1566', '372', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1567', '372', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('1568', '372', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1569', '372', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('1570', '372', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1571', '372', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('1572', '372', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1573', '372', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('1574', '372', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1575', '372', 'patrocinadores', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1576', '372', '_patrocinadores', 'field_535c54f61960d'); 
INSERT INTO `wp_postmeta` VALUES ('1577', '372', '_dp_original', '364'); 
INSERT INTO `wp_postmeta` VALUES ('1578', '373', '_edit_lock', '1398650601:1'); 
INSERT INTO `wp_postmeta` VALUES ('1579', '373', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1580', '373', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1581', '373', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1582', '373', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1583', '373', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1584', '373', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1585', '373', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1586', '373', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1587', '373', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1588', '373', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1589', '373', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1590', '373', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1591', '373', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1592', '373', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1593', '373', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1594', '373', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1595', '373', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1596', '373', 'grade_0_horario', '1398600000'); 
INSERT INTO `wp_postmeta` VALUES ('1597', '373', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1598', '373', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1599', '373', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1600', '373', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1601', '373', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1602', '373', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1603', '373', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1604', '373', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1605', '373', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1606', '373', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1607', '373', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1608', '373', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1609', '373', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1610', '373', 'grade_1_horario', '1398560400'); 
INSERT INTO `wp_postmeta` VALUES ('1611', '373', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1612', '373', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1613', '373', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1614', '373', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1615', '373', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1616', '373', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1617', '373', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1618', '373', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1619', '373', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1620', '373', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1621', '373', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1622', '373', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1623', '373', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1624', '373', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1625', '373', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1626', '373', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('1627', '373', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1628', '373', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('1629', '373', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1630', '373', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('1631', '373', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1632', '373', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('1633', '373', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1634', '373', 'patrocinadores', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1635', '373', '_patrocinadores', 'field_535c54f61960d'); 
INSERT INTO `wp_postmeta` VALUES ('1636', '373', '_dp_original', '364'); 
INSERT INTO `wp_postmeta` VALUES ('1639', '374', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1640', '374', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1641', '374', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1642', '374', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1643', '374', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1644', '374', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1645', '374', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1646', '374', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1647', '374', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1648', '374', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1649', '374', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1650', '374', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1651', '374', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1652', '374', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1653', '374', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1654', '374', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1655', '374', 'patrocinadores', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1656', '374', '_patrocinadores', 'field_535c54f61960d'); 
INSERT INTO `wp_postmeta` VALUES ('1657', '374', 'grade_0_horario', '1398600000'); 
INSERT INTO `wp_postmeta` VALUES ('1658', '374', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1659', '374', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1660', '374', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1661', '374', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1662', '374', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1663', '374', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1664', '374', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1665', '374', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1666', '374', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1667', '374', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1668', '374', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1669', '374', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1670', '374', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1671', '374', 'grade_1_horario', '1398560400'); 
INSERT INTO `wp_postmeta` VALUES ('1672', '374', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1673', '374', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1674', '374', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1675', '374', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1676', '374', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1677', '374', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1678', '374', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1679', '374', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1680', '374', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1681', '374', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1682', '374', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1683', '374', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1684', '374', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1685', '374', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1686', '374', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1687', '374', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('1688', '374', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1689', '374', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('1690', '374', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1691', '374', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('1692', '374', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1693', '374', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('1694', '374', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1697', '375', 'upload_do_banner', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1698', '375', '_upload_do_banner', 'field_535afeeb5871c'); 
INSERT INTO `wp_postmeta` VALUES ('1699', '375', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1700', '375', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1701', '375', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1702', '375', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1703', '375', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1704', '375', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1705', '375', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1706', '375', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1707', '375', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1708', '375', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1709', '375', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1710', '375', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1711', '375', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1712', '375', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1713', '375', 'patrocinadores', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1714', '375', '_patrocinadores', 'field_535c54f61960d'); 
INSERT INTO `wp_postmeta` VALUES ('1715', '375', 'grade_0_horario', '1398600000'); 
INSERT INTO `wp_postmeta` VALUES ('1716', '375', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1717', '375', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1718', '375', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1719', '375', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1720', '375', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1721', '375', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1722', '375', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1723', '375', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1724', '375', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1725', '375', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1726', '375', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1727', '375', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1728', '375', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1729', '375', 'grade_1_horario', '1398560400'); 
INSERT INTO `wp_postmeta` VALUES ('1730', '375', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1731', '375', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1732', '375', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1733', '375', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1734', '375', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1735', '375', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1736', '375', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1737', '375', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1738', '375', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1739', '375', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1740', '375', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1741', '375', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1742', '375', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1743', '375', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1744', '375', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('1745', '375', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('1746', '375', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1747', '375', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('1748', '375', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1749', '375', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('1750', '375', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('1751', '375', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('1752', '375', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('1753', '332', 'field_535d5655f7e4a', 'a:10:{s:3:"key";s:19:"field_535d5655f7e4a";s:5:"label";s:14:"Permitido para";s:4:"name";s:14:"permitido_para";s:4:"type";s:13:"role_selector";s:12:"instructions";s:36:"Quem poderá se inscrever no evento?";s:8:"required";s:1:"0";s:12:"return_value";s:4:"name";s:10:"field_type";s:12:"multi_select";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:7;}'); 
INSERT INTO `wp_postmeta` VALUES ('1757', '376', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398626757.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1758', '376', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1759', '376', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1760', '376', 'backup_size', '0.15 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1761', '377', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398713159.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1762', '377', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1763', '377', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1764', '377', 'backup_size', '0.15 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1765', '378', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398807894.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1766', '378', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1767', '378', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1768', '378', 'backup_size', '0.15 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1781', '395', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398952556.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1782', '395', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1783', '395', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1784', '395', 'backup_size', '0.15 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1785', '397', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1398972426.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1786', '397', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1787', '397', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1788', '397', 'backup_size', '0.15 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1789', '398', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1399133890.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1790', '398', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1791', '398', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1792', '398', 'backup_size', '0.14 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1793', '399', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1399145267.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1794', '399', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1795', '399', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1796', '399', 'backup_size', '0.14 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1797', '400', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1399231948.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1798', '400', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1799', '400', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1800', '400', 'backup_size', '0.14 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1801', '401', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1401490846.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1802', '401', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1803', '401', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1804', '401', 'backup_size', '0.14 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1805', '402', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1401750756.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1806', '402', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1807', '402', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1808', '402', 'backup_size', '0.14 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1809', '404', '_edit_lock', '1401202881:1'); 
INSERT INTO `wp_postmeta` VALUES ('1810', '404', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1811', '404', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('1812', '405', '_edit_lock', '1401215768:1'); 
INSERT INTO `wp_postmeta` VALUES ('1813', '405', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1814', '405', '_wp_page_template', 'default'); 
INSERT INTO `wp_postmeta` VALUES ('1815', '407', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('1816', '407', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1817', '407', '_menu_item_object_id', '336'); 
INSERT INTO `wp_postmeta` VALUES ('1818', '407', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('1819', '407', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('1820', '407', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('1821', '407', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('1822', '407', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('1823', '408', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1401883924.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1824', '408', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1825', '408', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1826', '408', 'backup_size', '0.13 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1827', '409', '_edit_lock', '1401884718:1'); 
INSERT INTO `wp_postmeta` VALUES ('1828', '410', '_edit_lock', '1401886093:1'); 
INSERT INTO `wp_postmeta` VALUES ('1829', '410', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1830', '298', 'issuu_pdf_id', '140604124725-7810a52e346e4b68bf737147d521cabc'); 
INSERT INTO `wp_postmeta` VALUES ('1831', '298', 'issuu_pdf_username', 'asugnews'); 
INSERT INTO `wp_postmeta` VALUES ('1832', '298', 'issuu_pdf_name', 'passei_online_menor_1'); 
INSERT INTO `wp_postmeta` VALUES ('1833', '187', 'issuu_pdf_id', '140604124726-d94aca0a3cf4422b818230aa40d7b93e'); 
INSERT INTO `wp_postmeta` VALUES ('1834', '187', 'issuu_pdf_username', 'asugnews'); 
INSERT INTO `wp_postmeta` VALUES ('1835', '187', 'issuu_pdf_name', 'cartao-sms'); 
INSERT INTO `wp_postmeta` VALUES ('1836', '411', '_edit_lock', '1401887819:1'); 
INSERT INTO `wp_postmeta` VALUES ('1837', '412', '_wp_attached_file', '2014/06/HWM_P_2014_06_downmagaz.com_.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('1838', '412', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('1839', '412', 'issuu_pdf_id', '140604125118-4d6564659e5f4ebe96b3cce40c94ded1'); 
INSERT INTO `wp_postmeta` VALUES ('1840', '412', 'issuu_pdf_username', 'asugnews'); 
INSERT INTO `wp_postmeta` VALUES ('1841', '412', 'issuu_pdf_name', 'hwm_p_2014_06_downmagaz-com'); 
INSERT INTO `wp_postmeta` VALUES ('1842', '411', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1843', '415', '_wp_attached_file', '2014/06/teste.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('1844', '415', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('1845', '415', 'issuu_pdf_id', '140604125757-5b4fe67daf2b44ccbd0ea2000ed66451'); 
INSERT INTO `wp_postmeta` VALUES ('1846', '415', 'issuu_pdf_username', 'asugnews'); 
INSERT INTO `wp_postmeta` VALUES ('1847', '415', 'issuu_pdf_name', 'teste'); 
INSERT INTO `wp_postmeta` VALUES ('1848', '416', '_wp_attached_file', '2014/06/2.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('1849', '416', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('1850', '416', 'issuu_pdf_id', '140604130731-3d76c6cf25c9485eb1cde6d0bda0fd1d'); 
INSERT INTO `wp_postmeta` VALUES ('1851', '416', 'issuu_pdf_username', 'asugnews'); 
INSERT INTO `wp_postmeta` VALUES ('1852', '416', 'issuu_pdf_name', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1853', '419', '_wp_attached_file', '2014/06/21.pdf'); 
INSERT INTO `wp_postmeta` VALUES ('1854', '419', '_wp_attachment_metadata', 'a:1:{s:20:"ewww_image_optimizer";s:74:"Missing finfo_file(), getimagesize() and mime_content_type() PHP functions";}'); 
INSERT INTO `wp_postmeta` VALUES ('1855', '419', 'issuu_pdf_id', '140604131010-06e24ac9938d4de994fa25d56ce7e10e'); 
INSERT INTO `wp_postmeta` VALUES ('1856', '419', 'issuu_pdf_username', 'asugnews'); 
INSERT INTO `wp_postmeta` VALUES ('1857', '419', 'issuu_pdf_name', '2-2'); 
INSERT INTO `wp_postmeta` VALUES ('1858', '421', '_edit_lock', '1401888162:1'); 
INSERT INTO `wp_postmeta` VALUES ('1859', '421', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1862', '421', '_wp_trash_meta_status', 'draft'); 
INSERT INTO `wp_postmeta` VALUES ('1863', '421', '_wp_trash_meta_time', '1401889895'); 
INSERT INTO `wp_postmeta` VALUES ('1864', '411', '_wp_trash_meta_status', 'draft'); 
INSERT INTO `wp_postmeta` VALUES ('1865', '411', '_wp_trash_meta_time', '1401889896'); 
INSERT INTO `wp_postmeta` VALUES ('1866', '410', '_wp_trash_meta_status', 'draft'); 
INSERT INTO `wp_postmeta` VALUES ('1867', '410', '_wp_trash_meta_time', '1401889896'); 
INSERT INTO `wp_postmeta` VALUES ('1868', '424', '_edit_lock', '1401890233:1'); 
INSERT INTO `wp_postmeta` VALUES ('1869', '425', '_edit_lock', '1401890258:1'); 
INSERT INTO `wp_postmeta` VALUES ('1870', '426', '_edit_lock', '1401890291:1'); 
INSERT INTO `wp_postmeta` VALUES ('1871', '427', '_edit_lock', '1401890315:1'); 
INSERT INTO `wp_postmeta` VALUES ('1872', '429', '_edit_lock', '1401890379:1'); 
INSERT INTO `wp_postmeta` VALUES ('1873', '430', '_edit_lock', '1401890421:1'); 
INSERT INTO `wp_postmeta` VALUES ('1874', '431', '_edit_lock', '1401890626:1'); 
INSERT INTO `wp_postmeta` VALUES ('1875', '432', '_edit_lock', '1401890648:1'); 
INSERT INTO `wp_postmeta` VALUES ('1876', '433', '_edit_lock', '1401890677:1'); 
INSERT INTO `wp_postmeta` VALUES ('1877', '434', '_edit_lock', '1401890735:1'); 
INSERT INTO `wp_postmeta` VALUES ('1878', '435', '_edit_lock', '1401890854:1'); 
INSERT INTO `wp_postmeta` VALUES ('1879', '436', '_edit_lock', '1401890960:1'); 
INSERT INTO `wp_postmeta` VALUES ('1880', '437', '_edit_lock', '1401891359:1'); 
INSERT INTO `wp_postmeta` VALUES ('1881', '439', '_edit_lock', '1401891439:1'); 
INSERT INTO `wp_postmeta` VALUES ('1882', '440', '_edit_lock', '1401898347:1'); 
INSERT INTO `wp_postmeta` VALUES ('1883', '441', '_edit_lock', '1401899531:1'); 
INSERT INTO `wp_postmeta` VALUES ('1884', '441', '_edit_last', '1'); 
INSERT INTO `wp_postmeta` VALUES ('1885', '442', '_wp_attached_file', '2014/06/bn-ret.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('1886', '442', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:476;s:6:"height";i:248;s:4:"file";s:18:"2014/06/bn-ret.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"bn-ret-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:59:"Reduced by 6.3% (502,0&nbsp;B&nbsp;) - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:18:"bn-ret-300x156.jpg";s:5:"width";i:300;s:6:"height";i:156;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:59:"Reduced by 6.3% (966,0&nbsp;B&nbsp;) - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:36:"Reduced by 1.6% (580,0&nbsp;B&nbsp;)";}'); 
INSERT INTO `wp_postmeta` VALUES ('1887', '441', '_dfads_impression_limit', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1888', '441', '_dfads_impression_count', '29'); 
INSERT INTO `wp_postmeta` VALUES ('1889', '444', '_menu_item_type', 'post_type'); 
INSERT INTO `wp_postmeta` VALUES ('1890', '444', '_menu_item_menu_item_parent', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1891', '444', '_menu_item_object_id', '6'); 
INSERT INTO `wp_postmeta` VALUES ('1892', '444', '_menu_item_object', 'page'); 
INSERT INTO `wp_postmeta` VALUES ('1893', '444', '_menu_item_target', ''); 
INSERT INTO `wp_postmeta` VALUES ('1894', '444', '_menu_item_classes', 'a:1:{i:0;s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('1895', '444', '_menu_item_xfn', ''); 
INSERT INTO `wp_postmeta` VALUES ('1896', '444', '_menu_item_url', ''); 
INSERT INTO `wp_postmeta` VALUES ('1898', '447', '_wp_attached_file', '2014/03/pilares.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('1899', '447', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:560;s:6:"height";i:400;s:4:"file";s:19:"2014/03/pilares.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:19:"pilares-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:60:"Reduced by 10.5% (744,0&nbsp;B&nbsp;) - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:19:"pilares-300x214.jpg";s:5:"width";i:300;s:6:"height";i:214;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:53:"Reduced by 10.5% (1,5&nbsp;kB) - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:36:"Reduced by 1.8% (743,0&nbsp;B&nbsp;)";}'); 
INSERT INTO `wp_postmeta` VALUES ('1900', '6', '_thumbnail_id', '120'); 
INSERT INTO `wp_postmeta` VALUES ('1901', '452', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1401909974.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1902', '452', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1903', '452', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1904', '452', 'backup_size', '0.13 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1905', '453', '_edit_lock', '1401922457:1'); 
INSERT INTO `wp_postmeta` VALUES ('1906', '454', 'backup_location', 'C:xampphtdocsasug/wp-content/uploads/wpbu-backups/1402002745.zip'); 
INSERT INTO `wp_postmeta` VALUES ('1907', '454', 'backup_type', 'Database'); 
INSERT INTO `wp_postmeta` VALUES ('1908', '454', 'backup_status', 'Completed'); 
INSERT INTO `wp_postmeta` VALUES ('1909', '454', 'backup_size', '0.13 MB'); 
INSERT INTO `wp_postmeta` VALUES ('1912', '455', 'upload_da_revista', '298'); 
INSERT INTO `wp_postmeta` VALUES ('1913', '455', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('1914', '455', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('1915', '455', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('1916', '455', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('1928', '457', 'upload_da_revista', '298'); 
INSERT INTO `wp_postmeta` VALUES ('1929', '457', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('1930', '457', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('1931', '457', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('1932', '457', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('1935', '458', 'upload_da_revista', '298'); 
INSERT INTO `wp_postmeta` VALUES ('1936', '458', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('1937', '458', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('1938', '458', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('1939', '458', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('1943', '460', 'upload_da_revista', '298'); 
INSERT INTO `wp_postmeta` VALUES ('1944', '460', '_upload_da_revista', 'field_53373670701de'); 
INSERT INTO `wp_postmeta` VALUES ('1945', '460', 'capa_da_revista', '214'); 
INSERT INTO `wp_postmeta` VALUES ('1946', '460', '_capa_da_revista', 'field_533745765a5ee'); 
INSERT INTO `wp_postmeta` VALUES ('1947', '460', '_', 'field_5337459f5a5ef'); 
INSERT INTO `wp_postmeta` VALUES ('1948', '332', 'rule', 'a:5:{s:5:"param";s:13:"post_category";s:8:"operator";s:2:"==";s:5:"value";s:2:"21";s:8:"order_no";i:0;s:8:"group_no";i:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('1949', '461', '_wp_attached_file', '2014/04/banner-conf.jpg'); 
INSERT INTO `wp_postmeta` VALUES ('1950', '461', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1024;s:6:"height";i:248;s:4:"file";s:23:"2014/04/banner-conf.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:23:"banner-conf-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:59:"Reduced by 7.9% (636,0&nbsp;B&nbsp;) - Previously Optimized";}s:6:"medium";a:5:{s:4:"file";s:22:"banner-conf-300x72.jpg";s:5:"width";i:300;s:6:"height";i:72;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:59:"Reduced by 6.6% (615,0&nbsp;B&nbsp;) - Previously Optimized";}s:14:"post-thumbnail";a:5:{s:4:"file";s:23:"banner-conf-624x151.jpg";s:5:"width";i:624;s:6:"height";i:151;s:9:"mime-type";s:10:"image/jpeg";s:20:"ewww_image_optimizer";s:52:"Reduced by 8.2% (2,3&nbsp;kB) - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:29:"Reduced by 2.7% (1,8&nbsp;kB)";}'); 
INSERT INTO `wp_postmeta` VALUES ('1951', '364', '_thumbnail_id', '461'); 
INSERT INTO `wp_postmeta` VALUES ('1954', '462', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('1955', '462', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('1956', '462', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('1957', '462', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('1958', '462', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('1959', '462', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('1960', '462', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('1961', '462', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('1962', '462', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('1963', '462', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('1964', '462', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('1965', '462', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('1966', '462', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('1967', '462', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('1968', '462', 'patrocinadores', '0'); 
INSERT INTO `wp_postmeta` VALUES ('1969', '462', '_patrocinadores', 'field_535c54f61960d'); 
INSERT INTO `wp_postmeta` VALUES ('1970', '462', 'grade_0_horario', '1402056000'); 
INSERT INTO `wp_postmeta` VALUES ('1971', '462', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1972', '462', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('1973', '462', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1974', '462', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('1975', '462', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1976', '462', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('1977', '462', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1978', '462', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('1979', '462', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1980', '462', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('1981', '462', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1982', '462', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('1983', '462', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1984', '462', 'grade_1_horario', '1402016400'); 
INSERT INTO `wp_postmeta` VALUES ('1985', '462', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('1986', '462', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('1987', '462', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('1988', '462', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('1989', '462', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('1990', '462', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('1991', '462', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('1992', '462', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('1993', '462', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('1994', '462', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('1995', '462', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('1996', '462', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('1997', '462', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('1998', '462', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('1999', '462', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('2000', '462', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('2001', '462', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('2002', '462', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('2003', '462', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('2004', '462', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('2005', '462', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('2006', '462', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('2007', '462', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('2010', '463', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('2011', '463', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('2012', '463', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('2013', '463', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('2014', '463', 'botao_de_cadastro', '64'); 
INSERT INTO `wp_postmeta` VALUES ('2015', '463', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('2016', '463', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('2017', '463', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('2018', '463', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('2019', '463', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('2020', '463', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('2021', '463', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('2022', '463', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('2023', '463', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('2024', '463', 'patrocinadores', '0'); 
INSERT INTO `wp_postmeta` VALUES ('2025', '463', '_patrocinadores', 'field_535c54f61960d'); 
INSERT INTO `wp_postmeta` VALUES ('2026', '463', 'grade_0_horario', '1402056000'); 
INSERT INTO `wp_postmeta` VALUES ('2027', '463', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('2028', '463', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('2029', '463', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('2030', '463', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('2031', '463', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('2032', '463', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('2033', '463', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('2034', '463', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('2035', '463', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('2036', '463', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('2037', '463', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('2038', '463', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('2039', '463', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('2040', '463', 'grade_1_horario', '1402016400'); 
INSERT INTO `wp_postmeta` VALUES ('2041', '463', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('2042', '463', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('2043', '463', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('2044', '463', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('2045', '463', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('2046', '463', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('2047', '463', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('2048', '463', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('2049', '463', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('2050', '463', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('2051', '463', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('2052', '463', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('2053', '463', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('2054', '463', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('2055', '463', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('2056', '463', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('2057', '463', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('2058', '463', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('2059', '463', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('2060', '463', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('2061', '463', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('2062', '463', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('2063', '463', '_fotos', 'field_535c3023bb097'); 
INSERT INTO `wp_postmeta` VALUES ('2064', '464', '_wp_attached_file', '2014/04/bt-insc.gif'); 
INSERT INTO `wp_postmeta` VALUES ('2065', '464', '_wp_attachment_metadata', 'a:6:{s:5:"width";i:200;s:6:"height";i:33;s:4:"file";s:19:"2014/04/bt-insc.gif";s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"bt-insc-150x33.gif";s:5:"width";i:150;s:6:"height";i:33;s:9:"mime-type";s:9:"image/gif";s:20:"ewww_image_optimizer";s:33:"No savings - Previously Optimized";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}s:20:"ewww_image_optimizer";s:10:"No savings";}'); 
INSERT INTO `wp_postmeta` VALUES ('2068', '465', 'data_do_evento', '20/06/2014'); 
INSERT INTO `wp_postmeta` VALUES ('2069', '465', '_data_do_evento', 'field_535aff2f5871d'); 
INSERT INTO `wp_postmeta` VALUES ('2070', '465', 'local_do_evento', 'a:3:{s:7:"address";s:51:"Av. Goiás, 3235, Santo Antonio, São Paulo, Brasil";s:3:"lat";s:11:"-23.6232156";s:3:"lng";s:11:"-46.5483557";}'); 
INSERT INTO `wp_postmeta` VALUES ('2071', '465', '_local_do_evento', 'field_535affcf5871e'); 
INSERT INTO `wp_postmeta` VALUES ('2072', '465', 'botao_de_cadastro', '464'); 
INSERT INTO `wp_postmeta` VALUES ('2073', '465', '_botao_de_cadastro', 'field_535b00015871f'); 
INSERT INTO `wp_postmeta` VALUES ('2074', '465', 'usuario_registrado', '2000'); 
INSERT INTO `wp_postmeta` VALUES ('2075', '465', '_usuario_registrado', 'field_535b004658720'); 
INSERT INTO `wp_postmeta` VALUES ('2076', '465', 'empresa_parceira', '1800'); 
INSERT INTO `wp_postmeta` VALUES ('2077', '465', '_empresa_parceira', 'field_535b008b58721'); 
INSERT INTO `wp_postmeta` VALUES ('2078', '465', 'empresa_cliente', '1500'); 
INSERT INTO `wp_postmeta` VALUES ('2079', '465', '_empresa_cliente', 'field_535b00a958722'); 
INSERT INTO `wp_postmeta` VALUES ('2080', '465', 'nao_associado', '2500'); 
INSERT INTO `wp_postmeta` VALUES ('2081', '465', '_nao_associado', 'field_535b00bf58723'); 
INSERT INTO `wp_postmeta` VALUES ('2082', '465', 'patrocinadores', '0'); 
INSERT INTO `wp_postmeta` VALUES ('2083', '465', '_patrocinadores', 'field_535c54f61960d'); 
INSERT INTO `wp_postmeta` VALUES ('2084', '465', 'grade_0_horario', '1402056000'); 
INSERT INTO `wp_postmeta` VALUES ('2085', '465', '_grade_0_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('2086', '465', 'grade_0_titulo_da_palestra', 'HR'); 
INSERT INTO `wp_postmeta` VALUES ('2087', '465', '_grade_0_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('2088', '465', 'grade_0_detalhes_da_palestra', 'Palestra sobre <strong>HR</strong>'); 
INSERT INTO `wp_postmeta` VALUES ('2089', '465', '_grade_0_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('2090', '465', 'grade_0_palestrante', 'Francisco'); 
INSERT INTO `wp_postmeta` VALUES ('2091', '465', '_grade_0_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('2092', '465', 'grade_0_sala', 'Sala norte'); 
INSERT INTO `wp_postmeta` VALUES ('2093', '465', '_grade_0_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('2094', '465', 'grade_0_capacidade_da_sala', '750'); 
INSERT INTO `wp_postmeta` VALUES ('2095', '465', '_grade_0_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('2096', '465', 'grade_0_upload_do_material', '134'); 
INSERT INTO `wp_postmeta` VALUES ('2097', '465', '_grade_0_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('2098', '465', 'grade_1_horario', '1402016400'); 
INSERT INTO `wp_postmeta` VALUES ('2099', '465', '_grade_1_horario', 'field_535b045d2d932'); 
INSERT INTO `wp_postmeta` VALUES ('2100', '465', 'grade_1_titulo_da_palestra', 'Como construir um APP'); 
INSERT INTO `wp_postmeta` VALUES ('2101', '465', '_grade_1_titulo_da_palestra', 'field_535b0b502d933'); 
INSERT INTO `wp_postmeta` VALUES ('2102', '465', 'grade_1_detalhes_da_palestra', 'Palestra sobre APP em IOs e Android'); 
INSERT INTO `wp_postmeta` VALUES ('2103', '465', '_grade_1_detalhes_da_palestra', 'field_535b0b6a2d934'); 
INSERT INTO `wp_postmeta` VALUES ('2104', '465', 'grade_1_palestrante', 'Huck'); 
INSERT INTO `wp_postmeta` VALUES ('2105', '465', '_grade_1_palestrante', 'field_535b0b7f2d935'); 
INSERT INTO `wp_postmeta` VALUES ('2106', '465', 'grade_1_sala', 'Sala Apple'); 
INSERT INTO `wp_postmeta` VALUES ('2107', '465', '_grade_1_sala', 'field_535b0b942d936'); 
INSERT INTO `wp_postmeta` VALUES ('2108', '465', 'grade_1_capacidade_da_sala', '200'); 
INSERT INTO `wp_postmeta` VALUES ('2109', '465', '_grade_1_capacidade_da_sala', 'field_535b0ba32d937'); 
INSERT INTO `wp_postmeta` VALUES ('2110', '465', 'grade_1_upload_do_material', '187'); 
INSERT INTO `wp_postmeta` VALUES ('2111', '465', '_grade_1_upload_do_material', 'field_535b0bb72d938'); 
INSERT INTO `wp_postmeta` VALUES ('2112', '465', 'grade', '2'); 
INSERT INTO `wp_postmeta` VALUES ('2113', '465', '_grade', 'field_535b04522d931'); 
INSERT INTO `wp_postmeta` VALUES ('2114', '465', 'fotos_0_foto_do_evento', '322'); 
INSERT INTO `wp_postmeta` VALUES ('2115', '465', '_fotos_0_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('2116', '465', 'fotos_1_foto_do_evento', '310'); 
INSERT INTO `wp_postmeta` VALUES ('2117', '465', '_fotos_1_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('2118', '465', 'fotos_2_foto_do_evento', '77'); 
INSERT INTO `wp_postmeta` VALUES ('2119', '465', '_fotos_2_foto_do_evento', 'field_535c303abb098'); 
INSERT INTO `wp_postmeta` VALUES ('2120', '465', 'fotos', '3'); 
INSERT INTO `wp_postmeta` VALUES ('2121', '465', '_fotos', 'field_535c3023bb097'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_posts`
--
DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=466 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_posts`
--
LOCK TABLES `wp_posts` WRITE;
INSERT INTO `wp_posts` VALUES ('1', '1', '2014-03-15 15:51:25', '2014-03-15 15:51:25', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG Day Porto Alegre 2013', '', 'publish', 'open', 'open', '', 'asug-day-porto-alegre-2013', '', '', '2014-03-16 23:45:36', '2014-03-16 23:45:36', '', '0', 'http://127.0.0.1/asug/?p=1', '0', 'post', '', '1'); 
INSERT INTO `wp_posts` VALUES ('2', '1', '2014-03-15 15:51:25', '2014-03-15 15:51:25', '', 'Home', '', 'publish', 'open', 'open', '', 'pagina-exemplo', '', '', '2014-04-23 00:21:50', '2014-04-23 00:21:50', '', '0', 'http://127.0.0.1/asug/?page_id=2', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('4', '1', '2014-03-15 15:55:31', '2014-03-15 15:55:31', '<p>Assunto (obrigatório)<br />
   [select* assunto include_blank "Grupo de pesquisas" "Portal ASUG" "Como se associar" "Assuntos gerais"]</p>

<p>[text* nome placeholder "Nome"] </p>

<p>[text* empresa placeholder "Empresa"] </p>

<p>[email* email placeholder "E-mail"] </p>

<p>[tel* telefone placeholder "Telefone "] </p>

<p>Sua mensagem<br />
    [textarea* your-message] </p>

<p>[submit "Enviar"]</p>
[your-subject]
[your-name] <[your-email]>
De: [your-name] <[your-email]>
Assunto: [your-subject]

Corpo da mensagem:
[your-message]

--
Este e-mail foi enviado de um formulário de contato em Asug | SAP NetWeaver Portal (http://127.0.0.1/asug)
felipe@montarsite.com.br




[your-subject]
[your-name] <[your-email]>
Corpo da mensagem:
[your-message]

--
Este e-mail foi enviado de um formulário de contato em Asug | SAP NetWeaver Portal (http://127.0.0.1/asug)
[your-email]



Sua mensagem foi enviada com sucesso. Obrigado.
Não foi possível enviar a sua mensagem. Por favor, tente mais tarde ou contate o administrador por outro método.
Ocorreram erros de validação. Por favor confira os dados e envie novamente.
Não foi possível enviar a sua mensagem. Por favor, tente mais tarde ou contate o administrador por outro método.
Por favor aceite os termos para prosseguir.
Por favor preencha este campo obrigatório.
O código digitado está incorreto.
Formato de número parece inválido.
Este número é muito pequeno.
Este número é muito grande.
O endereço de e-mail parece inválido.
URL parece inválido.
Telefone parece inválido.
Sua resposta está incorreta.
Formato da data parece inválido.
Esta data é demasiado primeira.
Esta data é demasiado tarde.
Falha no upload do arquivo.
Este tipo de arquivo não é permitido.
Este arquivo é grande demais.
Falha no upload do arquivo.', 'Formulário de contato 1', '', 'publish', 'open', 'open', '', 'formulario-de-contato-1', '', '', '2014-06-04 17:43:09', '2014-06-04 17:43:09', '', '0', 'http://127.0.0.1/asug/?post_type=wpcf7_contact_form&#038;p=4', '0', 'wpcf7_contact_form', '', '0'); 
INSERT INTO `wp_posts` VALUES ('5', '1', '2014-03-15 16:34:13', '2014-03-15 16:34:13', 'Esta é uma página de exemplo. É diferente de um post porque ela ficará em um local e será exibida na navegação do seu site (na maioria dos temas). A maioria das pessoas começa com uma página de introdução aos potenciais visitantes do site. Ela pode ser assim:
<blockquote>Olá! Eu sou um bike courrier de dia, ator amador à noite e este é meu blog. Eu moro em São Paulo, tenho um cachorro chamado Tonico e eu gosto de caipirinhas. (E de ser pego pela chuva.)</blockquote>
ou assim:
<blockquote>A XYZ foi fundada em 1971 e desde então vem proporcionando produtos de qualidade a seus clientes. Localizada em Valinhos, XYZ emprega mais de 2.000 pessoas e faz várias contribuições para a comunidade local.</blockquote>
Como um novo usuário do WordPress, você deve ir até o <a href="http://127.0.0.1/asug/wp-admin/">seu painel</a> para excluir essa página e criar novas páginas com seu próprio conteúdo. Divirta-se!', 'Home', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-03-15 16:34:13', '2014-03-15 16:34:13', '', '2', 'http://127.0.0.1/asug/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('6', '1', '2014-03-15 16:34:43', '2014-03-15 16:34:43', '<iframe width="100%" height="400" src="//www.youtube.com/embed/9Bo9kf9BJrI" frameborder="0" allowfullscreen></iframe>
<h2>CONHEÇA A ASUG BRASIL</h2>
ASUG Brasil (Associação dos Usuários SAP do Brasil) é uma entidade sem fins lucrativos que reúne clientes da SAP e parceiros credenciados (fornecedores e consultores), a fim de inteirá-los sobre a utilização de software desenvolvido pela SAP. Para isso, organiza conferências, seminários, premiações e reuniões de grupos sobre temas específicos. Desses eventos, surgem dúvidas, necessidades, aplicações de software SAP e troca de experiência entre os associados. A ASUG é o caminho mais seguro e rápido para os usuários agirem em conjunto, determinando prioridades e monitorando o desenvolvimento e o avanço tecnológico de aplicações SAP, por intermédio de requerimentos gerados nos Grupos de Pesquisa e Estudo e encaminhados à SAP Alemanha, para solução.
<h2>MISSÃO ASUG</h2>
"Agregar valor aos associados por meio da busca de soluções comuns, do compartilhamento do conhecimento e da representação dos interesses coletivos junto à SAP."
<h2>PILARES DA ASUG</h2>
<img class="aligncenter size-full wp-image-447" src="http://127.0.0.1/asug/wp-content/uploads/2014/03/pilares.jpg" alt="pilares" width="560" height="400" />
<h2>PORTAL ASUG - www.asug.com.br</h2>
O meio mais fácil de associar a sua empresa. É um portal com páginas públicas e privativas dos associados ASUG Brasil, contendo os seguintes assuntos: Apresentação, banco de atas, banco de desenvolvimento, lista de associados, diretoria, grupos de estudo, sala de chat, eventos, etc. Está em constante atualização, acompanhando as necessidades e os desejos dos associados.', 'Institucional', '', 'publish', 'open', 'open', '', 'institucional', '', '', '2014-06-04 16:43:30', '2014-06-04 16:43:30', '', '0', 'http://127.0.0.1/asug/?page_id=6', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('7', '1', '2014-03-15 16:34:43', '2014-03-15 16:34:43', '', 'Institucional', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-03-15 16:34:43', '2014-03-15 16:34:43', '', '6', 'http://127.0.0.1/asug/6-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('8', '1', '2014-03-15 16:35:03', '2014-03-15 16:35:03', '', 'Associe-se', '', 'publish', 'open', 'open', '', 'associe-se', '', '', '2014-03-15 16:35:03', '2014-03-15 16:35:03', '', '0', 'http://127.0.0.1/asug/?page_id=8', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('9', '1', '2014-03-15 16:35:03', '2014-03-15 16:35:03', '', 'Associe-se', '', 'inherit', 'open', 'open', '', '8-revision-v1', '', '', '2014-03-15 16:35:03', '2014-03-15 16:35:03', '', '8', 'http://127.0.0.1/asug/8-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('16', '1', '2014-03-15 16:36:39', '2014-03-15 16:36:39', '', 'Conferência anual', '', 'publish', 'open', 'open', '', 'conferencia-anual', '', '', '2014-03-15 16:36:39', '2014-03-15 16:36:39', '', '0', 'http://127.0.0.1/asug/?page_id=16', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('17', '1', '2014-03-15 16:36:39', '2014-03-15 16:36:39', '', 'Conferência anual', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2014-03-15 16:36:39', '2014-03-15 16:36:39', '', '16', 'http://127.0.0.1/asug/16-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('18', '1', '2014-03-15 16:37:04', '2014-03-15 16:37:04', '', 'Impact awards', '', 'publish', 'open', 'open', '', 'impact-awards', '', '', '2014-03-15 16:37:04', '2014-03-15 16:37:04', '', '0', 'http://127.0.0.1/asug/?page_id=18', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('19', '1', '2014-03-15 16:37:04', '2014-03-15 16:37:04', '', 'Impact awards', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2014-03-15 16:37:04', '2014-03-15 16:37:04', '', '18', 'http://127.0.0.1/asug/18-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('20', '1', '2014-03-15 16:37:26', '2014-03-15 16:37:26', '', 'Asug Day', '', 'publish', 'open', 'open', '', 'asug-day', '', '', '2014-04-12 19:21:12', '2014-04-12 19:21:12', '', '0', 'http://127.0.0.1/asug/?page_id=20', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('21', '1', '2014-03-15 16:37:26', '2014-03-15 16:37:26', '', 'Asug Day', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2014-03-15 16:37:26', '2014-03-15 16:37:26', '', '20', 'http://127.0.0.1/asug/20-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('22', '1', '2014-03-15 16:37:42', '2014-03-15 16:37:42', '', 'Asug News', '', 'publish', 'open', 'open', '', 'asug-news', '', '', '2014-04-12 19:21:54', '2014-04-12 19:21:54', '', '0', 'http://127.0.0.1/asug/?page_id=22', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('23', '1', '2014-03-15 16:37:42', '2014-03-15 16:37:42', '', 'Asug News', '', 'inherit', 'open', 'open', '', '22-revision-v1', '', '', '2014-03-15 16:37:42', '2014-03-15 16:37:42', '', '22', 'http://127.0.0.1/asug/22-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('35', '1', '2014-03-15 16:39:04', '2014-03-15 16:39:04', '', 'Diretoria', '', 'publish', 'open', 'open', '', 'diretoria', '', '', '2014-03-15 16:39:04', '2014-03-15 16:39:04', '', '6', 'http://127.0.0.1/asug/?page_id=35', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('36', '1', '2014-03-15 16:39:04', '2014-03-15 16:39:04', '', 'Diretoria', '', 'inherit', 'open', 'open', '', '35-revision-v1', '', '', '2014-03-15 16:39:04', '2014-03-15 16:39:04', '', '35', 'http://127.0.0.1/asug/35-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('37', '1', '2014-03-15 16:39:31', '2014-03-15 16:39:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Morbi in elementum justo. Aenean commodo sapien vulputate, vehicula lectus non, luctus augue. Nullam pulvinar tincidunt elementum. Integer ipsum neque, fermentum eu dignissim id, ultrices a augue. Integer eleifend neque in nisi euismod condimentum. Vestibulum mauris metus, hendrerit at lectus vel, sollicitudin semper libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla arcu dui, feugiat quis blandit id, elementum at est. Maecenas a nulla imperdiet, egestas est sit amet, cursus lacus. Nunc in ullamcorper mi. Nam purus nulla, cursus eu ornare ut, pellentesque in sapien. Sed ornare sapien nec erat pretium, mollis tincidunt nisl feugiat. Fusce at varius neque, ut vulputate ipsum. Duis sit amet odio lobortis, interdum turpis sit amet, tempor enim. Etiam justo urna, ullamcorper eget mollis vitae, hendrerit ut erat. Duis viverra malesuada consequat.

Nulla venenatis urna a massa suscipit feugiat. Nulla facilisi. Integer libero odio, ultrices et dui ac, cursus sollicitudin sem. Sed ut libero non nulla aliquam accumsan. Nam blandit purus sit amet turpis elementum tincidunt. Nunc quis ipsum sed mauris scelerisque varius at ut nisl. Duis tortor urna, ornare interdum quam at, iaculis lobortis elit. Pellentesque id consectetur felis. Mauris facilisis massa vitae elit consectetur venenatis.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Conselho administrativo', '', 'publish', 'open', 'open', '', 'conselho-administrativo', '', '', '2014-03-20 15:40:28', '2014-03-20 15:40:28', '', '6', 'http://127.0.0.1/asug/?page_id=37', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('38', '1', '2014-03-15 16:39:31', '2014-03-15 16:39:31', '', 'Conselho administrativo', '', 'inherit', 'open', 'open', '', '37-revision-v1', '', '', '2014-03-15 16:39:31', '2014-03-15 16:39:31', '', '37', 'http://127.0.0.1/asug/37-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('39', '1', '2014-03-15 16:39:51', '2014-03-15 16:39:51', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl. Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis. Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'publish', 'open', 'open', '', 'comite-estrategico', '', '', '2014-06-04 16:55:45', '2014-06-04 16:55:45', '', '6', 'http://127.0.0.1/asug/?page_id=39', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('40', '1', '2014-03-15 16:39:51', '2014-03-15 16:39:51', '', 'Comitê estratégico', '', 'inherit', 'open', 'open', '', '39-revision-v1', '', '', '2014-03-15 16:39:51', '2014-03-15 16:39:51', '', '39', 'http://127.0.0.1/asug/39-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('41', '1', '2014-03-15 16:40:22', '2014-03-15 16:40:22', '', 'Empresas associadas', '', 'publish', 'open', 'open', '', 'empresas-associadas', '', '', '2014-03-20 15:40:33', '2014-03-20 15:40:33', '', '6', 'http://127.0.0.1/asug/?page_id=41', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('42', '1', '2014-03-15 16:40:22', '2014-03-15 16:40:22', '', 'Empresas associadas', '', 'inherit', 'open', 'open', '', '41-revision-v1', '', '', '2014-03-15 16:40:22', '2014-03-15 16:40:22', '', '41', 'http://127.0.0.1/asug/41-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('43', '1', '2014-03-15 16:40:46', '2014-03-15 16:40:46', '', 'Parceiros associados', '', 'publish', 'open', 'open', '', 'parceiros-associados', '', '', '2014-03-20 15:40:53', '2014-03-20 15:40:53', '', '6', 'http://127.0.0.1/asug/?page_id=43', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('44', '1', '2014-03-15 16:40:46', '2014-03-15 16:40:46', '', 'Parceiros associados', '', 'inherit', 'open', 'open', '', '43-revision-v1', '', '', '2014-03-15 16:40:46', '2014-03-15 16:40:46', '', '43', 'http://127.0.0.1/asug/43-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('45', '1', '2014-03-15 17:25:27', '2014-03-15 17:25:27', ' ', '', '', 'publish', 'open', 'open', '', '45', '', '', '2014-06-04 16:38:23', '2014-06-04 16:38:23', '', '0', 'http://127.0.0.1/asug/?p=45', '1', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('47', '1', '2014-03-15 17:25:27', '2014-03-15 17:25:27', ' ', '', '', 'publish', 'open', 'open', '', '47', '', '', '2014-06-04 16:38:23', '2014-06-04 16:38:23', '', '0', 'http://127.0.0.1/asug/?p=47', '8', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('48', '1', '2014-03-15 17:25:27', '2014-03-15 17:25:27', ' ', '', '', 'publish', 'open', 'open', '', '48', '', '', '2014-06-04 16:38:24', '2014-06-04 16:38:24', '', '0', 'http://127.0.0.1/asug/?p=48', '11', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('49', '1', '2014-03-15 17:25:28', '2014-03-15 17:25:28', ' ', '', '', 'publish', 'open', 'open', '', '49', '', '', '2014-06-04 16:38:24', '2014-06-04 16:38:24', '', '0', 'http://127.0.0.1/asug/?p=49', '12', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('50', '1', '2014-03-15 17:25:28', '2014-03-15 17:25:28', ' ', '', '', 'publish', 'open', 'open', '', '50', '', '', '2014-06-04 16:38:24', '2014-06-04 16:38:24', '', '0', 'http://127.0.0.1/asug/?p=50', '9', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('54', '1', '2014-03-15 17:25:28', '2014-03-15 17:25:28', ' ', '', '', 'publish', 'open', 'open', '', '54', '', '', '2014-06-04 16:38:24', '2014-06-04 16:38:24', '', '0', 'http://127.0.0.1/asug/?p=54', '10', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('56', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '56', '', '', '2014-06-04 16:38:23', '2014-06-04 16:38:23', '', '6', 'http://127.0.0.1/asug/?p=56', '3', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('57', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '57', '', '', '2014-06-04 16:38:23', '2014-06-04 16:38:23', '', '6', 'http://127.0.0.1/asug/?p=57', '4', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('58', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '58', '', '', '2014-06-04 16:38:23', '2014-06-04 16:38:23', '', '6', 'http://127.0.0.1/asug/?p=58', '5', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('59', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '59', '', '', '2014-06-04 16:38:23', '2014-06-04 16:38:23', '', '6', 'http://127.0.0.1/asug/?p=59', '6', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('60', '1', '2014-03-15 17:25:29', '2014-03-15 17:25:29', ' ', '', '', 'publish', 'open', 'open', '', '60', '', '', '2014-06-04 16:38:23', '2014-06-04 16:38:23', '', '6', 'http://127.0.0.1/asug/?p=60', '7', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('61', '1', '2014-03-15 18:29:14', '2014-03-15 18:29:14', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg', 'asug-brasil.jpg', '', 'inherit', 'closed', 'open', '', 'asug-brasil-jpg', '', '', '2014-03-15 18:29:14', '2014-03-15 18:29:14', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/asug-brasil.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('63', '1', '2014-03-16 04:34:08', '2014-03-16 04:34:08', '', 'slider', '', 'inherit', 'closed', 'open', '', 'slider', '', '', '2014-03-16 04:34:08', '2014-03-16 04:34:08', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/slider.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('64', '1', '2014-03-16 05:06:14', '2014-03-16 05:06:14', '', 'banner03', '', 'inherit', 'closed', 'open', '', 'banner03', '', '', '2014-03-16 05:06:14', '2014-03-16 05:06:14', '', '72', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner03.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('65', '1', '2014-03-16 05:06:17', '2014-03-16 05:06:17', '', 'banner04', '', 'inherit', 'closed', 'open', '', 'banner04', '', '', '2014-03-16 05:06:17', '2014-03-16 05:06:17', '', '74', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner04.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('66', '1', '2014-03-16 05:06:21', '2014-03-16 05:06:21', '', 'banner01', '', 'inherit', 'closed', 'open', '', 'banner01', '', '', '2014-03-16 05:06:21', '2014-03-16 05:06:21', '', '68', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('67', '1', '2014-03-16 05:06:24', '2014-03-16 05:06:24', '', 'banner02', '', 'inherit', 'closed', 'open', '', 'banner02', '', '', '2014-03-16 05:06:24', '2014-03-16 05:06:24', '', '70', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner02.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('68', '1', '2014-03-16 06:11:23', '2014-03-16 06:11:23', '<a href="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg" alt="banner01" width="235" height="122" class="alignnone size-full wp-image-66" /></a>', 'banner01', '', 'publish', 'closed', 'closed', '', 'banner01', '', '', '2014-03-16 06:12:50', '2014-03-16 06:12:50', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&#038;p=68', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('69', '1', '2014-03-16 06:11:23', '2014-03-16 06:11:23', '<a href="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner01.jpg" alt="banner01" width="235" height="122" class="alignnone size-full wp-image-66" /></a>', 'banner01', '', 'inherit', 'closed', 'open', '', '68-revision-v1', '', '', '2014-03-16 06:11:23', '2014-03-16 06:11:23', '', '68', 'http://127.0.0.1/asug/68-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('70', '1', '2014-03-16 06:13:36', '2014-03-16 06:13:36', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner02.jpg" alt="banner02" width="234" height="122" class="alignnone size-full wp-image-67" /></a>', 'banner02', '', 'publish', 'closed', 'closed', '', 'banner02', '', '', '2014-03-16 06:13:36', '2014-03-16 06:13:36', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&#038;p=70', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('71', '1', '2014-03-16 06:13:36', '2014-03-16 06:13:36', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner02.jpg" alt="banner02" width="234" height="122" class="alignnone size-full wp-image-67" /></a>', 'banner02', '', 'inherit', 'closed', 'open', '', '70-revision-v1', '', '', '2014-03-16 06:13:36', '2014-03-16 06:13:36', '', '70', 'http://127.0.0.1/asug/70-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('72', '1', '2014-03-16 06:14:19', '2014-03-16 06:14:19', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner03.jpg" alt="banner03" width="235" height="121" class="alignnone size-full wp-image-64" /></a>', 'banner03', '', 'publish', 'closed', 'closed', '', 'banner03', '', '', '2014-03-16 06:14:19', '2014-03-16 06:14:19', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&#038;p=72', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('73', '1', '2014-03-16 06:14:19', '2014-03-16 06:14:19', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner03.jpg" alt="banner03" width="235" height="121" class="alignnone size-full wp-image-64" /></a>', 'banner03', '', 'inherit', 'closed', 'open', '', '72-revision-v1', '', '', '2014-03-16 06:14:19', '2014-03-16 06:14:19', '', '72', 'http://127.0.0.1/asug/72-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('74', '1', '2014-03-16 06:14:50', '2014-03-16 06:14:50', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner04.jpg" alt="banner04" width="235" height="121" class="alignnone size-full wp-image-65" /></a>', 'banner04', '', 'publish', 'closed', 'closed', '', 'banner04', '', '', '2014-03-16 06:14:50', '2014-03-16 06:14:50', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&#038;p=74', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('75', '1', '2014-03-16 06:14:50', '2014-03-16 06:14:50', '<a href="#"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/03/banner04.jpg" alt="banner04" width="235" height="121" class="alignnone size-full wp-image-65" /></a>', 'banner04', '', 'inherit', 'closed', 'open', '', '74-revision-v1', '', '', '2014-03-16 06:14:50', '2014-03-16 06:14:50', '', '74', 'http://127.0.0.1/asug/74-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('77', '1', '2014-03-16 19:59:29', '2014-03-16 19:59:29', '', 'eventos01', '', 'inherit', 'closed', 'open', '', 'eventos01', '', '', '2014-03-16 19:59:29', '2014-03-16 19:59:29', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/eventos01.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('78', '1', '2014-03-16 19:59:32', '2014-03-16 19:59:32', '', 'eventos02', '', 'inherit', 'closed', 'open', '', 'eventos02', '', '', '2014-03-16 19:59:32', '2014-03-16 19:59:32', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/eventos02.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('79', '1', '2014-03-16 22:38:16', '2014-03-16 22:38:16', 'CONTENTS', 'Eventos', 'CONTENTS', 'publish', 'closed', 'open', '', 'eventos', '', '', '2014-03-16 22:38:16', '2014-03-16 22:38:16', '', '0', 'http://127.0.0.1/asug/eventos/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('80', '1', '2014-03-16 22:38:17', '2014-03-16 22:38:17', 'CONTENTS', 'Locais', '', 'publish', 'closed', 'open', '', 'locais', '', '', '2014-03-16 22:38:17', '2014-03-16 22:38:17', '', '79', 'http://127.0.0.1/asug/eventos/locais/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('81', '1', '2014-03-16 22:38:17', '2014-03-16 22:38:17', 'CONTENTS', 'Categorias', '', 'publish', 'closed', 'open', '', 'categorias', '', '', '2014-03-16 22:38:17', '2014-03-16 22:38:17', '', '79', 'http://127.0.0.1/asug/eventos/categorias/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('82', '1', '2014-03-16 22:38:18', '2014-03-16 22:38:18', 'CONTENTS', 'Tags', '', 'publish', 'closed', 'open', '', 'tags', '', '', '2014-03-16 22:38:18', '2014-03-16 22:38:18', '', '79', 'http://127.0.0.1/asug/eventos/tags/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('83', '1', '2014-03-16 22:38:19', '2014-03-16 22:38:19', 'CONTENTS', 'Minhas Reservas', '', 'publish', 'closed', 'open', '', 'minhas-reservas', '', '', '2014-03-16 22:38:19', '2014-03-16 22:38:19', '', '79', 'http://127.0.0.1/asug/eventos/minhas-reservas/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('86', '1', '2014-03-16 23:39:19', '2014-03-16 23:39:19', '', 'eventos01', '', 'inherit', 'closed', 'open', '', 'eventos01-2', '', '', '2014-03-16 23:39:19', '2014-03-16 23:39:19', '', '1', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/eventos011.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('87', '1', '2014-03-16 23:39:21', '2014-03-16 23:39:21', '', 'eventos02', '', 'inherit', 'closed', 'open', '', 'eventos02-2', '', '', '2014-03-16 23:39:21', '2014-03-16 23:39:21', '', '1', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/eventos021.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('88', '1', '2014-03-16 23:45:29', '2014-03-16 23:45:29', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG Day Porto Alegre 2013', '', 'inherit', 'closed', 'open', '', '1-autosave-v1', '', '', '2014-03-16 23:45:29', '2014-03-16 23:45:29', '', '1', 'http://127.0.0.1/asug/1-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('89', '1', '2014-03-16 23:45:36', '2014-03-16 23:45:36', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG Day Porto Alegre 2013', '', 'inherit', 'closed', 'open', '', '1-revision-v1', '', '', '2014-03-16 23:45:36', '2014-03-16 23:45:36', '', '1', 'http://127.0.0.1/asug/1-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('90', '1', '2014-03-16 23:46:09', '2014-03-16 23:46:09', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY GOIÂNIA 2013', '', 'publish', 'closed', 'open', '', 'asug-day-goiania-2013', '', '', '2014-03-16 23:46:09', '2014-03-16 23:46:09', '', '0', 'http://127.0.0.1/asug/?p=90', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('91', '1', '2014-03-16 23:46:09', '2014-03-16 23:46:09', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY GOIÂNIA 2013', '', 'inherit', 'closed', 'open', '', '90-revision-v1', '', '', '2014-03-16 23:46:09', '2014-03-16 23:46:09', '', '90', 'http://127.0.0.1/asug/90-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('92', '1', '2014-03-16 23:46:37', '2014-03-16 23:46:37', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY SÃO PAULO 2014', '', 'publish', 'closed', 'open', '', 'asug-day-sao-paulo-2014', '', '', '2014-03-16 23:46:37', '2014-03-16 23:46:37', '', '0', 'http://127.0.0.1/asug/?p=92', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('93', '1', '2014-03-16 23:46:37', '2014-03-16 23:46:37', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY SÃO PAULO 2014', '', 'inherit', 'closed', 'open', '', '92-revision-v1', '', '', '2014-03-16 23:46:37', '2014-03-16 23:46:37', '', '92', 'http://127.0.0.1/asug/92-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('94', '1', '2014-03-16 23:47:08', '2014-03-16 23:47:08', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY CURITIBA 2014', '', 'publish', 'closed', 'open', '', 'asug-day-curitiba-2014', '', '', '2014-03-16 23:47:08', '2014-03-16 23:47:08', '', '0', 'http://127.0.0.1/asug/?p=94', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('95', '1', '2014-03-16 23:47:08', '2014-03-16 23:47:08', 'Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!

Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!', 'ASUG DAY CURITIBA 2014', '', 'inherit', 'closed', 'open', '', '94-revision-v1', '', '', '2014-03-16 23:47:08', '2014-03-16 23:47:08', '', '94', 'http://127.0.0.1/asug/94-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('102', '1', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', 'Register', '', 'publish', 'closed', 'open', '', 'register', '', '', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', '0', 'http://127.0.0.1/asug/register/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('103', '1', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', 'Account', '', 'publish', 'closed', 'open', '', 'account', '', '', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', '0', 'http://127.0.0.1/asug/account/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('104', '1', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '<p>The content you are trying to access is only available to members. Sorry.</p>', 'Protected Content', '', 'publish', 'closed', 'open', '', 'protected', '', '', '2014-03-20 02:20:18', '2014-03-20 02:20:18', '', '0', 'http://127.0.0.1/asug/protected/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('111', '1', '2014-03-20 15:39:45', '2014-03-20 15:39:45', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Morbi in elementum justo. Aenean commodo sapien vulputate, vehicula lectus non, luctus augue. Nullam pulvinar tincidunt elementum. Integer ipsum neque, fermentum eu dignissim id, ultrices a augue. Integer eleifend neque in nisi euismod condimentum. Vestibulum mauris metus, hendrerit at lectus vel, sollicitudin semper libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla arcu dui, feugiat quis blandit id, elementum at est. Maecenas a nulla imperdiet, egestas est sit amet, cursus lacus. Nunc in ullamcorper mi. Nam purus nulla, cursus eu ornare ut, pellentesque in sapien. Sed ornare sapien nec erat pretium, mollis tincidunt nisl feugiat. Fusce at varius neque, ut vulputate ipsum. Duis sit amet odio lobortis, interdum turpis sit amet, tempor enim. Etiam justo urna, ullamcorper eget mollis vitae, hendrerit ut erat. Duis viverra malesuada consequat.

Nulla venenatis urna a massa suscipit feugiat. Nulla facilisi. Integer libero odio, ultrices et dui ac, cursus sollicitudin sem. Sed ut libero non nulla aliquam accumsan. Nam blandit purus sit amet turpis elementum tincidunt. Nunc quis ipsum sed mauris scelerisque varius at ut nisl. Duis tortor urna, ornare interdum quam at, iaculis lobortis elit. Pellentesque id consectetur felis. Mauris facilisis massa vitae elit consectetur venenatis.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'inherit', 'closed', 'open', '', '39-revision-v1', '', '', '2014-03-20 15:39:45', '2014-03-20 15:39:45', '', '39', 'http://127.0.0.1/asug/39-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('112', '1', '2014-03-20 15:40:03', '2014-03-20 15:40:03', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Morbi in elementum justo. Aenean commodo sapien vulputate, vehicula lectus non, luctus augue. Nullam pulvinar tincidunt elementum. Integer ipsum neque, fermentum eu dignissim id, ultrices a augue. Integer eleifend neque in nisi euismod condimentum. Vestibulum mauris metus, hendrerit at lectus vel, sollicitudin semper libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla arcu dui, feugiat quis blandit id, elementum at est. Maecenas a nulla imperdiet, egestas est sit amet, cursus lacus. Nunc in ullamcorper mi. Nam purus nulla, cursus eu ornare ut, pellentesque in sapien. Sed ornare sapien nec erat pretium, mollis tincidunt nisl feugiat. Fusce at varius neque, ut vulputate ipsum. Duis sit amet odio lobortis, interdum turpis sit amet, tempor enim. Etiam justo urna, ullamcorper eget mollis vitae, hendrerit ut erat. Duis viverra malesuada consequat.

Nulla venenatis urna a massa suscipit feugiat. Nulla facilisi. Integer libero odio, ultrices et dui ac, cursus sollicitudin sem. Sed ut libero non nulla aliquam accumsan. Nam blandit purus sit amet turpis elementum tincidunt. Nunc quis ipsum sed mauris scelerisque varius at ut nisl. Duis tortor urna, ornare interdum quam at, iaculis lobortis elit. Pellentesque id consectetur felis. Mauris facilisis massa vitae elit consectetur venenatis.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Conselho administrativo', '', 'inherit', 'closed', 'open', '', '37-autosave-v1', '', '', '2014-03-20 15:40:03', '2014-03-20 15:40:03', '', '37', 'http://127.0.0.1/asug/37-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('113', '1', '2014-03-20 15:40:28', '2014-03-20 15:40:28', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Morbi in elementum justo. Aenean commodo sapien vulputate, vehicula lectus non, luctus augue. Nullam pulvinar tincidunt elementum. Integer ipsum neque, fermentum eu dignissim id, ultrices a augue. Integer eleifend neque in nisi euismod condimentum. Vestibulum mauris metus, hendrerit at lectus vel, sollicitudin semper libero. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nulla arcu dui, feugiat quis blandit id, elementum at est. Maecenas a nulla imperdiet, egestas est sit amet, cursus lacus. Nunc in ullamcorper mi. Nam purus nulla, cursus eu ornare ut, pellentesque in sapien. Sed ornare sapien nec erat pretium, mollis tincidunt nisl feugiat. Fusce at varius neque, ut vulputate ipsum. Duis sit amet odio lobortis, interdum turpis sit amet, tempor enim. Etiam justo urna, ullamcorper eget mollis vitae, hendrerit ut erat. Duis viverra malesuada consequat.

Nulla venenatis urna a massa suscipit feugiat. Nulla facilisi. Integer libero odio, ultrices et dui ac, cursus sollicitudin sem. Sed ut libero non nulla aliquam accumsan. Nam blandit purus sit amet turpis elementum tincidunt. Nunc quis ipsum sed mauris scelerisque varius at ut nisl. Duis tortor urna, ornare interdum quam at, iaculis lobortis elit. Pellentesque id consectetur felis. Mauris facilisis massa vitae elit consectetur venenatis.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Conselho administrativo', '', 'inherit', 'closed', 'open', '', '37-revision-v1', '', '', '2014-03-20 15:40:28', '2014-03-20 15:40:28', '', '37', 'http://127.0.0.1/asug/37-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('114', '1', '2014-03-21 02:04:06', '2014-03-21 02:04:06', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl. Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis. Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'inherit', 'closed', 'open', '', '39-autosave-v1', '', '', '2014-03-21 02:04:06', '2014-03-21 02:04:06', '', '39', 'http://127.0.0.1/asug/39-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('115', '1', '2014-03-20 15:44:13', '2014-03-20 15:44:13', '', 'Parceiros associados', '', 'inherit', 'closed', 'open', '', '43-autosave-v1', '', '', '2014-03-20 15:44:13', '2014-03-20 15:44:13', '', '43', 'http://127.0.0.1/asug/43-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('116', '1', '2014-03-20 16:11:44', '2014-03-20 16:11:44', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl.

Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis.

Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'inherit', 'closed', 'open', '', '39-revision-v1', '', '', '2014-03-20 16:11:44', '2014-03-20 16:11:44', '', '39', 'http://127.0.0.1/asug/39-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('117', '999999999', '2014-03-20 19:25:58', '2014-03-20 19:25:58', 'WP Backupware - 1395343555', 'WP Backupware - 1395343555', '', 'private', 'closed', 'open', '', 'wp-backupware-1395343555', '', '', '2014-03-20 19:25:58', '2014-03-20 19:25:58', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1395343555/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('118', '999999999', '2014-03-20 19:26:27', '2014-03-20 19:26:27', 'WP Backupware - 1395343586', 'WP Backupware - 1395343586', '', 'private', 'closed', 'open', '', 'wp-backupware-1395343586', '', '', '2014-03-20 19:26:27', '2014-03-20 19:26:27', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1395343586/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('119', '1', '2014-03-21 00:02:02', '2014-03-21 00:02:02', '', 'banner', '', 'inherit', 'closed', 'open', '', 'banner', '', '', '2014-03-21 00:02:02', '2014-03-21 00:02:02', '', '39', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('120', '1', '2014-03-21 01:41:03', '2014-03-21 01:41:03', '', 'banner_comite', '', 'inherit', 'closed', 'open', '', 'banner_comite', '', '', '2014-03-21 01:41:03', '2014-03-21 01:41:03', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner_comite.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('121', '1', '2014-03-21 02:36:56', '2014-03-21 02:36:56', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl. Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis. Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'inherit', 'closed', 'open', '', '39-revision-v1', '', '', '2014-03-21 02:36:56', '2014-03-21 02:36:56', '', '39', 'http://127.0.0.1/asug/39-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('123', '1', '2014-03-21 15:57:22', '2014-03-21 15:57:22', '', 'banner', '', 'inherit', 'closed', 'open', '', 'banner-2', '', '', '2014-03-21 15:57:22', '2014-03-21 15:57:22', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/banner1.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('124', '999999999', '2014-03-21 19:53:51', '2014-03-21 19:53:51', 'WP Backupware - 1395431624', 'WP Backupware - 1395431624', '', 'private', 'closed', 'open', '', 'wp-backupware-1395431624', '', '', '2014-03-21 19:53:51', '2014-03-21 19:53:51', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1395431624/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('125', '1', '2014-03-22 01:17:57', '2014-03-22 01:17:57', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl. Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis. Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.

[contact-form-7 id="4" title="Formulário de contato 1"]', 'Comitê estratégico', '', 'inherit', 'closed', 'open', '', '39-revision-v1', '', '', '2014-03-22 01:17:57', '2014-03-22 01:17:57', '', '39', 'http://127.0.0.1/asug/39-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('126', '1', '2014-03-22 03:46:10', '2014-03-22 03:46:10', '', 'sua_fatura_de_energia_mesref_201403', '', 'inherit', 'closed', 'open', '', 'sua_fatura_de_energia_mesref_201403', '', '', '2014-03-22 03:46:10', '2014-03-22 03:46:10', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014031.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('127', '1', '2014-03-22 04:01:21', '2014-03-22 04:01:21', '', 'sua_fatura_de_energia_mesref_201403', '', 'inherit', 'closed', 'open', '', 'sua_fatura_de_energia_mesref_201403-2', '', '', '2014-03-22 04:01:21', '2014-03-22 04:01:21', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014032.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('128', '1', '2014-03-22 04:02:07', '2014-03-22 04:02:07', '', 'sua_fatura_de_energia_mesref_201403', '', 'inherit', 'closed', 'open', '', 'sua_fatura_de_energia_mesref_201403-3', '', '', '2014-03-22 04:02:07', '2014-03-22 04:02:07', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014033.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('129', '1', '2014-03-22 04:09:29', '2014-03-22 04:09:29', '', 'sua_fatura_de_energia_mesref_201403', '', 'inherit', 'closed', 'open', '', 'sua_fatura_de_energia_mesref_201403-4', '', '', '2014-03-22 04:09:29', '2014-03-22 04:09:29', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014034.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('130', '1', '2014-03-22 04:10:50', '2014-03-22 04:10:50', '', 'sua_fatura_de_energia_mesref_201403', '', 'inherit', 'closed', 'open', '', 'sua_fatura_de_energia_mesref_201403-5', '', '', '2014-03-22 04:10:50', '2014-03-22 04:10:50', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014035.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('131', '1', '2014-03-22 04:12:00', '2014-03-22 04:12:00', '', 'sua_fatura_de_energia_mesref_201403', '', 'inherit', 'closed', 'open', '', 'sua_fatura_de_energia_mesref_201403-6', '', '', '2014-03-22 04:12:00', '2014-03-22 04:12:00', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014036.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('132', '1', '2014-03-22 04:13:12', '2014-03-22 04:13:12', '', 'sua_fatura_de_energia_mesref_201403', '', 'inherit', 'closed', 'open', '', 'sua_fatura_de_energia_mesref_201403-7', '', '', '2014-03-22 04:13:12', '2014-03-22 04:13:12', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014037.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('133', '1', '2014-03-22 04:13:33', '2014-03-22 04:13:33', '', 'sua_fatura_de_energia_mesref_201403', '', 'inherit', 'closed', 'open', '', 'sua_fatura_de_energia_mesref_201403-8', '', '', '2014-03-22 04:13:33', '2014-03-22 04:13:33', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014038.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('134', '1', '2014-03-22 04:15:21', '2014-03-22 04:15:21', '', 'wireframe-interna-ASUG', '', 'inherit', 'closed', 'open', '', 'wireframe-interna-asug', '', '', '2014-03-22 04:15:21', '2014-03-22 04:15:21', '', '411', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/wireframe-interna-ASUG.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('135', '999999999', '2014-03-23 17:37:44', '2014-03-23 17:37:44', 'WP Backupware - 1395596264', 'WP Backupware - 1395596264', '', 'private', 'closed', 'open', '', 'wp-backupware-1395596264', '', '', '2014-03-23 17:37:44', '2014-03-23 17:37:44', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1395596264/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('136', '999999999', '2014-03-23 19:26:05', '2014-03-23 19:26:05', 'WP Backupware - 1395602764', 'WP Backupware - 1395602764', '', 'private', 'closed', 'open', '', 'wp-backupware-1395602764', '', '', '2014-03-23 19:26:05', '2014-03-23 19:26:05', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1395602764/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('137', '1', '2014-03-23 19:39:41', '2014-03-23 19:39:41', '<strong>Modelos</strong> de e-mail da <em>ASUG</em>

<a href="[boleto_usuario]" target="_blank">Funciona</a>???

&nbsp;

teste', 'E-mail Boleto - Asug', '', 'publish', 'closed', 'open', '', 'e-mail-boleto-asug', '', '', '2014-03-23 22:28:28', '2014-03-23 22:28:28', '', '0', 'http://127.0.0.1/asug/?page_id=137', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('138', '1', '2014-03-23 19:39:41', '2014-03-23 19:39:41', 'Modelos de e-mail da ASUG

Funciona???

&nbsp;

teste', 'E-mail Boleto - Asug', '', 'inherit', 'closed', 'open', '', '137-revision-v1', '', '', '2014-03-23 19:39:41', '2014-03-23 19:39:41', '', '137', 'http://127.0.0.1/asug/137-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('139', '1', '2014-03-23 21:09:45', '2014-03-23 21:09:45', '', 'Home', '', 'inherit', 'closed', 'open', '', '2-revision-v1', '', '', '2014-03-23 21:09:45', '2014-03-23 21:09:45', '', '2', 'http://127.0.0.1/asug/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('140', '1', '2014-03-23 21:16:53', '2014-03-23 21:16:53', '<ul class="destaque">
						<li>
							<a href="">
								<img class="img_ntc" src="images/notici01.jpg" height="75" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>As perspectivas para a TI</h2>
							</a>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis, eaque, dolorem, explicabo sapiente consectetur quam expedita beatae assumenda enim qui unde eius ullam. Libero, earum, similique iure dolorum modi at.</p>
						</li>
						<li>
							<a href="">
								<img class="img_ntc" src="images/noticia02.jpg" height="75" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>SAP traz novo conceito de treinamento empresarial ao Brasil</h2>
							</a>
								<p>Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!</p>
						</li>
						<li>
							<a href="">
								<img class="img_ntc" src="images/noticia03.jpg" height="74" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>As perspectivas a TI</h2>
							</a>
								<p>Non, fugit, velit rerum suscipit magni optio quam unde dolores eveniet fugiat dolorum nam labore cum quidem aliquam placeat dignissimos. Quas, quis iste placeat veritatis assumenda sapiente praesentium provident facere.</p>
						</li>
						<li>
							<a href="">
								<img class="img_ntc" src="images/noticia04.jpg" height="74" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>SAP traz novo conceito de treinamento empresarial ao Brasil </h2>
							</a>
								<p>Numquam, deserunt, unde alias labore dolorem fugiat eius molestiae! Quisquam, ut, voluptate, unde, culpa necessitatibus beatae itaque nisi ducimus nobis explicabo distinctio possimus eos inventore eligendi amet officiis fugiat accusamus.</p>
						</li>
					</ul>', 'Home', '', 'inherit', 'closed', 'open', '', '2-revision-v1', '', '', '2014-03-23 21:16:53', '2014-03-23 21:16:53', '', '2', 'http://127.0.0.1/asug/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('141', '1', '2014-03-23 21:18:30', '2014-03-23 21:18:30', '<ul class="destaque">
						<li>
							<a href=""><img class="img_ntc" src="images/notici01.jpg" height="75" width="75" alt=""></a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href=""><h2>As perspectivas para a TI</h2></a><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis, eaque, dolorem, explicabo sapiente consectetur quam expedita beatae assumenda enim qui unde eius ullam. Libero, earum, similique iure dolorum modi at.</p>
						</li>
						<li>
							<a href="">
								<img class="img_ntc" src="images/noticia02.jpg" height="75" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>SAP traz novo conceito de treinamento empresarial ao Brasil</h2>
							</a>
								<p>Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!</p>
						</li>
						<li>
							<a href="">
								<img class="img_ntc" src="images/noticia03.jpg" height="74" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>As perspectivas a TI</h2>
							</a>
								<p>Non, fugit, velit rerum suscipit magni optio quam unde dolores eveniet fugiat dolorum nam labore cum quidem aliquam placeat dignissimos. Quas, quis iste placeat veritatis assumenda sapiente praesentium provident facere.</p>
						</li>
						<li>
							<a href="">
								<img class="img_ntc" src="images/noticia04.jpg" height="74" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>SAP traz novo conceito de treinamento empresarial ao Brasil </h2>
							</a>
								<p>Numquam, deserunt, unde alias labore dolorem fugiat eius molestiae! Quisquam, ut, voluptate, unde, culpa necessitatibus beatae itaque nisi ducimus nobis explicabo distinctio possimus eos inventore eligendi amet officiis fugiat accusamus.</p>
						</li>
					</ul>', 'Home', '', 'inherit', 'closed', 'open', '', '2-revision-v1', '', '', '2014-03-23 21:18:30', '2014-03-23 21:18:30', '', '2', 'http://127.0.0.1/asug/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('142', '1', '2014-03-23 21:23:21', '2014-03-23 21:23:21', '<ul class="destaque">
						<li>
							<a href="">
								<img class="img_ntc" src="images/notici01.jpg" height="75" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>As perspectivas para a TI</h2>
							</a>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis, eaque, dolorem, explicabo sapiente consectetur quam expedita beatae assumenda enim qui unde eius ullam. Libero, earum, similique iure dolorum modi at.</p>
						</li>
						<li>
							<a href="">
								<img class="img_ntc" src="images/noticia02.jpg" height="75" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>SAP traz novo conceito de treinamento empresarial ao Brasil</h2>
							</a>
								<p>Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!</p>
						</li>
						<li>
							<a href="">
								<img class="img_ntc" src="images/noticia03.jpg" height="74" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>As perspectivas a TI</h2>
							</a>
								<p>Non, fugit, velit rerum suscipit magni optio quam unde dolores eveniet fugiat dolorum nam labore cum quidem aliquam placeat dignissimos. Quas, quis iste placeat veritatis assumenda sapiente praesentium provident facere.</p>
						</li>
						<li>
							<a href="">
								<img class="img_ntc" src="images/noticia04.jpg" height="74" width="75" alt="">
							</a>
							<span class="dt_postagem"><time>04/04/2013 19:12:42</time></span>
							<a href="">
								<h2>SAP traz novo conceito de treinamento empresarial ao Brasil </h2>
							</a>
								<p>Numquam, deserunt, unde alias labore dolorem fugiat eius molestiae! Quisquam, ut, voluptate, unde, culpa necessitatibus beatae itaque nisi ducimus nobis explicabo distinctio possimus eos inventore eligendi amet officiis fugiat accusamus.</p>
						</li>
					</ul>', 'Home', '', 'inherit', 'closed', 'open', '', '2-autosave-v1', '', '', '2014-03-23 21:23:21', '2014-03-23 21:23:21', '', '2', 'http://127.0.0.1/asug/2-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('143', '1', '2014-03-23 21:21:16', '2014-03-23 21:21:16', '<ul class="destaque">
<li><a href=""><img class="img_ntc" src="images/notici01.jpg" height="75" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href=""><h2>As perspectivas para a TI</h2></a><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis, eaque, dolorem, explicabo sapiente consectetur quam expedita beatae assumenda enim qui unde eius ullam. Libero, earum, similique iure dolorum modi at.</p></li>

<li><a href=""><img class="img_ntc" src="images/noticia02.jpg" height="75" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href=""><h2>SAP traz novo conceito de treinamento empresarial ao Brasil</h2></a><p>Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!</p></li>

<li><a href=""><img class="img_ntc" src="images/noticia03.jpg" height="74" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span<a href=""><h2>As perspectivas a TI</h2></a><p>Non, fugit, velit rerum suscipit magni optio quam unde dolores eveniet fugiat dolorum nam labore cum quidem aliquam placeat dignissimos. Quas, quis iste placeat veritatis assumenda sapiente praesentium provident facere.</p></li>

<li><a href=""><img class="img_ntc" src="images/noticia04.jpg" height="74" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href=""><h2>SAP traz novo conceito de treinamento empresarial ao Brasil </h2></a><p>Numquam, deserunt, unde alias labore dolorem fugiat eius molestiae! Quisquam, ut, voluptate, unde, culpa necessitatibus beatae itaque nisi ducimus nobis explicabo distinctio possimus eos inventore eligendi amet officiis fugiat accusamus.</p></li>
</ul>', 'Home', '', 'inherit', 'closed', 'open', '', '2-revision-v1', '', '', '2014-03-23 21:21:16', '2014-03-23 21:21:16', '', '2', 'http://127.0.0.1/asug/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('144', '1', '2014-03-23 21:23:53', '2014-03-23 21:23:53', '<ul class="destaque">
<li><a href=""><img class="img_ntc" src="images/notici01.jpg" height="75" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href=""><h2>As perspectivas para a TI</h2></a><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis, eaque, dolorem, explicabo sapiente consectetur quam expedita beatae assumenda enim qui unde eius ullam. Libero, earum, similique iure dolorum modi at.</p></li>
<li><a href=""><img class="img_ntc" src="images/noticia02.jpg" height="75" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href=""><h2>SAP traz novo conceito de treinamento empresarial ao Brasil</h2></a><p>Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!</p></li>
<li><a href=""><img class="img_ntc" src="images/noticia03.jpg" height="74" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href=""><h2>As perspectivas a TI</h2></a><p>Non, fugit, velit rerum suscipit magni optio quam unde dolores eveniet fugiat dolorum nam labore cum quidem aliquam placeat dignissimos. Quas, quis iste placeat veritatis assumenda sapiente praesentium provident facere.</p></li>
<li><a href=""><img class="img_ntc" src="images/noticia04.jpg" height="74" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href=""><h2>SAP traz novo conceito de treinamento empresarial ao Brasil </h2></a><p>Numquam, deserunt, unde alias labore dolorem fugiat eius molestiae! Quisquam, ut, voluptate, unde, culpa necessitatibus beatae itaque nisi ducimus nobis explicabo distinctio possimus eos inventore eligendi amet officiis fugiat accusamus.</p>
</li>
</ul>', 'Home', '', 'inherit', 'closed', 'open', '', '2-revision-v1', '', '', '2014-03-23 21:23:53', '2014-03-23 21:23:53', '', '2', 'http://127.0.0.1/asug/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('145', '1', '2014-03-23 21:24:35', '2014-03-23 21:24:35', '<ul class="destaque">
<li><a href="#"><img class="img_ntc" src="images/notici01.jpg" height="75" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href="#"><h2>As perspectivas para a TI</h2></a><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis, eaque, dolorem, explicabo sapiente consectetur quam expedita beatae assumenda enim qui unde eius ullam. Libero, earum, similique iure dolorum modi at.</p></li>
<li><a href="#"><img class="img_ntc" src="images/noticia02.jpg" height="75" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href="#"><h2>SAP traz novo conceito de treinamento empresarial ao Brasil</h2></a><p>Accusantium, possimus, harum consequuntur et quis id similique ut repellendus est eaque quas sapiente officiis ullam dolorem ipsa magni porro ex debitis obcaecati assumenda doloribus laudantium a dolorum accusamus adipisci!</p></li>
<li><a href="#"><img class="img_ntc" src="images/noticia03.jpg" height="74" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href="#"><h2>As perspectivas a TI</h2></a><p>Non, fugit, velit rerum suscipit magni optio quam unde dolores eveniet fugiat dolorum nam labore cum quidem aliquam placeat dignissimos. Quas, quis iste placeat veritatis assumenda sapiente praesentium provident facere.</p></li>
<li><a href="#"><img class="img_ntc" src="images/noticia04.jpg" height="74" width="75" alt=""></a><span class="dt_postagem"><time>04/04/2013 19:12:42</time></span><a href="#"><h2>SAP traz novo conceito de treinamento empresarial ao Brasil </h2></a><p>Numquam, deserunt, unde alias labore dolorem fugiat eius molestiae! Quisquam, ut, voluptate, unde, culpa necessitatibus beatae itaque nisi ducimus nobis explicabo distinctio possimus eos inventore eligendi amet officiis fugiat accusamus.</p>
</li>
</ul>', 'Home', '', 'inherit', 'closed', 'open', '', '2-revision-v1', '', '', '2014-03-23 21:24:35', '2014-03-23 21:24:35', '', '2', 'http://127.0.0.1/asug/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('146', '1', '2014-03-23 21:29:08', '2014-03-23 21:29:08', '<strong>Modelos</strong> de e-mail da <em>ASUG</em>

Funciona???

&nbsp;

teste', 'E-mail Boleto - Asug', '', 'inherit', 'closed', 'open', '', '137-autosave-v1', '', '', '2014-03-23 21:29:08', '2014-03-23 21:29:08', '', '137', 'http://127.0.0.1/asug/137-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('147', '1', '2014-03-23 21:29:11', '2014-03-23 21:29:11', '<strong>Modelos</strong> de e-mail da <em>ASUG</em>

<a href="#">Funciona</a>???

&nbsp;

teste', 'E-mail Boleto - Asug', '', 'inherit', 'closed', 'open', '', '137-revision-v1', '', '', '2014-03-23 21:29:11', '2014-03-23 21:29:11', '', '137', 'http://127.0.0.1/asug/137-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('148', '1', '2014-03-23 22:27:39', '2014-03-23 22:27:39', '<strong>Modelos</strong> de e-mail da <em>ASUG</em>

<a href="[boleto_usuario]">Funciona</a>???

&nbsp;

teste', 'E-mail Boleto - Asug', '', 'inherit', 'closed', 'open', '', '137-revision-v1', '', '', '2014-03-23 22:27:39', '2014-03-23 22:27:39', '', '137', 'http://127.0.0.1/asug/137-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('149', '1', '2014-03-23 22:28:28', '2014-03-23 22:28:28', '<strong>Modelos</strong> de e-mail da <em>ASUG</em>

<a href="[boleto_usuario]" target="_blank">Funciona</a>???

&nbsp;

teste', 'E-mail Boleto - Asug', '', 'inherit', 'closed', 'open', '', '137-revision-v1', '', '', '2014-03-23 22:28:28', '2014-03-23 22:28:28', '', '137', 'http://127.0.0.1/asug/137-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('150', '999999999', '2014-03-24 22:40:39', '2014-03-24 22:40:39', 'WP Backupware - 1395700838', 'WP Backupware - 1395700838', '', 'private', 'closed', 'open', '', 'wp-backupware-1395700838', '', '', '2014-03-24 22:40:39', '2014-03-24 22:40:39', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1395700838/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('158', '999999999', '2014-03-25 23:01:11', '2014-03-25 23:01:11', 'WP Backupware - 1395788465', 'WP Backupware - 1395788465', '', 'private', 'closed', 'open', '', 'wp-backupware-1395788465', '', '', '2014-03-25 23:01:11', '2014-03-25 23:01:11', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1395788465/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('159', '999999999', '2014-03-26 21:51:11', '2014-03-26 21:51:11', 'WP Backupware - 1395870668', 'WP Backupware - 1395870668', '', 'private', 'closed', 'open', '', 'wp-backupware-1395870668', '', '', '2014-03-26 21:51:11', '2014-03-26 21:51:11', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1395870668/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('160', '1', '2014-03-27 01:40:55', '2014-03-27 01:40:55', 'Parabéns o representante da sua empresa acaba de ativar sua conta.

&nbsp;

Apartir de agora você tem permissão para acessar o site <a title="Sita ASUG" href="http://www.asug.com.br">www.asug.com.br</a>

&nbsp;

At.

&nbsp;

Equipe Asug', 'E-mail ativação dos usuários ativados pelo representante', '', 'publish', 'closed', 'closed', '', 'e-mail-ativacao-dos-usuarios-ativados-pelo-representante', '', '', '2014-03-27 01:57:40', '2014-03-27 01:57:40', '', '0', 'http://127.0.0.1/asug/?page_id=160', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('161', '1', '2014-03-27 01:40:55', '2014-03-27 01:40:55', 'Parabéns o [usuario-represetante]

já ativou seu cadastro, agora você tem permissão para acessar o site <a title="Sita ASUG" href="http://www.asug.com.br">www.asug.com.br</a>

At.
Equipe Asug', 'E-mail ativação dos usuários ativados pelo representante', '', 'inherit', 'closed', 'open', '', '160-revision-v1', '', '', '2014-03-27 01:40:55', '2014-03-27 01:40:55', '', '160', 'http://127.0.0.1/asug/160-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('162', '1', '2014-03-27 01:49:27', '2014-03-27 01:49:27', 'Parabéns o representante da sua empresa acaba de ativar sua conta.

Apartir de agora você tem permissão para acessar o site <a title="Sita ASUG" href="http://www.asug.com.br">www.asug.com.br</a>

At.
Equipe Asug', 'E-mail ativação dos usuários ativados pelo representante', '', 'inherit', 'closed', 'open', '', '160-revision-v1', '', '', '2014-03-27 01:49:27', '2014-03-27 01:49:27', '', '160', 'http://127.0.0.1/asug/160-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('163', '1', '2014-03-27 01:56:11', '2014-03-27 01:56:11', 'Parabéns o representante da sua empresa acaba de ativar sua conta.

Apartir de agora você tem permissão para acessar o site <a title="Sita ASUG" href="http://www.asug.com.br">www.asug.com.br</a>

At.

Equipe Asug', 'E-mail ativação dos usuários ativados pelo representante', '', 'inherit', 'closed', 'open', '', '160-autosave-v1', '', '', '2014-03-27 01:56:11', '2014-03-27 01:56:11', '', '160', 'http://127.0.0.1/asug/160-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('164', '1', '2014-03-27 01:57:40', '2014-03-27 01:57:40', 'Parabéns o representante da sua empresa acaba de ativar sua conta.

&nbsp;

Apartir de agora você tem permissão para acessar o site <a title="Sita ASUG" href="http://www.asug.com.br">www.asug.com.br</a>

&nbsp;

At.

&nbsp;

Equipe Asug', 'E-mail ativação dos usuários ativados pelo representante', '', 'inherit', 'closed', 'open', '', '160-revision-v1', '', '', '2014-03-27 01:57:40', '2014-03-27 01:57:40', '', '160', 'http://127.0.0.1/asug/160-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('165', '999999999', '2014-03-27 20:56:57', '2014-03-27 20:56:57', 'WP Backupware - 1395953779', 'WP Backupware - 1395953779', '', 'private', 'closed', 'open', '', 'wp-backupware-1395953779', '', '', '2014-03-27 20:56:57', '2014-03-27 20:56:57', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1395953779/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('167', '999999999', '2014-03-29 17:47:16', '2014-03-29 17:47:16', 'WP Backupware - 1396115234', 'WP Backupware - 1396115234', '', 'private', 'closed', 'open', '', 'wp-backupware-1396115234', '', '', '2014-03-29 17:47:16', '2014-03-29 17:47:16', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1396115234/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('187', '1', '2014-03-29 19:05:34', '2014-03-29 19:05:34', '', 'cartao-sms', '', 'inherit', 'closed', 'open', '', 'cartao-sms', '', '', '2014-03-29 19:05:34', '2014-03-29 19:05:34', '', '190', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/cartao-sms.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('189', '999999999', '2014-03-29 19:26:08', '2014-03-29 19:26:08', 'WP Backupware - 1396121168', 'WP Backupware - 1396121168', '', 'private', 'closed', 'open', '', 'wp-backupware-1396121168', '', '', '2014-03-29 19:26:08', '2014-03-29 19:26:08', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1396121168/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('190', '1', '2014-03-29 19:52:00', '0000-00-00 00:00:00', 'testes', 'Teste', '', 'draft', 'closed', 'closed', '', '', '', '', '2014-03-29 19:52:00', '2014-03-29 19:52:00', '', '0', 'http://127.0.0.1/asug/?post_type=epaper&#038;p=190', '0', 'epaper', '', '0'); 
INSERT INTO `wp_posts` VALUES ('202', '1', '2014-03-29 21:11:12', '2014-03-29 21:11:12', '', 'Revista', '', 'publish', 'closed', 'closed', '', 'acf_revista', '', '', '2014-03-29 22:14:05', '2014-03-29 22:14:05', '', '0', 'http://127.0.0.1/asug/?post_type=acf&#038;p=202', '0', 'acf', '', '0'); 
INSERT INTO `wp_posts` VALUES ('213', '1', '2014-03-29 22:06:37', '2014-03-29 22:06:37', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'publish', 'closed', 'open', '', 'asug-teste-2', '', '', '2014-03-29 22:39:24', '2014-03-29 22:39:24', '', '0', 'http://127.0.0.1/asug/?p=213', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('214', '1', '2014-03-29 22:06:11', '2014-03-29 22:06:11', '', 'capa-revista-hsm-management-01', '', 'inherit', 'closed', 'open', '', 'capa-revista-hsm-management-01', '', '', '2014-03-29 22:06:11', '2014-03-29 22:06:11', '', '213', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/capa-revista-hsm-management-01.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('215', '1', '2014-03-29 22:06:37', '2014-03-29 22:06:37', '', 'Asug teste 2', '', 'inherit', 'closed', 'open', '', '213-revision-v1', '', '', '2014-03-29 22:06:37', '2014-03-29 22:06:37', '', '213', 'http://127.0.0.1/asug/213-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('217', '1', '2014-03-29 22:14:33', '2014-03-29 22:14:33', '', 'Asug teste 2', '', 'inherit', 'closed', 'open', '', '213-revision-v1', '', '', '2014-03-29 22:14:33', '2014-03-29 22:14:33', '', '213', 'http://127.0.0.1/asug/213-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('218', '1', '2014-03-29 22:39:24', '2014-03-29 22:39:24', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'inherit', 'closed', 'open', '', '213-revision-v1', '', '', '2014-03-29 22:39:24', '2014-03-29 22:39:24', '', '213', 'http://127.0.0.1/asug/213-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('219', '999999999', '2014-04-01 22:50:17', '2014-04-01 22:50:17', 'WP Backupware - 1396392617', 'WP Backupware - 1396392617', '', 'private', 'closed', 'open', '', 'wp-backupware-1396392617', '', '', '2014-04-01 22:50:17', '2014-04-01 22:50:17', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1396392617/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('221', '1', '2014-04-01 22:58:08', '2014-04-01 22:58:08', '', 'Asug Day', '', 'inherit', 'closed', 'open', '', '20-autosave-v1', '', '', '2014-04-01 22:58:08', '2014-04-01 22:58:08', '', '20', 'http://127.0.0.1/asug/20-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('222', '1', '2014-04-01 23:03:26', '2014-04-01 23:03:26', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'publish', 'closed', 'open', '', 'asug-teste-33', '', '', '2014-04-01 23:03:26', '2014-04-01 23:03:26', '', '0', 'http://127.0.0.1/asug/?p=222', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('223', '1', '2014-04-01 23:02:48', '2014-04-01 23:02:48', '', 'capa-revista-gloss', '', 'inherit', 'closed', 'open', '', 'capa-revista-gloss', '', '', '2014-04-01 23:02:48', '2014-04-01 23:02:48', '', '222', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/capa-revista-gloss.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('224', '1', '2014-04-01 23:03:26', '2014-04-01 23:03:26', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'inherit', 'closed', 'open', '', '222-revision-v1', '', '', '2014-04-01 23:03:26', '2014-04-01 23:03:26', '', '222', 'http://127.0.0.1/asug/222-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('226', '1', '2014-06-02 00:32:31', '2014-06-02 00:32:31', '<iframe width="525" height="371" src="//e.issuu.com/embed.html#12211663/8129442" frameborder="0" allowfullscreen></iframe>

<strong>Lorem ipsum</strong> dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug news - Ed 02', '', 'publish', 'closed', 'open', '', 'asug-teste-2-6', '', '', '2014-06-06 14:27:10', '2014-06-06 14:27:10', '', '0', 'http://127.0.0.1/asug/?p=226', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('227', '1', '2014-04-02 00:32:30', '2014-04-02 00:32:30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'publish', 'closed', 'open', '', 'asug-teste-33-5', '', '', '2014-04-02 00:32:30', '2014-04-02 00:32:30', '', '0', 'http://127.0.0.1/asug/?p=227', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('228', '1', '2014-04-02 00:32:30', '2014-04-02 00:32:30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'publish', 'closed', 'open', '', 'asug-teste-2-5', '', '', '2014-04-02 00:32:30', '2014-04-02 00:32:30', '', '0', 'http://127.0.0.1/asug/?p=228', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('229', '1', '2014-04-02 00:32:30', '2014-04-02 00:32:30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'publish', 'closed', 'open', '', 'asug-teste-33-4', '', '', '2014-04-02 00:32:30', '2014-04-02 00:32:30', '', '0', 'http://127.0.0.1/asug/?p=229', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('230', '1', '2014-04-02 00:32:30', '2014-04-02 00:32:30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'publish', 'closed', 'open', '', 'asug-teste-2-4', '', '', '2014-04-02 00:32:30', '2014-04-02 00:32:30', '', '0', 'http://127.0.0.1/asug/?p=230', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('231', '1', '2014-04-02 00:32:29', '2014-04-02 00:32:29', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'publish', 'closed', 'open', '', 'asug-teste-33-3', '', '', '2014-04-02 00:32:29', '2014-04-02 00:32:29', '', '0', 'http://127.0.0.1/asug/?p=231', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('232', '1', '2014-04-02 00:32:29', '2014-04-02 00:32:29', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'publish', 'closed', 'open', '', 'asug-teste-2-3', '', '', '2014-04-02 00:32:29', '2014-04-02 00:32:29', '', '0', 'http://127.0.0.1/asug/?p=232', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('233', '1', '2014-04-02 00:32:29', '2014-04-02 00:32:29', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'publish', 'closed', 'open', '', 'asug-teste-33-2', '', '', '2014-04-02 00:32:29', '2014-04-02 00:32:29', '', '0', 'http://127.0.0.1/asug/?p=233', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('234', '1', '2014-04-02 00:32:28', '2014-04-02 00:32:28', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'publish', 'closed', 'open', '', 'asug-teste-2-2', '', '', '2014-04-02 00:32:28', '2014-04-02 00:32:28', '', '0', 'http://127.0.0.1/asug/?p=234', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('235', '1', '2014-04-02 00:32:28', '2014-04-02 00:32:28', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'inherit', 'closed', 'open', '', '234-revision-v1', '', '', '2014-04-02 00:32:28', '2014-04-02 00:32:28', '', '234', 'http://127.0.0.1/asug/234-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('236', '1', '2014-04-02 00:32:29', '2014-04-02 00:32:29', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'inherit', 'closed', 'open', '', '233-revision-v1', '', '', '2014-04-02 00:32:29', '2014-04-02 00:32:29', '', '233', 'http://127.0.0.1/asug/233-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('237', '1', '2014-04-02 00:32:29', '2014-04-02 00:32:29', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'inherit', 'closed', 'open', '', '232-revision-v1', '', '', '2014-04-02 00:32:29', '2014-04-02 00:32:29', '', '232', 'http://127.0.0.1/asug/232-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('238', '1', '2014-04-02 00:32:29', '2014-04-02 00:32:29', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'inherit', 'closed', 'open', '', '231-revision-v1', '', '', '2014-04-02 00:32:29', '2014-04-02 00:32:29', '', '231', 'http://127.0.0.1/asug/231-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('239', '1', '2014-04-02 00:32:30', '2014-04-02 00:32:30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'inherit', 'closed', 'open', '', '230-revision-v1', '', '', '2014-04-02 00:32:30', '2014-04-02 00:32:30', '', '230', 'http://127.0.0.1/asug/230-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('240', '1', '2014-04-02 00:32:30', '2014-04-02 00:32:30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'inherit', 'closed', 'open', '', '229-revision-v1', '', '', '2014-04-02 00:32:30', '2014-04-02 00:32:30', '', '229', 'http://127.0.0.1/asug/229-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('241', '1', '2014-04-02 00:32:30', '2014-04-02 00:32:30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'inherit', 'closed', 'open', '', '228-revision-v1', '', '', '2014-04-02 00:32:30', '2014-04-02 00:32:30', '', '228', 'http://127.0.0.1/asug/228-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('242', '1', '2014-04-02 00:32:30', '2014-04-02 00:32:30', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 33', '', 'inherit', 'closed', 'open', '', '227-revision-v1', '', '', '2014-04-02 00:32:30', '2014-04-02 00:32:30', '', '227', 'http://127.0.0.1/asug/227-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('243', '1', '2014-04-02 00:32:31', '2014-04-02 00:32:31', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'inherit', 'closed', 'open', '', '226-revision-v1', '', '', '2014-04-02 00:32:31', '2014-04-02 00:32:31', '', '226', 'http://127.0.0.1/asug/226-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('244', '1', '2014-04-02 01:51:20', '2014-04-02 01:51:20', '', 'revista', '', 'inherit', 'closed', 'open', '', 'revista', '', '', '2014-04-02 01:51:20', '2014-04-02 01:51:20', '', '20', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/revista.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('245', '999999999', '2014-04-02 21:41:06', '2014-04-02 21:41:06', 'WP Backupware - 1396474863', 'WP Backupware - 1396474863', '', 'private', 'closed', 'open', '', 'wp-backupware-1396474863', '', '', '2014-04-02 21:41:06', '2014-04-02 21:41:06', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1396474863/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('247', '999999999', '2014-04-03 22:03:13', '2014-04-03 22:03:13', 'WP Backupware - 1396562592', 'WP Backupware - 1396562592', '', 'private', 'closed', 'open', '', 'wp-backupware-1396562592', '', '', '2014-04-03 22:03:13', '2014-04-03 22:03:13', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1396562592/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('248', '1', '2014-04-03 22:57:39', '2014-04-03 22:57:39', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus fringilla, tortor quis ullamcorper mollis, nulla felis viverra magna, nec vehicula dui erat et nisl. Suspendisse lobortis pretium iaculis. Integer ut erat justo. Etiam urna leo, bibendum ac suscipit ut, ullamcorper mollis eros. Etiam mollis eleifend dignissim. Donec in mi vel urna tincidunt molestie ac in sem. Donec tristique orci at tincidunt pulvinar. Nullam fermentum dictum mi at tincidunt. Fusce varius accumsan aliquet. Integer luctus molestie diam id ultrices. Nam lacinia leo lectus, nec lobortis lacus ultricies ut. Integer volutpat vestibulum lacinia. Quisque nec erat feugiat, blandit est et, molestie nisl. Aliquam ullamcorper nisi ac nulla consequat iaculis. Vivamus elementum adipiscing semper. Mauris rutrum dui mi, quis tristique massa malesuada nec. Vestibulum dictum, nibh a pretium semper, libero nibh sodales nisi, at mattis nulla felis quis quam. Nulla vitae posuere magna. Nam non nisi nunc. Curabitur feugiat auctor euismod. Maecenas blandit sem eu enim bibendum, sed posuere velit luctus. Curabitur a elit sit amet risus euismod vestibulum. Duis laoreet commodo tellus tristique lobortis. Vivamus quis molestie odio. Suspendisse vulputate est et lacinia dapibus. Nulla tempor semper tortor, eget ullamcorper sapien facilisis sed. Sed at mollis tellus, lacinia porttitor quam. Nunc metus ipsum, tempor id blandit aliquam, bibendum eu nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut at felis justo. Nunc interdum mi ac ligula ullamcorper lobortis. Aliquam et felis felis. Vivamus cursus blandit lacus quis volutpat. Nullam nisi diam, egestas nec bibendum quis, adipiscing et felis. Praesent scelerisque adipiscing ante non pulvinar.', 'Comitê estratégico', '', 'inherit', 'closed', 'open', '', '39-revision-v1', '', '', '2014-04-03 22:57:39', '2014-04-03 22:57:39', '', '39', 'http://127.0.0.1/asug/39-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('250', '999999999', '2014-04-04 19:25:55', '2014-04-04 19:25:55', 'WP Backupware - 1396639554', 'WP Backupware - 1396639554', '', 'private', 'closed', 'open', '', 'wp-backupware-1396639554', '', '', '2014-04-04 19:25:55', '2014-04-04 19:25:55', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1396639554/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('251', '999999999', '2014-04-05 19:27:05', '2014-04-05 19:27:05', 'WP Backupware - 1396726024', 'WP Backupware - 1396726024', '', 'private', 'closed', 'open', '', 'wp-backupware-1396726024', '', '', '2014-04-05 19:27:05', '2014-04-05 19:27:05', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1396726024/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('253', '1', '2014-04-05 19:50:43', '0000-00-00 00:00:00', '', 'Recibo', '', 'draft', 'closed', 'open', '', '', '', '', '2014-04-05 19:50:43', '2014-04-05 19:50:43', '', '0', 'http://127.0.0.1/asug/?page_id=253', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('254', '1', '2014-04-05 19:57:58', '2014-04-05 19:57:58', '', 'asug_recibo_cabecalho', '', 'inherit', 'closed', 'open', '', 'asug_recibo_cabecalho', '', '', '2014-04-05 19:57:58', '2014-04-05 19:57:58', '', '253', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_cabecalho.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('255', '1', '2014-04-05 19:58:01', '2014-04-05 19:58:01', '', 'asug_recibo_rodape', '', 'inherit', 'closed', 'open', '', 'asug_recibo_rodape', '', '', '2014-04-05 19:58:01', '2014-04-05 19:58:01', '', '253', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('285', '1', '2014-04-05 21:07:14', '2014-04-05 21:07:14', '<img class="alignnone size-full wp-image-254" alt="asug_recibo_cabecalho" src="http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_cabecalho.jpg" width="1020" height="71" />

&nbsp;

Recebi do(a) [nome_da_empresa], o valor de R$ [valor], referente à associação do porta Asug (Associação de usuários SAP do brasil),  dando-lhe por este recibo a devida quitação anual.

[data]

&nbsp;

<img class="alignleft" alt="" src="http://fliporto.net/2013/wp-content/uploads/2013/11/JoseSaramagoAssinatura.png" width="424" height="193" />

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

_______________________________________________
João da Silva - Diretor Financeiro Asug Brasil

&nbsp;

&nbsp;

<a href="http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg"><img class="alignnone size-full wp-image-255" alt="asug_recibo_rodape" src="http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg" width="1020" height="38" /></a>

&nbsp;', 'Recibo', '', 'publish', 'closed', 'open', '', 'recibo', '', '', '2014-04-05 21:07:14', '2014-04-05 21:07:14', '', '0', 'http://127.0.0.1/asug/?page_id=285', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('286', '1', '2014-04-05 21:07:14', '2014-04-05 21:07:14', '<img class="alignnone size-full wp-image-254" alt="asug_recibo_cabecalho" src="http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_cabecalho.jpg" width="1020" height="71" />

&nbsp;

Recebi do(a) [nome_da_empresa], o valor de R$ [valor], referente à associação do porta Asug (Associação de usuários SAP do brasil),  dando-lhe por este recibo a devida quitação anual.

[data]

&nbsp;

<img class="alignleft" alt="" src="http://fliporto.net/2013/wp-content/uploads/2013/11/JoseSaramagoAssinatura.png" width="424" height="193" />

&nbsp;

&nbsp;

&nbsp;

&nbsp;

&nbsp;

_______________________________________________
João da Silva - Diretor Financeiro Asug Brasil

&nbsp;

&nbsp;

<a href="http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg"><img class="alignnone size-full wp-image-255" alt="asug_recibo_rodape" src="http://127.0.0.1/asug/wp-content/uploads/2014/04/asug_recibo_rodape.jpg" width="1020" height="38" /></a>

&nbsp;', 'Recibo', '', 'inherit', 'closed', 'open', '', '285-revision-v1', '', '', '2014-04-05 21:07:14', '2014-04-05 21:07:14', '', '285', 'http://127.0.0.1/asug/285-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('287', '999999999', '2014-04-12 19:05:54', '2014-04-12 19:05:54', 'WP Backupware - 1397329543', 'WP Backupware - 1397329543', '', 'private', 'closed', 'open', '', 'wp-backupware-1397329543', '', '', '2014-04-12 19:05:54', '2014-04-12 19:05:54', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1397329543/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('291', '1', '2014-04-12 19:16:04', '2014-04-12 19:16:04', '[contact-form-7 id="4" title="Formulário de contato 1"]
<h2>ASUG Line: 0800-164064</h2>
&nbsp;

Endereço: Rua Azevedo Macedo 20 - 7° andar - Vila Mariana - São Paulo - SP - CEP: 04013-060
<iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3656.6579937281545!2d-46.64000320000003!3d-23.580723699999968!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59850e9f6baf%3A0x24d306c625eb54d9!2sRua+Azevedo+Macedo%2C+20+-+Vila+Mariana!5e0!3m2!1spt-BR!2sbr!4v1401901175988" width="100%" height="450" frameborder="0"></iframe>', 'Fale conosco', '', 'publish', 'closed', 'open', '', 'fale-conosco', '', '', '2014-06-04 17:03:12', '2014-06-04 17:03:12', '', '0', 'http://127.0.0.1/asug/?page_id=291', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('292', '1', '2014-04-12 19:16:04', '2014-04-12 19:16:04', '', 'Fale conosco', '', 'inherit', 'closed', 'open', '', '291-revision-v1', '', '', '2014-04-12 19:16:04', '2014-04-12 19:16:04', '', '291', 'http://127.0.0.1/asug/291-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('293', '1', '2014-04-12 19:17:21', '2014-04-12 19:17:21', '', 'Contato', '', 'publish', 'closed', 'open', '', '293', '', '', '2014-06-04 16:38:24', '2014-06-04 16:38:24', '', '0', 'http://127.0.0.1/asug/?p=293', '14', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('294', '1', '2014-04-12 19:17:44', '2014-04-12 19:17:44', '', 'Asug internacional', '', 'publish', 'closed', 'open', '', 'asug-internacional', '', '', '2014-04-12 19:17:44', '2014-04-12 19:17:44', '', '0', 'http://127.0.0.1/asug/?page_id=294', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('295', '1', '2014-04-12 19:17:44', '2014-04-12 19:17:44', '', 'Asug internacional', '', 'inherit', 'closed', 'open', '', '294-revision-v1', '', '', '2014-04-12 19:17:44', '2014-04-12 19:17:44', '', '294', 'http://127.0.0.1/asug/294-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('296', '1', '2014-04-12 19:18:14', '2014-04-12 19:18:14', ' ', '', '', 'publish', 'closed', 'open', '', '296', '', '', '2014-06-04 16:38:24', '2014-06-04 16:38:24', '', '0', 'http://127.0.0.1/asug/?p=296', '13', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('297', '999999999', '2014-04-12 19:27:07', '2014-04-12 19:27:07', 'WP Backupware - 1397330827', 'WP Backupware - 1397330827', '', 'private', 'closed', 'open', '', 'wp-backupware-1397330827', '', '', '2014-04-12 19:27:07', '2014-04-12 19:27:07', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1397330827/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('298', '1', '2014-04-13 02:13:27', '2014-04-13 02:13:27', '', 'PASSEI_online_menor_[1]', '', 'inherit', 'closed', 'open', '', 'passei_online_menor_1', '', '', '2014-04-13 02:13:27', '2014-04-13 02:13:27', '', '226', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/PASSEI_online_menor_1.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('299', '1', '2014-04-13 02:13:33', '2014-04-13 02:13:33', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug teste 2', '', 'inherit', 'closed', 'open', '', '226-revision-v1', '', '', '2014-04-13 02:13:33', '2014-04-13 02:13:33', '', '226', 'http://127.0.0.1/asug/226-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('300', '999999999', '2014-04-13 19:30:28', '2014-04-13 19:30:28', 'WP Backupware - 1397417427', 'WP Backupware - 1397417427', '', 'private', 'closed', 'open', '', 'wp-backupware-1397417427', '', '', '2014-04-13 19:30:28', '2014-04-13 19:30:28', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1397417427/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('302', '999999999', '2014-04-14 19:56:05', '2014-04-14 19:56:05', 'WP Backupware - 1397505353', 'WP Backupware - 1397505353', '', 'private', 'closed', 'open', '', 'wp-backupware-1397505353', '', '', '2014-04-14 19:56:05', '2014-04-14 19:56:05', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1397505353/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('304', '999999999', '2014-04-15 19:31:03', '2014-04-15 19:31:03', 'WP Backupware - 1397590261', 'WP Backupware - 1397590261', '', 'private', 'closed', 'open', '', 'wp-backupware-1397590261', '', '', '2014-04-15 19:31:03', '2014-04-15 19:31:03', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1397590261/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('305', '999999999', '2014-04-22 21:35:55', '2014-04-22 21:35:55', 'WP Backupware - 1398202522', 'WP Backupware - 1398202522', '', 'private', 'closed', 'open', '', 'wp-backupware-1398202522', '', '', '2014-04-22 21:35:55', '2014-04-22 21:35:55', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398202522/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('308', '1', '2014-04-22 23:34:29', '2014-04-22 23:34:29', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/copy-asug-brasil.jpg', 'copy-asug-brasil.jpg', '', 'inherit', 'closed', 'open', '', 'copy-asug-brasil-jpg', '', '', '2014-04-22 23:34:29', '2014-04-22 23:34:29', '', '0', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/copy-asug-brasil.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('309', '1', '2014-04-23 00:01:59', '2014-04-23 00:01:59', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer suscipit magna at metus consequat iaculis. Nullam ut nulla facilisis, viverra magna at, pellentesque magna. Sed nibh turpis, tempus non nisi a, pharetra bibendum diam. Nulla aliquet eros enim, eu tempor mi egestas in. Nullam consequat interdum libero, vitae sodales tellus lobortis eu. Vivamus gravida libero ut lacus congue consequat. Duis viverra dolor vel nulla lacinia vehicula.

Suspendisse faucibus orci in turpis tincidunt, a aliquet velit feugiat. Duis eget dui velit. Phasellus ultrices, purus et gravida sodales, risus nibh pharetra dui, sit amet sagittis augue ipsum vitae massa. Fusce molestie laoreet nunc id posuere. In hac habitasse platea dictumst. Quisque vel sem ullamcorper, mattis enim eget, luctus metus. Pellentesque neque diam, vestibulum tincidunt bibendum a, egestas at enim. Nulla eu pellentesque mauris. Nullam aliquet ut nisi non imperdiet.

Donec est magna, tincidunt quis sagittis sed, aliquet non massa. Quisque rutrum arcu vitae massa sollicitudin consequat. Etiam tempor felis ut tortor viverra, vestibulum condimentum est blandit. Cras ultrices vestibulum dolor, nec rhoncus est vulputate nec. Ut sed augue id mi pellentesque interdum. Integer aliquam ipsum ut porttitor consectetur. Nullam sem mi, tristique nec condimentum feugiat, varius sit amet tellus. Integer a turpis ac est pellentesque ornare. Praesent id justo a eros malesuada sagittis. Suspendisse eget sapien id lorem accumsan tincidunt sed sit amet lorem. Ut pharetra purus quam, a luctus elit luctus sit amet. Aliquam placerat purus sem, non posuere velit cursus ullamcorper.

Aenean laoreet a leo sed lacinia. In hac habitasse platea dictumst. Morbi rutrum pharetra egestas. Nam rhoncus, dolor in sodales lacinia, leo nulla rutrum purus, at ornare dolor tortor et lorem. Quisque egestas in magna vitae rhoncus. Sed ligula erat, laoreet at turpis sit amet, tincidunt pulvinar justo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus porttitor nec mauris eget rutrum. Nunc semper felis vitae dolor blandit egestas a eget arcu. Praesent ipsum augue, porttitor eget lorem vel, euismod molestie nisi. Nullam dignissim erat id quam tristique, id adipiscing sem semper. Pellentesque ultricies diam sed nibh mattis, id pulvinar nunc suscipit. Praesent id mattis libero. Phasellus ac rhoncus ligula, quis consequat elit. Cras eros turpis, varius mollis odio vitae, consequat convallis quam.', 'AS PERSPECTIVAS PARA A TI', '', 'publish', 'closed', 'open', '', 'as-perspectivas-para-a-ti', '', '', '2014-04-23 00:01:59', '2014-04-23 00:01:59', '', '0', 'http://127.0.0.1/asug/?p=309', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('310', '1', '2014-04-23 00:01:39', '2014-04-23 00:01:39', '', 'Technology-news[1]', '', 'inherit', 'closed', 'open', '', 'technology-news1', '', '', '2014-04-23 00:01:39', '2014-04-23 00:01:39', '', '309', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/Technology-news1.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('311', '1', '2014-04-23 00:01:59', '2014-04-23 00:01:59', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer suscipit magna at metus consequat iaculis. Nullam ut nulla facilisis, viverra magna at, pellentesque magna. Sed nibh turpis, tempus non nisi a, pharetra bibendum diam. Nulla aliquet eros enim, eu tempor mi egestas in. Nullam consequat interdum libero, vitae sodales tellus lobortis eu. Vivamus gravida libero ut lacus congue consequat. Duis viverra dolor vel nulla lacinia vehicula.

Suspendisse faucibus orci in turpis tincidunt, a aliquet velit feugiat. Duis eget dui velit. Phasellus ultrices, purus et gravida sodales, risus nibh pharetra dui, sit amet sagittis augue ipsum vitae massa. Fusce molestie laoreet nunc id posuere. In hac habitasse platea dictumst. Quisque vel sem ullamcorper, mattis enim eget, luctus metus. Pellentesque neque diam, vestibulum tincidunt bibendum a, egestas at enim. Nulla eu pellentesque mauris. Nullam aliquet ut nisi non imperdiet.

Donec est magna, tincidunt quis sagittis sed, aliquet non massa. Quisque rutrum arcu vitae massa sollicitudin consequat. Etiam tempor felis ut tortor viverra, vestibulum condimentum est blandit. Cras ultrices vestibulum dolor, nec rhoncus est vulputate nec. Ut sed augue id mi pellentesque interdum. Integer aliquam ipsum ut porttitor consectetur. Nullam sem mi, tristique nec condimentum feugiat, varius sit amet tellus. Integer a turpis ac est pellentesque ornare. Praesent id justo a eros malesuada sagittis. Suspendisse eget sapien id lorem accumsan tincidunt sed sit amet lorem. Ut pharetra purus quam, a luctus elit luctus sit amet. Aliquam placerat purus sem, non posuere velit cursus ullamcorper.

Aenean laoreet a leo sed lacinia. In hac habitasse platea dictumst. Morbi rutrum pharetra egestas. Nam rhoncus, dolor in sodales lacinia, leo nulla rutrum purus, at ornare dolor tortor et lorem. Quisque egestas in magna vitae rhoncus. Sed ligula erat, laoreet at turpis sit amet, tincidunt pulvinar justo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus porttitor nec mauris eget rutrum. Nunc semper felis vitae dolor blandit egestas a eget arcu. Praesent ipsum augue, porttitor eget lorem vel, euismod molestie nisi. Nullam dignissim erat id quam tristique, id adipiscing sem semper. Pellentesque ultricies diam sed nibh mattis, id pulvinar nunc suscipit. Praesent id mattis libero. Phasellus ac rhoncus ligula, quis consequat elit. Cras eros turpis, varius mollis odio vitae, consequat convallis quam.', 'AS PERSPECTIVAS PARA A TI', '', 'inherit', 'closed', 'open', '', '309-revision-v1', '', '', '2014-04-23 00:01:59', '2014-04-23 00:01:59', '', '309', 'http://127.0.0.1/asug/309-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('312', '1', '2014-04-23 00:15:37', '2014-04-23 00:15:37', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer suscipit magna at metus consequat iaculis. Nullam ut nulla facilisis, viverra magna at, pellentesque magna. Sed nibh turpis, tempus non nisi a, pharetra bibendum diam. Nulla aliquet eros enim, eu tempor mi egestas in. Nullam consequat interdum libero, vitae sodales tellus lobortis eu. Vivamus gravida libero ut lacus congue consequat. Duis viverra dolor vel nulla lacinia vehicula.

Suspendisse faucibus orci in turpis tincidunt, a aliquet velit feugiat. Duis eget dui velit. Phasellus ultrices, purus et gravida sodales, risus nibh pharetra dui, sit amet sagittis augue ipsum vitae massa. Fusce molestie laoreet nunc id posuere. In hac habitasse platea dictumst. Quisque vel sem ullamcorper, mattis enim eget, luctus metus. Pellentesque neque diam, vestibulum tincidunt bibendum a, egestas at enim. Nulla eu pellentesque mauris. Nullam aliquet ut nisi non imperdiet.

Donec est magna, tincidunt quis sagittis sed, aliquet non massa. Quisque rutrum arcu vitae massa sollicitudin consequat. Etiam tempor felis ut tortor viverra, vestibulum condimentum est blandit. Cras ultrices vestibulum dolor, nec rhoncus est vulputate nec. Ut sed augue id mi pellentesque interdum. Integer aliquam ipsum ut porttitor consectetur. Nullam sem mi, tristique nec condimentum feugiat, varius sit amet tellus. Integer a turpis ac est pellentesque ornare. Praesent id justo a eros malesuada sagittis. Suspendisse eget sapien id lorem accumsan tincidunt sed sit amet lorem. Ut pharetra purus quam, a luctus elit luctus sit amet. Aliquam placerat purus sem, non posuere velit cursus ullamcorper.

Aenean laoreet a leo sed lacinia. In hac habitasse platea dictumst. Morbi rutrum pharetra egestas. Nam rhoncus, dolor in sodales lacinia, leo nulla rutrum purus, at ornare dolor tortor et lorem. Quisque egestas in magna vitae rhoncus. Sed ligula erat, laoreet at turpis sit amet, tincidunt pulvinar justo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus porttitor nec mauris eget rutrum. Nunc semper felis vitae dolor blandit egestas a eget arcu. Praesent ipsum augue, porttitor eget lorem vel, euismod molestie nisi. Nullam dignissim erat id quam tristique, id adipiscing sem semper. Pellentesque ultricies diam sed nibh mattis, id pulvinar nunc suscipit. Praesent id mattis libero. Phasellus ac rhoncus ligula, quis consequat elit. Cras eros turpis, varius mollis odio vitae, consequat convallis quam.', 'SAP traz novo conceito de treinamento empresarial ao Brasil', '', 'publish', 'closed', 'open', '', 'sap-traz-novo-conceito-de-treinamento-empresarial-ao-brasil', '', '', '2014-04-23 00:15:37', '2014-04-23 00:15:37', '', '0', 'http://127.0.0.1/asug/?p=312', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('313', '1', '2014-04-23 00:16:35', '2014-04-23 00:16:35', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer suscipit magna at metus consequat iaculis. Nullam ut nulla facilisis, viverra magna at, pellentesque magna. Sed nibh turpis, tempus non nisi a, pharetra bibendum diam. Nulla aliquet eros enim, eu tempor mi egestas in. Nullam consequat interdum libero, vitae sodales tellus lobortis eu. Vivamus gravida libero ut lacus congue consequat. Duis viverra dolor vel nulla lacinia vehicula.

Suspendisse faucibus orci in turpis tincidunt, a aliquet velit feugiat. Duis eget dui velit. Phasellus ultrices, purus et gravida sodales, risus nibh pharetra dui, sit amet sagittis augue ipsum vitae massa. Fusce molestie laoreet nunc id posuere. In hac habitasse platea dictumst. Quisque vel sem ullamcorper, mattis enim eget, luctus metus. Pellentesque neque diam, vestibulum tincidunt bibendum a, egestas at enim. Nulla eu pellentesque mauris. Nullam aliquet ut nisi non imperdiet.

Donec est magna, tincidunt quis sagittis sed, aliquet non massa. Quisque rutrum arcu vitae massa sollicitudin consequat. Etiam tempor felis ut tortor viverra, vestibulum condimentum est blandit. Cras ultrices vestibulum dolor, nec rhoncus est vulputate nec. Ut sed augue id mi pellentesque interdum. Integer aliquam ipsum ut porttitor consectetur. Nullam sem mi, tristique nec condimentum feugiat, varius sit amet tellus. Integer a turpis ac est pellentesque ornare. Praesent id justo a eros malesuada sagittis. Suspendisse eget sapien id lorem accumsan tincidunt sed sit amet lorem. Ut pharetra purus quam, a luctus elit luctus sit amet. Aliquam placerat purus sem, non posuere velit cursus ullamcorper.

Aenean laoreet a leo sed lacinia. In hac habitasse platea dictumst. Morbi rutrum pharetra egestas. Nam rhoncus, dolor in sodales lacinia, leo nulla rutrum purus, at ornare dolor tortor et lorem. Quisque egestas in magna vitae rhoncus. Sed ligula erat, laoreet at turpis sit amet, tincidunt pulvinar justo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus porttitor nec mauris eget rutrum. Nunc semper felis vitae dolor blandit egestas a eget arcu. Praesent ipsum augue, porttitor eget lorem vel, euismod molestie nisi. Nullam dignissim erat id quam tristique, id adipiscing sem semper. Pellentesque ultricies diam sed nibh mattis, id pulvinar nunc suscipit. Praesent id mattis libero. Phasellus ac rhoncus ligula, quis consequat elit. Cras eros turpis, varius mollis odio vitae, consequat convallis quam.', 'AS PERSPECTIVAS PARA A TI', '', 'publish', 'closed', 'open', '', 'as-perspectivas-para-a-ti-2', '', '', '2014-04-23 00:16:35', '2014-04-23 00:16:35', '', '0', 'http://127.0.0.1/asug/?p=313', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('314', '1', '2014-04-23 00:17:40', '2014-04-23 00:17:40', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer suscipit magna at metus consequat iaculis. Nullam ut nulla facilisis, viverra magna at, pellentesque magna. Sed nibh turpis, tempus non nisi a, pharetra bibendum diam. Nulla aliquet eros enim, eu tempor mi egestas in. Nullam consequat interdum libero, vitae sodales tellus lobortis eu. Vivamus gravida libero ut lacus congue consequat. Duis viverra dolor vel nulla lacinia vehicula.

Suspendisse faucibus orci in turpis tincidunt, a aliquet velit feugiat. Duis eget dui velit. Phasellus ultrices, purus et gravida sodales, risus nibh pharetra dui, sit amet sagittis augue ipsum vitae massa. Fusce molestie laoreet nunc id posuere. In hac habitasse platea dictumst. Quisque vel sem ullamcorper, mattis enim eget, luctus metus. Pellentesque neque diam, vestibulum tincidunt bibendum a, egestas at enim. Nulla eu pellentesque mauris. Nullam aliquet ut nisi non imperdiet.

Donec est magna, tincidunt quis sagittis sed, aliquet non massa. Quisque rutrum arcu vitae massa sollicitudin consequat. Etiam tempor felis ut tortor viverra, vestibulum condimentum est blandit. Cras ultrices vestibulum dolor, nec rhoncus est vulputate nec. Ut sed augue id mi pellentesque interdum. Integer aliquam ipsum ut porttitor consectetur. Nullam sem mi, tristique nec condimentum feugiat, varius sit amet tellus. Integer a turpis ac est pellentesque ornare. Praesent id justo a eros malesuada sagittis. Suspendisse eget sapien id lorem accumsan tincidunt sed sit amet lorem. Ut pharetra purus quam, a luctus elit luctus sit amet. Aliquam placerat purus sem, non posuere velit cursus ullamcorper.

Aenean laoreet a leo sed lacinia. In hac habitasse platea dictumst. Morbi rutrum pharetra egestas. Nam rhoncus, dolor in sodales lacinia, leo nulla rutrum purus, at ornare dolor tortor et lorem. Quisque egestas in magna vitae rhoncus. Sed ligula erat, laoreet at turpis sit amet, tincidunt pulvinar justo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus porttitor nec mauris eget rutrum. Nunc semper felis vitae dolor blandit egestas a eget arcu. Praesent ipsum augue, porttitor eget lorem vel, euismod molestie nisi. Nullam dignissim erat id quam tristique, id adipiscing sem semper. Pellentesque ultricies diam sed nibh mattis, id pulvinar nunc suscipit. Praesent id mattis libero. Phasellus ac rhoncus ligula, quis consequat elit. Cras eros turpis, varius mollis odio vitae, consequat convallis quam.', 'SAP traz novo conceito de treinamento empresarial ao Brasil ', '', 'publish', 'closed', 'open', '', 'sap-traz-novo-conceito-de-treinamento-empresarial-ao-brasil-2', '', '', '2014-04-23 00:17:40', '2014-04-23 00:17:40', '', '0', 'http://127.0.0.1/asug/?p=314', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('320', '1', '2014-04-23 00:15:21', '2014-04-23 00:15:21', '', 'circuit-Sqr[1]', '', 'inherit', 'closed', 'open', '', 'circuit-sqr1', '', '', '2014-04-23 00:15:21', '2014-04-23 00:15:21', '', '312', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/circuit-Sqr1.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('321', '1', '2014-04-23 00:15:37', '2014-04-23 00:15:37', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer suscipit magna at metus consequat iaculis. Nullam ut nulla facilisis, viverra magna at, pellentesque magna. Sed nibh turpis, tempus non nisi a, pharetra bibendum diam. Nulla aliquet eros enim, eu tempor mi egestas in. Nullam consequat interdum libero, vitae sodales tellus lobortis eu. Vivamus gravida libero ut lacus congue consequat. Duis viverra dolor vel nulla lacinia vehicula.

Suspendisse faucibus orci in turpis tincidunt, a aliquet velit feugiat. Duis eget dui velit. Phasellus ultrices, purus et gravida sodales, risus nibh pharetra dui, sit amet sagittis augue ipsum vitae massa. Fusce molestie laoreet nunc id posuere. In hac habitasse platea dictumst. Quisque vel sem ullamcorper, mattis enim eget, luctus metus. Pellentesque neque diam, vestibulum tincidunt bibendum a, egestas at enim. Nulla eu pellentesque mauris. Nullam aliquet ut nisi non imperdiet.

Donec est magna, tincidunt quis sagittis sed, aliquet non massa. Quisque rutrum arcu vitae massa sollicitudin consequat. Etiam tempor felis ut tortor viverra, vestibulum condimentum est blandit. Cras ultrices vestibulum dolor, nec rhoncus est vulputate nec. Ut sed augue id mi pellentesque interdum. Integer aliquam ipsum ut porttitor consectetur. Nullam sem mi, tristique nec condimentum feugiat, varius sit amet tellus. Integer a turpis ac est pellentesque ornare. Praesent id justo a eros malesuada sagittis. Suspendisse eget sapien id lorem accumsan tincidunt sed sit amet lorem. Ut pharetra purus quam, a luctus elit luctus sit amet. Aliquam placerat purus sem, non posuere velit cursus ullamcorper.

Aenean laoreet a leo sed lacinia. In hac habitasse platea dictumst. Morbi rutrum pharetra egestas. Nam rhoncus, dolor in sodales lacinia, leo nulla rutrum purus, at ornare dolor tortor et lorem. Quisque egestas in magna vitae rhoncus. Sed ligula erat, laoreet at turpis sit amet, tincidunt pulvinar justo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus porttitor nec mauris eget rutrum. Nunc semper felis vitae dolor blandit egestas a eget arcu. Praesent ipsum augue, porttitor eget lorem vel, euismod molestie nisi. Nullam dignissim erat id quam tristique, id adipiscing sem semper. Pellentesque ultricies diam sed nibh mattis, id pulvinar nunc suscipit. Praesent id mattis libero. Phasellus ac rhoncus ligula, quis consequat elit. Cras eros turpis, varius mollis odio vitae, consequat convallis quam.', 'SAP traz novo conceito de treinamento empresarial ao Brasil', '', 'inherit', 'closed', 'open', '', '312-revision-v1', '', '', '2014-04-23 00:15:37', '2014-04-23 00:15:37', '', '312', 'http://127.0.0.1/asug/312-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('322', '1', '2014-04-23 00:16:24', '2014-04-23 00:16:24', '', 'technology-hand[1]', '', 'inherit', 'closed', 'open', '', 'technology-hand1', '', '', '2014-04-23 00:16:24', '2014-04-23 00:16:24', '', '313', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/technology-hand1.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('323', '1', '2014-04-23 00:16:35', '2014-04-23 00:16:35', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer suscipit magna at metus consequat iaculis. Nullam ut nulla facilisis, viverra magna at, pellentesque magna. Sed nibh turpis, tempus non nisi a, pharetra bibendum diam. Nulla aliquet eros enim, eu tempor mi egestas in. Nullam consequat interdum libero, vitae sodales tellus lobortis eu. Vivamus gravida libero ut lacus congue consequat. Duis viverra dolor vel nulla lacinia vehicula.

Suspendisse faucibus orci in turpis tincidunt, a aliquet velit feugiat. Duis eget dui velit. Phasellus ultrices, purus et gravida sodales, risus nibh pharetra dui, sit amet sagittis augue ipsum vitae massa. Fusce molestie laoreet nunc id posuere. In hac habitasse platea dictumst. Quisque vel sem ullamcorper, mattis enim eget, luctus metus. Pellentesque neque diam, vestibulum tincidunt bibendum a, egestas at enim. Nulla eu pellentesque mauris. Nullam aliquet ut nisi non imperdiet.

Donec est magna, tincidunt quis sagittis sed, aliquet non massa. Quisque rutrum arcu vitae massa sollicitudin consequat. Etiam tempor felis ut tortor viverra, vestibulum condimentum est blandit. Cras ultrices vestibulum dolor, nec rhoncus est vulputate nec. Ut sed augue id mi pellentesque interdum. Integer aliquam ipsum ut porttitor consectetur. Nullam sem mi, tristique nec condimentum feugiat, varius sit amet tellus. Integer a turpis ac est pellentesque ornare. Praesent id justo a eros malesuada sagittis. Suspendisse eget sapien id lorem accumsan tincidunt sed sit amet lorem. Ut pharetra purus quam, a luctus elit luctus sit amet. Aliquam placerat purus sem, non posuere velit cursus ullamcorper.

Aenean laoreet a leo sed lacinia. In hac habitasse platea dictumst. Morbi rutrum pharetra egestas. Nam rhoncus, dolor in sodales lacinia, leo nulla rutrum purus, at ornare dolor tortor et lorem. Quisque egestas in magna vitae rhoncus. Sed ligula erat, laoreet at turpis sit amet, tincidunt pulvinar justo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus porttitor nec mauris eget rutrum. Nunc semper felis vitae dolor blandit egestas a eget arcu. Praesent ipsum augue, porttitor eget lorem vel, euismod molestie nisi. Nullam dignissim erat id quam tristique, id adipiscing sem semper. Pellentesque ultricies diam sed nibh mattis, id pulvinar nunc suscipit. Praesent id mattis libero. Phasellus ac rhoncus ligula, quis consequat elit. Cras eros turpis, varius mollis odio vitae, consequat convallis quam.', 'AS PERSPECTIVAS PARA A TI', '', 'inherit', 'closed', 'open', '', '313-revision-v1', '', '', '2014-04-23 00:16:35', '2014-04-23 00:16:35', '', '313', 'http://127.0.0.1/asug/313-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('324', '1', '2014-04-23 00:17:19', '2014-04-23 00:17:19', '', 'cpuaroundworld_alpha[1]', '', 'inherit', 'closed', 'open', '', 'cpuaroundworld_alpha1', '', '', '2014-04-23 00:17:19', '2014-04-23 00:17:19', '', '314', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/cpuaroundworld_alpha1.png', '0', 'attachment', 'image/png', '0'); 
INSERT INTO `wp_posts` VALUES ('325', '1', '2014-04-23 00:17:40', '2014-04-23 00:17:40', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer suscipit magna at metus consequat iaculis. Nullam ut nulla facilisis, viverra magna at, pellentesque magna. Sed nibh turpis, tempus non nisi a, pharetra bibendum diam. Nulla aliquet eros enim, eu tempor mi egestas in. Nullam consequat interdum libero, vitae sodales tellus lobortis eu. Vivamus gravida libero ut lacus congue consequat. Duis viverra dolor vel nulla lacinia vehicula.

Suspendisse faucibus orci in turpis tincidunt, a aliquet velit feugiat. Duis eget dui velit. Phasellus ultrices, purus et gravida sodales, risus nibh pharetra dui, sit amet sagittis augue ipsum vitae massa. Fusce molestie laoreet nunc id posuere. In hac habitasse platea dictumst. Quisque vel sem ullamcorper, mattis enim eget, luctus metus. Pellentesque neque diam, vestibulum tincidunt bibendum a, egestas at enim. Nulla eu pellentesque mauris. Nullam aliquet ut nisi non imperdiet.

Donec est magna, tincidunt quis sagittis sed, aliquet non massa. Quisque rutrum arcu vitae massa sollicitudin consequat. Etiam tempor felis ut tortor viverra, vestibulum condimentum est blandit. Cras ultrices vestibulum dolor, nec rhoncus est vulputate nec. Ut sed augue id mi pellentesque interdum. Integer aliquam ipsum ut porttitor consectetur. Nullam sem mi, tristique nec condimentum feugiat, varius sit amet tellus. Integer a turpis ac est pellentesque ornare. Praesent id justo a eros malesuada sagittis. Suspendisse eget sapien id lorem accumsan tincidunt sed sit amet lorem. Ut pharetra purus quam, a luctus elit luctus sit amet. Aliquam placerat purus sem, non posuere velit cursus ullamcorper.

Aenean laoreet a leo sed lacinia. In hac habitasse platea dictumst. Morbi rutrum pharetra egestas. Nam rhoncus, dolor in sodales lacinia, leo nulla rutrum purus, at ornare dolor tortor et lorem. Quisque egestas in magna vitae rhoncus. Sed ligula erat, laoreet at turpis sit amet, tincidunt pulvinar justo. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Vivamus porttitor nec mauris eget rutrum. Nunc semper felis vitae dolor blandit egestas a eget arcu. Praesent ipsum augue, porttitor eget lorem vel, euismod molestie nisi. Nullam dignissim erat id quam tristique, id adipiscing sem semper. Pellentesque ultricies diam sed nibh mattis, id pulvinar nunc suscipit. Praesent id mattis libero. Phasellus ac rhoncus ligula, quis consequat elit. Cras eros turpis, varius mollis odio vitae, consequat convallis quam.', 'SAP traz novo conceito de treinamento empresarial ao Brasil ', '', 'inherit', 'closed', 'open', '', '314-revision-v1', '', '', '2014-04-23 00:17:40', '2014-04-23 00:17:40', '', '314', 'http://127.0.0.1/asug/314-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('326', '1', '2014-04-23 00:21:50', '2014-04-23 00:21:50', '', 'Home', '', 'inherit', 'closed', 'open', '', '2-revision-v1', '', '', '2014-04-23 00:21:50', '2014-04-23 00:21:50', '', '2', 'http://127.0.0.1/asug/2-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('327', '999999999', '2014-04-24 01:20:13', '2014-04-24 01:20:13', 'WP Backupware - 1398302411', 'WP Backupware - 1398302411', '', 'private', 'closed', 'open', '', 'wp-backupware-1398302411', '', '', '2014-04-24 01:20:13', '2014-04-24 01:20:13', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398302411/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('328', '999999999', '2014-04-25 00:06:36', '2014-04-25 00:06:36', 'WP Backupware - 1398384395', 'WP Backupware - 1398384395', '', 'private', 'closed', 'open', '', 'wp-backupware-1398384395', '', '', '2014-04-25 00:06:36', '2014-04-25 00:06:36', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398384395/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('329', '1', '2014-04-25 01:38:16', '2014-04-25 01:38:16', '', 'Notícias em destaques', '', 'publish', 'closed', 'open', '', 'noticias-em-destaques', '', '', '2014-04-25 01:40:04', '2014-04-25 01:40:04', '', '0', 'http://127.0.0.1/asug/?page_id=329', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('330', '1', '2014-04-25 01:38:16', '2014-04-25 01:38:16', '', 'Notícias em destaques', '', 'inherit', 'closed', 'open', '', '329-revision-v1', '', '', '2014-04-25 01:38:16', '2014-04-25 01:38:16', '', '329', 'http://127.0.0.1/asug/329-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('331', '999999999', '2014-04-25 21:58:35', '2014-04-25 21:58:35', 'WP Backupware - 1398463094', 'WP Backupware - 1398463094', '', 'private', 'closed', 'open', '', 'wp-backupware-1398463094', '', '', '2014-04-25 21:58:35', '2014-04-25 21:58:35', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398463094/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('332', '1', '2014-04-26 00:46:49', '2014-04-26 00:46:49', '', 'Conferência anual', '', 'publish', 'closed', 'closed', '', 'acf_conferencia-anual', '', '', '2014-06-06 17:39:49', '2014-06-06 17:39:49', '', '0', 'http://127.0.0.1/asug/?post_type=acf&#038;p=332', '0', 'acf', '', '0'); 
INSERT INTO `wp_posts` VALUES ('361', '999999999', '2014-04-26 22:01:31', '2014-04-26 22:01:31', 'WP Backupware - 1398549688', 'WP Backupware - 1398549688', '', 'private', 'closed', 'open', '', 'wp-backupware-1398549688', '', '', '2014-04-26 22:01:31', '2014-04-26 22:01:31', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398549688/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('364', '1', '2014-04-26 22:42:31', '2014-04-26 22:42:31', 'A <strong>ASUG Brasil</strong> realizará no dia 19 de agosto de 2014 a 17ª CONFERÊNCIA ANUAL, no Hotel Transamérica São Paulo, um dos melhores e mais conceituados hotéis nacionais para esse tipo de evento. Este é o evento mais esperado do ano pelos associados da ASUG Brasil, por sua importância em trazer e atualizar todas as novidades do ano preparadas pela SAP mundial ao cenário nacional. Serão mais de 50 palestras simultâneas, do mais alto nível de informação sobre as diversidades do ecossistema SAP. Este evento proporcionará ainda momentos especiais de networking entre os parceiros e clientes SAP.

RESERVE SUA AGENDA!', 'Coferência anual 2014', '', 'publish', 'closed', 'open', '', 'coferencia-anual-2014', '', '', '2014-06-06 18:01:53', '2014-06-06 18:01:53', '', '0', 'http://127.0.0.1/asug/?p=364', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('365', '1', '2014-04-26 22:42:31', '2014-04-26 22:42:31', '', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-revision-v1', '', '', '2014-04-26 22:42:31', '2014-04-26 22:42:31', '', '364', 'http://127.0.0.1/asug/364-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('366', '1', '2014-04-26 23:10:22', '2014-04-26 23:10:22', '', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-revision-v1', '', '', '2014-04-26 23:10:22', '2014-04-26 23:10:22', '', '364', 'http://127.0.0.1/asug/364-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('367', '1', '2014-04-26 23:10:43', '2014-04-26 23:10:43', '', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-revision-v1', '', '', '2014-04-26 23:10:43', '2014-04-26 23:10:43', '', '364', 'http://127.0.0.1/asug/364-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('368', '1', '2014-04-27 00:45:08', '2014-04-27 00:45:08', '', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-revision-v1', '', '', '2014-04-27 00:45:08', '2014-04-27 00:45:08', '', '364', 'http://127.0.0.1/asug/364-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('369', '1', '2014-04-27 00:48:54', '2014-04-27 00:48:54', '', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-revision-v1', '', '', '2014-04-27 00:48:54', '2014-04-27 00:48:54', '', '364', 'http://127.0.0.1/asug/364-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('370', '1', '2014-06-06 17:55:26', '2014-06-06 17:55:26', 'A ASUG Brasil realizará no dia 19 de agosto de 2014 a 17ª CONFERÊNCIA ANUAL, no Hotel Transamérica São Paulo, um dos melhores e mais conceituados hotéis nacionais para esse tipo de evento. Este é o evento mais esperado do ano pelos associados da ASUG Brasil, por sua importância em trazer e atualizar todas as novidades do ano preparadas pela SAP mundial ao cenário nacional. Serão mais de 50 palestras simultâneas, do mais alto nível de informação sobre as diversidades do ecossistema SAP. Este evento proporcionará ainda momentos especiais de networking entre os parceiros e clientes SAP.

RESERVE SUA AGENDA!', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-autosave-v1', '', '', '2014-06-06 17:55:26', '2014-06-06 17:55:26', '', '364', 'http://127.0.0.1/asug/364-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('371', '1', '2014-04-27 00:59:01', '2014-04-27 00:59:01', 'Lorem <strong>ipsum</strong> dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, <em>consectetur</em> adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet consectetur <strong><span style="color: #ff0000;">adipisicing</span> </strong>elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-revision-v1', '', '', '2014-04-27 00:59:01', '2014-04-27 00:59:01', '', '364', 'http://127.0.0.1/asug/364-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('372', '1', '2013-04-27 01:03:14', '2013-04-27 01:03:14', 'Lorem <strong>ipsum</strong> dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, <em>consectetur</em> adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet consectetur <strong><span style="color: #ff0000;">adipisicing</span> </strong>elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Coferência anual 2013', '', 'publish', 'closed', 'open', '', 'coferencia-anual-2013', '', '', '2014-04-27 01:03:46', '2014-04-27 01:03:46', '', '0', 'http://127.0.0.1/asug/?p=372', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('373', '1', '2012-04-27 01:03:29', '2012-04-27 01:03:29', 'Lorem <strong>ipsum</strong> dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, <em>consectetur</em> adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet consectetur <strong><span style="color: #ff0000;">adipisicing</span> </strong>elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Coferência anual 2012', '', 'publish', 'closed', 'open', '', 'coferencia-anual-2012', '', '', '2014-04-27 01:04:00', '2014-04-27 01:04:00', '', '0', 'http://127.0.0.1/asug/?p=373', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('374', '1', '2014-04-27 01:03:46', '2014-04-27 01:03:46', 'Lorem <strong>ipsum</strong> dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, <em>consectetur</em> adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet consectetur <strong><span style="color: #ff0000;">adipisicing</span> </strong>elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Coferência anual 2013', '', 'inherit', 'closed', 'open', '', '372-revision-v1', '', '', '2014-04-27 01:03:46', '2014-04-27 01:03:46', '', '372', 'http://127.0.0.1/asug/372-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('375', '1', '2014-04-27 01:04:00', '2014-04-27 01:04:00', 'Lorem <strong>ipsum</strong> dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, <em>consectetur</em> adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet consectetur <strong><span style="color: #ff0000;">adipisicing</span> </strong>elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Coferência anual 2012', '', 'inherit', 'closed', 'open', '', '373-revision-v1', '', '', '2014-04-27 01:04:00', '2014-04-27 01:04:00', '', '373', 'http://127.0.0.1/asug/373-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('376', '999999999', '2014-04-27 19:25:58', '2014-04-27 19:25:58', 'WP Backupware - 1398626757', 'WP Backupware - 1398626757', '', 'private', 'closed', 'open', '', 'wp-backupware-1398626757', '', '', '2014-04-27 19:25:58', '2014-04-27 19:25:58', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398626757/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('377', '999999999', '2014-04-28 19:26:00', '2014-04-28 19:26:00', 'WP Backupware - 1398713159', 'WP Backupware - 1398713159', '', 'private', 'closed', 'open', '', 'wp-backupware-1398713159', '', '', '2014-04-28 19:26:00', '2014-04-28 19:26:00', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398713159/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('378', '999999999', '2014-04-29 21:45:01', '2014-04-29 21:45:01', 'WP Backupware - 1398807894', 'WP Backupware - 1398807894', '', 'private', 'closed', 'open', '', 'wp-backupware-1398807894', '', '', '2014-04-29 21:45:01', '2014-04-29 21:45:01', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398807894/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('395', '999999999', '2014-05-01 13:55:59', '2014-05-01 13:55:59', 'WP Backupware - 1398952556', 'WP Backupware - 1398952556', '', 'private', 'closed', 'open', '', 'wp-backupware-1398952556', '', '', '2014-05-01 13:55:59', '2014-05-01 13:55:59', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398952556/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('397', '999999999', '2014-05-01 19:27:09', '2014-05-01 19:27:09', 'WP Backupware - 1398972426', 'WP Backupware - 1398972426', '', 'private', 'closed', 'open', '', 'wp-backupware-1398972426', '', '', '2014-05-01 19:27:09', '2014-05-01 19:27:09', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1398972426/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('398', '999999999', '2014-05-03 16:18:14', '2014-05-03 16:18:14', 'WP Backupware - 1399133890', 'WP Backupware - 1399133890', '', 'private', 'closed', 'open', '', 'wp-backupware-1399133890', '', '', '2014-05-03 16:18:14', '2014-05-03 16:18:14', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1399133890/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('399', '999999999', '2014-05-03 19:27:48', '2014-05-03 19:27:48', 'WP Backupware - 1399145267', 'WP Backupware - 1399145267', '', 'private', 'closed', 'open', '', 'wp-backupware-1399145267', '', '', '2014-05-03 19:27:48', '2014-05-03 19:27:48', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1399145267/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('400', '999999999', '2014-05-04 19:32:29', '2014-05-04 19:32:29', 'WP Backupware - 1399231948', 'WP Backupware - 1399231948', '', 'private', 'closed', 'open', '', 'wp-backupware-1399231948', '', '', '2014-05-04 19:32:29', '2014-05-04 19:32:29', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1399231948/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('401', '999999999', '2014-05-30 23:00:49', '2014-05-30 23:00:49', 'WP Backupware - 1401490846', 'WP Backupware - 1401490846', '', 'private', 'closed', 'open', '', 'wp-backupware-1401490846', '', '', '2014-05-30 23:00:49', '2014-05-30 23:00:49', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1401490846/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('402', '999999999', '2014-06-02 23:12:39', '2014-06-02 23:12:39', 'WP Backupware - 1401750756', 'WP Backupware - 1401750756', '', 'private', 'closed', 'open', '', 'wp-backupware-1401750756', '', '', '2014-06-02 23:12:39', '2014-06-02 23:12:39', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1401750756/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('403', '1', '2014-06-02 23:12:48', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-02 23:12:48', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=403', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('404', '1', '2014-05-06 14:22:42', '2014-05-06 14:22:42', '', 'Minha Conta', '', 'publish', 'closed', 'closed', '', 'conta', '', '', '2014-05-09 02:04:27', '2014-05-09 02:04:27', '', '0', 'http://127.0.0.1/asug/minha-conta-2/', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('405', '1', '2014-05-27 12:03:23', '2014-05-27 15:03:23', '(página de sistema do perfil do associado)', 'Perfil', '', 'publish', 'closed', 'closed', '', 'perfil', '', '', '2014-05-27 12:03:23', '2014-05-27 15:03:23', '', '0', 'http://127.0.0.1/asug/?page_id=334', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('406', '1', '2014-05-27 12:04:29', '2014-05-27 15:04:29', '(página de sistema que redireciona para realizar login na SuccessFactors)', 'SAP', '', 'publish', 'closed', 'closed', '', 'sap', '', '', '2014-05-27 12:04:53', '2014-05-27 15:04:53', '', '0', 'http://127.0.0.1/asug/?page_id=336', '0', 'page', '', '0'); 
INSERT INTO `wp_posts` VALUES ('407', '29', '2014-06-02 18:43:44', '2014-06-02 21:43:44', '', 'Fórum', '', 'publish', 'closed', 'open', '', 'forum-2', '', '', '2014-06-02 18:43:44', '2014-06-02 21:43:44', '', '0', 'http://127.0.0.1/asug/?p=339', '9', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('408', '999999999', '2014-06-04 12:12:05', '2014-06-04 12:12:05', 'WP Backupware - 1401883924', 'WP Backupware - 1401883924', '', 'private', 'closed', 'open', '', 'wp-backupware-1401883924', '', '', '2014-06-04 12:12:05', '2014-06-04 12:12:05', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1401883924/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('409', '1', '2014-06-04 12:21:17', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 12:21:17', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=409', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('410', '1', '2014-06-04 12:37:50', '2014-06-04 12:37:50', '[pdf issuu_pdf_id="140329182930-60a7a3782bd04be4987cb898e71b0cb2" layout="1" width="800" height="600" bgcolor="FFFFFF" allow_full_screen_="1" flip_timelaps="6000" ]', '', '', 'trash', 'closed', 'open', '', '410', '', '', '2014-06-04 13:51:36', '2014-06-04 13:51:36', '', '0', 'http://127.0.0.1/asug/?p=410', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('411', '1', '2014-06-04 13:13:06', '2014-06-04 13:13:06', '[pdf issuu_pdf_id="140604131010-06e24ac9938d4de994fa25d56ce7e10e" layout="1" width="800" height="600" bgcolor="FFFFFF" allow_full_screen_="1" flip_timelaps="6000" ]', '', '', 'trash', 'closed', 'open', '', '411', '', '', '2014-06-04 13:51:36', '2014-06-04 13:51:36', '', '0', 'http://127.0.0.1/asug/?p=411', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('412', '1', '2014-06-04 12:51:11', '2014-06-04 12:51:11', '', 'HWM_P_2014_06_downmagaz.com', '', 'inherit', 'closed', 'open', '', 'hwm_p_2014_06_downmagaz-com', '', '', '2014-06-04 12:51:11', '2014-06-04 12:51:11', '', '411', 'http://127.0.0.1/asug/wp-content/uploads/2014/06/HWM_P_2014_06_downmagaz.com_.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('413', '1', '2014-06-04 12:52:49', '2014-06-04 12:52:49', '[pdf issuu_pdf_id="140604125118-4d6564659e5f4ebe96b3cce40c94ded1" layout="1" width="800" height="600" bgcolor="FFFFFF" allow_full_screen_="1" flip_timelaps="6000" ]', '', '', 'inherit', 'closed', 'open', '', '411-revision-v1', '', '', '2014-06-04 12:52:49', '2014-06-04 12:52:49', '', '411', 'http://127.0.0.1/asug/411-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('414', '1', '2014-06-04 12:54:22', '2014-06-04 12:54:22', '<a href="http://127.0.0.1/asug/wp-content/uploads/2014/03/wireframe-interna-ASUG.pdf">wireframe-interna-ASUG</a> [pdf issuu_pdf_id="140329182930-60a7a3782bd04be4987cb898e71b0cb2" layout="1" width="800" height="600" bgcolor="FFFFFF" allow_full_screen_="1" flip_timelaps="6000" ]', '', '', 'inherit', 'closed', 'open', '', '411-revision-v1', '', '', '2014-06-04 12:54:22', '2014-06-04 12:54:22', '', '411', 'http://127.0.0.1/asug/411-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('415', '1', '2014-06-04 12:57:50', '2014-06-04 12:57:50', '', 'teste', '', 'inherit', 'closed', 'open', '', 'teste', '', '', '2014-06-04 12:57:50', '2014-06-04 12:57:50', '', '411', 'http://127.0.0.1/asug/wp-content/uploads/2014/06/teste.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('416', '1', '2014-06-04 13:07:25', '2014-06-04 13:07:25', '', '2', '', 'inherit', 'closed', 'open', '', '2', '', '', '2014-06-04 13:07:25', '2014-06-04 13:07:25', '', '411', 'http://127.0.0.1/asug/wp-content/uploads/2014/06/2.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('417', '1', '2014-06-04 13:07:40', '2014-06-04 13:07:40', '<a href="http://127.0.0.1/asug/wp-content/uploads/2014/06/2.pdf">2</a> [pdf issuu_pdf_id="140604130731-3d76c6cf25c9485eb1cde6d0bda0fd1d" layout="1" width="800" height="600" bgcolor="FFFFFF" allow_full_screen_="1" flip_timelaps="6000" ]', '', '', 'inherit', 'closed', 'open', '', '411-revision-v1', '', '', '2014-06-04 13:07:40', '2014-06-04 13:07:40', '', '411', 'http://127.0.0.1/asug/411-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('418', '1', '2014-06-04 13:08:31', '2014-06-04 13:08:31', '[pdf issuu_pdf_id="140604130731-3d76c6cf25c9485eb1cde6d0bda0fd1d" layout="1" width="800" height="600" bgcolor="FFFFFF" allow_full_screen_="1" flip_timelaps="6000" ]', '', '', 'inherit', 'closed', 'open', '', '411-revision-v1', '', '', '2014-06-04 13:08:31', '2014-06-04 13:08:31', '', '411', 'http://127.0.0.1/asug/411-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('419', '1', '2014-06-04 13:10:04', '2014-06-04 13:10:04', '', '2', '', 'inherit', 'closed', 'open', '', '2-2', '', '', '2014-06-04 13:10:04', '2014-06-04 13:10:04', '', '411', 'http://127.0.0.1/asug/wp-content/uploads/2014/06/21.pdf', '0', 'attachment', 'application/pdf', '0'); 
INSERT INTO `wp_posts` VALUES ('420', '1', '2014-06-04 13:11:04', '2014-06-04 13:11:04', '[pdf issuu_pdf_id="140604131010-06e24ac9938d4de994fa25d56ce7e10e" layout="1" width="800" height="600" bgcolor="FFFFFF" allow_full_screen_="1" flip_timelaps="6000" ]', '', '', 'inherit', 'closed', 'open', '', '411-revision-v1', '', '', '2014-06-04 13:11:04', '2014-06-04 13:11:04', '', '411', 'http://127.0.0.1/asug/411-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('421', '1', '2014-06-04 13:18:51', '2014-06-04 13:18:51', 'http://issuu.com/asugnews/docs/2', '', '', 'trash', 'closed', 'open', '', '421', '', '', '2014-06-04 13:51:35', '2014-06-04 13:51:35', '', '0', 'http://127.0.0.1/asug/?p=421', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('422', '1', '2014-06-04 13:17:56', '2014-06-04 13:17:56', 'http://issuu.com/asugnews/docs/2', '', '', 'inherit', 'closed', 'open', '', '421-revision-v1', '', '', '2014-06-04 13:17:56', '2014-06-04 13:17:56', '', '421', 'http://127.0.0.1/asug/421-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('423', '1', '2014-06-04 13:51:36', '2014-06-04 13:51:36', '[pdf issuu_pdf_id="140329182930-60a7a3782bd04be4987cb898e71b0cb2" layout="1" width="800" height="600" bgcolor="FFFFFF" allow_full_screen_="1" flip_timelaps="6000" ]', '', '', 'inherit', 'closed', 'open', '', '410-revision-v1', '', '', '2014-06-04 13:51:36', '2014-06-04 13:51:36', '', '410', 'http://127.0.0.1/asug/410-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('424', '1', '2014-06-04 13:53:46', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 13:53:46', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=424', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('425', '1', '2014-06-04 13:57:17', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 13:57:17', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=425', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('426', '1', '2014-06-04 13:57:50', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 13:57:50', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=426', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('427', '1', '2014-06-04 13:58:13', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 13:58:13', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=427', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('428', '1', '2014-06-04 13:58:41', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 13:58:41', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=428', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('429', '1', '2014-06-04 13:58:45', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 13:58:45', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=429', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('430', '1', '2014-06-04 13:59:38', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 13:59:38', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=430', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('431', '1', '2014-06-04 14:00:22', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 14:00:22', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=431', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('432', '1', '2014-06-04 14:03:47', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 14:03:47', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=432', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('433', '1', '2014-06-04 14:04:16', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 14:04:16', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=433', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('434', '1', '2014-06-04 14:04:47', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 14:04:47', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=434', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('435', '1', '2014-06-04 14:05:36', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 14:05:36', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=435', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('436', '1', '2014-06-04 14:07:36', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 14:07:36', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=436', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('437', '1', '2014-06-04 14:09:22', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 14:09:22', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=437', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('438', '1', '2014-06-04 14:16:05', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 14:16:05', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=438', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('439', '1', '2014-06-04 14:16:27', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 14:16:27', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=439', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('440', '1', '2014-06-04 16:10:41', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 16:10:41', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&p=440', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('441', '1', '2014-06-04 16:14:10', '2014-06-04 16:14:10', '<a href="http://127.0.0.1/asug/wp-content/uploads/2014/06/bn-ret.jpg"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/06/bn-ret.jpg" alt="bn-ret" width="476" height="248" class="alignnone size-full wp-image-442" /></a>', 'Banner Destaque', '', 'publish', 'closed', 'closed', '', 'banner-destaque', '', '', '2014-06-04 16:14:10', '2014-06-04 16:14:10', '', '0', 'http://127.0.0.1/asug/?post_type=dfads&#038;p=441', '0', 'dfads', '', '0'); 
INSERT INTO `wp_posts` VALUES ('442', '1', '2014-06-04 16:13:57', '2014-06-04 16:13:57', '', 'bn-ret', '', 'inherit', 'closed', 'open', '', 'bn-ret', '', '', '2014-06-04 16:13:57', '2014-06-04 16:13:57', '', '441', 'http://127.0.0.1/asug/wp-content/uploads/2014/06/bn-ret.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('443', '1', '2014-06-04 16:14:10', '2014-06-04 16:14:10', '<a href="http://127.0.0.1/asug/wp-content/uploads/2014/06/bn-ret.jpg"><img src="http://127.0.0.1/asug/wp-content/uploads/2014/06/bn-ret.jpg" alt="bn-ret" width="476" height="248" class="alignnone size-full wp-image-442" /></a>', 'Banner Destaque', '', 'inherit', 'closed', 'open', '', '441-revision-v1', '', '', '2014-06-04 16:14:10', '2014-06-04 16:14:10', '', '441', 'http://127.0.0.1/asug/441-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('444', '1', '2014-06-04 16:32:59', '2014-06-04 16:32:59', ' ', '', '', 'publish', 'closed', 'open', '', '444', '', '', '2014-06-04 16:38:23', '2014-06-04 16:38:23', '', '0', 'http://127.0.0.1/asug/?p=444', '2', 'nav_menu_item', '', '0'); 
INSERT INTO `wp_posts` VALUES ('445', '1', '2014-06-04 16:38:36', '2014-06-04 16:38:36', '<iframe width="100%" height="400" src="//www.youtube.com/embed/9Bo9kf9BJrI" frameborder="0" allowfullscreen></iframe>
<h2>CONHEÇA A ASUG BRASIL</h2>
ASUG Brasil (Associação dos Usuários SAP do Brasil) é uma entidade sem fins lucrativos que reúne clientes da SAP e parceiros credenciados (fornecedores e consultores), a fim de inteirá-los sobre a utilização de software desenvolvido pela SAP. Para isso, organiza conferências, seminários, premiações e reuniões de grupos sobre temas específicos. Desses eventos, surgem dúvidas, necessidades, aplicações de software SAP e troca de experiência entre os associados. A ASUG é o caminho mais seguro e rápido para os usuários agirem em conjunto, determinando prioridades e monitorando o desenvolvimento e o avanço tecnológico de aplicações SAP, por intermédio de requerimentos gerados nos Grupos de Pesquisa e Estudo e encaminhados à SAP Alemanha, para solução.
<h2>MISSÃO ASUG</h2>
"Agregar valor aos associados por meio da busca de soluções comuns, do compartilhamento do conhecimento e da representação dos interesses coletivos junto à SAP."
<h2>PILARES DA ASUG</h2>
<img class="aligncenter size-full wp-image-447" src="http://127.0.0.1/asug/wp-content/uploads/2014/03/pilares.jpg" alt="pilares" width="560" height="400" />
<h2>PORTAL ASUG - www.asug.com.br</h2>
O meio mais fácil de associar a sua empresa. É um portal com páginas públicas e privativas dos associados ASUG Brasil, contendo os seguintes assuntos: Apresentação, banco de atas, banco de desenvolvimento, lista de associados, diretoria, grupos de estudo, sala de chat, eventos, etc. Está em constante atualização, acompanhando as necessidades e os desejos dos associados.', 'Institucional', '', 'inherit', 'closed', 'open', '', '6-autosave-v1', '', '', '2014-06-04 16:38:36', '2014-06-04 16:38:36', '', '6', 'http://127.0.0.1/asug/6-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('446', '1', '2014-06-04 16:34:39', '2014-06-04 16:34:39', '<h2>CONHEÇA A ASUG BRASIL</h2>
ASUG Brasil (Associação dos Usuários SAP do Brasil) é uma entidade sem fins lucrativos que reúne clientes da SAP e parceiros credenciados (fornecedores e consultores), a fim de inteirá-los sobre a utilização de software desenvolvido pela SAP.
Para isso, organiza conferências, seminários, premiações e reuniões de grupos sobre temas específicos. Desses eventos, surgem dúvidas, necessidades, aplicações de software SAP e troca de experiência entre os associados.
A ASUG é o caminho mais seguro e rápido para os usuários agirem em conjunto, determinando prioridades e monitorando o desenvolvimento e o avanço tecnológico de aplicações SAP, por intermédio de requerimentos gerados nos Grupos de Pesquisa e Estudo e encaminhados à SAP Alemanha, para solução.
<h2>MISSÃO ASUG</h2>
"Agregar valor aos associados por meio da busca de soluções comuns, do compartilhamento do conhecimento e da representação dos interesses coletivos junto à SAP."

&nbsp;
<h2>PILARES DA ASUG</h2>
&nbsp;
<h2>PORTAL ASUG - www.asug.com.br</h2>
O meio mais fácil de associar a sua empresa. É um portal com páginas públicas e privativas dos associados ASUG Brasil, contendo os seguintes assuntos: Apresentação, banco de atas, banco de desenvolvimento, lista de associados, diretoria, grupos de estudo, sala de chat, eventos, etc. Está em constante atualização, acompanhando as necessidades e os desejos dos associados.', 'Institucional', '', 'inherit', 'closed', 'open', '', '6-revision-v1', '', '', '2014-06-04 16:34:39', '2014-06-04 16:34:39', '', '6', 'http://127.0.0.1/asug/6-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('447', '1', '2014-06-04 16:36:05', '2014-06-04 16:36:05', '', 'pilares', '', 'inherit', 'closed', 'open', '', 'pilares', '', '', '2014-06-04 16:36:05', '2014-06-04 16:36:05', '', '6', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/pilares.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('448', '1', '2014-06-04 16:37:50', '2014-06-04 16:37:50', '<iframe width="100%" height="400" src="//www.youtube.com/embed/9Bo9kf9BJrI" frameborder="0" allowfullscreen></iframe>
<h2>CONHEÇA A ASUG BRASIL</h2>
ASUG Brasil (Associação dos Usuários SAP do Brasil) é uma entidade sem fins lucrativos que reúne clientes da SAP e parceiros credenciados (fornecedores e consultores), a fim de inteirá-los sobre a utilização de software desenvolvido pela SAP. Para isso, organiza conferências, seminários, premiações e reuniões de grupos sobre temas específicos. Desses eventos, surgem dúvidas, necessidades, aplicações de software SAP e troca de experiência entre os associados. A ASUG é o caminho mais seguro e rápido para os usuários agirem em conjunto, determinando prioridades e monitorando o desenvolvimento e o avanço tecnológico de aplicações SAP, por intermédio de requerimentos gerados nos Grupos de Pesquisa e Estudo e encaminhados à SAP Alemanha, para solução.
<h2>MISSÃO ASUG</h2>
"Agregar valor aos associados por meio da busca de soluções comuns, do compartilhamento do conhecimento e da representação dos interesses coletivos junto à SAP."
<h2>PILARES DA ASUG</h2>
<img class="aligncenter size-full wp-image-447" src="http://127.0.0.1/asug/wp-content/uploads/2014/03/pilares.jpg" alt="pilares" width="560" height="400" />
<h2>PORTAL ASUG - www.asug.com.br</h2>
O meio mais fácil de associar a sua empresa. É um portal com páginas públicas e privativas dos associados ASUG Brasil, contendo os seguintes assuntos: Apresentação, banco de atas, banco de desenvolvimento, lista de associados, diretoria, grupos de estudo, sala de chat, eventos, etc. Está em constante atualização, acompanhando as necessidades e os desejos dos associados.', 'Institucional', '', 'inherit', 'closed', 'open', '', '6-revision-v1', '', '', '2014-06-04 16:37:50', '2014-06-04 16:37:50', '', '6', 'http://127.0.0.1/asug/6-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('449', '1', '2014-06-04 17:03:06', '2014-06-04 17:03:06', '<h2></h2>
<h2>ASUG Line: 0800-164064</h2>
&nbsp;

Endereço: Rua Azevedo Macedo 20 - 7° andar - Vila Mariana - São Paulo - SP - CEP: 04013-060
<iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3656.6579937281545!2d-46.64000320000003!3d-23.580723699999968!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59850e9f6baf%3A0x24d306c625eb54d9!2sRua+Azevedo+Macedo%2C+20+-+Vila+Mariana!5e0!3m2!1spt-BR!2sbr!4v1401901175988" width="100%" height="450" frameborder="0"></iframe>', 'Fale conosco', '', 'inherit', 'closed', 'open', '', '291-autosave-v1', '', '', '2014-06-04 17:03:06', '2014-06-04 17:03:06', '', '291', 'http://127.0.0.1/asug/291-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('450', '1', '2014-06-04 17:00:40', '2014-06-04 17:00:40', '<h2>ASUG Line: 0800-164064</h2>
&nbsp;

Endereço: Rua Azevedo Macedo 20 - 7° andar - Vila Mariana - São Paulo - SP - CEP: 04013-060
<iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3656.6579937281545!2d-46.64000320000003!3d-23.580723699999968!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59850e9f6baf%3A0x24d306c625eb54d9!2sRua+Azevedo+Macedo%2C+20+-+Vila+Mariana!5e0!3m2!1spt-BR!2sbr!4v1401901175988" width="100%" height="450" frameborder="0"></iframe>', 'Fale conosco', '', 'inherit', 'closed', 'open', '', '291-revision-v1', '', '', '2014-06-04 17:00:40', '2014-06-04 17:00:40', '', '291', 'http://127.0.0.1/asug/291-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('451', '1', '2014-06-04 17:03:12', '2014-06-04 17:03:12', '[contact-form-7 id="4" title="Formulário de contato 1"]
<h2>ASUG Line: 0800-164064</h2>
&nbsp;

Endereço: Rua Azevedo Macedo 20 - 7° andar - Vila Mariana - São Paulo - SP - CEP: 04013-060
<iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3656.6579937281545!2d-46.64000320000003!3d-23.580723699999968!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59850e9f6baf%3A0x24d306c625eb54d9!2sRua+Azevedo+Macedo%2C+20+-+Vila+Mariana!5e0!3m2!1spt-BR!2sbr!4v1401901175988" width="100%" height="450" frameborder="0"></iframe>', 'Fale conosco', '', 'inherit', 'closed', 'open', '', '291-revision-v1', '', '', '2014-06-04 17:03:12', '2014-06-04 17:03:12', '', '291', 'http://127.0.0.1/asug/291-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('452', '999999999', '2014-06-04 19:26:15', '2014-06-04 19:26:15', 'WP Backupware - 1401909974', 'WP Backupware - 1401909974', '', 'private', 'closed', 'open', '', 'wp-backupware-1401909974', '', '', '2014-06-04 19:26:15', '2014-06-04 19:26:15', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1401909974/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('453', '1', '2014-06-04 22:34:10', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'open', '', '', '', '', '2014-06-04 22:34:10', '0000-00-00 00:00:00', '', '0', 'http://127.0.0.1/asug/?p=453', '0', 'post', '', '0'); 
INSERT INTO `wp_posts` VALUES ('454', '999999999', '2014-06-05 21:12:28', '2014-06-05 21:12:28', 'WP Backupware - 1402002745', 'WP Backupware - 1402002745', '', 'private', 'closed', 'open', '', 'wp-backupware-1402002745', '', '', '2014-06-05 21:12:28', '2014-06-05 21:12:28', '', '0', 'http://127.0.0.1/asug/wpbu_backups/wp-backupware-1402002745/', '0', 'wpbu_backups', '', '0'); 
INSERT INTO `wp_posts` VALUES ('455', '1', '2014-06-06 12:39:35', '2014-06-06 12:39:35', 'http://issuu.com/asugnews/docs/2

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug news - Ed 02', '', 'inherit', 'closed', 'open', '', '226-revision-v1', '', '', '2014-06-06 12:39:35', '2014-06-06 12:39:35', '', '226', 'http://127.0.0.1/asug/226-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('457', '1', '2014-06-06 13:06:35', '2014-06-06 13:06:35', '[http://issuu.com/asugnews/docs/2]

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug news - Ed 02', '', 'inherit', 'closed', 'open', '', '226-revision-v1', '', '', '2014-06-06 13:06:35', '2014-06-06 13:06:35', '', '226', 'http://127.0.0.1/asug/226-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('458', '1', '2014-06-06 13:13:40', '2014-06-06 13:13:40', 'http://issuu.com/asugnews/docs/2

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug news - Ed 02', '', 'inherit', 'closed', 'open', '', '226-revision-v1', '', '', '2014-06-06 13:13:40', '2014-06-06 13:13:40', '', '226', 'http://127.0.0.1/asug/226-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('459', '1', '2014-06-06 14:10:48', '2014-06-06 14:10:48', '<iframe width="525" height="371" src="//e.issuu.com/embed.html#12211663/8129442" frameborder="0" allowfullscreen></iframe>

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug news - Ed 02', '', 'inherit', 'closed', 'open', '', '226-autosave-v1', '', '', '2014-06-06 14:10:48', '2014-06-06 14:10:48', '', '226', 'http://127.0.0.1/asug/226-autosave-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('460', '1', '2014-06-06 14:27:10', '2014-06-06 14:27:10', '<iframe width="525" height="371" src="//e.issuu.com/embed.html#12211663/8129442" frameborder="0" allowfullscreen></iframe>

<strong>Lorem ipsum</strong> dolor sit amet, consectetur adipiscing elit. Morbi scelerisque ut ligula id convallis. Suspendisse tempor mauris vulputate ipsum viverra pretium. Duis semper cursus posuere. Cras hendrerit consequat leo, sit amet rhoncus nulla condimentum ut. Aenean ut malesuada diam. Pellentesque pellentesque ante mollis, ornare purus eu, feugiat risus. Vivamus id libero dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec eget ante justo. Nam convallis lorem ac tempus tempor. In et dignissim libero. Proin tristique venenatis mi ut bibendum. Nam luctus, justo id convallis mollis, sem dui feugiat justo, ac vulputate ipsum turpis non eros. Nulla facilisi. Vestibulum diam neque, porttitor in arcu vitae, lacinia vulputate velit. Nullam aliquam tellus at bibendum consectetur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque et orci facilisis, egestas neque quis, euismod ante. Vivamus rutrum, sapien at vulputate molestie, sem justo dignissim ipsum, vitae lobortis urna orci vel odio. Quisque vitae luctus sapien. Suspendisse semper quis velit sit amet congue. Nullam vitae placerat est. Curabitur orci arcu, tristique et dignissim lacinia, iaculis vitae mauris. Proin eu felis id odio gravida congue et at nunc. Vestibulum eget sodales lectus. Morbi a tortor in nunc adipiscing blandit id et arcu. Nulla facilisi. Suspendisse aliquam luctus velit, nec pellentesque tellus condimentum quis. Mauris consectetur arcu ut auctor molestie. In aliquam nunc vitae mattis malesuada.', 'Asug news - Ed 02', '', 'inherit', 'closed', 'open', '', '226-revision-v1', '', '', '2014-06-06 14:27:10', '2014-06-06 14:27:10', '', '226', 'http://127.0.0.1/asug/226-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('461', '1', '2014-06-06 17:40:25', '2014-06-06 17:40:25', '', 'banner-conf', '', 'inherit', 'closed', 'open', '', 'banner-conf', '', '', '2014-06-06 17:40:25', '2014-06-06 17:40:25', '', '364', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/banner-conf.jpg', '0', 'attachment', 'image/jpeg', '0'); 
INSERT INTO `wp_posts` VALUES ('462', '1', '2014-06-06 17:40:36', '2014-06-06 17:40:36', 'Lorem <strong>ipsum</strong> dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, <em>consectetur</em> adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Lorem ipsum dolor sit amet consectetur <strong><span style="color: #ff0000;">adipisicing</span> </strong>elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-revision-v1', '', '', '2014-06-06 17:40:36', '2014-06-06 17:40:36', '', '364', 'http://127.0.0.1/asug/364-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('463', '1', '2014-06-06 17:55:30', '2014-06-06 17:55:30', 'A <strong>ASUG Brasil</strong> realizará no dia 19 de agosto de 2014 a 17ª CONFERÊNCIA ANUAL, no Hotel Transamérica São Paulo, um dos melhores e mais conceituados hotéis nacionais para esse tipo de evento. Este é o evento mais esperado do ano pelos associados da ASUG Brasil, por sua importância em trazer e atualizar todas as novidades do ano preparadas pela SAP mundial ao cenário nacional. Serão mais de 50 palestras simultâneas, do mais alto nível de informação sobre as diversidades do ecossistema SAP. Este evento proporcionará ainda momentos especiais de networking entre os parceiros e clientes SAP.

RESERVE SUA AGENDA!', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-revision-v1', '', '', '2014-06-06 17:55:30', '2014-06-06 17:55:30', '', '364', 'http://127.0.0.1/asug/364-revision-v1/', '0', 'revision', '', '0'); 
INSERT INTO `wp_posts` VALUES ('464', '1', '2014-06-06 18:01:41', '2014-06-06 18:01:41', '', 'bt-insc', '', 'inherit', 'closed', 'open', '', 'bt-insc', '', '', '2014-06-06 18:01:41', '2014-06-06 18:01:41', '', '364', 'http://127.0.0.1/asug/wp-content/uploads/2014/04/bt-insc.gif', '0', 'attachment', 'image/gif', '0'); 
INSERT INTO `wp_posts` VALUES ('465', '1', '2014-06-06 18:01:53', '2014-06-06 18:01:53', 'A <strong>ASUG Brasil</strong> realizará no dia 19 de agosto de 2014 a 17ª CONFERÊNCIA ANUAL, no Hotel Transamérica São Paulo, um dos melhores e mais conceituados hotéis nacionais para esse tipo de evento. Este é o evento mais esperado do ano pelos associados da ASUG Brasil, por sua importância em trazer e atualizar todas as novidades do ano preparadas pela SAP mundial ao cenário nacional. Serão mais de 50 palestras simultâneas, do mais alto nível de informação sobre as diversidades do ecossistema SAP. Este evento proporcionará ainda momentos especiais de networking entre os parceiros e clientes SAP.

RESERVE SUA AGENDA!', 'Coferência anual 2014', '', 'inherit', 'closed', 'open', '', '364-revision-v1', '', '', '2014-06-06 18:01:53', '2014-06-06 18:01:53', '', '364', 'http://127.0.0.1/asug/364-revision-v1/', '0', 'revision', '', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_term_relationships`
--
DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_term_relationships`
--
LOCK TABLES `wp_term_relationships` WRITE;
INSERT INTO `wp_term_relationships` VALUES ('1', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('1', '4', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('45', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('47', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('48', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('49', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('50', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('54', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('56', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('57', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('58', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('59', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('60', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('68', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('70', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('72', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('74', '3', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('76', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('90', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('90', '4', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('92', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('92', '4', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('94', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('94', '4', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('213', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('222', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('226', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('227', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('228', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('229', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('230', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('231', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('232', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('233', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('234', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('293', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('296', '2', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('309', '20', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('312', '20', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('313', '20', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('314', '20', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('364', '21', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('372', '21', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('373', '21', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('410', '19', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('411', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('421', '1', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('441', '24', '0'); 
INSERT INTO `wp_term_relationships` VALUES ('444', '2', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_term_taxonomy`
--
DROP TABLE IF EXISTS `wp_term_taxonomy`;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_term_taxonomy`
--
LOCK TABLES `wp_term_taxonomy` WRITE;
INSERT INTO `wp_term_taxonomy` VALUES ('1', '1', 'category', 'Destaque em eventos no qual terá relevância na homepage', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('2', '2', 'nav_menu', '', '0', '14'); 
INSERT INTO `wp_term_taxonomy` VALUES ('3', '3', 'dfads_group', 'Banners Home', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('4', '4', 'category', '', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('5', '5', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('6', '6', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('7', '7', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('8', '8', 'product_type', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('9', '9', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('10', '10', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('11', '11', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('12', '12', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('13', '13', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('14', '14', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('15', '15', 'shop_order_status', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('18', '18', 'post_format', '', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('19', '19', 'category', '', '0', '11'); 
INSERT INTO `wp_term_taxonomy` VALUES ('20', '20', 'category', 'Destaque de notícia, no qual ganhará relevância na homepage', '0', '4'); 
INSERT INTO `wp_term_taxonomy` VALUES ('21', '21', 'category', 'Conferência anual', '0', '3'); 
INSERT INTO `wp_term_taxonomy` VALUES ('22', '22', 'category', 'Impact Awards', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('23', '23', 'category', 'Asug Day', '0', '0'); 
INSERT INTO `wp_term_taxonomy` VALUES ('24', '24', 'dfads_group', 'Banner destaque na home', '0', '1'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_terms`
--
DROP TABLE IF EXISTS `wp_terms`;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_terms`
--
LOCK TABLES `wp_terms` WRITE;
INSERT INTO `wp_terms` VALUES ('1', 'Destaque Eventos', 'destaque-eventos', '0'); 
INSERT INTO `wp_terms` VALUES ('2', 'Topo', 'topo', '0'); 
INSERT INTO `wp_terms` VALUES ('3', 'Banners Home', 'banners-home', '0'); 
INSERT INTO `wp_terms` VALUES ('4', 'Eventos', 'eventos', '0'); 
INSERT INTO `wp_terms` VALUES ('5', 'simple', 'simple', '0'); 
INSERT INTO `wp_terms` VALUES ('6', 'grouped', 'grouped', '0'); 
INSERT INTO `wp_terms` VALUES ('7', 'variable', 'variable', '0'); 
INSERT INTO `wp_terms` VALUES ('8', 'external', 'external', '0'); 
INSERT INTO `wp_terms` VALUES ('9', 'pending', 'pending', '0'); 
INSERT INTO `wp_terms` VALUES ('10', 'failed', 'failed', '0'); 
INSERT INTO `wp_terms` VALUES ('11', 'on-hold', 'on-hold', '0'); 
INSERT INTO `wp_terms` VALUES ('12', 'processing', 'processing', '0'); 
INSERT INTO `wp_terms` VALUES ('13', 'completed', 'completed', '0'); 
INSERT INTO `wp_terms` VALUES ('14', 'refunded', 'refunded', '0'); 
INSERT INTO `wp_terms` VALUES ('15', 'cancelled', 'cancelled', '0'); 
INSERT INTO `wp_terms` VALUES ('18', 'post-format-status', 'post-format-status', '0'); 
INSERT INTO `wp_terms` VALUES ('19', 'Revista', 'revista', '0'); 
INSERT INTO `wp_terms` VALUES ('20', 'Notícia destaque', 'post-destaque', '0'); 
INSERT INTO `wp_terms` VALUES ('21', 'Conferência anual', 'conferencia-anual', '0'); 
INSERT INTO `wp_terms` VALUES ('22', 'Impact Awards', 'impact-awards', '0'); 
INSERT INTO `wp_terms` VALUES ('23', 'Asug Day', 'asug-day', '0'); 
INSERT INTO `wp_terms` VALUES ('24', 'Banner Destaque', 'banner-destaque', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_user_status_manager`
--
DROP TABLE IF EXISTS `wp_user_status_manager`;
CREATE TABLE `wp_user_status_manager` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `user_id` mediumint(9) NOT NULL,
  `user_name` text NOT NULL,
  `user_email` text NOT NULL,
  `status_from` text NOT NULL,
  `status_to` text NOT NULL,
  `status` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_user_status_manager`
--
LOCK TABLES `wp_user_status_manager` WRITE;
INSERT INTO `wp_user_status_manager` VALUES ('1', '4', 'pita', 'spynomak@hotmail.com', '', '', '1'); 
INSERT INTO `wp_user_status_manager` VALUES ('2', '5', 'felipe', 'felipe@montarsite.com.br', '', '', '0'); 
INSERT INTO `wp_user_status_manager` VALUES ('3', '6', 'suporte', 'suporte@montarsite.com.br', '', '', '1'); 
INSERT INTO `wp_user_status_manager` VALUES ('4', '7', 'marco', 'marco@montarsite.com.br', '25/02/2014', '25/02/2015', '1'); 
INSERT INTO `wp_user_status_manager` VALUES ('5', '8', 'jim', 'jim@montarsite.com.br', '', '', '0'); 
INSERT INTO `wp_user_status_manager` VALUES ('6', '9', 'teste1', 'teste@montarsite.com.br', '', '', '0'); 
INSERT INTO `wp_user_status_manager` VALUES ('7', '10', 'teste2', 'teste2@ms.com.br', '', '', '0'); 
INSERT INTO `wp_user_status_manager` VALUES ('8', '11', 'teste3', 'teste3@ms.com.br', '2014/03/23', '2015/03/23', '0'); 
INSERT INTO `wp_user_status_manager` VALUES ('9', '1', 'contato@montarsite.com.br', 'contato@montarsite.com.br', '', '', '0'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_usermeta`
--
DROP TABLE IF EXISTS `wp_usermeta`;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_usermeta`
--
LOCK TABLES `wp_usermeta` WRITE;
INSERT INTO `wp_usermeta` VALUES ('1', '1', 'first_name', 'Nome'); 
INSERT INTO `wp_usermeta` VALUES ('2', '1', 'last_name', 'Sobrenome'); 
INSERT INTO `wp_usermeta` VALUES ('3', '1', 'nickname', 'adminasugms'); 
INSERT INTO `wp_usermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('10', '1', 'wp_capabilities', 'a:14:{s:13:"administrator";b:1;s:15:"membershipadmin";b:1;s:24:"membershipadmindashboard";b:1;s:22:"membershipadminmembers";b:1;s:21:"membershipadminlevels";b:1;s:28:"membershipadminsubscriptions";b:1;s:22:"membershipadmincoupons";b:1;s:24:"membershipadminpurchases";b:1;s:29:"membershipadmincommunications";b:1;s:21:"membershipadmingroups";b:1;s:20:"membershipadminpings";b:1;s:23:"membershipadmingateways";b:1;s:22:"membershipadminoptions";b:1;s:32:"membershipadminupdatepermissions";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('11', '1', 'wp_user_level', '10'); 
INSERT INTO `wp_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks,wp390_widgets'); 
INSERT INTO `wp_usermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `wp_usermeta` VALUES ('14', '1', 'wp_dashboard_quick_press_last_post_id', '403'); 
INSERT INTO `wp_usermeta` VALUES ('15', '1', 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'); 
INSERT INTO `wp_usermeta` VALUES ('16', '1', 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'); 
INSERT INTO `wp_usermeta` VALUES ('17', '1', 'wp_user-settings', 'imgsize=full&libraryContent=browse&urlbutton=none&editor=tinymce&hidetb=1&wplink=1&align=center'); 
INSERT INTO `wp_usermeta` VALUES ('18', '1', 'wp_user-settings-time', '1402077332'); 
INSERT INTO `wp_usermeta` VALUES ('19', '1', 'nav_menu_recently_edited', '2'); 
INSERT INTO `wp_usermeta` VALUES ('20', '1', 'manageedit-eventcolumnshidden', 'a:1:{i:0;s:8:"event-id";}'); 
INSERT INTO `wp_usermeta` VALUES ('21', '1', 'membership_permissions_updated', 'yes'); 
INSERT INTO `wp_usermeta` VALUES ('49', '4', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('50', '4', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('51', '4', 'nickname', 'pitaaa'); 
INSERT INTO `wp_usermeta` VALUES ('52', '4', 'description', 'teste'); 
INSERT INTO `wp_usermeta` VALUES ('53', '4', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('54', '4', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('55', '4', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('56', '4', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('57', '4', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('58', '4', 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('59', '4', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('60', '4', 'default_password_nag', ''); 
INSERT INTO `wp_usermeta` VALUES ('61', '4', 'billing_first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('62', '4', 'billing_last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('63', '4', 'billing_company', ''); 
INSERT INTO `wp_usermeta` VALUES ('64', '4', 'billing_address_1', ''); 
INSERT INTO `wp_usermeta` VALUES ('65', '4', 'billing_address_2', ''); 
INSERT INTO `wp_usermeta` VALUES ('66', '4', 'billing_city', ''); 
INSERT INTO `wp_usermeta` VALUES ('67', '4', 'billing_postcode', ''); 
INSERT INTO `wp_usermeta` VALUES ('68', '4', 'billing_state', ''); 
INSERT INTO `wp_usermeta` VALUES ('69', '4', 'billing_country', ''); 
INSERT INTO `wp_usermeta` VALUES ('70', '4', 'billing_phone', ''); 
INSERT INTO `wp_usermeta` VALUES ('71', '4', 'billing_email', ''); 
INSERT INTO `wp_usermeta` VALUES ('72', '4', 'shipping_first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('73', '4', 'shipping_last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('74', '4', 'shipping_company', ''); 
INSERT INTO `wp_usermeta` VALUES ('75', '4', 'shipping_address_1', ''); 
INSERT INTO `wp_usermeta` VALUES ('76', '4', 'shipping_address_2', ''); 
INSERT INTO `wp_usermeta` VALUES ('77', '4', 'shipping_city', ''); 
INSERT INTO `wp_usermeta` VALUES ('78', '4', 'shipping_postcode', ''); 
INSERT INTO `wp_usermeta` VALUES ('79', '4', 'shipping_state', ''); 
INSERT INTO `wp_usermeta` VALUES ('80', '4', 'shipping_country', ''); 
INSERT INTO `wp_usermeta` VALUES ('81', '4', 'dbem_phone', ''); 
INSERT INTO `wp_usermeta` VALUES ('82', '4', 'manageedit-eventcolumnshidden', 'a:1:{i:0;s:8:"event-id";}'); 
INSERT INTO `wp_usermeta` VALUES ('85', '4', 'display_boleto', 'a:3:{s:4:"file";s:84:"C:xampphtdocsasug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_201403.pdf";s:3:"url";s:88:"http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_201403.pdf";s:4:"type";s:15:"application/pdf";}'); 
INSERT INTO `wp_usermeta` VALUES ('87', '4', 'simple_local_avatar', 'a:4:{s:8:"media_id";i:123;s:4:"full";s:60:"http://127.0.0.1/asug/wp-content/uploads/2014/03/banner1.jpg";i:96;s:66:"http://127.0.0.1/asug/wp-content/uploads/2014/03/banner1-96x96.jpg";i:32;s:66:"http://127.0.0.1/asug/wp-content/uploads/2014/03/banner1-32x32.jpg";}'); 
INSERT INTO `wp_usermeta` VALUES ('88', '4', 'simple_local_avatar_rating', 'G'); 
INSERT INTO `wp_usermeta` VALUES ('90', '4', 'user_meta_image', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/wireframe-interna-ASUG.pdf'); 
INSERT INTO `wp_usermeta` VALUES ('91', '5', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('92', '5', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('93', '5', 'nickname', 'felipe'); 
INSERT INTO `wp_usermeta` VALUES ('94', '5', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('95', '5', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('96', '5', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('97', '5', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('98', '5', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('99', '5', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('100', '5', 'wp_capabilities', 'a:1:{s:13:"representante";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('101', '5', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('102', '5', 'default_password_nag', ''); 
INSERT INTO `wp_usermeta` VALUES ('103', '6', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('104', '6', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('105', '6', 'nickname', 'suporte'); 
INSERT INTO `wp_usermeta` VALUES ('106', '6', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('107', '6', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('108', '6', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('109', '6', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('110', '6', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('111', '6', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('112', '6', 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('113', '6', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('114', '6', 'default_password_nag', '1'); 
INSERT INTO `wp_usermeta` VALUES ('115', '7', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('116', '7', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('117', '7', 'nickname', 'marco'); 
INSERT INTO `wp_usermeta` VALUES ('118', '7', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('119', '7', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('120', '7', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('121', '7', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('122', '7', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('123', '7', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('124', '7', 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('125', '7', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('126', '7', 'default_password_nag', '1'); 
INSERT INTO `wp_usermeta` VALUES ('127', '8', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('128', '8', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('129', '8', 'nickname', 'jim'); 
INSERT INTO `wp_usermeta` VALUES ('130', '8', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('131', '8', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('132', '8', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('133', '8', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('134', '8', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('135', '8', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('136', '8', 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('137', '8', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('138', '8', 'default_password_nag', '1'); 
INSERT INTO `wp_usermeta` VALUES ('139', '9', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('140', '9', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('141', '9', 'nickname', 'teste1'); 
INSERT INTO `wp_usermeta` VALUES ('142', '9', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('143', '9', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('144', '9', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('145', '9', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('146', '9', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('147', '9', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('148', '9', 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('149', '9', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('150', '9', 'default_password_nag', '1'); 
INSERT INTO `wp_usermeta` VALUES ('151', '10', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('152', '10', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('153', '10', 'nickname', 'teste2'); 
INSERT INTO `wp_usermeta` VALUES ('154', '10', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('155', '10', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('156', '10', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('157', '10', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('158', '10', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('159', '10', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('160', '10', 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('161', '10', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('162', '10', 'default_password_nag', '1'); 
INSERT INTO `wp_usermeta` VALUES ('163', '11', 'first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('164', '11', 'last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('165', '11', 'nickname', 'teste3'); 
INSERT INTO `wp_usermeta` VALUES ('166', '11', 'description', ''); 
INSERT INTO `wp_usermeta` VALUES ('167', '11', 'rich_editing', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('168', '11', 'comment_shortcuts', 'false'); 
INSERT INTO `wp_usermeta` VALUES ('169', '11', 'admin_color', 'fresh'); 
INSERT INTO `wp_usermeta` VALUES ('170', '11', 'use_ssl', '0'); 
INSERT INTO `wp_usermeta` VALUES ('171', '11', 'show_admin_bar_front', 'true'); 
INSERT INTO `wp_usermeta` VALUES ('172', '11', 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}'); 
INSERT INTO `wp_usermeta` VALUES ('173', '11', 'wp_user_level', '0'); 
INSERT INTO `wp_usermeta` VALUES ('174', '11', 'default_password_nag', '1'); 
INSERT INTO `wp_usermeta` VALUES ('176', '5', 'billing_first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('177', '5', 'billing_last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('178', '5', 'billing_company', ''); 
INSERT INTO `wp_usermeta` VALUES ('179', '5', 'billing_address_1', ''); 
INSERT INTO `wp_usermeta` VALUES ('180', '5', 'billing_address_2', ''); 
INSERT INTO `wp_usermeta` VALUES ('181', '5', 'billing_city', ''); 
INSERT INTO `wp_usermeta` VALUES ('182', '5', 'billing_postcode', ''); 
INSERT INTO `wp_usermeta` VALUES ('183', '5', 'billing_state', ''); 
INSERT INTO `wp_usermeta` VALUES ('184', '5', 'billing_country', ''); 
INSERT INTO `wp_usermeta` VALUES ('185', '5', 'billing_phone', ''); 
INSERT INTO `wp_usermeta` VALUES ('186', '5', 'billing_email', ''); 
INSERT INTO `wp_usermeta` VALUES ('187', '5', 'shipping_first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('188', '5', 'shipping_last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('189', '5', 'shipping_company', ''); 
INSERT INTO `wp_usermeta` VALUES ('190', '5', 'shipping_address_1', ''); 
INSERT INTO `wp_usermeta` VALUES ('191', '5', 'shipping_address_2', ''); 
INSERT INTO `wp_usermeta` VALUES ('192', '5', 'shipping_city', ''); 
INSERT INTO `wp_usermeta` VALUES ('193', '5', 'shipping_postcode', ''); 
INSERT INTO `wp_usermeta` VALUES ('194', '5', 'shipping_state', ''); 
INSERT INTO `wp_usermeta` VALUES ('195', '5', 'shipping_country', ''); 
INSERT INTO `wp_usermeta` VALUES ('196', '5', 'dbem_phone', ''); 
INSERT INTO `wp_usermeta` VALUES ('197', '6', 'user_meta_image', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014036.pdf'); 
INSERT INTO `wp_usermeta` VALUES ('198', '6', 'billing_first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('199', '6', 'billing_last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('200', '6', 'billing_company', ''); 
INSERT INTO `wp_usermeta` VALUES ('201', '6', 'billing_address_1', ''); 
INSERT INTO `wp_usermeta` VALUES ('202', '6', 'billing_address_2', ''); 
INSERT INTO `wp_usermeta` VALUES ('203', '6', 'billing_city', ''); 
INSERT INTO `wp_usermeta` VALUES ('204', '6', 'billing_postcode', ''); 
INSERT INTO `wp_usermeta` VALUES ('205', '6', 'billing_state', ''); 
INSERT INTO `wp_usermeta` VALUES ('206', '6', 'billing_country', ''); 
INSERT INTO `wp_usermeta` VALUES ('207', '6', 'billing_phone', ''); 
INSERT INTO `wp_usermeta` VALUES ('208', '6', 'billing_email', ''); 
INSERT INTO `wp_usermeta` VALUES ('209', '6', 'shipping_first_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('210', '6', 'shipping_last_name', ''); 
INSERT INTO `wp_usermeta` VALUES ('211', '6', 'shipping_company', ''); 
INSERT INTO `wp_usermeta` VALUES ('212', '6', 'shipping_address_1', ''); 
INSERT INTO `wp_usermeta` VALUES ('213', '6', 'shipping_address_2', ''); 
INSERT INTO `wp_usermeta` VALUES ('214', '6', 'shipping_city', ''); 
INSERT INTO `wp_usermeta` VALUES ('215', '6', 'shipping_postcode', ''); 
INSERT INTO `wp_usermeta` VALUES ('216', '6', 'shipping_state', ''); 
INSERT INTO `wp_usermeta` VALUES ('217', '6', 'shipping_country', ''); 
INSERT INTO `wp_usermeta` VALUES ('218', '6', 'dbem_phone', ''); 
INSERT INTO `wp_usermeta` VALUES ('219', '5', 'dismissed_wp_pointers', 'wp330_toolbar'); 
INSERT INTO `wp_usermeta` VALUES ('220', '5', 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:51:"dashboard_representante_inativos,dashboard_activity";s:4:"side";s:30:"dashboard_representante_ativos";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'); 
INSERT INTO `wp_usermeta` VALUES ('221', '5', 'closedpostboxes_dashboard', 'a:1:{i:0;s:18:"dashboard_activity";}'); 
INSERT INTO `wp_usermeta` VALUES ('222', '5', 'metaboxhidden_dashboard', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('223', '1', 'closedpostboxes_page', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('224', '1', 'metaboxhidden_page', 'a:5:{i:0;s:20:"tgm-new-media-plugin";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'); 
INSERT INTO `wp_usermeta` VALUES ('225', '1', 'closedpostboxes_post', 'a:0:{}'); 
INSERT INTO `wp_usermeta` VALUES ('226', '1', 'metaboxhidden_post', 'a:7:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";i:6;s:7:"acf_202";}'); 
INSERT INTO `wp_usermeta` VALUES ('227', '1', 'total_time', '23278643'); 
INSERT INTO `wp_usermeta` VALUES ('228', '1', 'logged_in_amount', '2'); 
INSERT INTO `wp_usermeta` VALUES ('229', '1', 'average_time', '11639321.5'); 
INSERT INTO `wp_usermeta` VALUES ('230', '5', 'start_time', '1396718730'); 
INSERT INTO `wp_usermeta` VALUES ('231', '5', 'wp_user-settings', 'mfold=o'); 
INSERT INTO `wp_usermeta` VALUES ('232', '5', 'wp_user-settings-time', '1396723062'); 
INSERT INTO `wp_usermeta` VALUES ('233', '5', 'user_meta_image', 'http://127.0.0.1/asug/wp-content/uploads/2014/03/sua_fatura_de_energia_mesref_2014034.pdf'); 
INSERT INTO `wp_usermeta` VALUES ('234', '1', 'start_time', '1402058307'); 
INSERT INTO `wp_usermeta` VALUES ('235', '5', 'simple_local_avatar', 'a:4:{s:8:"media_id";i:214;s:4:"full";s:83:"http://127.0.0.1/asug/wp-content/uploads/2014/03/capa-revista-hsm-management-01.jpg";i:96;s:89:"http://127.0.0.1/asug/wp-content/uploads/2014/03/capa-revista-hsm-management-01-96x96.jpg";i:32;s:89:"http://127.0.0.1/asug/wp-content/uploads/2014/03/capa-revista-hsm-management-01-32x32.jpg";}'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_users`
--
DROP TABLE IF EXISTS `wp_users`;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_boleto` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_users`
--
LOCK TABLES `wp_users` WRITE;
INSERT INTO `wp_users` VALUES ('1', 'adminasugms', '$P$BoPNw4CMc/GAVk1olJyhHsV/qSVDiz/', 'adminasugms', '', 'contato@montarsite.com.br', '', '2014-03-15 15:51:25', '', '0', 'adminasugms'); 
INSERT INTO `wp_users` VALUES ('4', 'pita', '$P$BRqbQvJhgJUx754bqXeru4BtiQSPhO1', 'pita', '', 'spynomak@hotmail.com', '', '2014-03-20 02:57:27', '', '0', 'pita'); 
INSERT INTO `wp_users` VALUES ('5', 'felipe', '$P$BtFWvQW7iPbKUJxbRvsSiCdXVlOmTf0', 'felipe', '', 'felipe@montarsite.com.br', '', '2014-03-23 17:41:05', '', '0', 'felipe'); 
INSERT INTO `wp_users` VALUES ('6', 'suporte', '$P$BwsTYDMxv/iiPSC5Il.DX0rbbpPJpb/', 'suporte', '', 'suporte@montarsite.com.br', '', '2014-03-23 17:54:37', '', '0', 'suporte'); 
INSERT INTO `wp_users` VALUES ('7', 'marco', '$P$BS0264WoA0tsZWx/AouN/gG/hikSOc0', 'marco', '', 'marco@montarsite.com.br', '', '2014-03-23 17:55:33', '', '0', 'marco'); 
INSERT INTO `wp_users` VALUES ('8', 'jim', '$P$B8uOsZKjqoicEVxTk8aUrbdDv8sfVg1', 'jim', '', 'jim@montarsite.com.br', '', '2014-03-23 17:56:10', '', '0', 'jim'); 
INSERT INTO `wp_users` VALUES ('9', 'teste1', '$P$BDdIg/Bi06u5lydRqeXHoZP9m2lwOy/', 'teste1', '', 'teste@montarsite.com.br', '', '2014-03-23 17:56:58', '', '0', 'teste1'); 
INSERT INTO `wp_users` VALUES ('10', 'teste2', '$P$ByUYRpvdhAISTilyvhCBX4Ph2Zs.4k0', 'teste2', '', 'teste2@ms.com.br', '', '2014-03-23 17:57:41', '', '0', 'teste2'); 
INSERT INTO `wp_users` VALUES ('11', 'teste3', '$P$BwgS64xl6h7M8AmR32fnGv4jSvz5ka1', 'teste3', '', 'teste3@ms.com.br', '', '2014-03-23 18:00:05', '', '0', 'teste3'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_usm_post_message`
--
DROP TABLE IF EXISTS `wp_usm_post_message`;
CREATE TABLE `wp_usm_post_message` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `post_message` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
--
-- Dumping data for table `wp_usm_post_message`
--
LOCK TABLES `wp_usm_post_message` WRITE;
INSERT INTO `wp_usm_post_message` VALUES ('1', 'Ops'); 

UNLOCK TABLES;
--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--
DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;
CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_woocommerce_order_itemmeta`
--
LOCK TABLES `wp_woocommerce_order_itemmeta` WRITE;
UNLOCK TABLES;
--
-- Table structure for table `wp_woocommerce_order_items`
--
DROP TABLE IF EXISTS `wp_woocommerce_order_items`;
CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext NOT NULL,
  `order_item_type` varchar(200) NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Dumping data for table `wp_woocommerce_order_items`
--
LOCK TABLES `wp_woocommerce_order_items` WRITE;
UNLOCK TABLES;
